/**
 * CFLYHL · 精简版 2.1.7
 * 仅保留：登录、使用量、网络信息、设置(密码)、操作日志、关于、默认清空 KV
 */
const LOG_KEY = "cfapex_op_logs";
const PASS_KEY = "cfapex_panel_pass";
const CFAPEX_USAGE_CREDS_KEY = "cfapex_usage_creds";

function json(obj, status = 200) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" }
  });
}

async function getPass(env) {
  try {
    const kv = env && (env.K || env.KV || env.KV_NAMESPACE);
    if (!kv) return "";
    return (await kv.get(PASS_KEY)) || "";
  } catch {
    return "";
  }
}

async function hashPass(p) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode("cfapex:" + String(p)));
  return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

function readSid(req) {
  const m = (req.headers.get("Cookie") || "").match(/(?:^|;\s*)cfapex_sid=([^;]*)/);
  return m ? decodeURIComponent(m[1].trim()) : "";
}

async function isAuthed(req, pass) {
  if (!pass) return true;
  const sid = readSid(req);
  return !!(sid && sid === (await hashPass(pass)));
}

function cookie(sid, maxAge = 604800) {
  return `cfapex_sid=${encodeURIComponent(sid)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAge}`;
}

function getKV(env) {
  return env && (env.K || env.KV || env.KV_NAMESPACE);
}

async function appendOpLog(request, env, type, detail) {
  try {
    const kv = getKV(env);
    if (!kv) return;
    let arr = [];
    try { arr = JSON.parse((await kv.get(LOG_KEY)) || "[]"); } catch { arr = []; }
    if (!Array.isArray(arr)) arr = [];
    arr.unshift({
      t: Date.now(), type: type || "操作", detail: detail || "",
      IP: request.headers.get("CF-Connecting-IP") || "",
      CC: request.cf ? `${request.cf.country || ""} ${request.cf.city || ""}`.trim() : "",
      ASN: request.cf ? `AS${request.cf.asn || ""} ${request.cf.asOrganization || ""}`.trim() : "",
      URL: request.url, UA: request.headers.get("User-Agent") || ""
    });
    while (arr.length > 300) arr.pop();
    await kv.put(LOG_KEY, JSON.stringify(arr));
  } catch (e) { console.error("appendOpLog", e); }
}

async function getCloudflareUsage(Email, GlobalAPIKey, AccountID, APIToken) {
  const API = "https://api.cloudflare.com/client/v4";
  const sum = (a) => a?.reduce((t, i) => t + (i?.sum?.requests || 0), 0) || 0;
  const cfg = { "Content-Type": "application/json" };
  try {
    if (!AccountID && (!Email || !GlobalAPIKey)) {
      return { success: false, pages: 0, workers: 0, total: 0, max: 100000, msg: "缺少 AccountID 或 Email+GlobalAPIKey" };
    }
    if (!AccountID) {
      const r = await fetch(`${API}/accounts`, { method: "GET", headers: { ...cfg, "X-AUTH-EMAIL": Email, "X-AUTH-KEY": GlobalAPIKey } });
      if (!r.ok) throw new Error(`账户获取失败: ${r.status}`);
      const d = await r.json();
      if (!d?.result?.length) throw new Error("未找到账户");
      const idx = d.result.findIndex((a) => a.name?.toLowerCase().startsWith(Email.toLowerCase()));
      AccountID = d.result[idx >= 0 ? idx : 0]?.id;
    }
    const now = new Date();
    now.setUTCHours(0, 0, 0, 0);
    const hdr = APIToken ? { ...cfg, Authorization: `Bearer ${APIToken}` } : { ...cfg, "X-AUTH-EMAIL": Email, "X-AUTH-KEY": GlobalAPIKey };
    const res = await fetch(`${API}/graphql`, {
      method: "POST", headers: hdr,
      body: JSON.stringify({
        query: `query getBillingMetrics($AccountID: String!, $filter: AccountWorkersInvocationsAdaptiveFilter_InputObject) {
          viewer { accounts(filter: {accountTag: $AccountID}) {
            pagesFunctionsInvocationsAdaptiveGroups(limit: 1000, filter: $filter) { sum { requests } }
            workersInvocationsAdaptive(limit: 10000, filter: $filter) { sum { requests } }
          } }
        }`,
        variables: { AccountID, filter: { datetime_geq: now.toISOString(), datetime_leq: new Date().toISOString() } }
      })
    });
    if (!res.ok) throw new Error(`查询失败: ${res.status}`);
    const result = await res.json();
    if (result.errors?.length) throw new Error(result.errors[0].message);
    const acc = result?.data?.viewer?.accounts?.[0];
    if (!acc) throw new Error("未找到账户数据");
    const pages = sum(acc.pagesFunctionsInvocationsAdaptiveGroups);
    const workers = sum(acc.workersInvocationsAdaptive);
    const total = pages + workers;
    const max = 100000;
    const remaining = Math.max(0, max - total);
    const percent = Math.min(100, Math.round((total / max) * 10000) / 100);
    const resetAt = new Date(now); resetAt.setUTCDate(resetAt.getUTCDate() + 1);
    const msLeft = resetAt - Date.now();
    const hLeft = Math.max(0, Math.floor(msLeft / 3600000));
    const mLeft = Math.max(0, Math.floor((msLeft % 3600000) / 60000));
    const sLeft = Math.max(0, Math.floor((msLeft % 60000) / 1000));
    return { success: true, pages, workers, total, max, remaining, percent, resetIn: { h: hLeft, m: mLeft, s: sLeft }, resetText: `距离重置还有 ${hLeft} 小时 ${mLeft} 分 ${sLeft} 秒` };
  } catch (error) {
    return { success: false, pages: 0, workers: 0, total: 0, max: 100000, msg: error.message };
  }
}

async function loadUsageCreds(env) {
  const fromEnv = { Email: (env && env.CF_EMAIL) || "", GlobalAPIKey: (env && env.CF_GLOBAL_API_KEY) || "", AccountID: (env && env.CF_ACCOUNT_ID) || "", APIToken: (env && env.CF_API_TOKEN) || "" };
  try {
    const kv = getKV(env);
    if (kv && typeof kv.get === "function") {
      const raw = await kv.get(CFAPEX_USAGE_CREDS_KEY);
      if (raw) {
        const saved = JSON.parse(raw);
        return { Email: saved.Email || fromEnv.Email || "", GlobalAPIKey: saved.GlobalAPIKey || fromEnv.GlobalAPIKey || "", AccountID: saved.AccountID || fromEnv.AccountID || "", APIToken: saved.APIToken || fromEnv.APIToken || "", source: "kv" };
      }
    }
  } catch {}
  const has = fromEnv.AccountID || fromEnv.APIToken || fromEnv.Email;
  return { ...fromEnv, source: has ? "env" : "none" };
}

async function saveUsageCreds(env, creds) {
  const kv = getKV(env);
  if (!kv || typeof kv.put !== "function") return { ok: false, msg: "未绑定 KV（变量名需为 K）" };
  await kv.put(CFAPEX_USAGE_CREDS_KEY, JSON.stringify({ Email: creds.Email || "", GlobalAPIKey: creds.GlobalAPIKey || "", AccountID: creds.AccountID || "", APIToken: creds.APIToken || "" }));
  return { ok: true, msg: "已保存到 KV" };
}

async function clearUsageCreds(env) {
  const kv = getKV(env);
  if (!kv || typeof kv.delete !== "function") return { ok: false, msg: "未绑定 KV" };
  await kv.delete(CFAPEX_USAGE_CREDS_KEY);
  return { ok: true, msg: "已清除" };
}

function esc(s) {
  return String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

function loginPage(err) {
  const msg = err ? `<div class="err">${esc(err)}</div>` : "";
  return `<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>登录 · CFLYHL</title>
<style>*{box-sizing:border-box}body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;font-family:system-ui,sans-serif;background:#151a2d;color:#edf0fc}
.card{width:min(400px,92vw);background:#222940;border:1px solid #39415e;border-radius:16px;padding:28px 24px}
h1{margin:0 0 8px;font-size:22px;text-align:center}.sub{text-align:center;color:#a4adc8;font-size:13px;margin-bottom:20px}
label{display:block;font-size:13px;color:#a4adc8;margin:12px 0 6px}
input{width:100%;padding:12px 14px;border-radius:10px;border:1px solid #39415e;background:#1b2237;color:#edf0fc;font-size:15px}
button{width:100%;margin-top:18px;padding:12px;border:0;border-radius:999px;font-size:15px;font-weight:700;cursor:pointer;background:linear-gradient(90deg,#ff0000,#ff7f00,#ffff00,#00ff00,#00bfff,#8b00ff,#ff1493);color:#111}
.err{background:#3c1f28;color:#f3a1a6;border:1px solid #6b3340;border-radius:8px;padding:10px 12px;margin-bottom:12px;font-size:13px}</style></head>
<body><form class="card" method="POST" action="/login"><h1>CFLYHL</h1><div class="sub">面板登录</div>${msg}
<label for="password">密码</label><input id="password" name="password" type="password" autocomplete="current-password" required autofocus>
<button type="submit">登录</button></form></body></html>`;
}

function renderUsagePage(data, query, saved, notice) {
  const hasSaved = saved && (saved.AccountID || saved.APIToken || saved.Email || saved.GlobalAPIKey);
  const sourceLabel = saved?.source === "kv" ? "已保存（KV）" : saved?.source === "env" ? "环境变量" : "未配置";
  const email = query.get("Email") || (hasSaved ? saved.Email : "") || "";
  const acc = query.get("AccountID") || (hasSaved ? saved.AccountID : "") || "";
  const noticeHtml = notice ? `<div class="notice">${esc(notice.msg || "")}</div>` : "";
  return `<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>使用量 · CFLYHL</title>
<style>body{font-family:system-ui,sans-serif;background:#151a2d;color:#edf0fc;padding:24px;max-width:560px;margin:0 auto}
.card{background:#222940;border:1px solid #39415e;border-radius:12px;padding:20px}label{display:block;margin:10px 0 4px;font-size:13px;color:#a4adc8}
input{width:100%;padding:10px;border-radius:8px;border:1px solid #39415e;background:#1b2237;color:#edf0fc;box-sizing:border-box}
button{margin-top:14px;padding:10px 18px;border:0;border-radius:8px;background:#3d55bd;color:#fff;font-weight:600;cursor:pointer}
.notice{background:#1e3a2f;color:#77c8ab;padding:10px;border-radius:8px;margin-bottom:12px}a{color:#9dacff}.stat{font-size:28px;font-weight:800;margin:8px 0}</style></head><body>
<div class="card"><h2>Workers/Pages 使用量</h2><div>来源：${esc(sourceLabel)}</div>
${data.success ? `<div class="stat">${data.total.toLocaleString()} / ${data.max.toLocaleString()}</div><div>Workers ${data.workers} · Pages ${data.pages} · 剩余 ${data.remaining}</div><div style="margin-top:8px;color:#a4adc8">${esc(data.resetText || "")}</div>` : `<div style="color:#f3a1a6">${esc(data.msg || "查询失败")}</div>`}
${noticeHtml}<form method="POST" action="/usage"><input type="hidden" name="action" value="save">
<label>Account ID</label><input name="AccountID" value="${esc(acc)}" autocomplete="off">
<label>API Token</label><input name="APIToken" type="password" value="" placeholder="${hasSaved && saved.APIToken ? "已保存，留空保持不变" : "Bearer Token"}" autocomplete="off">
<label>Email（可选）</label><input name="Email" value="${esc(email)}" autocomplete="off">
<label>Global API Key（可选）</label><input name="GlobalAPIKey" type="password" value="" autocomplete="off">
<button type="submit">保存凭证</button></form>
<p style="margin-top:16px"><a href="/">← 返回面板</a></p></div></body></html>`;
}

const PANEL_HTML = `<!DOCTYPE html>
<html lang="zh-CN" data-theme="dark">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>CFLYHL</title>
<style>
:root{--bg:#151a2d;--card:#222940;--tx:#edf0fc;--mut:#a4adc8;--line:#39415e;--pri:#9dacff;--field:#1b2237}
*{box-sizing:border-box}body{margin:0;font-family:system-ui,sans-serif;background:var(--bg);color:var(--tx);min-height:100vh}
header{display:flex;align-items:center;gap:12px;padding:14px 18px;border-bottom:1px solid var(--line);position:sticky;top:0;background:rgba(21,26,45,.92);backdrop-filter:blur(8px);z-index:10}
.brand{font-weight:800;font-size:18px;background:linear-gradient(90deg,#ff0000,#ff7f00,#ffff00,#00ff00,#00bfff,#8b00ff,#ff1493);-webkit-background-clip:text;background-clip:text;color:transparent;animation:hue 4s linear infinite}
@keyframes hue{to{filter:hue-rotate(360deg)}}
.tag{font-size:11px;color:var(--mut);border:1px solid var(--line);border-radius:999px;padding:2px 8px}
main{padding:16px;max-width:720px;margin:0 auto;padding-bottom:100px}
.box{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:16px;margin-bottom:14px}
.box h2{margin:0 0 10px;font-size:15px}.mut{color:var(--mut);font-size:12px;line-height:1.6}
.tabs{display:flex;gap:8px;margin:12px 0;flex-wrap:wrap}
.tab{border:0;background:transparent;color:var(--mut);padding:10px 14px;border-radius:8px 8px 0 0;font-weight:650;cursor:pointer;font-size:14px}
.tab.on{color:var(--pri);box-shadow:inset 0 -3px var(--pri)}.panel{display:none}.panel.on{display:block}
.field{display:block;width:100%;padding:11px 12px;margin:6px 0 12px;border:1px solid var(--line);border-radius:8px;background:var(--field);color:var(--tx);font:inherit}
label{font-size:13px;color:var(--mut)}.row{display:flex;gap:8px;flex-wrap:wrap;margin-top:8px}
button{border:1px solid var(--line);background:var(--field);color:var(--tx);border-radius:999px;padding:10px 18px;cursor:pointer;font-weight:600}
button.pri{border:none;background:transparent;background-image:linear-gradient(90deg,#ff0000,#ff7f00,#ffff00,#00ff00,#00bfff,#8b00ff,#ff1493);-webkit-background-clip:text;background-clip:text;color:transparent;font-weight:800}
.hint{font-size:12px;color:var(--mut);margin:6px 0;line-height:1.6}
.stat-num{font-size:32px;font-weight:800;color:#22c55e}
.ubar{height:8px;border-radius:6px;background:#2d3550;overflow:hidden;margin:10px 0}.ubar>i{display:block;height:100%;background:linear-gradient(90deg,#ff0000,#ff7f00,#ffff00,#00ff00,#00bfff,#8b00ff);width:0}
.grid3{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-top:10px}
.mini{background:var(--field);border-radius:10px;padding:10px;text-align:center}.mini b{display:block;font-size:18px;margin-top:4px}
.net-card{background:var(--field);border-radius:12px;padding:12px;margin:8px 0}
.net-card .ip{font-size:18px;font-weight:700;color:#60a5fa;word-break:break-all}.net-card .sub{font-size:12px;color:var(--mut);margin-top:4px}
.lat{display:flex;justify-content:space-between;align-items:center;padding:10px 12px;background:var(--field);border-radius:10px;margin:6px 0}.lat .ms{font-weight:700}
.global-actions{position:fixed;right:16px;bottom:16px;z-index:20;display:flex;flex-direction:column;align-items:flex-end;gap:8px}
.global-buttons{display:flex;gap:8px}#g-stat{font-size:12px;background:var(--card);border:1px solid var(--line);padding:8px 12px;border-radius:8px;max-width:70vw}#g-stat:empty{display:none}
table{width:100%;border-collapse:collapse;font-size:12px}th,td{border-bottom:1px solid var(--line);padding:8px 6px;text-align:left;vertical-align:top;word-break:break-all}th{color:var(--mut)}.empty{color:var(--mut);text-align:center}
.theme-toggle{margin-left:auto;border-radius:999px;padding:6px 10px}
html[data-theme=light]{--bg:#e9edf4;--card:#fdfefe;--tx:#1c2440;--mut:#626d86;--line:#d6dce9;--pri:#3d55bd;--field:#f6f7fb}
</style></head>
<body>
<header>
  <span class="brand">CFLYHL</span>
  <span class="tag">2.1.7</span>
  <button type="button" class="theme-toggle" id="theme-toggle">☀️</button>
</header>
<main>
  <div class="box" id="cf-usage-box">
    <h2>Workers/Pages 请求使用情况 <span class="tag" id="cf-usage-src">…</span></h2>
    <div id="cf-usage-body"><div class="mut">正在获取今日请求量…</div></div>
  </div>
  <div class="box">
    <h2>🌍 当前网络信息</h2>
    <div class="net-card"><div class="mut">国内测试</div><div class="ip" id="ip-cn">检测中…</div><div class="sub">您访问国内站点所使用的 IP</div></div>
    <div class="net-card"><div class="mut">国外测试</div><div class="ip" id="ip-fr">检测中…</div><div class="sub">您访问墙外站点所使用的 IP</div></div>
    <div class="net-card"><div class="mut">Cloudflare</div><div class="ip" id="ip-cf">检测中…</div><div class="sub">访问 CF 相关站点的落地 IP</div></div>
    <div id="latency-list"></div>
  </div>
  <div class="tabs">
    <button type="button" class="tab on" data-t="t-settings">设置</button>
    <button type="button" class="tab" data-t="t-logs">操作日志</button>
    <button type="button" class="tab" data-t="t-about">关于</button>
  </div>
  <section class="panel on" id="t-settings">
    <div class="box">
      <h2>面板登录密码</h2>
      <div class="hint" id="panel-pass-stat">正在读取…</div>
      <label>当前密码（已设置时必须填写才能修改或清除）</label>
      <input class="field" type="password" id="panel-pass-old" autocomplete="current-password" placeholder="首次设置可留空">
      <label>新密码</label>
      <input class="field" type="password" id="panel-pass-new" autocomplete="new-password" placeholder="至少 4 位">
      <label>确认新密码</label>
      <input class="field" type="password" id="panel-pass-new2" autocomplete="new-password" placeholder="再输入一次">
      <div class="row">
        <button type="button" class="pri" id="panel-pass-save">保存</button>
        <button type="button" id="panel-pass-clear">清除</button>
        <button type="button" id="panel-logout">退出登录</button>
      </div>
      <div class="hint">密码写入 KV（绑定名需为 K）。设置后访问面板需先登录。</div>
    </div>
  </section>
  <section class="panel" id="t-logs">
    <div class="box">
      <h2>操作日志</h2>
      <div class="row" style="margin-bottom:10px">
        <button type="button" id="log-refresh">刷新</button>
        <button type="button" id="log-clear">清空</button>
        <span class="hint" id="log-stat">—</span>
      </div>
      <div style="overflow:auto;max-height:60vh">
        <table><thead><tr><th>时间</th><th>类型</th><th>详情</th><th>IP</th></tr></thead>
        <tbody id="log-body"><tr><td colspan="4" class="empty">暂无记录</td></tr></tbody></table>
      </div>
      <div class="hint">绑定 K 时写入 KV；未绑定则使用本机 localStorage。</div>
    </div>
  </section>
  <section class="panel" id="t-about">
    <div class="box">
      <h2>CFLYHL · 版本 2.1.7</h2>
      <div class="hint" style="color:var(--tx);font-size:14px">CFLYHL · 版本 2.1.7林呓互联</div>
    </div>
  </section>
</main>
<div class="global-actions">
  <div id="g-stat"></div>
  <div class="global-buttons">
    <button type="button" id="g-reset">默认</button>
    <button type="button" class="pri" id="g-save">保存</button>
  </div>
</div>
<script>
(function(){
  function $(id){ return document.getElementById(id); }
  function setSt(s){ var el=$('panel-pass-stat'); if(el) el.textContent=s||''; }
  function setG(s){ var el=$('g-stat'); if(el) el.textContent=s||''; }
  function esc(s){ return String(s==null?'':s).replace(/[&<>"']/g,function(c){return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[c];}); }
  var LOG_LS='cfapex_op_logs_local';
  function readLocal(){ try{ var a=JSON.parse(localStorage.getItem(LOG_LS)||'[]'); return Array.isArray(a)?a:[]; }catch(e){ return []; } }
  function writeLocal(a){ try{ localStorage.setItem(LOG_LS, JSON.stringify((a||[]).slice(0,300))); }catch(e){} }
  function pushLocal(type, detail){ var a=readLocal(); a.unshift({ t:Date.now(), type:type||'操作', detail:detail||'', IP:'' }); writeLocal(a); return a; }
  function api(name, opt){
    opt=opt||{}; opt.credentials='same-origin'; opt.cache='no-store';
    if(!opt.headers) opt.headers={'Content-Type':'application/json','Accept':'application/json'};
    return fetch('/api/'+name, opt).then(function(r){
      return r.text().then(function(t){
        var d=null; try{ d=t?JSON.parse(t):{}; }catch(e){ var err=new Error('非 JSON HTTP '+r.status); throw err; }
        if(!r.ok){ var e2=new Error((d&&(d.error||d.msg))||('HTTP '+r.status)); throw e2; }
        return d;
      });
    });
  }
  function showTab(id){
    document.querySelectorAll('.tab').forEach(function(t){ t.classList.toggle('on', t.getAttribute('data-t')===id); });
    document.querySelectorAll('.panel').forEach(function(p){ p.classList.toggle('on', p.id===id); });
    if(id==='t-logs') loadLogs();
    if(id==='t-settings') loadPass();
  }
  document.querySelectorAll('.tab').forEach(function(btn){ btn.addEventListener('click', function(){ showTab(btn.getAttribute('data-t')); }); });

  function loadPass(){
    setSt('正在读取…');
    var ctrl=new AbortController();
    var timer=setTimeout(function(){ try{ctrl.abort();}catch(e){} }, 5000);
    fetch('/api/panel-pass',{credentials:'same-origin',cache:'no-store',signal:ctrl.signal,headers:{'Accept':'application/json'}})
      .then(function(r){ return r.text().then(function(t){ return {ok:r.ok,status:r.status,t:t}; }); })
      .then(function(res){
        clearTimeout(timer);
        var d=null; try{ d=res.t?JSON.parse(res.t):{}; }catch(e){ setSt('读取失败：返回非 JSON (HTTP '+res.status+')'); return; }
        if(!res.ok){ setSt('读取失败：'+((d&&(d.error||d.msg))||('HTTP '+res.status))); return; }
        if(d.storage==='none') setSt('未绑定 K，无法写入 KV');
        else if(d.set) setSt('已设置面板登录密码（KV）');
        else setSt('未设置面板登录密码');
      })
      .catch(function(e){ clearTimeout(timer); setSt(e&&e.name==='AbortError'?'读取超时，请检查 Worker/KV 绑定':('读取失败：'+(e&&e.message||e))); });
  }
  $('panel-pass-save').onclick=function(){
    var o=$('panel-pass-old').value||'', n=$('panel-pass-new').value||'', n2=$('panel-pass-new2').value||'';
    if(n.length<4){ setSt('新密码至少 4 位'); return; }
    if(n!==n2){ setSt('两次新密码不一致'); return; }
    setSt('保存中…');
    api('panel-pass',{method:'POST',body:JSON.stringify({password:n,oldPassword:o})})
      .then(function(){ setSt('密码已保存到 KV'); pushLocal('修改密码','保存/更新面板登录密码'); $('panel-pass-old').value=''; $('panel-pass-new').value=''; $('panel-pass-new2').value=''; })
      .catch(function(e){ setSt('保存失败：'+(e.message||e)); });
  };
  $('panel-pass-clear').onclick=function(){
    api('panel-pass',{method:'POST',body:JSON.stringify({action:'clear',oldPassword:$('panel-pass-old').value||''})})
      .then(function(){ setSt('已清除面板登录密码'); pushLocal('修改密码','清除面板登录密码'); })
      .catch(function(e){ setSt('清除失败：'+(e.message||e)); });
  };
  $('panel-logout').onclick=function(){ pushLocal('退出','退出登录'); location.href='/logout'; };

  function paintLogs(arr, label){
    var ls=$('log-stat'), lb=$('log-body');
    if(ls) ls.textContent='共 '+(arr||[]).length+' 条 · '+(label||'');
    if(!lb) return; lb.innerHTML='';
    if(!arr||!arr.length){ lb.innerHTML='<tr><td colspan="4" class="empty">暂无记录</td></tr>'; return; }
    arr.forEach(function(item){
      var tr=document.createElement('tr');
      function c(v){ var td=document.createElement('td'); td.textContent=v||''; return td; }
      tr.appendChild(c(item.t?new Date(item.t).toLocaleString('zh-CN',{hour12:false}):''));
      tr.appendChild(c(item.type)); tr.appendChild(c(item.detail)); tr.appendChild(c(item.IP||''));
      lb.appendChild(tr);
    });
  }
  function loadLogs(){
    $('log-stat').textContent='加载中…';
    api('logs').then(function(d){
      if(d.storage==='kv'){ paintLogs(d.logs||[],'KV'); return; }
      paintLogs(readLocal(),'本机');
    }).catch(function(){ paintLogs(readLocal(),'本机'); });
  }
  $('log-refresh').onclick=function(){ loadLogs(); };
  $('log-clear').onclick=function(){ writeLocal([]); api('logs',{method:'POST',body:JSON.stringify({action:'clear'})}).finally(loadLogs); };

  $('g-reset').onclick=function(){
    if(!confirm('确定清空绑定 K 中的全部数据？此操作不可撤销。')) return;
    setG('正在清空 KV…');
    api('kv-reset',{method:'POST',body:JSON.stringify({action:'clear_all'})})
      .then(function(d){ writeLocal([]); pushLocal('重置','清空 KV 全部内容'); setG('已清空 KV（处理 '+(d.deleted||0)+' 项）'); alert('已清空 KV（处理 '+(d.deleted||0)+' 项）'); loadPass(); })
      .catch(function(e){ setG('清空失败：'+(e.message||e)); alert('清空失败：'+(e.message||e)); });
  };
  $('g-save').onclick=function(){ setG('精简版无额外配置可保存'); };

  $('theme-toggle').onclick=function(){
    var cur=document.documentElement.getAttribute('data-theme')==='light'?'light':'dark';
    var next=cur==='dark'?'light':'dark';
    document.documentElement.setAttribute('data-theme', next);
    $('theme-toggle').textContent=next==='dark'?'☀️':'🌙';
    try{ localStorage.setItem('pth', next); }catch(e){}
  };
  try{ var pt=localStorage.getItem('pth'); if(pt==='light'||pt==='dark'){ document.documentElement.setAttribute('data-theme',pt); $('theme-toggle').textContent=pt==='dark'?'☀️':'🌙'; } }catch(e){}

  function renderUsage(d){
    var src=$('cf-usage-src'), body=$('cf-usage-body'); if(!body) return;
    if(!d||!d.success){ if(src) src.textContent='失败'; body.innerHTML='<div class="mut">获取失败：'+esc(d&&d.msg||'未知')+' · <a href="/usage" style="color:var(--pri)">配置凭证</a></div>'; return; }
    if(src) src.textContent=d.credSource==='kv'?'已保存':(d.credSource==='env'?'环境变量':'自动');
    var pct=d.percent||0;
    body.innerHTML='<div class="stat-num">'+(d.total||0).toLocaleString()+' <span style="font-size:14px;color:var(--mut)">('+pct+'%)</span></div>'+
      '<div class="mut">配额 '+(d.max||100000).toLocaleString()+'</div><div class="ubar"><i style="width:'+Math.min(100,pct)+'%"></i></div>'+
      '<div class="grid3"><div class="mini"><span class="mut">Workers</span><b>'+(d.workers||0).toLocaleString()+'</b></div>'+
      '<div class="mini"><span class="mut">Pages</span><b>'+(d.pages||0).toLocaleString()+'</b></div>'+
      '<div class="mini"><span class="mut">剩余</span><b>'+(d.remaining||0).toLocaleString()+'</b></div></div>'+
      '<div class="mut" style="margin-top:10px">'+esc(d.resetText||'')+' · <a href="/usage" style="color:var(--pri)">详情/更新凭证</a></div>';
  }
  fetch('/usage?format=json',{credentials:'same-origin',cache:'no-store'}).then(function(r){ return r.json(); }).then(renderUsage).catch(function(e){ renderUsage({ success:false, msg:e.message||String(e) }); });

  function setIp(id, ip){ var el=$(id); if(el) el.textContent=ip||'获取失败'; }
  function fetchText(url, ms){
    return new Promise(function(resolve,reject){
      var c=new AbortController(); var t=setTimeout(function(){ c.abort(); reject(new Error('timeout')); }, ms||5000);
      fetch(url,{signal:c.signal,cache:'no-store'}).then(function(r){ return r.text(); }).then(function(t2){ clearTimeout(t); resolve(t2); }).catch(function(e){ clearTimeout(t); reject(e); });
    });
  }
  fetchText('https://www.cloudflare.com/cdn-cgi/trace',5000).then(function(t){ var m=t.match(/ip=(.+)/); setIp('ip-cf', m&&m[1]?m[1].trim():''); }).catch(function(){ setIp('ip-cf','获取失败'); });
  fetchText('https://api.ipify.org?format=json',5000).then(function(t){ try{ setIp('ip-fr', JSON.parse(t).ip||''); }catch(e){ setIp('ip-fr','获取失败'); } }).catch(function(){ setIp('ip-fr','获取失败'); });
  fetchText('https://myip.ipip.net',5000).then(function(t){ var m=String(t).match(/(\\d+\\.\\d+\\.\\d+\\.\\d+)/); setIp('ip-cn', m?m[1]:String(t).slice(0,40)); }).catch(function(){
    fetchText('https://api.ip.sb/ip',4000).then(function(t){ setIp('ip-cn', String(t).trim()); }).catch(function(){ setIp('ip-cn','获取失败'); });
  });
  var sites=[{name:'字节抖音',url:'https://www.douyin.com',region:'国内'},{name:'Bilibili',url:'https://www.bilibili.com',region:'国内'},{name:'GitHub',url:'https://github.com',region:'国际'},{name:'Cloudflare',url:'https://www.cloudflare.com',region:'国际'},{name:'Google',url:'https://www.google.com/generate_204',region:'国际'}];
  var list=$('latency-list');
  sites.forEach(function(site){
    var row=document.createElement('div'); row.className='lat';
    row.innerHTML='<div><b>'+esc(site.name)+'</b> <span class="mut">'+esc(site.region)+'</span></div><div class="ms" data-ms>—</div>';
    list.appendChild(row);
    var msEl=row.querySelector('[data-ms]'); var t0=performance.now();
    fetch(site.url,{mode:'no-cors',cache:'no-store'}).then(function(){
      var ms=Math.round(performance.now()-t0); msEl.textContent=ms+'ms'; msEl.style.color=ms<200?'#22c55e':(ms<500?'#f59e0b':'#ef4444');
    }).catch(function(){ msEl.textContent='失败'; msEl.style.color='#ef4444'; });
  });
  loadPass();
})();
</script>
</body></html>`;

async function handlePanelPass(request, env) {
  const kv = getKV(env);
  if (request.method === "GET") {
    let set = false, storage = "none";
    try {
      if (kv && typeof kv.get === "function") {
        storage = "kv";
        const pass = await Promise.race([kv.get(PASS_KEY), new Promise((r) => setTimeout(() => r(null), 2500))]);
        set = !!pass;
      }
    } catch {}
    return json({ ok: true, set, storage });
  }
  if (request.method === "POST") {
    if (!kv) return json({ ok: false, error: "no_kv" }, 400);
    const pass = await getPass(env);
    let body = {};
    try { body = await request.json(); } catch { return json({ ok: false, error: "bad_body" }, 400); }
    if (body.action === "clear") {
      if (pass && String(body.oldPassword || "") !== pass) return json({ ok: false, error: "bad_old" }, 403);
      await kv.delete(PASS_KEY);
      await appendOpLog(request, env, "修改密码", "清除面板登录密码");
      return new Response(JSON.stringify({ ok: true, set: false }), { headers: { "Content-Type": "application/json; charset=utf-8", "Set-Cookie": cookie("", 0) } });
    }
    const np = String(body.password || "").trim();
    if (np.length < 4) return json({ ok: false, error: "too_short" }, 400);
    if (pass && String(body.oldPassword || "") !== pass) return json({ ok: false, error: "bad_old" }, 403);
    await kv.put(PASS_KEY, np);
    await appendOpLog(request, env, "修改密码", pass ? "更新面板登录密码" : "首次设置面板登录密码");
    return new Response(JSON.stringify({ ok: true, set: true }), { headers: { "Content-Type": "application/json; charset=utf-8", "Set-Cookie": cookie(await hashPass(np)) } });
  }
  return json({ ok: false }, 405);
}

async function handleLogs(request, env) {
  const kv = getKV(env);
  const pass = await getPass(env);
  if (pass && !(await isAuthed(request, pass))) return json({ ok: false, error: "unauthorized" }, 401);
  if (request.method === "GET") {
    let arr = [];
    if (kv) { try { arr = JSON.parse((await kv.get(LOG_KEY)) || "[]"); } catch { arr = []; } }
    return json({ ok: true, logs: Array.isArray(arr) ? arr : [], storage: kv ? "kv" : "none" });
  }
  if (request.method === "POST") {
    let body = {};
    try { body = await request.json(); } catch { return json({ ok: false, error: "bad_body" }, 400); }
    if (body.action === "clear") { if (kv) await kv.put(LOG_KEY, "[]"); return json({ ok: true, logs: [] }); }
    return json({ ok: false }, 400);
  }
  return json({ ok: false }, 405);
}

async function handleKvReset(request, env) {
  if (request.method !== "POST") return json({ ok: false, error: "method" }, 405);
  const pass = await getPass(env);
  if (pass && !(await isAuthed(request, pass))) return json({ ok: false, error: "unauthorized" }, 401);
  const kv = getKV(env);
  if (!kv || typeof kv.delete !== "function") return json({ ok: false, error: "no_kv", msg: "未绑定 KV（需绑定变量名 K）" }, 400);
  let deleted = 0;
  for (const key of [LOG_KEY, PASS_KEY, CFAPEX_USAGE_CREDS_KEY]) {
    try { await kv.delete(key); deleted++; } catch {}
  }
  if (typeof kv.list === "function") {
    let cursor;
    try {
      do {
        const res = await kv.list(cursor ? { cursor, limit: 1000 } : { limit: 1000 });
        for (const k of res.keys || []) { try { await kv.delete(k.name); deleted++; } catch {} }
        cursor = res.list_complete ? null : res.cursor;
      } while (cursor);
    } catch {}
  }
  return json({ ok: true, deleted });
}

async function handleLogin(request, env) {
  if (request.method === "GET") {
    return new Response(loginPage(""), { headers: { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store" } });
  }
  let pw = "";
  try {
    const ct = (request.headers.get("Content-Type") || "").toLowerCase();
    if (ct.includes("json")) { const b = await request.json(); pw = b.password || ""; }
    else { const fd = await request.formData(); pw = fd.get("password") || ""; }
  } catch {}
  const real = await getPass(env);
  if (!real) return new Response(loginPage("尚未设置密码"), { headers: { "Content-Type": "text/html; charset=utf-8" } });
  if (String(pw) !== real) {
    await appendOpLog(request, env, "登录", "登录失败：密码错误");
    return new Response(loginPage("密码错误"), { status: 401, headers: { "Content-Type": "text/html; charset=utf-8" } });
  }
  await appendOpLog(request, env, "登录", "登录成功");
  return new Response(null, { status: 302, headers: { Location: "/", "Set-Cookie": cookie(await hashPass(real)) } });
}

async function handleUsageRoute(request, env, url, path) {
  let notice = null;
  let saved = await loadUsageCreds(env);
  if (request.method === "POST" && (path === "/usage" || path.endsWith("/usage"))) {
    const form = await request.formData();
    const action = form.get("action") || "save";
    if (action === "clear") { notice = await clearUsageCreds(env); saved = await loadUsageCreds(env); }
    else {
      const next = { Email: form.get("Email") || "", GlobalAPIKey: form.get("GlobalAPIKey") || "", AccountID: form.get("AccountID") || "", APIToken: form.get("APIToken") || "" };
      if (!next.APIToken && saved.APIToken) next.APIToken = saved.APIToken;
      if (!next.GlobalAPIKey && saved.GlobalAPIKey) next.GlobalAPIKey = saved.GlobalAPIKey;
      if (!next.Email && saved.Email) next.Email = saved.Email;
      if (!next.AccountID && saved.AccountID) next.AccountID = saved.AccountID;
      notice = await saveUsageCreds(env, next);
      saved = await loadUsageCreds(env);
    }
  }
  const Email = url.searchParams.get("Email") || saved.Email || "";
  const GlobalAPIKey = url.searchParams.get("GlobalAPIKey") || saved.GlobalAPIKey || "";
  const AccountID = url.searchParams.get("AccountID") || saved.AccountID || "";
  const APIToken = url.searchParams.get("APIToken") || saved.APIToken || "";
  const wantsJson = url.searchParams.get("format") === "json" || (request.headers.get("Accept") || "").includes("application/json");
  const data = await getCloudflareUsage(Email, GlobalAPIKey, AccountID, APIToken);
  if (wantsJson) {
    return new Response(JSON.stringify({ ...data, credSource: saved.source }, null, 2), {
      headers: { "Content-Type": "application/json; charset=utf-8", "Access-Control-Allow-Origin": "*", "Cache-Control": "no-store" }
    });
  }
  return new Response(renderUsagePage(data, url.searchParams, saved, notice), { headers: { "Content-Type": "text/html; charset=utf-8" } });
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const path = url.pathname.replace(/\/+$/, "") || "/";
    try {
      if (path === "/usage" || path.endsWith("/usage")) return await handleUsageRoute(request, env, url, path);
      if (path === "/api/logs" || path.endsWith("/api/logs")) return handleLogs(request, env);
      if (path === "/api/panel-pass" || path.endsWith("/api/panel-pass")) return handlePanelPass(request, env);
      if (path === "/api/kv-reset" || path.endsWith("/api/kv-reset")) return handleKvReset(request, env);
      if (path === "/api/ping" || path.endsWith("/api/ping")) return json({ ok: true, time: Date.now() });
      if (path === "/login" || path.endsWith("/login")) return handleLogin(request, env);
      if (path === "/logout" || path.endsWith("/logout")) {
        await appendOpLog(request, env, "退出", "退出登录");
        return new Response(null, { status: 302, headers: { Location: "/login", "Set-Cookie": cookie("", 0) } });
      }
      const pass = await getPass(env);
      if (pass) {
        const ok = await isAuthed(request, pass);
        if (!ok) {
          const ua = (request.headers.get("User-Agent") || "").toLowerCase();
          if (/mozilla|chrome|safari|firefox|edg|mobile/i.test(ua)) {
            return new Response(loginPage("请登录后继续"), { status: 401, headers: { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store" } });
          }
          return json({ ok: false, error: "unauthorized" }, 401);
        }
      }
      return new Response(PANEL_HTML, { headers: { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store" } });
    } catch (e) {
      return json({ ok: false, error: String(e && e.message || e) }, 500);
    }
  }
};
