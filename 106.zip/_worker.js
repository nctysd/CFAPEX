/**
 * CFLYHL shell — 无概览圆圈、无代理；设置/日志/关于可用
 */
const LOG_KEY = "cfapex_op_logs";
const PASS_KEY = "cfapex_panel_pass";
const CFAPEX_USAGE_CREDS_KEY = "cfapex_usage_creds";

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const path = url.pathname.replace(/\/+$/, "") || "/";

    try {
      // usage (original style APIs)
      if (
        path === "/usage" ||
        path === "/cf-usage" ||
        path.endsWith("/usage") ||
        path.endsWith("/cf-usage") ||
        path.endsWith("/admin/getCloudflareUsage")
      ) {
        return handleUsage(request, env, url, path);
      }

      if (path === "/api/logs" || path.endsWith("/api/logs")) {
        return handleLogs(request, env);
      }
      if (path === "/api/panel-pass" || path.endsWith("/api/panel-pass")) {
        return handlePanelPass(request, env);
      }
      if (path === "/api/ping" || path.endsWith("/api/ping")) {
        return json({ ok: true, time: Date.now() });
      }
      if (path === "/login" || path.endsWith("/login")) {
        return handleLogin(request, env, path);
      }

      // password gate for browser panel
      const pass = await getPass(env);
      if (pass) {
        const ok = await isAuthed(request, pass);
        if (!ok) {
          const ua = (request.headers.get("User-Agent") || "").toLowerCase();
          if (/mozilla|chrome|safari|firefox|edg/i.test(ua)) {
            return new Response(loginPage("请登录后继续", "/login"), {
              status: 401,
              headers: { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store" }
            });
          }
        }
      }

      return new Response(panelPage(), {
        headers: { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store" }
      });
    } catch (e) {
      return json({ ok: false, error: String(e && e.message || e) }, 500);
    }
  }
};

function json(obj, status = 200) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: { "Content-Type": "application/json; charset=utf-8" }
  });
}

async function getPass(env) {
  try {
    const kv = env && env.K;
    if (!kv) return "";
    return (await kv.get(PASS_KEY)) || "";
  } catch {
    return "";
  }
}

async function hashPass(p) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode("cfapex:" + String(p)));
  return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

function readSid(req) {
  const m = (req.headers.get("Cookie") || "").match(/(?:^|;\s*)cfapex_sid=([^;]*)/);
  return m ? decodeURIComponent(m[1].trim()) : "";
}

async function isAuthed(req, pass) {
  if (!pass) return true;
  const sid = readSid(req);
  if (!sid) return false;
  return sid === (await hashPass(pass));
}

function cookie(sid, maxAge = 604800) {
  return `cfapex_sid=${encodeURIComponent(sid)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAge}`;
}

async function handleLogs(request, env) {
  const kv = env && env.K;
  const pass = await getPass(env);
  if (pass && !(await isAuthed(request, pass))) return json({ ok: false, error: "unauthorized" }, 401);

  if (request.method === "GET") {
    let arr = [];
    if (kv) {
      try {
        arr = JSON.parse((await kv.get(LOG_KEY)) || "[]");
      } catch {
        arr = [];
      }
    }
    if (!Array.isArray(arr)) arr = [];
    return json({ ok: true, logs: arr, storage: kv ? "kv" : "none" });
  }

  if (request.method === "POST") {
    let body = {};
    try {
      body = await request.json();
    } catch {
      return json({ ok: false, error: "bad_body" }, 400);
    }
    if (body.action === "clear") {
      if (kv) await kv.put(LOG_KEY, "[]");
      return json({ ok: true, logs: [], storage: kv ? "kv" : "none" });
    }
    let arr = [];
    if (kv) {
      try {
        arr = JSON.parse((await kv.get(LOG_KEY)) || "[]");
      } catch {
        arr = [];
      }
    }
    if (!Array.isArray(arr)) arr = [];
    arr.unshift({
      t: Date.now(),
      type: body.type || "操作",
      detail: body.detail || "",
      IP: request.headers.get("CF-Connecting-IP") || "",
      CC: request.cf ? `${request.cf.country || ""} ${request.cf.city || ""}`.trim() : "",
      ASN: request.cf ? `AS${request.cf.asn || ""} ${request.cf.asOrganization || ""}`.trim() : "",
      URL: body.URL || request.url || "",
      UA: body.UA || request.headers.get("User-Agent") || ""
    });
    while (arr.length > 300) arr.pop();
    if (kv) await kv.put(LOG_KEY, JSON.stringify(arr));
    return json({ ok: true, storage: kv ? "kv" : "none" });
  }
  return json({ ok: false, error: "method" }, 405);
}

async function handlePanelPass(request, env) {
  const kv = env && env.K;
  const pass = await getPass(env);

  if (request.method === "GET") {
    return json({ ok: true, set: !!pass, storage: kv ? "kv" : "none" });
  }

  if (request.method === "POST") {
    if (!kv) return json({ ok: false, error: "no_kv" });
    let body = {};
    try {
      body = await request.json();
    } catch {
      return json({ ok: false, error: "bad_body" }, 400);
    }

    if (body.action === "clear") {
      if (pass && String(body.oldPassword || "") !== pass) return json({ ok: false, error: "bad_old" }, 403);
      await kv.delete(PASS_KEY);
      return new Response(JSON.stringify({ ok: true, set: false }), {
        headers: { "Content-Type": "application/json; charset=utf-8", "Set-Cookie": cookie("", 0) }
      });
    }

    const np = String(body.password || "").trim();
    if (np.length < 4) return json({ ok: false, error: "too_short" }, 400);
    if (pass && String(body.oldPassword || "") !== pass) return json({ ok: false, error: "bad_old" }, 403);
    await kv.put(PASS_KEY, np);
    return new Response(JSON.stringify({ ok: true, set: true }), {
      headers: {
        "Content-Type": "application/json; charset=utf-8",
        "Set-Cookie": cookie(await hashPass(np))
      }
    });
  }
  return json({ ok: false, error: "method" }, 405);
}

async function handleLogin(request, env, path) {
  if (request.method === "GET") {
    return new Response(loginPage("", path), {
      headers: { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store" }
    });
  }
  let pw = "";
  try {
    const ct = (request.headers.get("Content-Type") || "").toLowerCase();
    if (ct.includes("json")) {
      const b = await request.json();
      pw = b.password || "";
    } else {
      const fd = await request.formData();
      pw = fd.get("password") || "";
    }
  } catch {}
  const real = await getPass(env);
  if (!real) {
    return new Response(loginPage("尚未设置密码（请先在设置中保存，并绑定 KV：K）", path), {
      headers: { "Content-Type": "text/html; charset=utf-8" }
    });
  }
  if (String(pw) !== real) {
    return new Response(loginPage("密码错误", path), {
      status: 401,
      headers: { "Content-Type": "text/html; charset=utf-8" }
    });
  }
  // log
  try {
    const kv = env && env.K;
    if (kv) {
      let arr = [];
      try {
        arr = JSON.parse((await kv.get(LOG_KEY)) || "[]");
      } catch {
        arr = [];
      }
      if (!Array.isArray(arr)) arr = [];
      arr.unshift({
        t: Date.now(),
        type: "登录后台",
        detail: "登录成功",
        IP: request.headers.get("CF-Connecting-IP") || "",
        CC: request.cf ? `${request.cf.country || ""} ${request.cf.city || ""}`.trim() : "",
        ASN: request.cf ? `AS${request.cf.asn || ""} ${request.cf.asOrganization || ""}`.trim() : "",
        URL: request.url,
        UA: request.headers.get("User-Agent") || ""
      });
      while (arr.length > 300) arr.pop();
      await kv.put(LOG_KEY, JSON.stringify(arr));
    }
  } catch {}
  return new Response(null, {
    status: 302,
    headers: { Location: "/", "Set-Cookie": cookie(await hashPass(real)) }
  });
}

async function loadUsageCreds(env) {
  const fromEnv = {
    Email: (env && env.CF_EMAIL) || "",
    GlobalAPIKey: (env && env.CF_GLOBAL_API_KEY) || "",
    AccountID: (env && env.CF_ACCOUNT_ID) || "",
    APIToken: (env && env.CF_API_TOKEN) || ""
  };
  try {
    const kv = env && env.K;
    if (kv && typeof kv.get === "function") {
      const raw = await kv.get(CFAPEX_USAGE_CREDS_KEY);
      if (raw) {
        const saved = JSON.parse(raw);
        return {
          Email: saved.Email || fromEnv.Email || "",
          GlobalAPIKey: saved.GlobalAPIKey || fromEnv.GlobalAPIKey || "",
          AccountID: saved.AccountID || fromEnv.AccountID || "",
          APIToken: saved.APIToken || fromEnv.APIToken || "",
          source: "kv"
        };
      }
    }
  } catch (e) {}
  const has = !!(fromEnv.AccountID || fromEnv.APIToken || fromEnv.Email || fromEnv.GlobalAPIKey);
  return { ...fromEnv, source: has ? "env" : "none" };
}

async function saveUsageCreds(env, creds) {
  const kv = env && env.K;
  if (!kv || typeof kv.put !== "function") {
    return { ok: false, msg: "未绑定 KV（变量名需为 K）" };
  }
  try {
    await kv.put(
      CFAPEX_USAGE_CREDS_KEY,
      JSON.stringify({
        Email: (creds.Email || "").trim(),
        GlobalAPIKey: (creds.GlobalAPIKey || "").trim(),
        AccountID: (creds.AccountID || "").trim(),
        APIToken: (creds.APIToken || "").trim()
      })
    );
    return { ok: true, msg: "凭证已保存" };
  } catch (e) {
    return { ok: false, msg: "写入 KV 失败：" + (e.message || e) };
  }
}

async function clearUsageCreds(env) {
  const kv = env && env.K;
  if (!kv) return { ok: false, msg: "未绑定 KV" };
  try {
    await kv.delete(CFAPEX_USAGE_CREDS_KEY);
    return { ok: true, msg: "已清除" };
  } catch (e) {
    return { ok: false, msg: String(e.message || e) };
  }
}

async function getCloudflareUsage(Email, GlobalAPIKey, AccountID, APIToken) {
  const API = "https://api.cloudflare.com/client/v4";
  const sum = (a) => a?.reduce((t, i) => t + (i?.sum?.requests || 0), 0) || 0;
  try {
    if (!AccountID && (!Email || !GlobalAPIKey)) {
      return { success: false, pages: 0, workers: 0, total: 0, max: 100000, msg: "缺少 AccountID 或 Email+GlobalAPIKey" };
    }
    let headers = { "Content-Type": "application/json" };
    if (APIToken) headers.Authorization = "Bearer " + APIToken;
    else if (Email && GlobalAPIKey) {
      headers["X-Auth-Email"] = Email;
      headers["X-Auth-Key"] = GlobalAPIKey;
    } else {
      return { success: false, pages: 0, workers: 0, total: 0, max: 100000, msg: "请提供 API Token 或 Email+GlobalAPIKey" };
    }
    if (!AccountID) {
      const r = await fetch(`${API}/accounts?per_page=1`, { headers });
      const j = await r.json();
      AccountID = j?.result?.[0]?.id || "";
      if (!AccountID) return { success: false, pages: 0, workers: 0, total: 0, max: 100000, msg: "无法获取 AccountID" };
    }
    const now = new Date();
    const start = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
    const end = new Date(start.getTime() + 86400000);
    const gql = {
      query: `query {
        viewer {
          accounts(filter: { accountTag: "${AccountID}" }) {
            workersInvocationsAdaptive(limit: 10000, filter: { datetime_geq: "${start.toISOString()}", datetime_lt: "${end.toISOString()}" }) {
              sum { requests }
            }
            pagesFunctionsInvocationsAdaptiveGroups(limit: 10000, filter: { datetime_geq: "${start.toISOString()}", datetime_lt: "${end.toISOString()}" }) {
              sum { requests }
            }
          }
        }
      }`
    };
    const gr = await fetch(`${API}/graphql`, { method: "POST", headers, body: JSON.stringify(gql) });
    const gj = await gr.json();
    if (gj.errors && gj.errors.length) {
      return { success: false, pages: 0, workers: 0, total: 0, max: 100000, msg: gj.errors[0]?.message || "GraphQL 错误" };
    }
    const acc = gj?.data?.viewer?.accounts?.[0] || {};
    const workers = sum(acc.workersInvocationsAdaptive);
    const pages = sum(acc.pagesFunctionsInvocationsAdaptiveGroups);
    const total = workers + pages;
    const max = 100000;
    return {
      success: true,
      pages,
      workers,
      total,
      max,
      remaining: Math.max(0, max - total),
      percent: Math.min(100, Math.round((total / max) * 10000) / 100),
      msg: "ok"
    };
  } catch (e) {
    return { success: false, pages: 0, workers: 0, total: 0, max: 100000, msg: String(e.message || e) };
  }
}

async function handleUsage(request, env, url, path) {
  let notice = null;
  let saved = await loadUsageCreds(env);
  if (request.method === "POST" && (path === "/usage" || path.endsWith("/usage"))) {
    const form = await request.formData();
    const action = form.get("action") || "save";
    if (action === "clear") {
      notice = await clearUsageCreds(env);
      saved = await loadUsageCreds(env);
    } else {
      const next = {
        Email: form.get("Email") || "",
        GlobalAPIKey: form.get("GlobalAPIKey") || "",
        AccountID: form.get("AccountID") || "",
        APIToken: form.get("APIToken") || ""
      };
      if (!next.APIToken && saved.APIToken) next.APIToken = saved.APIToken;
      if (!next.GlobalAPIKey && saved.GlobalAPIKey) next.GlobalAPIKey = saved.GlobalAPIKey;
      if (!next.Email && saved.Email) next.Email = saved.Email;
      if (!next.AccountID && saved.AccountID) next.AccountID = saved.AccountID;
      notice = await saveUsageCreds(env, next);
      saved = await loadUsageCreds(env);
    }
  }
  const Email = url.searchParams.get("Email") || saved.Email || "";
  const GlobalAPIKey = url.searchParams.get("GlobalAPIKey") || saved.GlobalAPIKey || "";
  const AccountID = url.searchParams.get("AccountID") || saved.AccountID || "";
  const APIToken = url.searchParams.get("APIToken") || saved.APIToken || "";
  const wantsJson =
    url.searchParams.get("format") === "json" ||
    path.endsWith("getCloudflareUsage") ||
    (request.headers.get("Accept") || "").includes("application/json");
  const data = await getCloudflareUsage(Email, GlobalAPIKey, AccountID, APIToken);
  if (wantsJson) {
    return json({ ...data, credSource: saved.source });
  }
  const ok = data && data.success;
  const pct = data?.percent || 0;
  const bar = pct >= 90 ? "#ef4444" : pct >= 70 ? "#f59e0b" : "#22c55e";
  const html = `<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>用量设置</title>
<style>
body{margin:0;font-family:system-ui,sans-serif;background:#0f172a;color:#e2e8f0;padding:24px}
.card{max-width:520px;margin:0 auto;background:#1e293b;border-radius:16px;padding:20px;border:1px solid #334155}
h1{margin:0 0 12px;font-size:20px}
label{display:block;margin:10px 0 4px;font-size:13px;color:#94a3b8}
input{width:100%;box-sizing:border-box;padding:10px;border-radius:8px;border:1px solid #475569;background:#0f172a;color:#e2e8f0}
button{margin-top:12px;padding:10px 16px;border:0;border-radius:999px;background:#3b82f6;color:#fff;font-weight:700;cursor:pointer}
.btn-danger{background:#ef4444}
.bar{height:10px;background:#334155;border-radius:999px;overflow:hidden;margin:10px 0}
.bar>i{display:block;height:100%;background:${bar};width:${Math.min(100, pct)}%}
.ok{color:#4ade80}.bad{color:#f87171}.tip{font-size:12px;color:#94a3b8;margin-top:12px}
a{color:#38bdf8}
</style></head><body><div class="card">
<h1>Workers/Pages 请求使用情况</h1>
${notice ? `<p class="${notice.ok ? "ok" : "bad"}">${notice.msg || ""}</p>` : ""}
${
  ok
    ? `<p>今日合计：<b>${(data.total || 0).toLocaleString()}</b> / ${(data.max || 100000).toLocaleString()}（${pct}%）</p>
<p>Workers：${data.workers || 0} · Pages：${data.pages || 0} · 剩余：${data.remaining || 0}</p>
<div class="bar"><i></i></div>`
    : `<p class="bad">${(data && data.msg) || "尚未显示用量"}</p>`
}
<form method="POST" action="/usage">
<label>Account ID</label>
<input name="AccountID" value="${saved.AccountID || ""}" placeholder="Cloudflare Account ID">
<label>API Token</label>
<input name="APIToken" type="password" value="" placeholder="${saved.APIToken ? "已保存，留空保持不变" : "API Token"}">
<label>Email（可选，Global Key 方式）</label>
<input name="Email" value="${saved.Email || ""}">
<label>Global API Key（可选）</label>
<input name="GlobalAPIKey" type="password" value="" placeholder="${saved.GlobalAPIKey ? "已保存，留空保持不变" : ""}">
<button type="submit">保存并显示</button>
</form>
${
  saved.source === "kv"
    ? `<form method="POST" action="/usage"><input type="hidden" name="action" value="clear"><button type="submit" class="btn-danger">清除已保存凭证</button></form>`
    : ""
}
<p class="tip">必须绑定 KV，变量名 <code>K</code>。也可设环境变量 CF_ACCOUNT_ID / CF_API_TOKEN。<br><a href="/">返回面板</a></p>
</div></body></html>`;
  return new Response(html, { headers: { "Content-Type": "text/html; charset=utf-8" } });
}

function loginPage(err, action) {
			const msg = err ? `<div class="err">${err}</div>` : "";
			const act = action || "";
			const logo = `data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQAAAAEACAYAAABccqhmAADe00lEQVR42uy9d7zsV1X3/1577+/MnHL7vbm5qZBGQiAQAiG0hCIEkCJo4kO3gQWxozzKY4gIgo8NfFQQFVBBSEDpXWKkhN6SUEJCer39njrz/e69fn/s8t1zgj+7tDP3Na/TZuaeMzNr7bU+6/P5LGH98j11URDAED+u+VG8Svy4flm/rF++W4L+EnAaA//fcvt/823XL9/ZF1l/Cr77T3sBX31vO3BcZ+3RoroVGIFdsiHcCO7rwuS6XADkJCAQ1p/N9cv65Tsr+G31+bbO8JxO+KA3cps3omqMqrGqxqVro51pDnk7/LS3w9/WZss968fS9cNi/bJ++c449XPwK2xthd/yhpvUoGrQYEU7a9vONuPODMednRl3dm7c2Y0TbzcHtVtV3Wbt7Py4k7m3TNh6ZvXY623B+mX98m0e/ALQWh6vhmty4HeGcWdl0jnT+qbpOjfqOjvTdXbWt3aD7+wW39ntXed2tp09YtzaI7yaneplS+tl24sv4jy7trJYv6xjAOuXb6PgF1AFE4TfMcKvAngYI+IAUTGIGOJBbkENKvFzwQIOxSIaP6KNB6zTRRO0/XCr235qxFe+rmBrXGH9sp4A1i/f4uAHuAPmthneZOH7PbQKYgQDBhVBMYixgIkBjgWJXwtN/BqLqEXVoWoRbVRx3unSIDDebcz8D0p3+UfWk8B3x2W9p/vuCH4D2C3CxSn4x4AVEYPE4Ef64EcMIhYxLn4UhxgHxoE0qDQgDokfRcS5TnZMjGzbEcL4HWPucZqA19QWrF/WK4D1y7cuAVgB3wqvdMLzYslPE1/dxPcRSSe9RcUiYmMFIA7BIjgQh+JALaoW1MVKgAYJLt5XnXcsN14Xr14J8w/awGV3aBwzro8J1xPA+uVbFfxjw08M4DVemCjiBAVjYuBjUsDHsl8kJwGXPg4QUtDjQGMSiBhBEz/P31MLOtNZXRh4XbjE6t0fC8stXBzW2YPrLcD65X/wchFYA34VTrbwRwhewcZqPwa/iiAmAX3Gxu+bKgmYJpb+ksv/9DG1ApgmtQTpaxkgiPVsX7Wy5WETue63hYs9nLf+PlqvANYv/8OnvwHUC++1wrlemCA4jEFEyIi/ptJfMBixBGws9aW/ijhUG8ChufTX2B6gDRpcnAyohWAxOgqqAWGfN8HdF959JVwgwoXrrcB6BbB++R8q/cPY8gQrcm4ntCo4jIDJJ7+AsfFqDWosPpX95KpgCg+IX5tUAcQqok8Q4CK0IAMUMchcMOwYegkXxPL/y+uHyXoCWL/8DwS/AOEKGFjlAkRjhW8k/iS3AMamIBdEbN8CWIeYBmNdTA7pZyrxcyUmgljyNykJ2B4kxKHSoIjzsqET2fDklh9+qHDx+lRgPQGsX/4nXjMBvZvl8U44vTN4jFg16ScxG8TR31QiiFVArgpKJZCTQM0LyK1Dnhzg+rEgrtxWGalhuxGR58df7e7rQOB6Ali//PcXASDKcxEQK5pL/1ju2wL6xVM/XtXGoFcxaNUCRFJQ4gikRJExA8htQj75E2+AJrYDKtYz72H++xZ5xunChWG9ClhPAOuX/+bef+J4AIazvaHDYCINyJATgZTAj8FeEoG1KdAjCUilKv1TRVBwgwok1DQRiHyBBmh6IJGRt2wbDBg9b/0VWk8A65f/gYvAT1qDxeAjDzCW/dhc1udrf/rH8V7/MSYIFxNCffrn8j/dVksSqJiC6WOiD9uOGUVmzj/ALxwXsYAL1t9X6wlg/fJffPobAb884mjgB4IhiBOrRiSe/CYh9wZsLOm19P2mQv4TLmBcAQBj35/YgpKEQdInhdIeTFUHDTBAcQKzXcP2uYFpnhp/21PXJwLrCWD98t/xWrnAM51hk1o6RExE/CURf3LJbwoJKLMBNQdyIgL11UCDmPyzPiloUgyK2CpR1AShISqDlAicBOZBR0+7lgtGcH5YNxBZTwDrl/+6018AfwPMGOVH1AJGjFqJp73NAS1Tp7VW7YDkHj+f5HVgG9dXBHnsVzEDI2U4jQVN5ANEYDBWAcjAdMx2I7acvM0OHhd5ARetv7fWE8D65b/qdRLQXZZHWcsJvhGvRgxGECto+hhLf1NKfkmnvZQSf3osmBNCGfmtHQFWgGFJDJRTP4GADqUBGSlsxofRc+KvfOX6SHA9Aaxf/uuKABDheak9D8YJ4vpALzP/guRXp/0Uum+qayYPVQkhg4NTuoA6QbgKHIwcAcURMHbFjIJh/pz9/Pm9hQvDResjwfUEsH75T0d+HP2NeIg4HuaH4nFi1RnUSCrxKxDQ9qBfUQSW075ODBkrsEgB+vJI0BSykEp1+ptBLwwyrlQBmgRDysjPyI7BWOQX429/3voLuJ4A1i//Fae/UX7ZDDDS4HPZj408/8gBsBHxt33g61Twm8L3z6e/phN9Ovgr4G8NTjB921gFlGvkBpglBkGYP/8WLrr7eZwX1keC6wlg/fIfj3wDqM5xKpbH+Ea8ilhNp70YKbz/kCuBTAEW27cGebxnpnt/kagcDGuBwZQkJHsIShYGmTIFUNOgNn00jmAaglhRGfoZdoxaMc8VRNdHgusJYP3yH7+IgHbKT9qGAQ0dRoQU7HnsF0v4dBVTkkKZ46dKQOmrgJ76Kz0BqB4nUlULfBOQMOEDwTqCmaoGzKpxAeaeeg3vOIb1KmA9Aaxf/sOnf1jdwImI/EgYGa/GuNzri43U3hy4Uk0AVCQiB6ZqDWpcYA0paCoRGImnfsYAjAMzKJwBzSNDYwmJUBRsg1qH2oZgRIJpulmzbXOwo59drwLWE8D65T9x+kvgl9yADdrgxRghE39yr2/7oO8VgFkNKFMnfI30M6UNMMVAJAOFRU8wpQnIHy0hE4Yy/mAbNCcE09ixMUF18OPXzV66K1YBup4E1hPA+uXfc/ovb+EYKzzFjwiI2Hyqh1yqFxVgrwXQyvarB/Gmwb84+hOUeJU6QdCrBmMicfExa0AwEY80X22eSEisBIyRYGw3w9atCyvmJ2MVsP5eW08A65d/1+nfjHm+HcomnHQIQqXxz+U6U8QfMz3mmzrxpewGKHLfmj6cJwLWldN/ujWwPbswS4qrRBCMIRiX2gJDZ6xdtSZ4mfmZz8x+ZhewXgWsJ4D1y7/19B9v4VRx/HgYRcOPPtAFs4bYo6Yy/6TS+ku/A6DnBfQlv4pNAV9pAPJ1DSOwBH56/Bzo8cSPVUCwORk4VIx41/gZ2bFjsmJfIIhezMXr77dvt5Nm/Sn49ksAAqHdwBvdjDylm5NWsLY/9SMYF8t8k3T5lbe/WiDZeZO9/NKqr2L7na2/m6LvRxOvXwfx6zBAdYRo/KihEcJIgw7QMCDoANUBXgd4dfjQ4MOANgzovKULjo5Gx96wsjpeWR10pz90fOo1sbqRdfPQ9Qpg/fJNgj+y/rZylrGc52ekEyM2kn0kAW5x/p/L91yia038qcDAerwHleY/twUJB5ju+3svgUgAyo8ZGxG1RrA2If+2XEMGIK0lWIM3IqFxfuS2zutk+OsJC1i/rCeA9cu/nAPAePktMyeOoQSsQV3v6oPtKcB1W6BrKL49BhCLvD5BJNpwKfFj25AnAFE2HI1Da1ux3lDElgQSAz8FvOmTQLCW4FxMEM7Y1RnvRWaf9sHm2tMF9CIuWtcIrCeA9cs3O/1Xt/NYO+SRftZ0WONwFrGGKP3NAZzUf5kJWJF0poxBqilBJAhV1cKdNAHVGJDaPDROAsQ0WjwHraU2IolYgCFYQ3AWb21MAjExiB/YYAfzg+XW/B/Wq4D1BLB+uVPwC4Ceg7OB39J5YCCKMYitpL3V3H9a6Wd64k9B9r/J/H8qQVSUYesq2rCpyv6eCpxBQTW96UgwIlolALWW4CzqDMEZvDP42ArY8VzbObPpCRfbGx96Puf79SpgPQGsX6rXQcC3V5ifdLNyRpgxbez90+gun7S2l/7mj2qqSqBSAAqV5Lci+5DagJ42XM32rYWE6pfbm15shHWKcfl2GhNCzz0oLYHL1UC8qhi0cWrmZq0PM//3knPUpdS3DkKvJ4Dv+dPfAGHpSI4yTn/Lz5ugzhgtjD8pJ38ss6XgAFMqP9aw/oyghnRy5/XgvVloDOTYp0/7BNgiEy57A2pRkXGKcRoi2KeZ/edNLvlNFCblliCBgoqxk/lxOxhsu+/1H9n3y7EKWH//rSeA9YsI6KDjZXaOrTqSSPm1FSU3Bf8Ul99UkmBTndapYqgVg/19shNwcga2rmAIWhaG2qQFMFNbg/JJHyRes5YgGIMXKWrE7E+gSaZcEoA14KyZbJx4mP0/r53fffL5EC5A19+D6wngexr486tH8Hg3kKeFDTIRm8Z+OXATAChry/w1zD+pcAFJIz7WoPf9/ePXIY8Qi6FILQCqCULVMpEyghSCCAEIJn8dK5TgIl05pEQQnMS2ACM6Q2hGo7nVpZmXI6KnrnNR1hPA9zDwp7eexpxBfj/Mi2pjJM/8KUBbD/aJMZEFuEbOq0UcJFVCiD19FvxoVQX0CsHsEuzSbVwF/NneJ6AkkYoGXK4p+IsWwJRrsII6iUnBChoxDTve0nbOzjzhlc3i95+P+IsiK2n9sp4AvueAv7B1D7/dzHFimJUWESvZ5dfFa0H+bVVKW4mvnAiSNwFLZQdWTwSSSEhsWhM+he5XGv9iAJq+NyU3nrYaK7Tf1OdrCnBvBW9SZWCnAz+4eFULzEDYgrZt84pXH7dv05Wg6zqBb83FrT8F37rSvz2Ghxvh5/1G04oTVy/tLMo8DCZz8NO+PiMG1CQWX57dZ6afgEZ2nxGDps8hjRQ13T56iyejEItoQ1YCxuWfBgmJ3Zf+X9VINda8U1Dj46j2m4VDEAJC0HhVhGBAAwTRWC2omG6r70bjwfF7r9cXX4j8HFzigG793bFeAXxPlP56BrMS+BOzycBIyomPM9V6r0rkU/rvXpDTK/kqVl+e9dcOQOTlIHkXYHwcU+7XlMfLSUGk2iqcuQXWoq5nI2Z6cmYAFkKQpKBPD6emrghIkw2xq4f5VlzzM78xXHn4hTysW28F1hPA98Il8v338DK7wZzsN5oWY2wu9yW78pg1Dj95tl+p8kQMUlUGSehfAr++n8g3oQgXC/C1q796d+B6Z0CP8teTCFPakugLYKb8AYKJQR8c4ARtBHWxEtAZFd0mls696tdSK3DBun3YegL4Li/9u9W72scNBvI8v1VaLE5NPbtPgJ7NNF5i6Z6+F+3ApCfwpLGdZEAQ6Uk8SftPZRJSE4nU9Ah/NvnIk4BAZATemSXYg31hKtgNKhQ8IN4mBX/5OnYeUYyoEMSEbb4dzLsTu+tnf+9CkQAvWn9PrieA777LBYnwc+je7HAm/BlbTdCBiNQEnczGW8vTNzI9YzdJIGTrpR+mZ/iZyuefjB/Uhp/93B9c5QgkZaeglO3AtQlINhXp7cb7ZCCJ+BNPfZ9PfxFUIBgIRlGTPhdQURTs5PCuNW74E88drT7hQqQ7b70VWE8A322XF50T13uNFvlzu0mO6ubECxIZfzad6jYCdVpz/tP83liHuHy7HPhoUQPWa8LXuAFJsQRPdt+F7turAbPzb0kc9VbhMgJM7YWJfX5uB0I9EkwMxBz8IX3u8/dSIggZhwTCjIgeHkLw9s+eu23piIsRv04QWk8A3z2l/zk4uZRu9WTzi82s+QG/QSaiWE0BLzau+dI0MhPbe/zF0r8334w9etkHINkIdGorUN3P5x59SkOQen/rSgsQH693/K19A9RM//+9+WcP/vUBH1mB2CoRZDDQamwB6nbAgiombA3ebnVHLC0P3vi8R181/DLIulZgPQF8d/T9l9It35tzGqsv95tp1WExBpP65BxAtb5/6qPNwGAvBy66fmunXYKLsMcU/wCpNPzTir9+m5AWp2DX04tNDy7Gkz+JfUpbYBMtOPsT1KSgngwUbF/2B5OCPn+0CkbxYP0R3WQw487Z97Fjfv9iEX9OnEeuX9YTwHds8BsBv3gGuwadvIEt0uisiFgRXOyZ+2DtA74IgaasvWvbbzt9O1sr9myl8JOqEujXfmslHirW35kqnP5PtdOjxwIw0rcC+etAmv3H2ymJCOQzC7CU/pkLoKU68FbwVlOFgOuO7FrV4XOfvHH1By9FunMiP2D9sp4AvuOCXzgPueg87GjMX9nNHBk2SisYQ5qlS9LOk6+pdJ5qASpTD62AtzppaCrfS7tQc/7tdGuQjUC1HvnZdPKbNdhAtSwklu29H0A+9bMwKIqEepuyCDZSBTslGXhDqgo0AoOJeyQKzCF6RBeYuFf/wBGrJ13Kw9ZBwf/Gy3p2/e+6nIOVi+nGp8uf2k3yaL+ZiSCuLt+nADsyS8+k1jd9VFvIPJKYNSaz8KRi22QgLzH9JB2pqpGhJ8Yi6vokgO1r8cTiQw2CRXPE5mDWJCtGCGpQrRyCEUImJqnBi5GAjSKhfF+NlmSBhAGQvm8UVYmG4f3mAGN24m1nt4136989/bRbz/7bL7ESn4x1N6H1CuA7CPTr7ssvDIby036LTLDicAYaC42JV1ej/elzqfv/6RVf+bahEHlIrL8+qfTMwOkpQo0pSCYJmbWbg2tL8co+PJORMscgG4Dkk76oA1OPL6nHl5gEguTSP43/SB+zZ0HiBWjaOI6KNUd3k8EWd5/dN25/FSIh4gHroOB6AvgOCf7VM3miIH/gt0rLIPn651K/sYjLxJ6e8FM0/mtkv9PAoOmpuFJvA47/fxEHJVS+tv6isgKTNY9dlorGR5lqQTLgV+jCxibU3xTAL8qCexpwCXyjiRaceQGJDyBKlxOCJDC0SBSUAC4c27Vm1j39YdsmL4x4wDoouJ4Avp2D/7yI+B+6P6c4ldezQ5Q5FQxCk8ZxLp7qZVSWHX7WjgNNbwPej+D63l+sTIOFUjkEZ0KPrLEGN9Hxt2gITAXyfTOfwco7QKtxZDb7UCfJAlz66iUHtDA18ss9v1Yswfj9iBFoxgPS8C8oeKc2HONbXPPihxzWPS0mAV1vW9cTwLcp4n8x/tCj2TGjcpHdLpt0k3hqso9LAW96wk9x/K3IP1Jdp8A+6fcCrJ0IlNO9QvfvbB6SXX+k3xYka6cP0xyCPF2QkgQy2GcTc7GfQvRsxb4FKJ8bTdWExnK/YgX6nAQsBKcxKVhQDzqrwtGha5G/uP/Ryw9enwysg4DflsEP6K1PZ27267zVbpV7+K0yIYijSco604t3qMU9YhDtBT2qSbyjESiLbW8f2BFQI4mA0kkfehkw5f8wBE2f5yhE0uPH/l3ybD/vCizRahPQl0d/afyXAcdgSi+vIuX3zrfPcmBF423K86QEJbYLKhEXUFCNAGEcJ1K+LyIEj9EtwVs1w/HNg7eefuzqQy+9fvSVhI769XffegXwrQ7+2H1fgN12rbzRbpKH+G2MERxOEuAnUYKfQT1rqtl9ogBnd9/UCmgluc19eBb8SKH+SmUcWs3rq1EhU+W+i8ShZDpSzEIS53960Ui61qNHE4N7Gn+Q6v80Oc+kE15i116uUgYWapMiMOWcYMAnvADTi4ZwoB7L9tDJkfaw1jf/cPrdlo6Iwb9OF15PAN/q4D8PI0JoP8Rrmzme0O2QCYYm98jYXjdPksRm9F+y428V6IVzb1IZn/v5RK2V5ARUtwqFr29NtcwjTQdsbw8WOQJSRD1USSCrAaMMWEqbUHwCpSceTeETtR2YIZGImA78Mq3UiOWnv0UTAQirhTqsoslFiF4vYEA7LNvb1u40d1teGb3r5JMPbgMJ60lgPQF8a4P/Ynz7EPnjZlae3m5ngsP1wR/7fqykj9USDytTAhopuEAMLpG+p5Y6OdSTgBzwlUdfX1msEQUlRF/smgUhld/gnSYPU6SialRpK2VgdiEWpvj9Pc1AEj0hmYRYgVQd5L4fK5o+pvtooQwHm/aWpvGg7OomZoc5fWVl7u93PvLWufUksJ4AvqXBP36YvMSN+NluJxMZ4MSmsr8EeX+6i6nsvSvDjix7ySe95KRQLwWVmAiMrbX70waiJciLeWiVcKoFI9EotKf9ZjWhiExxBrTeMlQtDa2rlKRKLC1CEfykazCalIDaKwETExArGjlIilhVtVqmJGp73QCmbweC4vSIbsJ2ezbX7rjohEdfNYwvyXoSWE8A/1OXyPLz7SPkwsGQX++OkInMiJU05xdHku3mMR8lIfRz/z7QtcIDcs8utgpYMRUW0N+37PSzmc7bn9rTY756YUhND656eal7filEH9YEebYD722+8hyfvgXIp72JJX4QLRZhKin4G1SaGNihEdT1KwhCqghCriScpglBSiwizhzVTewW+9gD1x33pjOe81kHJqwThdYTwH/7yZ+JPpNHmRe4Ab/Z7ZJWZsRijNAINEyBX9FjM48B+9M4Vwdi+2Aut8vz/imrrZrpJwWYy6Be0RJMLQfNCcBOWYZnWm+WFitS7qNW6M1JcwtAtfBj+lqSQJH/5hI+MwDp72eqyqA4A0lhMIdGCA2oUynBXnCCdPsmYgZixdmj/YTN9ge+/rF7v/nu510+SK/SehL4d1zWx4D/3pP/UrrVx/BLjeN3usOkZZTkcA0JpacKrnp1Vwq6PNbTFPiZ9y/9qE7UphFe4v8HSZx5kMr9V+jdgMt4MdTjvHxb1ugMsndgBBo18fvjSDIi/fXvlOr0xOfvlX/RlTiSdoImVJ8U9KoxAaSxZRzzUUZ9Pk4vVTM1OF9VRUXQ9Hgk3UCgGieaVPSjzh7RTeRW96Rrv37SX6PyFCQ/4rpuYD0B/BdeLskn//fz883A/L4/XFoZaGTFOFPZV/SkHCsGT5UEquDvG//ezDN/LyC9yCfN+CWJc9RDpuqaJMDRcuglezGVFAcpyPMRm/nCmnkIUuzHUYuGylg0VQYapAR+bwfWJxBN3IJoP065BgGf5/r5+xpRfp9+3oF4gWBEFcEHJOTgLwuD0teBkmzitzWGuMW5o7pJe1vzw8Mz2vFE5FmqataTwHoC+K8D/PLJ/3jzv5uGl/pd0jJSQ0Ckkf7Ur224E0++JAQMBArRByrFTArI8jn0ar50KvfVQyLtZCJQrBOi4i+p8rJqUNUgNIgaQv5/Ezkowe7x9vm2aqYdhdPXgSTjxcSgFsEDXjVeBbwoXoUOLT6AVMEfgtKhtChdeoyQRUSKBIjTAaQEf6wMlJBwfk3ZZaoiiJ2/s0d2k3Cbe6a9T9t1n5MfZz0JrCeA/8rgnzyB5zcDfanfKS0zakRFGNBv6Mny3eqU1Jqem05t8T2zrrDrUrmfE4BQVwj0QRsSIJhOdK3aB6GWBqctQDgI9f3yUhBTgrsEvSZwsUoCIbEBfWppRs0Ii2GSBvS5BdEkPxY1aIBJ6AgmxL5eFVHLwCU9lAWnsNBCCJMyfYiswTRO1L6TV00gYpYV07cHObwlKoUdR/oJt7gfs/drg/+0PDs1GIaUX9Yv6wng3xf8cdTXTZ7ErzVD8zK/U1odBCMapfUF0MtoegpqMTmIoKbxonEBiHqTSvTp07o/nfPhlTEAUwg9Gmyv2c+beXKwq60CWOL3kgtQTgqaNP8S1uASkq16Ten34+kfAcEJcN1kL50aViee8UTxxtI5R2cMXqFDaDUwP9yGmhk6AjPDAbcuHuSqvVeze7KfziijZoYts8ewcdMxeA147dL0QWNCCX0rkaAPDSqEoKKantMqQUAKcVEnR/uJ3uZ+Qs6azOqj/ulZXPiwbj0JrCeA/2jw+9Unc0EzMi/yu2hpgpEgEplr+UCVflxW9cbTnpb9z6QyzyCX5SGV+SGV9JoDMUZA4e1rvwZsqszX6lQvegAXvzZJi5ATBLavCDRWC1LdT/PgvdIaNM2A61YXePJHX8liuwKdR1VTVdNEwC+0GDugaye86FHP58T5e7I8hnd+5R1yydXv4OB4SZEmVS9jBkY58cgHctbpz0SaTQRt43OYc2bWERijBT9Qo/hkJg5VdaXxOQsA6jjKT+TW5ql84EEjfZ4+lT+WMReo4cL1JLCeAP614FeEFyFyIb49X17hhvxcd5i2MtQ4U3PpZLY9Ay7P8++06TqX6BX4pqTbZ6COSPhRTadyJsMntU083SMrRjUuAy2CoTxrTC4cGpJjD5EGrCFNCPIacE2VhwiGejpRYRFJnJN9AzX9ft7AnuV9MDmQ2oWZ+PbxiyAdMhjhFTSMWem8eAOv++KfcNlV74HhZggrYBXjhoR2hYk2XHn9h7l9+VYec/avYQfztBrS/x0nCPH5C6JGFAQJmjD+DDgmrCCJpIxGkRGCk6P9BNc8WT8f3s55t/8QF8riehJYTwD//8F/ASa1oWH8v/gTNyc/023XiQyIA3OXJK1Mi2FCSgKS+9dyiMVADfnE1jzWqsZ/eXGHVoSffCKrgU6qLT+mBHVtBebTYw0GDtwIGEBowIzADsEMoLPQuSTMbwitoW0zNGGQ0K8UK36A6fdofWDeDfnZez6BcTcmeME3Dd5ZnBWuv+MGLrn2E+A65kYb5Mgtd+HjN3ySy656N25uF76bcPpxj+CUox+AsSOu3fs1Pn3Ve/FY9uz5Bp/76tt44FnPYnHFR3BP+/wZklWYhiCaxUSaR4Ja7MYUTc83SJwiOI7uJsa5c8NtW9/FeQeezIWyj/PUcvG6inA9AXyT4JcLCZdcgFu9mr8azMszusMSt59szZcQ+tpwo6znjjPu/C+3ABGoSqdpSPfX+ueVlJd+fi8h/bxJ/XmXev4E4vkQH2PgDHbDCJpZDi7C1w8oX9uzyHULnn1dw1gGCJZZ7dhpHMfMz3PClm2cPLOF0YaZmBRaYaxUisLcpsRk1amyyc7yf057Eq1xrHrDqhgmA9iwEX7lfa+NxKHO8/DTHsnRR23mjy/7CDI4jK4d8/B7PI7vv9f/Yu8qTAgcc9Q92LXzeC7+x5cDgW9c/ylOv+8PYNw8IfheTiwKyVmIlFyD1vLinCxKyi2fxRYFJ0d1E7HuHL1j7j08Th/HxbJnPQmsJ4Dp4D8PKxfib/8Z5rdczZubzfJYv1PGWG0kcfWL3L76uoB8pselJI+nkp6/Tga579YK6Zfy4L0XAKkEl5DWdCNoE9sDRQidYdhYcA03LTTy/uuFD962zKdva7nxwCJtN1YYgLg+agTAAxNGznH8xk2cddjhPObwozl7x5HsmN0MXljuYmmd/f3ISQDYM15kYi0TY1jxDheGfPqWa3nHV/8JBrPMmpE88u7fx82LB7ll4VbUOmaH85x9r+9jVVo6O6FTYdIpR+46hUee/XO0oWU0N4yjxeQbWE73afikjAF7nIDpbLD20yAExXFENxHn7q+3+0v4/tUnc7F8nXPUcal06wlgPfitXIw/+Fy2zR7k791WObvbyUQcMfgrno7QC3ekavkVwZiMTBs0WDQkOa2Y0haYPM9P5bYpJh/9BCD3/5Idf4jOvqjBYxlaC7MNX7pJ+LMvr/LW6yfsXswjvjwgtxJBSQUdg06IHbIDcax2gSv37+fK/cv85VXXydFzQ3746OP1p+52P47fdDjL444uxLGcB4KLY0BDuhqHBRrjeOPl70T9IngjDzzlbLbNbuPKfdewMl6EMGbzzFZGozm6LuBGjuFgCA5WPBx/1wfgLTRzsP9QwGtLsKY3EUlBH5966XuD3PdLdhSJ+ABVWtVI3E7YCE52+YkM7D30Ri7h3PETeL98bj0JfI8nAD0HJxfTrfwMJ7hl3up2mtO6bToRi8OmtR5CUezlj5lBp9WPTGK+CYIb+gjOecV3MSlEpJ1+TFjP38sRF28TQUJTOAGK4L0wnLfcsjjg5R8XXnN5YGWs0KQ3euiYa5QTtgy5987N3HXTiO1DS6MB75VxZ7m9bbh6/ypX3LGHaw4t0nYd2AE3Li3r711+GX919Rd47qkP4RdOP4cNYYa9y5Oy+y9k+TKWLsDQzvD526/mozd+AjFDGTWzPOpej2Is0LZeQ7cE2iHqpWuFDkNQz6eueA/L7SoAK6uLtOpBlKPv9mgGWw8HuuSOVLEH0Z7tKCXrxp0DOSdkZpBoP9o0CSqM3GTHjq4V647Um/kQj1p8Kh+Q932vJwH3PR38l9ItP5sHDsZykTlcjuy26kTAFS5NT+pLoz5KKa+55k/IfJe8P1sPn7l1OxMdsnM04eTNq5FiG/qJQAYBezBQ8uSrDL8lsf4Qg5EGNxL+/krh5z825KYDirGxnCdMePARI84/aROPOGLIcTvmGY2G0GoE/oIDbRSG0MxCM2JhoeOqW5b48O4DvOW6W/RTt94OxnGg7Xjx5y7h7TffyB/c/9E8aNvx7B13UfTjpDACNQhi4A2XvwPvJwKBs087l+OPOpKDY89gkMx7xWBco8YIbRC6oFx2+XtZOrAHnIuTATy0S2y7y+mMRkegbdXfS99OoRqrorr3lxj4SiJNhpKeydCAqOT9g9BhZWfXytBs4brRO/Tc5R/n/fI3ERMgfC+yBr/nEkBN8Ol+mvOkk9eaXTLnt+lEVB1CL8VNR3sw0qP8CaCKBUFC5tNozgjsmwx4wt+cyb69M/zgmTfxlqd/mcmiwVotAZ/HgITpkWGfGHpxj2JpbcOLLh3w8o83MDRgldCNefLdHM87faM++LCBuOLl30GXkoe1MEg2RF6UtoVOmLMDzti5lTPuchS/eP/T+cev38LvfvJTfPiWG5CZLXzpwB08+r1/wYVnPIYfu/s5rKTnILYEyszMDJ++6Wt87BuXIc2MDs2QJ9z3UTIJHttYxfWZU0yDGYLxgYEIWzduIoQxrpmV1fGihtARjMU2BhlE5mAgMf0kagCCimKkj05VJCQoVeIcJVOJc/hLqahCrw8yAl4tW0KLEcP1M3/NYyZHc7G8NGaZCwxcGNYTwHdr8CfivFyM757LL1kxv+93od0m7eLJL9V0TgpBTgp1P53W+XjK9X+ayiOCDGCm6RCzgtXlSEBL7jcS+hNNSOShWh0YyS49B1+Fwcjw+/9sefmlAwYbDJPVwGlHGl7+sO08+igPk8BkoopVGAxkXzvkqt0tV+2bcNuhRcYMGbiBzlk43BpO3LSFE3ftZHZ+FhYDYbXj3GOO5dwjjueN136dF3zq09y4cAgzcPzGR97K5h1befJJZ7FneYI3ceToBvDGKz4YhU6t8uB7PZijt+3ijqUV7HAGH9KEXj2+W6VFscOYKB//yJ/Hd51s2DjgTe94FTfd/BUEh2lM9Abo+tM/9Vtatgil+X/hAVVYYOrHIiNI0nOJJlWS9uWEEbRTy6agciItNzQv0cf6I3j3i34OuTB8r3EFvmcSgF4QvfsQdPwz8go7Kz8XDpNWI6/f5LG6FLPNyn9P6ndbJtUkDF96JRyimOxvlzjsWInYWzLayAy+yg9rSvknOQGIQdThVXjKPVve8tXAZ26e5xcf0vDi7xsw52B1QRkNG/Gt8JarW33LN/byyd2WGxYmGsbLEEK/5UdbgTHDwVDvtv0wHnb04Tz52CM5e+eRgGMxCE+995mcc9yp/OQH38m7v/YlnnS/h3Lu3e7JQjtBrKUFZjYM+fyt3+Cj13wOGW2kCfC4Mx7JskfVGTqFDfOzDAczLE9WWVhdgWaCdbMsdzCY2Yr3qmbW0SEgDrENdjSTjUJSJ5T5fhLLDtODghqqz3MvINVMUFI5ltqGKB/WXqZoAC+ic8HI8YzlBvtcfdxvHsXzf/YZXCgLnHOJ49KHdesJ4LtszKcXMN/tkb9wm80P++06YRisiJSxfD7psVrKfzEUaq9kiWyy5bYikYST2HNkFxz1gIuWNy555wuRB7BW7FMscJMlWDUOFLH4YDhmh/I3PwCfuc3z9DMb2iUEER1t3igXfbHl5Zfu43M3L0la9BkjJ9h4nMpqymgjYJZxG/jS7fv50s138MpPfJpHHH24/OoDzuGRJ96DQyutbprZwN8+/mm8+sR78MR73J8hQxY0EKylU2E0MLzhM/9I102gUx5y2kM57shj2bsyxjSG1a6VrYdtZfvWY/TG26/n0OIiX7v+Cu57nweyeEBwRhk4xw03X8Oe3deCczSDGYabt9Hho7FJWgOYE0FJxLmHS92AhhT8dx4BqiZGgBqVzL8o98lAq0d0GJwcr2Nzs3tiuGLL+zlv5WlcPHPt9wo46L4HTn4nF9Kt/AbH+31ykdsq9/GHhbFaGkmOtFKN+jT1+sVyO4/pq7I0QXb4XIjW5WVCyjEuLd+w8ZDXZAmWuP6ZZCNkym8k/8SvbTnyrBja1nLyTuHkIwLjQxOGQ/jGwRn5+fcv8q6vdslNqIHJss4NLffcuZnTjtjKXTYNmQ0tPoge9EO5/pDnS7cf4Irb99GGZdQO+ND1t/GhG/6Bn7jvzbzsEY+WUTtgxav+1H0fyv7Os+Q92jS0Ksw0M3z+hmu55Ip/QpzQBOUJ93sUnQEZxQpcRXEzQ868x/3khuu/rHZmhr9//2tZGK9w1DF3BwvXf+MGPnLpGwjdCrQdR93tvoy2buHAeBzHgAXJT6e2jbV/SIYCZSBgpGIFTrUCJQUgufXqKZqS2IXiQFsRtdpw124ijXuA3iKXcd7qj3OxvDsmAfx3Mzj4XZsAFIQLsHIh3eR/c45dlr81O81R3VadiNBkn36p0P66BYhMv3Qq15LeWuE3Re2NHFUxBmMdSJNstdIb0fQ+AD2ynduBXhdQqo1qkYcxhlYdvjWMRoYPXjXhWX+/wK1LDXZ2gF+Fux02w4+efhhPuOsGTtyxGbdhLrIHl0N8mZsZMENWFuGKG/bzpqtu4o1fvZ7bDoxxwxF/8clP8onrv8FrHvtUjt95FLsnK4gbgLN4bwkqzMzBX7/jbXTdQWiFs077Pk6867Hs78aYRugUjBE9NG7lfvc5h89/5TK55qpP68rcRt7+gdcwmtuOimO8tAfoYLzE7IZd3PPhT2YsIdmBC2vZPtoHf7WIgT74taZgS/mBVE+zpNZBEpW4HxuShUSOo7tWnNupNzRv53GTn+Nd8qeghgtUvltxAfNdeuobALmQbvwC8zTr7QfMLnNUt1Nbseqydx8ubaS1JL9+gSb27CZ/XXv3le9lIZ2UfX3ZEFOsIOJ6tCrdziST0N7FtzIIzTN22/vt92vE49VYwTgDowG3TUZ663KnmFUd+iV9yWO26md+5VT9tUcfyym7ZnC0sLIco2LjHGyeB+eUVa+N99zvqJ38/uMfxmd/4en81EPuRTdZArPM1ftu0H3aqZlrMEOHOkswhs4pMxtn+Pi1X+Efr7gUaTYwHG3lyQ99PF0D3oI3Eq8N6CCozDb6tGf+st7zPg+HSQtdYPXQAcYH90Lnoe04/JhTOOdZL8Aedhhj7WBg+p0C6XXRbAoav9badpy8TbgBSdeo16j8BEWU5FRML3SsjFrT4zkAsRzRdXI3kKb5Ex7TvgyRwIUSOE+/KxeTftcZKGZm3wWKeeGvyUvdUH6tO0wCsyEk+l0y3azeDP08qaj7yvqu2v5K6H34ajuv5OHXoNyxPOCMlz9UbrrF8eQzb+Ktz71OJytDBkLU1gdbrb3J8thU9gdb3tGi0TJXtSESiRowDSE0NDMNr/nIhD+77BCv+aFdnHHcZiZjw2Awgpk59u7t+NK1C1yzr+NgaLBuwA5nOX5+lrvv2M7GDZtkEoyqGTBs5nnjJy/nhe9/L3/45B/hMfc4nVtXlwkMaINlopZJMHjbcOOhvexZ2o8MG2wzYuumw1gOykSgE6VF6ARaYBLAG4s3lquv+So3XPcVDi4coAvK7Pw8hx1zNzYedw9WjWW1XcVbSyeCT/6BHdAitApeoA3gQ0RXOoUutWBe0sekWQiJ+exTW4Wo1O2EhoofUAwLk70YgnYJOlgh6LW20f3+nRy2+hxeP3/bdyMuIN9lJ7+TC+kWf5tdo0V5rd1gzu22aMsodvZqtC/5zTTNNyeA+L1+061kWaxUTj7Z3y+rVLAEdTQauOmgkTNf9iBuvbXhSWfexlt+/ibtJiOcgHopCUA0tgmoSV586Xvq0FiexKDPx1xJGA2qDmeHLIV55pwyWfYM5oZ8ZXfDn1y2wLuu3MP1ew9B21a1seKGcMK2bZx3+iny0w88XXcNN3JooWV2NMctY2HDcAMronjjmPiGiZqYBLCsKkjTYIaGCbAa4MDqhBZoBdooXIxBKzABxl6ZKMhogDTxe8tdTBCtwuJqyzgEvDF0QJdXigOtxvt2EnUIPig+iPoU/NMJIFqR+RC/F8I0n0qD9AKhEvjJIqTYtEFZXOhT69fRcZ0d6K3hOobjH+Fts5d+t5GGviswgErD300u4IFm2fy1PUyO95sZixGHRBMPIZb3dc9PPeojo/49D4B08hsx/SyqUE0lKfOS5n4kbAoeTe3icDDAbGxksGC0nYSkHKycfXOvbypdP3kUaKORR2+4X1mAWToMMwNlQoNsnOH3PniL/Nb7bmNhxUJjswG/EjoIrWDQrhvy1b0rvPi9n9bXXfYlXv6ER/GD9zyNg16Z3zhkJXTAAK8Gbyky5ZCmcRNaJpMU3CLoIA3p06QkoNEbMMWSmtgJTfyESaeMgXFQWk3uwE1MfAFNrsL0zsJJTNVP7yKYH6qJXnETloL4p9eFZCyacECnoqF6s5j4C6qJGUJyJZBGh9iYYdSok7v4iQztXfSmwft53OTnuVheDfDdoij8jk8Ael6cxgE6ucD8rLXyf81hOuo2hIlgmrKbTmpCTxoDiRYpb1mOkQGoPA0owS+9vXaVBLw3DGY78IYv3riND12xg8V2A2bW8pW9O/n7j8F9j9nDMYcvwVLDpHU4lzz9QoIK6O23JZt1FvsuU2y/8pocSTZfbVCGG0f88fv28vyLbsVuGoEsQzvhPsds5z7HHyHHbphR7VquXViRT16/oF++dT+YwI2Lizz1NW/ibb+yhe8/7RTuWGwR6+hC8gLEEpLXQPHqQ4r+PgPuUTmoU7bfsapOtuBZUJSsvnLq8+nnyQBY6s3HMcizO3A1+zdUJKAaLOzH/5KDvFoPoJkjEKpWQPI0Jmo+JPQVApIpR4IqjmN8ZzZKo1c3r9JHtadz6q2/yB/KyndDS/Ad3QLkkv/A77N1/pC8ys6Y8/w2DTqnwSgmWEmmNzHYTXarja4RCfVPRBHpfeam/Pyz1Xey5dKkyRdioLjRmA99fjsvedtJXPaNwxhPZsEWrjC0LYfNHdQfPGsvv/74Q3LUZqVbbVQkmXuoRWQQP4Zc/jdpA0Ys9+Nt4ueS0S4ZRm9BM+TW8Rw//Jpr+Pjl+3nMvTfKr5x9FA+563aazVvANDFxNCOWF9H3ffZ6+e33fYrPX3OrnveIs3jVM56E+IaJOjoavDpaDK3aeA3CWISJxLJ9AoyBVmLZPUFoRZmksr4ViVdgVZVWhAnx1J+U8l2YhOgQ3IrVTlQ6tCSKLj8WpL5e6IKqT8mkv53SKdX3iG7DGmuwkqwyYSiX/OQpQCILhcQhCv3X+JSwfEo+oLJC4Drb6F7/Web8c7ho+Lnv9JZAvkMDP6P8YfJS7mcm8ld2q7lHtzG00iQBfWOmQb58XxODP2/Lgn7eX2y9hMSgy5z2vHwjcvPjCe1wo8AFF53Kiy8+Bp2M49htdsBhW53MNLDvkLJwYAISFBlw9I6BvO6nvsHDT11kcsiqtdnmexCJQ6GZ6vWpMABNn4s0aLq9qCV4S7NhnqtvC3zwq6v89EOPhZWxtMuexo1gOAtuBsbCpDU6mJ2XA6ueP7/sKv2xh53FBpnl0KrizYAWixdHh6VVwyQYWjVR4UcM4EkOaGIyyD1/S7pKTAjjFPAThIkorcb7dQnYa1Vppe/nuxi4dCkBdOnxfAL1ugQAxqvgNVqRd0pJAip58UhMAKEmCIU8CpQyNoyVQvpeBgJ9vq0UPIAA2sUEIkE6ucUO9MawqEx+jnfNvPY7uSX4jksAehFWzo8cnMlL+QWj8jt2q4z8JiagDiNlhFQCOx/i+S82WtF6e9KPIgX0K8yzNDPqFYCGEBzNXMsL33g6L3nzPWGwzMAv8rSzb+KZDz/I3Y42zBjljn1ePn5lo3/yj0fymet3gTQyZxd4/6/fwINO7LRdaTDGISEGfTTuTElAXTzxq++LpKqAASKuVAShExrjYHYj7dgiboRrRnzuq7vlM9cfZDQacf9jd3G3w3fo6sRgZ+doZuZZPOQZd45gGybB4UnBj6VTw0QNExUmRIBvQgpodCr4xwqtKF6EiQitKqvp552gY1XGinQi8dTX9DGJi3LAB+2DfwroU9FcIeRgz+1Gp6kKkLxZSEosB+2ZgpragrVAYDm7Q6oAMhCYE0CuBnzKNJ0gqJd9OL3Ria52r+GMg7/ChdsPfSdWA98xCUAV4fzo1Lvyh9ylWZZX2A3yhLBJAjPBq2I1ufT2Ut5E+1rj3FNeH+lP/2kucG35ZSq00ODVMZjteMfHD+eJL38A0giHbxD+9pc/w8PvfRuMHbRNBPQMMAi0k1n+998dz++/fZfQLXPC4at88uV7dfNACJ0k9D+f+q766KbbAZrkR54qg9wOqEW1IWiDcSPGdo5fe8OXefWHvybdeAIC8zMj/fUnncmv/sDZjFeFrhMCDV4GdDS06ujU0qmjw6QRnEkBH4NxjJSTf5JO6ElMDNqC1JVAvK3SiegEjYlEVPJoLyeAqUBPJ35JAKr5tFefND11AvB1oqgWhuQEoFotE0H6kqD4jUc/gTINSB+loI3pez61AikDxd0OBFYlcIsZ6B5/JSY8l7cNLgX4ThIUme+YU19QuRg/fjFPaxbMp+xh8oRup7bMq2Kw02QQ6RNBqgTE5UWd8eeaST2FcGP6asD2q7n7a1yNbZ1hcXnEC954KkLLMLS86Vc/z8PP3M/qoVkmk0HUvmNp/YDJ8jxWB/zeT1wnz374DeANV988zyvetw0zbyPIVshAfTWSF4XWV7Fpr4BNpKH8uzuHDBpoLG5+wF9+4Gv8yVs+Dc0Mbm4Tbm4zSwzk11/7QT58+Y3Mzs6gSSqszkb+vTOoM6iLyz6DlWglkK6hWvldVnX335PgiAtBbbIhyFejkd2XiDzBanpc6YudsgW4/1oTUUdtgUGyoVEkcFVryLEkklbumCQ9jhaijxgtW5vj+0J7i0XX/01xY3F6fKPxfmVJaXq8RlFRoyN1HNdN5Bh7qmD/kSe1L+Yz2nwnEYfMt/upn0v+hT/lsPZlvH4wb/7W3sXs8Nu1lUZsSBwZmmigWd5MFfNLXH4z9YBf3oYrZSuvIM7EN9Iaxl6W8wYEOxP40OW7+Mot21Hv+JHvu4GzT7+V8T7LYChYF5OHGMFYg2tMXJ+1CC976u0ce5QizVD/7hMDDh0S3GDNVt+poLdIXuddbRCWzBa0/WpxtYJxQmg7HnfmkZx8ylHSTUL60wK6tMLZ9zmJM046kpW2hcbFJOCkMBCz8UcMzpgAfA7kFITB9ddcqNTB7630wW+FLnU4cRtwMhZJ91E3/XiakkPZDFw6IukTQ9oonBNVnzQ0JfUYwIXduTa55J/Z/L7oBZNS7XoQ2/NC8przqOxMSlFXhGJOD/etnAQy617IBd2lnL94r4gHqHCBmvUE8J859c/Ht7/Lo2YOyifcdvPMcKxpwxb1iNjyIqYXvlBtc/CnN0HoF+8m+m1/0pNebMkJIieFHPy2D061Bhx86PIjES80w45nPvJ26EwUlgjpthY1Nq7wTsmm9QPdusvqDz94UdV7rr018OUbh9iRQ8VN/V8lIVjTU4NTQtD8+zuDWBvXg2fDEmMJQTjuLjv42+c/XOdHhvH+A4z37ObonfP8za/+MFvnZ2mVtAI8bvktll8u/n/BmRLA5dS3QkiUXK1P+BLw8dTsjOKN4m28Bit0Jq779q6+n6bqoKfthnptuIPQSNxT4rQkgZCC8E6ViZN0aiN15ablPULBhvokP50kamU2NlYMWiWFXDmI7X8uFkCtzgXhWD+RXe4BsjzzER4/eR4i2lcD355ry7/teAB6AYYvI3I+/uAfs212SS40wnPNkeA36UQkOIXkhSdren2tGHz9Uy4Sp3IhHaJ5jp0xAJM4AL7q/3s2oC1CHWsAb/nyDQ6djNm1bZHjjmyjoaehwg3SPD+v7RKLiRtFuNfRiyCObhWu3+s4a2DRVU0cgGnMIVuGR26LIRRLMVP1M/3OPzUOYwe0i6uccdeNvO+F36dXfuMAXfA8+LS7ccy2eRYWW2QwwKsQ0igzJJJRKPN+TbbcGSdLRAvWrPKuvqcZsU/LQUPVp/vI5pNOMs7WcwRCYinmteE67fUfN50lfkZIYF4hGmUUS+llgdkisTixppc64wFp+3DGfTRoeq9ocXyOXOJUKSYMqdzOkw0gCUHTeyuBik6dHOFbmbfz3GpeqY+ePJF5fo2L5bPfrpMC92136ieEf/UPeKKb2D+w2zmumw9eZ1HAxXJMMgN32rizgjXLm6Py3JSpUV8i/uQtteV7pl/6If2KrCzjbYNwaHUSTThnYTjrwAYk7dzTvLEnRBafFBpvfLzRUOLp4S0r3sZe1IR+c4+kx1E7RTrSalegmryYM28BiiNLEUtAMGJplzsedPddPOiME0AGsBRYWh3HDT7p//Jp7Vh2Di+BrWnMBiUwA3ndd+/MExJQ1xk0IASvBT8L+XGNpvXipI9abfapsGjt5/b19l/NewHyfYJOJZ2yTbSMezQi/slKSCogsFiwJUMR0f7wkMrXvci+TXoSjCA+To8kBX+UGUvVqya+icfq5hCY0SC3N49gt/+YPn7yWzzjbS/nfPHfbpMC9+0S+JxPkPPxy6/mmGZRfts18gy2C34+TAR1SFrLRcXgM9M23ZKWSSh5xp8yfi34yQKf9KYshp/Z0iuvxi4rtaTYcwVvGIw6tm+00Myyf6wsdbNsnkussV6G1lcBxN4ghKg0vGN1DtiIDgJbNqyAtIhz/Zov+r2BVNTfskEY0+8OmEoE+Q1sUHEYaRiHQFhYAW1RM4TBsJz8PkmNI3FGiruOT+M2MCkp6BS7z+eRW1zrHSdkpDXh9FReTXFSVokb8BqS118FxtfU3priWxKSijdxOaiisZ3TPuZCxRYsxiw56isrcSkbhnqdsOb/KL83AqUaKCWj5L0KfeBnM9KcULI7lKb741W0wXK0b9moA7mteYm+/smP5wcnv8rF8pFvp2rgW4oB1CAfinSv5GeHq/JJt9M8wx8jnd8cOgwOJzDQ0sdJmfMr9TYrTXZcEdCZRoUjgNMj+1HiayosIPbYoQLbNMt2rUES+s6s4d6nBGiG3L5/ls9fMwtDxWMRa8U4m3Zg2+h8a6upglc+9AUDrWdupuWko0J80yV0H5sNROLvoMak/YOCGocai5cYvN7EoPdlbJ1WiJn4/6o1GGuwzmKcQ5yLZhvO4E0C/Zoe+AtOYj8vPaCnFQDYTwYS2GeUYKOsLlnwiTc9XuBNDPpgNKHq0wh/xg60evx6IoCdngYEp+XzvC4xS7hr7GAK/6mrxUoGLPXPy2MqZemrlSgrdr2lWy9Rzt+vwUSJ4GK+XQMMQEWtbpLAcb6Vo+xZdPYSHtf+Ic/R7d8uIOG36j+XGuSb/AnnhFeYj9gN5o/lKHN4t4NWR2qwYhiSltxUwM0aCW95ISxIHv0Y0iiPvlooQd+DfBGx7782BWVPoz9rSyIwDtCGx511B2bgYTLhlW/eGt1/HBIReZEY8BZJCacNhuFm4RNfHvCuyyzCitzz2FZOOKaTts2/U0oA1hKMjQGeAMWmceJGVtyslcG8Y7BhwGC+oZm1DGYtzUxDMxrQDBuca4DItW+9MtEowmkNeGvwKQnEQDa0BloCY/WMCYxRxhpYDYGOEGW+EqLaLwe1TR4ABXyLj9ERaDXQqqfTEFd/E6sKFU3ThnifDAjWU4bwTaYE2qB55BesSBFNmjjAF4nVtEoSYRkfDURNP7Yru08zLdxKOTzolySnIFfEaQGFs79AcY6y0++3OnFIDv4MEDalELQc5ls5XkW2ul/gNv85njx5TgEJz1H3rQIJ5VtR7uc+f/Fv2DWzIC9UzE/ZnWL8PC027b+yNTd/7SaeyqaratnLXri8sVeoynpSn5zL+pj/MupfZL/GpBXe/SrvqT4cgwyGPPIXTuOSyzaABF7+vDv41Z++QzhgGY9D8vNzGnEAw2Be2LN3hkf84hFcfh2iy6v87YuFpz3S6/hgwIpDZEAIDSE4hsMmUnh1wGQxyN7FhoUlw8IYlidWvY/rvxvrGLgBo+GImdEsM7MzzI+GzDUjbDOAwSyYIQTL6gQWW0FlgFdLkEj4aUazGDtgHKBV01N+I+kNb2FxAvuX2yLNzXLfwtcXwc5YVoEVYDURhDwxUFoDix0sLbcEIz3NtwIJfaXx77EFSTycRAgKkYPTdUoYOXQmlt9eo19AqN7QqqDLoKtdYvsl5VHeOKqV5Rip/E/gg/rMCJT0tRayUNEG5NvUv3RiE2oPoBRSkbYacYQgHQftgD2gi+H9OP8bvG0QQcJvgQWZ/E8GPuclbEix/k/Mj4mTF5ntHOHnxDPSED20NHnLUWy5pl15q99ceqRW19Y1IlPX0vdLRfclO+/EYiOk/l8qL3CtvMLy+u3BrPCpK2c55yfuzkQasCN+5anL/PozbpFNmxfycZa8sRsu+9I8P/2y7Xzx+llYCTzuYa28/aWesBJUFII3qDYMZkeA5SvXCB++3HLZVwJfvmEst+zrWFkJrLRK2wWNbr/x13JWGFjDwAmDQSMbRwO2zDvdtmWeo7bPs3P7Jo7aPMtpJx/Dyccfy9gbAo5ODYPZGT7+mav43BXXMZidpQ2BLuEDrffxNB+3HHn8sZxy1r1Zbn2yBo88/klQJtawtLLKFz/0CSaTltZGoU/cpWAwzjAZTwgb5thy7oPREPCSGX1SMIdOen5/pPhmWn4K/hh7dEFph47J5VcRvvh1dGYUFYm+Q0MboUI7iI4kdz8BPfk4dMXH5J+Yf71VeF2SJtDQJ0S/Cuq0vKgP/tBnL41BHSXFPkEOXtJt8+Okn3eRQqlIoFWVPa7hDr+qQV/B7Mrvc/HG3f/T+MB/ewKohTsA7V/yJLNqf81sNPdnm+LndBLJ7hnRT3LNKe5+9dtmxWbh90uF3NYJgOLiSxXUmhMC1cy/Ovn7SUC6rVaLARIAF9Ti5sdc9J5tPP3/nEprZkAdJxy5wOMecIecelJgvjHcshv92OVbePenNjFeWYbljvvcO8j7/6DVrbOO4JMKUA12dobLLh/wiouWedcnV1g6FEeQva7BJHGiVqecJslsRuVCvwzUewhtPLoOLvOMH3kEf/6bT+OOg6sYO2B5omzdtoUXvPwN8pevfids2QhdG+tcDaBdfD327efMJz+GX/7dX+DgwgSxsUroiIYfOtNw/ddv5E+e9cJ4HxUh+NSeNbG1CS2g+uDX/habTjuOpaUWNVKEPz6d+EEqsU9k3Wo1VpRM+W2NsvSjL6G7/CswM5PQQB//fwLSzIgeGsP/Olfl159F2DuJhCrV2kSgnyVOXTN6WakH80meAZfqc+3ifcTXt09TA99XEXgttGImBUD0sojT/U7Y52+C8MfsWnw1f7714P9UInD/rYF/apznA7Sv4aHGy2+Yxn4fO6Gb1xarRjSt4soElzozlfl+ivyy+Inydfbj78X7lNurrBntJQMIzeu9S9LJ8//8aW4TpGoP+n1hRmG8OMP5T1hi0/breO6Lj+ea61uuvlr5o69tIyoRLUxWYgJxK6ATnvxo4c9eMNHts0o7ibFmnDAZB375FSv8v7dNxC97mHU0G0WjJj6kNeKZx54/F8nj7JwMMX2LE5ucAS7u7mDrlk3oIAGBqQ9uURnNzmG3bsFtnCF0nWh+pyoYa/DAzIbZ1KvHHt6X8j8CXwcPHMIMBpi5OUIXej/+6MCpxgzpFla5+k3/yOn3OQ5vFE2PXfn/32nEGJEDKYc23mO3DBi/41N019yE7Noa/QVLgo5jgEzCYt8+CYpKYyg8gcDU+6kX/WhPGMiTSZNPb7IFdHqPaN+Kunjf3Jb2FWmqXmtOQch+hYJ0oC2WjRpkYxfY5o5ir3253r7xJ3ji+MW87aVvQMSjKpyP+e9KBO6/O/Anr+MMGcuvWivnyy7Bb9RWnQpBbATntPTkkra55icye7tT+cJXT31VvyTPfqkEPkXcw/TJXzgDksgzUv3/cZSX8QNhrVAoO/OAtUK71HDuQ5b55Buv4VVvmudN7x3KtTc7ltoRhA4ZdWydn3DmqZafPK/jiQ8TaB3dWJCBBdMw0QE/eOEK7/lHj91scRsheKHr4t9ZexLG7qh/g+YwL09E/jtUCdrf0LdjRk5jT28iFyIHtFePbycYP6TzyR8LioLOewO2UWmgM7G095UAhwYO7ttPGI+RkYv9r+SFHXE+EXxQmWm47cOf4JZPPIgND7g73dIErKkIRTn4+4QQXYZi/MURoCEsrrL6Nx+Igde21fKTqgzMxn97DmDaFh2Y/vTOQZn6ftUkDc8EoVBVkFrjUIkCnPv7zBlIv2Ac/8UEUsbOWXBkejxAU2VRjEgjy8rqls7LZvGy357IHfav9Qde+NM8+YW/g8g7U7MhnPdfnwjcf1fg6+s5KYzllzDmR80xDMJG7UKjio/u+AymN+5UG916pl4F9uXgjWuf8+qnEgnVKqlK4CNyJwSxPLaRqkJI5nGl9KeQhHIbUdoJzUkiEm/aBcu2uY7f+Jn98otPNVx1wzw37e3oJoa5mbGccNRY73pMrAi6RYdgMM7hvaGZs/zUS+E9/2RluN0x6XwawucMFlQ1s83SR1mDjPYu2CX4NQ+7M0HGGGbmBkwIdMm52Ct4a6JJjyoaKp/sUmHFJz8Ylc6gXXIt66oq2TWwuG9/XEJS+C3FTyf9PioYA+2qXvfad3CPB54MTapE8vYu8jxfygKfukKnC7B1wOrr/pnuyqtgyyy0bZrB57JI+i2r1sCBBWR5CTZsJtAlK6K699ViF45Jen+TJcPV01ExAcv0yafkHHImTO/B3O9Ln0yyBVn8WSI9hd7EQIMiHkFxeljXySbUHHAP0D28Q5/YvZvB5P9ysVzKxf/1ieA/nQAuugh73pVo7vHHf8u93bI813fmf9mjzLzfFIKf0VY7bMTEpHjjBZQq1rMzVDp9e0poKuj7g670/z2I26P/PbFHqgSga739C2W4J/tQUYRlTQKJe8UidTb+nhZjHLYx4FX8KszOwr1Pa7n3IK6/pmthEvBjwQfBWoUQopXXBuUt7/f85cUdzRbHpKu5rZnZElLQg28DtF3iw6Zv5vamDCqC5mppStzoRmzcthl1li5ZjAcVOmfoCjS+dsNG/8J4AhMbx4Bqe+C7dYJ1sLjvEFPUHmUKp4gBFJD5OTl42eW675++wNbH3IeVQy3eRgp2oQjT24rVhBFtLOHAMqtv+CCMXOype5SIwuJJx7IagUMHlb370e2bi+tPfp+QgOa+w0zbiFTLqU4iLskUkaxqP73Wm90j8KdTlMoeAwjTPGrRZEkedLoN8WIYKXqE7zgMZJ/9fm4dfT/ndR/Qgb6SN8q7YyLIGMF/jlX4H04AehGWK+McH2DyV9zPdjyP1pxvjjHDsAn8bGgJaiSIlYa+RC9BfmcMMmQ6dlXgFjs4Kamgeo9qhfSnZR/TDNOpYJbe6K86RU2fqosRaFILShwFhpoSTCTsLKw2HFocIniC90m3P4wrwTIYh5dNc6Lzs0IIsXJw0tC2A373jSYS0Ip/VfKeSuegSCBMAnTCtsMcx+4YsmnTiGY4UoyjC9CNOyarHSsTz6Flz+LimKXlluUJ0Hm8b2HfHmyS+wYbN/3muX7IvLv01IR80lWVgI9035gATMIb0YjmAwt79idDTe60pie/zuU1sUZu+It36fwjTsO7GPjZbxCtXl3pDwW6AFsc41d9DH/1jci2OfABEdMHf/yoZY2wEWVxDHsPxq1oY00gbzqxM74UKv5/Yvj14HPs/8sIMff4FVaga+nmmYTomQ7+ID3dMfQ/k5C8DzV+Lq64F0X5yFG+ZQeGffZRcgeP0vO7Sxl0r+Svf+dtiPynE4H7DwV+ou0CTP6Gh9hWfk6N/IA5VpzfYrSb11aiysRi0xKOqofvqfuJ1ltpOaSe8km/9y0H/53GgEol5jDF8MMkUIkaG6Av68vXGVyscILS80vmAZiKLuzwwdFscPzm7x3O69+8QYYbO7pgkxmBItn9UgO+bbn4Dyc8/EEd3WIEEgezwpeuMHzhqx4ZxjFgT1iPic8YxY9bjtk1w0uedwLnnLGJbRuHDIdDsc0IzFC9xt+l7WDcGlY7y9Kq4eCC58Bi4NCi57Z9K3z1K9dz1+O2cWgyiUnAxJhqTQ6dCB5k9uw0vqKIiHoTdf5R1xZdfIIRVjwc2n0IjCEEH+OkBOYUTAMakPk5lr7wDdn3oc/ppiediT8wQaxDiNPNKMDXvP0vBseMpb1tgZXXfQCZb+KEo3QauZRLlYckoMQY1Cu6+2B6/yVWYFU3SDaHyQhe0Om+M/RCoJgY+seg5pzUrO2+C5rGCiT9v/k0C73gwdQORaTqIxV0CpYZ4GjfcpgKB9w53GbP4Skv/ARP+fVX8MuDt3Jfaf+jUwP37+rxgb7Ht+f6Tn5OGh5r7grdrIZuVlunanzA5uUbWpaxronb5NSqdflfne55vbOab1YpTKP+xb47g71pwUTdJ0siAtUkoFI5ZNPPohHoyUF9a9BXCY2xrCw4ee9HR+xfVPDZocfEwXCuNTvD1m2OU0+KfoFiI8DHIPCZr05oFwe4TQGfT6RsFS4QgmdutuEtf3B37nffLbQHOyYelicd2nYaBUwhHSyR+tu4AZvnh2w+bMCxxiF2hLFDOh7A/sUxC+MJ6pqIO2XjDiNT1VQBw4r+Jk5T2uQNIDa79URGXzteZfnAIVKD1/dlUmEJU6IfhYHhtte8VzY+6nRlYPvCQVKqr0//1iMbHZPXfBR//W3I9llou+kJdg0cKcmfOL0BbtuLMWiwgkpIwG7dBlb7xUgIvtaAYYU/5aC1lPdeFAkxRSTK6+PVUPgGpQXRfvIgqfuqF5RAv4Jea0+hgNVZQTb5lp0Ce91Zegdn8Yf+8zx9/Eqeev3f8VgZx1Vm8G91JHL/1lO/jPPewGOlNb/KnDnHHi10m9SHgQZarFFjQ956XT3PoTpZCsorvYjCal8hCb0qpB8F5lXP9JOBCvmPFV8/uusBRDOl+isCoRLUUrn/9pwBk09+SXP/4hUYJwCMhCs+P+KaGwUzl9K88VUparAm0LXC/U+dsHNnx2TZlBXhWMMte9LfYFzPTEv1o4gQxi1nnDbL/e7ecOCORWwzC8ahONWqOgmarulv9F7xnY9IfVim0wkBS3AN6pp+7i5EunHyzy6CFl2zalck0nrT+KozGQNQaBwr+w6yemgp0pjLa6ZTYxrNwg+AEJDZAUtfuIrdb/0IW57zcPzeNm0FrqoOBKNKmHNwyyHGb/ggzA9i6T/dCGqx/q3bgfw2uXV3fDg7DQNRV4fJxFlNbx2uUguImE4YIVGAtQr+/AYOFYhoa0KRlAQRkdW+6JOQq5381OVWRIp5aYGuFKuzChu6To4V1X32dLnZvlbffNwv8azVC3m9vJUL/+1tgfvXxDq8KCL7q3/PSW7ZvMTOmh/iGKHbph1NUGmxeCyNVC9d1nhPz+1FpkXcJm/Z1aQmqVZA6xT3R3tdd17TVSuARaaWe2SUMM7xpVLKUX2eT34zvf47twKmP/HzOm9F8MHihoGPfHaebnGOZvMqne8lpuVVNYpOlEeebZQZh19RnE1kejsqpKey37484Vpy1J4DLRNGNHOG1XH6O9P9at19FAxZPCkRpEmFmqQUlCQiEuiy8aYRvKEgXKWMVan0eKYQr4KFNmksyti8gaUDh5gsrUTdRN22VSO0emKTVXPMDLjjrz7A/A8+ADMaxvGhScad+Y4+4OYdS3/yz7Q33YHZNi/a+bSgRVP3JtU7vO8XVUGsRW/bFy2FXU8YLb9i0F7Lb6qxX0gYa9C0NajKZ+XtLPVG0gxSVXbjKW5NJg6tMVSwTGMCWr19yLhDzWxLQ9L+TR/X3N3Fd9wFNbvtPfUq+xb90cl72Nj+Fq+QTwL/qj+h+f8r+UUiut+9yfykm5hP2VPtD/kHmC7chVYGYoyKVSfIUKKXWnaxTr58xtVefNIv1KwFGvnJS1ZL6TaKFY3CjWzVpP1t834/6T9qdcqXysD0231LkjD9mFCT8k9qhaDJdmGSREBRkJNFRMYYaC2XfHoGXKTVaj4m1Be4t+uUZn6Js++fVC0DhzYGb6OycdMmn8rDCp5GUQ2o99jRkC9fA7/5qt0MZ2bYvK2hmY07+FZDvLbEU9xLtOP2Jq3SSoBdl/r2KOLRCPylUZ6mXDR1LOoUx6oP4HzyS7L8MpEEpANY2X+IsDrGZPBVa+hW70Ts0oTSy8yIyVU3cfBNH8XNmUh4yrP21GfrjCPceJDFN/wTsmEm7gVLngn5BdVq8lBRQBML28LeA+jqBBnY4gYV8k6I1KaKyUm0UggmL0MpFmH0YqCmV5kWG7F8v6IYzCpPKV6DVL6DJBs7mjgSL3Z2Ln9f0YEiA0GGIMNYecoQGGpcxz4EMWrEYTnWd/Jw35kzmsfKZPhRfnL8u1xy7ehf8yc0/2LJfyHhwMfZ2r5B3mA3yavk/rLJn6CtNMHQYaNTtaQ/Jv4h1vXqKbG9DFeroJdktEi1oFMs/aIOQ0RFpPhcTK3yKmw9E/GBspW3bPuRsvnHJEsuNYKpVH1ipDxuQXaLBDht6pWkEJReGqxiaUaGm29zfOILDma6Ah4rffo2RtBV4YS7ek6+W8dqG+W3PllvETz3uJtHBiGepEayOr02rMXMNLz8VdfxoP/1aV7xuhu44upDiDVs2jZk07Yhw7kh6gxjSF79SktgIspEAq3p0ftO0h69FPhtzGN4U+potILxMyqPxr18UU0YV3916X5hAAv7D0EXkoleAtlyLas6Rd0qx58q+A6Zc+x93QfQ3UswslGHb3KyV+zIcOj1H6a96VYY2GLgoX2fQLHulWk0CSXKt/cfRA4cRAam2H1JsYSrJcKalKSSDEMlJYFp2zLuZDuX7ORq2XF+XNcrDNUqkrdSN1mqrkijaKNR7j6g31rdEBPDMCYCBpSrDAUdAENBR/E2CIYhhtN8ax4jYo4ZPJ+Ljv4IL1k4jYvFc84l7t/UAuR+f/mDHDO8Xt5mTjCn+7sxwYllglWJQS9TfWNfEon2K6MKSq/VyZDHzmtw4tL/pPpMEpLvE8IrKlNTAhBsEvcUsU7pAPq+3iQE35v+pKstvyThACr94s9C/U23U5NWZQULI8cnPj/LnlvAbI7bKnrsPv4NIpF/e/aZA52bFw4uKMbarN5haWy5732Eux4vXHu9wQwDIWjBOXLG0+CxI/jUZ/fxqY/fymCj4+4nbeJep+3i3vfYxumn7eKud93Kpm1DOhVZWjUsj1U7jXLWPIHqJAlq8uZdUbzGhZwh1aoyhdmHVBrELSpeAxMTV4CrkSjYSa3Agdv39/RaMYnVEorhhqCxP7YZ+u4pzTIaMPnGLex7w6Vs+4XHstr5KBnuAjJq8DfuZ+GNlyLzA+h8H/j5lPdhyt6rnxqld6ARdGmM2XMAPXFn2lRasUaDVoSxCsBUmWYHpvVhVHbhGclXqQK/Jz/27YFNXxvtdxOsbSF0mkaRfx/JY9Ra6ip1saNpyU3+G0IEC7cDj/QTc6W9b/jc7D/xq4tP43fn3/vNpgTumwW/vp+7+j18wJzqTvCnMJaJNnSxkpW6R6/p02mFUwFUqPa3hYQN5BVNpe/VUjZmdp7RKA8lqcSq16Q8ObmR86V3p3CvtYh8pGekFXqwSSh/7P/FGAyWUM37pyTAxhYfviAGH0sVPvrpOUSjS59XShLJr6ASwAjfd86QQMCbuJlcJfoDjr2wdbPh53/C8fO/rNhZJXjtlU4mDaFjO6B2xsDcLJMu8IUrFvnCF67l9eY6mvmRHH/0jN7rHlvlvmfs4p5nHMmRJ2yXZjDQpaXoB4BN4hoTz/e420LpNLUQYc07UCtGZtXCeyIVmKjXxEd/VJZuOVC0B1oTugWh87htc2y476ns+8DnVQYWfJsCMDnobJjljtd+kLnzHojZuZnQdTGfNHDwrz6Mv3UPZtts3MyTT3tjYOLhqB2400+ke+tHYH42thE1DGwM0raw55DqIDMEZQpoVKVw96fXhifsSachkZgIqkDNlWvI8dfjkGtnoULsWERV6nJP1nAw69ei+BTK9Ewlt0nxvZ3GlWJiJSNCMOp4gG/NJrMl/NPw7fzK0nn8nrydi9Ryfp8EzFTPfz5+8ZMcHvbLO+297AnhVB1Lqw0SS3wpfXwu83WqFNeq/BHb8/xrdxZJbrdS9fHFnEHSglxLvF3d75ts1SzpflIEROWwMnWPb5Lffu2qI8WlV2zsL0Lq/YL0+wFEkmNOqjB8sgQTJ4zHAz76hQ3owMY3Sn0oEZ15fSds2en1XqcJix68cfjk5tNKdN/dveL48WeM+MEfhsntKzjr+1Fl5XGlGufjvtNohDwzwG2yuA2NdKHlq1/bI29+45d5/i99gCc96W/5yWdezDveciWCYdOWubicw0QdwFhSKW+E1mjR5PdeB/UBpKWlyZ5+wUjplb2NS0IWbz8Y3YsK8SkSbnIZzqBh108/hmbbFtEuJNFPDgdBBo72xts58NoP4xxIF2hGDVy/l4U3XoLMN6gPa0bAAQ4u0jzuTAbffz+0NWXcJPUUwxgIXvX2fWtMPFKxUvr/3hK8rJAXnd4ePV0U9j1/3i1QWl3p/5+8eyJ5V6pRwelU61FszJ1OORdnJ6Le0VjJuy/MIJmNDCIeQMYHRsmJaKQRK+iwep/QmccaK5PR3/HLCw8vvoR1AsgV4O23Mz/8hrzdnGJO9acwptWGqcU4kuzpMnicgTit3FHSH5DdVLO/mqn7di321lo292r/ApREIpHRlZ1hzZrlGSIF2LFrvl9+nvmwueRPwJ7ma7LRit+3xSabNDfK14AwMwx8+RrHFVePkBlNPnX5sIhb7EQUxlZPO9Wy6wjP0gSCMXRiq6vDS8NiEP74D+Z44g9Be/sSwQuuSYo+DVqUKvQagKCK9wHftUrosEOD2zTAbp5hZSJ8/J9v4H//3HvkaU/6Gz74zq+yceMcnYExUcM/zokgsviS7m8NzVrrFk5zTRMrYIkMQHVCN+5YvmO/ZERbRPo755mrc+y41zHsfNgpcOhQBNSKf19A2xaZH7L/zf8EN+3HDC1DCwt//RHxdxwSGZoo9c27fyIPX3TjnDQ//GCabRthMEQSAKtTtG9URdFrby+gZsYB8qhaTW0V3yeEslDGyNTegOw2pNW+gGIlngK2x8WiMxCNxqsT1Eha7pR3GCQwMQOCDeggLh+JS6HSfTPeNkw/HwQYCgwNDEzBCXSYdDZDkBmBCSbcMwTOZcTK6GJeevAkLhafrcjiq3QxRi4kbPowL3N3tWf602RVJjSabbMNZUU0a0w6ynYaiW5Y9eZdqsxab9jKp7tKBuT65RuS/fgljd0zg6tkYJkCczTdN5g8vosWW+XET57+UlUOUrECiz1YwgFUDCGPzdKK7ICJTD+Uj142YHVvHHsjNiHSWtRvIl7pJjzkgQ3OOloVOky5erHxaiwrHibW8qevPpoX//4RHL7d0e5XwtgjRrEuAopi+uWksRwNqHpUAz7EhBC8YqzDbpzHbRpx1VW75Ref/WZ+77fejwwbxiYGf2s07u8z0ZUnFDterZG1qXI0UqHjbb0qHVHOu7I8YWXfQtwqpJpoxdLzL7wy3L6NZmDZ8bSHIDODZMqZcJ8QokZg4Ghv3cu+v/0I842VybW7Zd8b/xnZMES7NBrVKMwX62BZMeeeBScejo4sMgQNvld/xmY7kvqNwE17RCYILo2FK1A5Vql6p/dqtpfL4J9WVWg+oIztk0M+uYs3YEMJcKlOc6lOdXH1Nqsc6KRgl7Lspt4VK06RQTz9U9DHXbGNRIBwkADFzE0bgbRi9EG0co7byg2j16AZEFQxBfR7F2c3s/anw93NBGjK6Zp5+SZO56hHd/kJTE9iqE57LR/78l7LaVzJdm01KTCy5raR4aOiUo/3ip6gSh51a1ASQaU7oCj8Kv626Qk1me8f8kck8f9jVRDzpeWSy4Ygq7ViLI4sTHzzeR+QQcsD7g+LxGrCY6LjjcTPs+FFMIaxh0Ot4cefcyTveu9JvOA3d3LSCY6wvEq3d4xfCgQfBTzGCibtrpcQKnOQXtIcvMd3PlYGGxp54+++R171W+8ROzMjE0I0/EzBP8lCNkn1u6pOKTSzjVrS7pdluQrBGcaHllk9tJJIPMqduH9eGe7YTAfM3e8Etp17P9FFL+IGff+aRDXMjbj19f8oSwdX2X/RZXQ334oMsiuTqfriIAxndOYnHqkOtNs6B7MG7YJOrYLO1sHOwt5FldVWo82cVgAa1XLYvjIo3oGmL9+jfXuqWK2U6rZ8XSYJUsaD4gRJy1Tq5KClpJc1ySJOBOJkIJ70MujXRpZATxOCuDc2QINKg8bRIfU6yZg0hkCL41w/kRMHZ/O8B/x8HA9iDFfGl705JC829xCjG4LIhMwPY4pkIWvEGinITD3Tl1DUVvW+zTKuWzMqUalHe1K1BEmnYVBMFo3o1EhwKlEUqm9F6zU9O1CFivffj/oiwp/twEw58WMiEHxSCrrGcPu+AZ/+0jCWWh7Rwu2kcBJ07Dn2WLjb3WHJ+56Eo6Yg8Z0KHqPFl18Me1ZbNuxQfuZ527n43SfzuovuwXN+9RjOeNAWNm5w+KUJ3b4V/OIyoZtQppT1302PHYTYJuB2zPPW//cBvnDpV5mZmaFN/IE2rfguMuo8banm97kNKA49ZJvv+PPFOw7SLa0kPKWWKmduvafZMR/vF2DXTz8WmZlHQ6b6V/79zqF793PtBX/Hnnd8CjaMVDuvpZc3FrUOXVhW94DjMWcdj289ZssGNZvne4HPFCEI1DnYvY9waBka2zOBMgfArjl0pMaxdHqsV9aJ6TcxB80afyn7CwtXwKVkYKXf+Vq2G0XX5HzKkxyGp7gCA4mnfhNLfM1JYQA6iK0GA0UHqnXVUBLHMLXfM1geSUDMC3j1oe1cTHByIWFyCvezW83Z/kj1dHHUN0W5TzTFkF+wmrYrcZFEv1Fbcvboxx2mdmrM47Ie4rcyvctdCj0z4crxMXSKU5LenIWmmwM/B1Ut651SB0o58fOpqYktqJqSQvLMV8nsP9g4CHz0y7PcfPNIzNCn0XPorV4CWKeEsXDmfUds3qjsXYmefdl8ND8uYjVEQxL1eeBphNXWs+AVM3CcefYWHnD2USwFwy03dnztK0t86bMHufLz+7jma3vZf+tiJOfPz2EaE1V8BU8O5QRUJ0DD+173Se51zj1ZlZaARuIQPp5y9UhH88yrfzFCCInIFl8Rn97DK7ccQMctdjgidGHanIRo0zXYsSkWA0urbLz/iWx5+D3Y955PIvNNcs9MfNCuQ2adrlx0CdI0yMD12Hie7xoHatBnnk1nwK54mlGD2bZV/bV3VIQMI2XUaAU9uKSydwE5ahM6oZfsaa9ALOzgovyrnGbLUpY8wk6EpXrpSPFfSPSHPFXIT2lhu1a8L9aI5GpCczG21URTpjBM1+7D0LqisZFLPo2rJY3DBOGeoZN7N9v1czwN5BVx1UYr55sTLH4YPBNcJa5KPH2d0t1LoevrmlGHTL9mcCdjj3yf3vwj6b/TE2nTaZMpvvH9GJ9K1eklQDVivdbOa6oULfZUJo3jhIrnknz1yvshBX8SAhGnACBc8tGR6KrFzXq60PsWxAcM6XUPPOjBWeDSy4g1lUNBq68RVJx6NRKXdMSTolPDgZWA1xWwji3HNjzk2K2c8+gjWUa449YxV1+xyKcu2c0/vvMGDu5ZxMwOk3hEp7jyIQjMb+ArX7qNm3YfxG6bYdKG1IoUS7TES86z1H6ImxKJRKu7JMFLeMHK7oNRmScyzWOFMgod7tgYq1+JWOGuZz6Ife/+eEaKeyfn9AaQUZNehMrqK5/Oi6si9zkJeeR9VFa7+PwPDObwbcXoY/qYSMGyOEFuOwD3Oqon+JvecaSM0kLlsGSq2Zz2/BXJhkNJtC1lHdn0cyNVEOSk0s/3+zYl46VS/87ZTkxqExItEwnN37eVHHaqLe9f0jxlk7TYRMGY+6D6JZ7BFVf8mdErGDAjj2Sb9jYbVRCFlNGMVM8Fa9jXRqZsk7TuI3O20p4rYqTinvepF5FoDNkb+yRwcEq2X/P1e8RfpFqQkYJNKhQfsajYct/Ipc/adik78AJShDV5Jx5GWPSGSz/RQNPGoDJMufOIGHwnDLcIp93bsERcEOpTAsnXUJJCBhiJHAMiRhCBwrQF2AlBlPHYc3C1ZffKMovjMXOHjbj/I+/Cr770ofqqdz6Jk+97GGGli/IFrfQFWdDUiB7at6C3XL8PMQavgZA8+8MUumv6E65iNq7lqeSh3HjPAkXM3qceFUKcijROZ3Ztjvs1ncNPPFseciobzjoRXZqAtZhKAVkcdrSuGDOn3iCTDvvMh+FGDgmhVHD2yM0RGJWSyssmQUSVzmNv2z/l7oVRjUuYVLGo1szAPObLAKH0uwEoAKHB2KqNKGvIK8pwtYk4jwMls2VtnArksr+nDEu1AKdH/6VJ7cMAlcaoOIke2rnFyFMEJ2DD1HKU8ja1ikwwHBtUtsq9efNx9zOLX+JkmdUTmFEVH7kKUr+cULshTs1jK6MtFSPJzyWxvyQXjKFWuiYr1Fxhp6g3Ub4RK/H+CQ9S99g9n7/n669R+5VRn6gYoyo2KuiMK712PtkVSxnjiRDElpM58j76j83AcO0Njsu/OoBhRK77niVpDYyITuBuJ4045jjL8iTvxDMlsXTJ8CV32h1Iq1Z8Ov19Sj4ZfyjuOCaSkox1iDT4znJodcINSwfYeZd5/YkLHqLGeNUwVpH0i1VJ3BDQlUUO7FuMAZewC08gaBqeS6UAnhIEJJJX7b6U4nThlv1p/kqJtUIICoo0lmbrhoIoqA+EgWXns88tQE+hIEsv2hKpqHXq49x/aYy5510Z/cCZ6lofuSRZCXr4pjQhjLuSEiWt+EGiit6yt6c1SV3zS0XoUSSud1Q1olijVFT0Mi60gAn92nAT+gU0NVXYCOKiWjvrA2Jwpk3MLnMIKh5AspWQWhOQ+nkzMJq3FvW6m7gqvcciQqG6i9SVQKoCOkW34PUoZzng7meawAl2Vua6xobYmE4l//ImMDIt7ChmClNWWxKnxsleorAeK6Y50/4cfSmeyTgmCcILN8WUKiCNDbU/1dcu9Oy5/ZqsvtXk0Z4pI77i8CP9mK+c/on1l1mfXTAMUT7x6SFLew22map0U+VMFAlN4AH3N4waS+tTRZEcpH02uVShRWSiSD0R6MgVR9qlR961R2pb8t8QATdN68z2dytsPnwDzYYBIVNjp4d4uZGXLvXyQeK2nn69nVarlOOxK1KRgyqjDK0+rtx+sKgAtVIUgKA+YGZG2G0bCjsWE7kDGx91H2bvcxK6NI5BUjtFTKkievdeXVnBPeOh2PkhxivGZJs20F3b4smnVTlcl9QWwo17p7wAC4hd5vlSIBokcVHiQaRSu1bbmnA2XXZrWneeJ2PpTIlVQ54E1CPBoi+oK4VaUFetG6t1M7afPOQtRCV5GDM15RDprfZ6k1lgO9DKcUas2cKMicm47vtqbvQUAz/DNmlpJnVvL1O+ylq8NUWNGE2K6CpIk0Q4CW2yTZfWZrdp25akkzZkW64K+Ov7/IL6S0hASFx7nTbeFhPWGOTx908pv6D/KQnkxZkSV3z/00dHvV0UtcYhW1oLNIH7PQDGtAXb8NonFk/k32MFOxyAswRRWvVMQmDVB1Y9TLzGpRs+MPaarnHXxar3jH2g9VGYM+Nm+eJnb2Z8wGMHwyRdq/jwSAQIh0Md7ZhlQpeSW6wAVNc6APU4VuagT8l6NP7+YWnMyu4D8bQr4HD1IF5xcyPMxll8qJbwdJ7RTMMRP/bwaPZR+Nv0zJt674ERZHWCHL8L+0Nnxaxoey6KAn7HRmQw6BeBUltAKdI49MY9cW2BrVpKW7P7er6JVOPtYghlVet1YmX83ROBNFYPmt5OomWlWAzYmLtLQCtYNClf+7K/CuysVExcA+1JSDr18wSyp/SlPRlS+oRcA/oAMgdY3eoIoaXaTxi3cmVefw/yee0hm1Axl6X6TFVFkkKzgP9aHffV0RnLDSmHTsb8ReoDKfkFSC/0iBVd3Y5IpelPjUlG9XNgai8aCtrfPqQMU4C63B5U5b9xcMeC8KnPORh6fDDTCSebxI4D2w+Hk+8pLIYOFdefsFIBf8awvGg5tF8YzRuakdKMhKETTJKDRYmxJdAQEtPDMyDgGKN0GJSGpSXhfe+9gtdd8DFkIHGluISK2BOd9tUrm3ZuYcddtzL2bUpGWizTanRnShOQWgWdVjuKsY12i0usHlhIdNu+6yCk09F7BtvmaeaHhK7Xn4izdJ1n2+Pvyy1/egzLX7sRmRlENXB5h1XNpzGw0jF61rm4LXOw0oKzZSGKAnrYRpgboeOVmD+yGCH/4tbA7fuQg0vophlog2BMArcqTn76mzWt/i6nppoM7sXAmN5QpTXiP3VgCkz5XQuV6EC0thXTLF7K5sZrt2EVI9P+Pdd7a2pvi4ZOxYYU1Z7cyVQLIbgg3OoX1dP1ugBf+eHndCIJHdapYY9OPwO5EpDaam2Ny0x1/1rfN2UONrXqS4oJSF8hyLRqTvqKpIz2qmQQlL6/F6l6/f62xUij3F/ogmGmgc99ueG662aRUZegXzPFljFGCaueU+7uZPvhqguryU+EYlMcMQAPGweOj3604QU/dzNbd3hGA2Vm85DNmwZs3mQZzloG846ZGctoNMQ2LpXZ0ftvaSXIoYMTdt+8zPVfO6S3fv0ANAYZDERD7WiZTFcE/OKqnvDYu7Jj6zz7VlfBNKXNwFabj7TyruuzQH0og4hagywdWGJyaFnFmv7E0R4j0KA02zdhRw1+te0RcCNop+jsgC3PeDjLv/KXMDdKdN9QqWRSeb7aYo45nNmnPBh8wBtTRneqUTnItg3Ipjn0liUYuGpBQkokTtADC7BvEd02h7S+wjrWBFlZMV6p0KR2TE54/1RJJEX9LMKaJ2OqGiZbMKn0PxctA6dpzk01AcgemVp7Gd6JeiVTJjpGq9tXEi9F4hJHIwccjmt1URftRDeFET5J7GBKr9f3iLIGKqp9eorlVyFZSTXzzM5N/SA0qKQJX+3zr9O+9+l07iu6euYhRcabk0BuV4NUQU9/4tfBH7ROHgn5z0lAo1ORRfjYJ+fQVcGNBO8pZAiRPmPjA2c+wGAwdBpwOXFlwqBIqTSuv2WB1f2eW7wKY6JlbZhEtkxIC+hqyLoYxElCiCSCYwMwc8P49+e1YLXdmQqqHkzgQU8/HZ9si7RaWEMyRSnPsUavwSl+UHWiqSoWWN1zCL+8Gsd2IdQuUmnkFBhs31hGfCKmOEKJEbousOlJZ3HHq95He8tuZNj0Q3VN4J11sLyKPf/BmB0bCKttdPkplnEaZdQbZpCtm+DG26tRdHW4GIMsrBJ2LyAn7iwOT1MeiDLtJl3P+KfOL5OcgkSmAVOmtBD95qmqUIgHV+iPv5hp+v2ztSu8TO/EKCTNaty+1ie3z0fae2oXWyItFA8JiO4GrF5lRudxvV/Vb8iiJBxg2tt52iJ6ajNd+SqNitN4tD/btUzDi8dv7/OXxvsFN64R/4L6G9ZuBa3tvzRbf0klxS79vVSOS1Lss/rdjn0SKOCf1vbtsSVYBT522UyRwdbJvay08mDnLWc8sGE1la3V/sjKHTriD7feuIBoS9MY7IxgZwW7QbCbDG6zxW4ZYLcMsVtGuM1D7OYZzOZZ7JbZ+L1NQ+zmISYFX1zqUZlvJ3NJO2gIdyxy36fej+MffDwL49UIVlaVT8YA0ooOlTWnyZ3KxpR6F27bD+NJ5c9Rvz5xWO62bii/j5T1X8k2ddwy2jbHtmc8FJbbfqadZ/AEaBU5/DCap5+THHbNnY4cgiIDg+zYDD4UtmoNg4gITFq4cXdRv93JgysD1bWzXGGy6p2pw5VGRWpdQWYY1rcX7e3qe5BSxIj2pUQ2N7uzhZ+EyhpPp20N6y1OpWXPXyfnsNyTKxCMwj4sN/pVNupHjQittvpudgtpfWHZRGOmrKGr/1hqzKEHT81a326VKttK+cWmnog17YGWPkcLdbcaG0gmR2hl612X8loFW8/nFyrlXj/3r+b9GfSLg6SYIJqhcuMtA754hYGhR0OlCdU4ohJRwlg55ng47m6OlS6+UcsYT6YTQUfD/r2RzBEBSoMPQvBK6BTvpRQCwWv6fug/th2+6wg+xGlkv/Au+RlEIMk4Q3fHCic9+p784EufyFI7KVOJghDnUyGEqcpLMl6jPSmlPNtx0q6rtx3UOHoLUdWn3OkYG+zakrwzpLbqS249VrWD7U99MO6uh6PjyqdCkwvTwgKjJ5zJ/LHb4xowqUwza0YYwM7NNR1Ye3fghMEEkBv39u6OwvT70KzxyZrykJzeYrVW7q5mjcakJues2UWzhgBYxUePQ0xpGXJzrEk+PbV0pPYT7DEM0VpxWXkUxtUVgesMeoDPcOrbLzcA7ZC/81/vOlkSS8JGVBGvWk2Iq8m/SlXiVxTIO6Hj9KCh9gOqO5dWU8bQMjWDXmusIP3WGJUeQFlb3pd5vkyf6qFOFrliyOh/5U7chUihvuLKIQd3N7hBIsMmApAk3ry1HpkI9zlzyPxc0ElLRTaqKg5NdlooS4sDEdeIJj/AinHH2u0IOk1pTEyfkCVIpa8TE9S4OIwPi2P8gTH3e9bpPOf1T8XNWIL3qOmnNjY5Lql60HE6MWrZppZlJZLWN+dWrgOWbk0+AFVjVhiYqeF1mQOQu5GqdDdGkLbF7djExqc/HFY8ONsvR/GKbJxl5lkPif93X1KriNW6ZQmAHrU5rSfL2og8v0gggHHCdXfUdmcyzcyr5OMlYcXjN57wZsoXYGpT0BR3TksiKNus1jJTy1qyvuDqHdTSarF0kuU1hxoQ9YimMlJDXFdfyTT7+2TMS3sr8+JVG2zQyxE0vJHzz/curlLhy+M3+PcMbmie4E8xE5nEjb29L+za2Wy/Q1Iq/7g1GMYU9ReddmtW1WrB5RrSURwOa59YlGpgTL9JlrI+rKcgmSoZmNTTm3Ta9gCflglA+n520k1NS7S1UD5yyQBd8nR5wWRtF6tRdEPXcuaDZjXgUGkJFZe8n0bE3nfcBm65cYK24Lvk9mr6xFJAzjvtQl8LnaZEHeLMXZfHMOlgZsBxZx2lD/+Zs7jnuXdj0ipd14F1yX08/kZl+7VoBuDSaZcmCSE1MWGChlDe9z6t9F64eU8CEC0qedCae1sPjWVm5+bc/KmuHS+jkU0XYPtTHsiB13+YcOBgMl8FDrQMzjuHmbsfFYFAa7WmGZvK/V8Ac+S2RLJKz45Y0CRbUg/Wq968J767bD1FCtO8faoqdQrvqjwTQr2qrp969QC8icFd4QAqtdyiGC0VF/W1dnd5RiAyDZD3LU4cc/fse4mcu3osXi1B0QC6QYJ8AaeXd3dwj+U3g4rLf9riYfpC85XuXHOYs7otqExqqms1nKlsvaOnmsn7I/pA1jKKFp0agWgFXCQQJG0AKaSOKjEXg6r0xwSlEFQKb19q/ZpUttg96Bff+GZNkCcnIO1vF98OpvCzFzrDDTdZjjixZThvCD4Qghc0RGa4iXlgNDKcem9liS6NIPkmk4ZIXFkdtxxxVNCV5cCkHcjSQmB1dYyOU5+gaxfWV+48AlMGdNYio4ZNm0dsO2qeY+93JKc86kSOP+tonG1YXFmJAhpp0iQkgJrEAYCWUKYAJnQQXG9vrYDv0C7ahnTZCs8KbetZuuX26J4UTPT885OerdkqZmaemR2bMVMakunlL4gSxi2DI7aw5QfPZO8fvRPZthntJsjMgLkffxg2j6A1THnjiYiKRs6YAdyxO+hm5qLnWfBpEUC8n/ooOuK2RWRpAkMbuRE6hcT3YVYJdnRq2Um9vir2UXlHu04dfjo931LTn2dUZ1uVGr6Ze79m4o5OJVGRehluT+6ZggVEplesYRVz0Ab9EA43uYBnb97HRRoN0i66CHv++fiFi/iF+Z3uD/1ZMsHiCFXuUpn27+trvWmPQK05AtLvUJtCByL4kdFXBcl6+v4UnLJ5J9AzN8rMXs2a0t8W7734s7w8w5bbF5BQExNQbZIDRyF4vH3GBSyLy7MIwwjsaSaaUn4fYRBXW41CWgITWRsGqwGbtu7Z9H9BwGKYYbLasLRiWFgMHDrkObQfFg4Ky4uB1UUYryrjMbRtLPW8V4wz2EHDcLZhZvMMc9vmmd81x+bD55jdMYu4ES3CeBwIwYBtEtHJlefG579PDcE6Vu5YZmXPEp0YWiV5IPbvnOAV2boJd+R2tItLN73C8jduox23cdtwen3bEJgksoazjsEJh+Mbpz6RlkIaS4V0VGQ2YmsMYWFF/HW3Q2PpVBk7ByfswmhettYzF71YAiEBrfH0MKst3Tduw2sPivZryuOyF2kc4fjDIyAXSvhpL27rCW2q06BbTaoUlbzHrE8UeidgLp51QSthkFY7EDOkobUL03S+qcKpwgZETb0Tj2r+VoMNvfRQRTCzdPp3ZqCfm7yFPxuexw9Gg1BZawi68kb569Hxg2f4+zIh+Ea0KnN0zZIHXUMb1r40TWs3you9tqOPB3lIf4OR3sQzqwR1ataQZyVFVksKKiiB3TP6bFX25+Az5edTty1JwBY8IAt1VGzqm13crkOVdNQUlqBi6YKtKgwbF4iKSzBZzzgMieCDcWAzC9Ehif+pifATyUAukYEcSlP9bhaPoyNafU2AyQQ6Hx8/nvr5d47B7xOPtXgdaBQqmUGDoaFDaDF0xYAjOSpjGaOMxx0k6nIQsANXwM1cq3RQfAYV6DofhxTxlS4thyLVNCbRnm0xHpGkk6Abd9lkvGwPVklU6QrbURAvFtz0Il6+GabehbT5NyeAdLSrVkRmmcandA3BR6uJtVYLQevJw52SQkbia8VgdlCviFb1Gux66qRaj+Wl3uGiaysGWbMcd5N08i4zCB/oLuecgw/mGdsWuADhQgm9K/B5BL0Aw1P02eM3tEcMxT3CnyETVJy2FblnzbQO7clCUxum8ws0hRXUfOSaQ4jmCq/e9KSy9nnPTK3MNwipZ5VpDb+mxFMx/lSk3zdfbjPtzByknxB4jY8XuvqNS2EIBjFoML1VWmkrqt9dVXJFUZbGpNfY+0DoTBbkoHi8Cp6Ax+FxqXJpUyJw5TTPgZ3pzNlt2Fqbgr0HOjPjr/crThVMfM/jJx2t+kRbTmvGal5FenwrsfrJgGW7Mil8G18B0/kNEEzURyh6JwGZrlk/RYZVujbrCMEYrJisWJweD+djQXuwzqhHx0k5rv1pqDW/JPcLd6I+a2GfSb8QcIpaXHZZqqSzuteTq+oazsv0oahTSGggb4EoeaGACD0tul+OKmVFY6HdhZ5xXyYE3Jmyr41F5n0n7zODcEl3Oyes/DDP2H6o3hZkasl8+jhePDM8efLV9r32U2agnXiaoKUJrCzkNFRbTkOaioQKvUx71iUjkUF7uaoGsSppMY724+uqRJpeU5dGhKmq6KchGsvBrFir3tz9r6b1abFm3l9PCqTcr97y1D/Z2o97Kp26Jq88rUC8oiWokk+/KTqLlbSIZMQYjIvX6DAbpaPGWow18epMpTbLXojR4kvXrEfLp2hOAIHQC4AkpHFe4l9UBqtiBWPTchMTRUdqKqpvrv+yZVY2zqz8GK0TnDFV35+nJnXwaY/3ZqzJmCjyKWo209uGFUp1foObXh2qFXZss+t0ej5s/v1MtcZ3zakiSr0jqR845eG2Vvsq05it1vtHFVwWwPYBXKH4OUNKFRvlBfFRMaa+J4+ol/S15s+FVkUniHZAK+kKEi2eykfGOUd0nbzTDsKHw3UctvhoXrDxK5yntl4VNrUy6MJLUb0AM/dDrNq/580P/FjY0eyX+zMQYXPwdGpI+9IlBXdpDRJwLNqvN+751X02NbmPqmw8MkXCSDV+mRr7JURdezeinrtPhe6bfr6/ltsvNTBYm3WYqnWgKAP770mlFch8gvz/pMeoaFu5reiCTcpDmSInRfzBlsfNKpKgFh8MXvL3ozrEY+hCcaGMvAHJnAVTEkz+fbsQQbMu25kj1d9k1wCUTLEiQ0aw01jU52SYzENCsg3M9uoRJ9G8EL3A1vlxvQ95fV98kU0SfHc+RrjpBbpTOzJ6LwpRREJQ0Sju6ik5PjIaxEjFHraVKC3y7SVT1afeWlMrTDOK1xe2aqY0EjK1Nq1OIlXAB6accHKFENXWMjWTF60W4GaGmqfElFYxlpNH/JlJCULLqRUP3HRatSnrzxDsAVHeZZtwuf8IJ02ewP/e+LV/dTEIgFyYWgHBC/ozK29sv9TcYn/Xniob/IlMaDCsqMnMIltKv34rkKRKIJJ6euS+JOBQLzlMlZdKbyGe35zVmDDPNmsWnmohraYADSkgp6cDoZIc9xOC6eUsYYonINNtQi6ji0V2/Ls6r9GlyucTPjPJDJtGI1pgadKioilQTN+jloQWk8Bo2NAiLE4Ur3lNOTjbMDsYsYqyPA69kEey0KiqihRmhyMUy77O430PbGl5l9q+Fchgl2hNW6fT+DvY4QDBstJ2dAHMaIQDQjvJgR9ZCWivocgaEmtpBpYJ0C23GAE1Ae8cZhj3a/vVri7PJQesSLaliCy/ASYamLY+ti1B0VF0rKcN1cg5aP8GNH2DnbpySdWnGCldQkXUnebTTs3nq3lbSAO24t2lpaTPdhaJ9FBZjPW2YNF7dc33U8BrAphN+lwrkD2Xt7LWVq9ytKJBMRr4nGvCJ0EXJn/EL1//Ak46afzNgv9f4HtWi2ovjstCFt7OaaMD5k/dYe5BnBAIhzFRL1baPnNLlQBKiVgLo0z/JEum1U7RJU3lDdAv/ERIOnjKCR5qU4/k4phP7VA0/tnZwZZTV4slV972Y3tgrTqVCwiYHzc/htiIDaSFyKNG2XcIBnMz+M4JxqrIAAkjPvWPlu2HdbLrHhopleqqk7hJIKZDGWCk4aufXWR5JXDMmVsjMGcaBmaWpd3CtZ88xPwJs2w/eQMTDyqW1ue/KZaprVqCbbjlU3egC4EtZx5NmB8QPIj0z48kcbnX6EAUzwBTyl1VocUysY6Va/fSHlzB3O1IGA1Y/MINYlrVTfc+mrYxdF6KdiYxKMWrQmPxe5e444NXsuHM4xideBghVqYs3rqfhfd9kS0POYW5E3amvYZE/4Su02jOEreIdyhmzyH8Z28hnHlX2u0jxqueSeMI7/8Czc5NmFOPwg9cxoVUdRptiFWXTvFQpsZshQOilTFf2WKt6RSX6WCvT6EaCNTprb4J+VREJWjfDvQ87AocqjcF93ZlPRDWJ4qK9x6/PYjQkNxiG/0i6NX+q8x2z+eVo3f9axuC/8WtoRdeCBdejOoFuOFPcevD/0H/+vCP6h3mOr2bWWKHsWLCnLZiiKtpQ6VGrBJpoShWa+EyCChr1Ev1ikrqcrCWd+d5vql89TKjr8z0kypQTWkHQvpap4Q/fbnfawHqvr137S3fQ/DBMBoIX/iM8ivf37BKIw954Ayr3smGZk6uurKVX3z0frn5hiUe/Yw5sTJkxswhRmg17ukrbYZa1DT89jOu4P1/eSMP/dET0EY5dIeRQTsjX/vcAX7/By5hYWGVE886nAN7JvhVxY4cmpSOHcJKAO+G/N2z3i4f+cOPc8oz7s1g6wyhU6xxOBkiZoRKnDJkBWDvZ5mehwBtF7DDWS756b/k0xf8Nbue/lAZbtsiH3nKH3Llqz/CCc86GzM/pGt9PrklkYKZdAEzarjm/32Ir/7Mn7G8DM32jRy84nomw4Y73voJbv7p/8uCnWWwcQNLV9/O4jdup50ZIBtmCSFIUEScwTWWPf90Jbc/8fcYrwT08feiG1jCFTew+ojfoLt6D4NnPxxnDT5bhOn0rsY7K2CrA748B3ce94n2RCxZyzWvAMDMJZKkQJOscgsSXaP9mtKS0rNKqQhCZP+VttpX/HEP4kG6WOpLC9oqdEK0MxMvt0vD56zVj/vd7PEv45yDz+YFGy/nPLV8+UVw6TdjGfwLLcA3aQk6vQBjhE4Jf7L/Et4wdy0/K9fzHHeEOZqjFL9VW7UqjGNzHEzSUxudZrBmb/+pTc4yvT2IalcblXlrpunWq7RrPKBiHqpoKd11ijFYIfHaE49CvfmmAgrrZBuStbWmLKdeGDQjFryRv/p1OPpY5fprOy59825WBRjBVV8N/OTDbkJlIIOZDXSLlqf+5lDv/4hNLI7jG7YZOkZYZmcE4wJbDpvhms/tkd957KeY27EZPw6C83z2zV/jyo/cRGCIsbM8//2P0vljHe1YGUuAkZOAsrpvmbljN8nMXbaqt4YNMzN84V1f4VO/9zmaWcdkaR9qPbSGM37mEdzzKfdlYXUMKYjMaMQMTTSHtAOCDGhDiIs3RgPEqiyFoAOEZnaEAdq2TTsJlNH8kP1fvkmu/8OLkJnA3n/4Z/a+67Nw+43MPfXBtFfvBjuni399CV9+4yfjjr8Dt7LhrS9k55PPFJ0EwmiAv/o29v3z1UxQzHHbGL/53YRjRrhjdtK96ZPocAZO2EX7N5fBMdvgIScRJp2oiW+mkEhn9YErFU25N/rUYuum1cmv1K7BqGa2s07jXpr7zbp1KESqNGAM2hNbAtJTdntkWEO/X7AHzdMcPyUIQlK7OhQjnlvtQL+B1Wv9Mr57A5va3+blszfwF/Avlfz/7gRQcAEQLsLIwzgA/PbBD/o/m7lWn2Fv5jl2hzmFIwx+h3Y0QU0rVjXbEVdiHl8bMGi1PKSWPsZILOuWK536lJtAJTzok7P2PX16fK1689gnh0oDkPt5oZ5V1xXW9Mc8i1EWJoFT7mX4P381w689coV3X7TKSfd0LI+XuP1Gx3DzLMfdY47J8iFWVwPjLtCqwbgB4Gj9mNlZ4RPvu5VLXrfC7usFH4b84bO/wEOedBQP+/G78OE//wY7T97CA599CmGp5SOv3cNgyxwPfNoxuHmRznsNChuGc7zv97/ANf90Dct7xpjRjL7jx99GWFnisJOPYua4XdzxyW+I7BoyaDrCuKW9YYmDTzyUtn1G9ZE0M1z1pk+z/4s3yanPf0J8dwTP7PyQbcZitcG3HePgGRnLV3737Ww7/a7seORptKtj3MCxeu1uvvSUV+EPLbHjH36dxb/8Z1bf80WOfu+L2Pv6DzD51JVsff2viL/6gB586dvZ9uc/QnPPozBHbIU2rvZyBpY/fz2Lz34lMr8RBg20He0L/5LODVC3FWYOx7/1iyy/5iPYH30YzTknRcCtcsPVKYmTjduU1rLS8kFT4INCQP0m1+xeXZf6plgmSdXjFwAslZaSArmeCBQhTwruuF0uJQEvKcGkx0SikKdVletdw3VYvbHbqx2vZ4d/NS8bXQXAOeq4FP9vCf5/cwIoIXd+GgVfjJFHshfCH938Gf585xc4X2+R57lt5j4cJYQddDJCtcWWAj/5rEV5cuZrJ4TVpBM/UKi0ksxXyuitGvWEapN95AVoZfqhZaw4PRIMCQw02SeHIDkhSEUg6WWh+f8J2qsUNVmL2QZaOh7xIMeffmSOzUcFtuyEjTvneNVzlnjGbzsO7m5Y3D/Pc39vV5rNt6y0IgcnE41VnnLrzWM+997bsFs2YdxGrnjPPh75Iyfpj7/kQfKVS3ezutJx7vPP4OavHuSf/+hjPPqCE3nSj53CdRxipe0QLAbL/i8v6Y3/fKvI/EbUN9zy0Ztob1yQxTOD3v2Ew5F2P6c89/Hc72cfzXVv/Tz//Ky/AQkySVNzVJkzDTe89Ut84y0fZsOPnkPQFkLgjku+xswpyxFYGwx0KI6vXPgWvv6iN8mGB9yDsx54khoXF64u3XaQycIhNvzYY/Bfvo0N5z8QWW1pt8yy4QlnYkZzDB92b7q77JHhZ65Tv2nE7ClH4oYNeN+zQ4YG3ALNzz4R85xH0x1cEH3eqwnX3KEzF/1vmiO3M/7yzYx/6JWYQbVBunbAmXLo8FOU37IQSUxPzJnuPVNPH5FOU+nr6z6/WDXUaHI+KYJU4/LqNEnCHemVYtXapXQAhv52DEwM/Gtto1+BcJu/AauvZ+eh1/CSbTdGHo9aLiIg0vHvuDj+nZfM/SiJ4L4sQ3jdJcrfPuBV/vHN7fJcs1kewQmWsEM7dUF1kpYyu7RFKGdR06Ojapkyai17MafZxeVF7fF4E+Wo9A6zoXAGAqoWn2jHoWJ7hYTMZ3S/JIViET5d/lMpCrEwXhrw5tcOWV2dMCuGYx40YRvKG1+6yKYTLCfd2/OSH13WiVp51LM7urCCHQY2HTnEiEWtcGjScZ8f2sG9vv9oXvnMr3PHDZ6//tz5/MNfXsFbXvAFFnYri7cs8QfnfoCF2yId+FNvvpZPvvZLnP5jJ3O/Hz2ZJd+ysrrAE//f/bnrubv0bU97n9zvpWfLg37s3vy/s96gg+0bUCaoX9LhsJG5YYOdi4nMGIvipVNVkSBKoNk8i9m4MZ6Wdgiyic8+9c/5+kNPZbB5FuOEzz/vtf9fe+8dZ1ld3/8/35/PObdMn+0Lu8suvaiASABFEbuxBQzEltiVaGJiiSUxLKvG2BJjjd3YogG72MuCihRBkF6Wssv23enl3nvO+Xzevz8+55x7ZjD5xW8sIPezj3nMMHvnzt1hPu/6Kuz7ymU0H3wUR/7Ls3B1i888WZLSf8rBPGTLu5n68RZuPP11DD71YYycfjw7T34jsmwAaqPMfHmjYjqYUUhefDnZcx/Pqnc/H5IOXgKC1HqBaAj3nZ+jV9+Kaqx+xxxok84/X0gSCczNQDaB+rSrUJWLbISoZroY2/zy+5ygXIXKVg1rim1Wd+1UZPZFRiB+IQ8/709Lowvx2p3w++4Uv9prSq79QiY5RkC6eBknqBEvXpU7bMxt4He5m3D+PRw/91+8cnSyvPhHo2wS99+P9H+DAeC/DQSBJPYV0K+kH9InyDXZ39kR+yjWWrKlPtOah0yNGEPhJqvFHrGktFf0RH2xfq3MA0qXouKCV8REqtLVFBlfcpBQVQcgXPMwMKxe/O46rbsm6yIzyw1E3s3MzcF/vM2RtVJlKuLMd2WyZtozfVsHlg7z2id4laYB63nlyTfD/BRLHzTCeT8+hIaVoDOHZXA4oj7cILIgmnHNtXsYn00ki2OGDo4wQzWMNyw/vI8VxzRx8/O4TlCqSPGk6nGaMdo3wOS2GXCw/KHLmdcOnd1jNE9fGwRIqWFtjJLRSZPSCj3/twpAB59vKuKgBWHqUGty5KYnsuLYA7nh4xfhJmbZ991fsvLZD+PwdzybvgOWknZaiDF49SSZYfLiG9A7d7F60/OpHbGKbO0ofR94IbZRI5IYI0qnEZFcdwfJW78EA4PUgDTX8yugviBQrxP1D0BspdPox3fm1NYtph6gxkgKUUwMZKaAaWuhyUYBMwzcTpUqwm+hIEp3naG5Z3K53tNKoPAL13fVgWCg52r5cVn25xe6CASq4fKX2d9J3gLkrYGVgGy7M4r1LtC9/jaM+zdOH/sUf7F6jk8vyPiO/8OJ+D+eMhDkMwLOwovwHfDfST8hfyw36OuiwfgRrLW4VWmqxotkxqipbgtyb0rbXRVqxTcwuJkL6hUvwXEmV5HMK4AiCNAt3VVKlOCCfj//43IySTcwmJK3oJXHsjgo5DyQeCjh/T+ocenFRj77NwkOYe2xjj/915X0DQ7iXSJfee+8iqY8+e+XkyWj9I0aNEo18aFwj03E3i2ea75/N+N3TZCMO3nn477Gi3/0GB7/ynVc+bWdXPiG23nEKzdw+JOWMj7Tpt4YpL/WR2ZTZpIWxsRIDiG++9Kd2AOarDx+BXdfvBVmd8nSw0/TWqMhEOF8SrvEvLn8T1DvCa1N/i+2DWxswadgHUf89ak0RpdxzQe+AlmH49/3Ig5+waky5xKy2RlsLUZFcV6JI8vk+Zfqro/8hxz0009gts2w5y/ehtZiJR2AwSExri3NVz9e+//kVEne+nVMvaYxAbxkNDAVM9+BdB/R6U+Wwb94HNYljL/683TGJrEvfBjxmlH0pm34H14HtRibY2C6jlJdWbAulT38YqgssIGqsFoqq7lyj18xKPHVjVZlVVdy9jW/5ItWe8VUvwT8aKkUI4VEkssxYR7P3TbWW0F3ujux/n08LP4YL7IzfLQY7uG54P8t4//GA8DiGUFBLOJsvLzAfQvhW+0PZ38aXWNea5ebE1mnZCtIxQTmidhuua8VWyRf9E4mh0laSvBQyM22q1orBUjHL2zFChrw4j9SBfVQCRSmu2lYvFHQ/PKjeC+IVQ47ps2Wu8FlGS6tUbMNHv7HI8S1Op1M+eaHUjE+5YTH9mOiOj5Nmd3ZYWC1JU2Fgf4+vveJvWz+5y2wPCOywpPfeQLfe9ctfPJn02jcwO2f5wsv/ym8Cmoj/YCQ3D3DKf/0YB7+t8fSns+o99XZs32cOy7axuBBwwxIgzu/fzdgdcUp6+nsbgeLMx/8AEJ/maHe5/9uLWXCvWZgIupRHOqdbI79e2cYGBjAZ06pG1Y+7YGS0SG2hnigj3aalqhBC0RDA0i0jChxJFv3kN2+n/5zn0X/IWuQ/bPsefWnqd+5T/o2rAbaaGc+KH51qeBkcy1wHTrv+Tp7//WikC2GaiAdOk9+Ix06YPvA1fEzrUBACkkkLxRL9H6u7OAriqULZTS1XM35BehV1YUroQWXv9IKBORed3KfyyOUiD51lbLGd99rnv1zCcSMnVLT26zVbe5O8B/k+LmP8crRST4JbNSITf/74d7vPAAsCAaLA8FL3BdV3VeSD5u/MGP8Q7RaDmEdZMs0FY+VrLBcLvy2q+JJuSqJL6yacqRf7j2nFfFMVd9108kz/4JVYGXwF8r50Aq4Crko0IQlDzNaGQDSDQQ4vBfmnCdtB6H3oXqT975Quf3be2DIQNqBvkCg+LtjboFmH0zWOO01AzzvnUuYSBPaOI5/0mqWrFsql3zqJsb3zPDwl25g6KAaF8+2uPuySU58yWGsOXKQPXfM8LOP7GTk0AYnvnIDy44b1cwrkZjAge+rc+gZ67jtM7fw2Seez/TWGYZPPZYVf3Qwt3/+KjB1IlOjBjifBbEMLX4mXd5l2AikpD5sGHBtYaCm9biBSAMwzEzOYpYOMPfLHTCf0DxuLWmY8gQn4DRFM9WBekyn1hD6lpPdtF/mb5/EdGah3kKtJ/MKzKsmLdK8EhFriYHm40/Afv2dUG+q11hcs0brvPPJrrpWap/4G7WrV2IJycGvX5bbrQsLlblz9oJo4VaD3gMMtJC9t5DaXtWZq6wJ/cI9sVSGReLyi5+7uqiv4vsrrUCO0iTCyQSGW23N3+6mSNJ3c+Tsv/H6JVNlj38Bnk2/3nDv9xoAflUgCCxO/8nx7/Plgds4x+7jVdEGsyI7ECeD6iVViwafs4LOXfw+FgObUjUrh7UWsF7F54CfhTJfKtW877tMPi2GgFJm9QJfUEAwVXy5hfDqSxsrn/MInCoDVrHWYMwAXuv8+Wvr3PLEeSQGn9b48rvHkASedu5KfC0ibcGG4xt4L8SRZTbJ2HByxJEPG+WKr9bQPTXGJ2bY8NhBvvXWBD8zhzGW4x57ID/69HZMlvGwTUfwoKccTMt10DTD2Djs7/sjnvSxp8lVJ1zOT15/CWgfKx59MMNxH3FcDxnM1Bign0ZUz4GzjkILKPwy2EA4ylq4ZoxIhojqxI9vgTXj2OYoUp8VjMH7mB3fuY4tf/9FPfY7r2TpY48jm5vPq97wrHUjeCtgLfG65choP519u0E8kXpiEYUmRAFP4L1im5bxj/6UmW9cg1k5iPrCGt7jd+wBC+4b16Mje8JA1ijZ3Ax2pIl9x7PwjThcQOny+as2Kd1bvggksKifv+fbQg2+Rfjxco8fnMykMtlXqoSfgtxDjJc5UW61sd7uvXayT7M0ezNva24J67zNERc/8jee8X+nAaAaCEocwWOZAv/28U/x+YHb5bxouzxfNhibrdMUq0acLBAiCi1ClwUSKgGp7Px9DvX1lbI/p/JKnunLgaB2H19hFFaxh11kZmVmUHDR8/7ZeaHR77j6F47//KdBfKPONz7SZu0DUv7k5ZaIQK/95UUWTfp45l+twKHM0ybBMduZRaSWQ5ID0982+pGapd7o005zjid99Gi544tj/Oxjd3P5f+6BOVhx8ggHPKQfmKchgTvgJWDj43rMxNg4d1+2DTShtqyP7Z++ju8MfJmlhwwg/XDTxy7lzi/dTDIzh/T34b0jzascZ2B+aoZkLkOa/dz8j1+Wicu3qCaeG5/1Hhl81CnY0QHQDNtXY8CAjs1ADXwtKmvhGoiJG0A/iRfa7TmY2Yuf2KemM4mOTwht0XjpMoaXDrJLhpBaM8A/NFiXte/cQ/vHN8JoE7Ikl7vq4JMZwQj+0uvx0RBqIkRTaM3C4Qdgva8Q9UvIbkWMsmD9SMXTVLrT/epksESBVYd9uQhuuOiyECVGqdGnLp/oZxVV2CyvDIJjkNMttsaNoOP+Yvo65/LRvh8vyPgX/3Yy/u8lANwDR3AeVp7LNnAvaH2Mz8Q3mDdHe+RheojBHeBTHNZ4wUcVrkAVE62LcJ2FxZUUQ8AwTSmrgQVKwfnaTxYCj8PjTWVYmGedArJbrBK9UouVrVtg4xmDdHYLDz1njpsvU975+EmWnhiz6tAGUaODFYM2Y33rOROoiZibnKWvv82f/stKak1LzTTYetMMN31nH2N3eEzcYHa3Y/tPZ9l+87juun5K3NwsfatG6D9miL0/38unH/oTjn/O4ZzwvMPpP6hBkjm8jbh781Yu/oeLdfzSrax71vGc/I+n8b2X/oC7v3M7Qy84EvUZ2dwsrtlQ9Yq6PrHUMPi8gmjw01d8nm1fuELpH2TPf1wh0Zo+GT39WEaOOpBVTzqWG9/9bXTvXq55yYe13mww/tMtmOUj9B28IqziDESgYutIPMSsCO6wFTSffCw6Nonf2aY+NKg85mQ6t40zkdwIJsKljhTwxpAkGYOvfSJL//axOGtIVUk1kH9mnvVeTX6+RQa/+0bq65eTpZ6OQqYeYw3SrJXc/VJ3r6uLL1Q9K7Q7WF4wEMx1IO7BJOtedFkwBCxZecVEv7rbD0FAs3w2YHGyX63eGNV0m7+TWnYen6l/Grdonfc7PBG/45NX6lmFbLR5o/pHvP4DvCweZ2N0sCzLDtZMBzySiSkt60uvdKnoE1elg6vdfr76y9eA3f2+r4CzfJcaXKAGWYgH6OIG8pYg5yMkDlYeIBxxvDJ61Ky+4p8b7Nxq5Rsf6OeazQ1uucziWh0V1w6vJRrA1GL8eIdjn1RjcKiPmVZK3PTMjmV883V3KX01TnrhenTe8J9n3g7aou8QePCLD+TEFx3KsgOXcv3XdnHJh7dz2Xt36/onbaBxCGSJUmtYbv78HYxfOs6Rr3o4x7/pEfT19/HoTz6BWscyedcscb2fw15xkj7kZY9m13du4qd/+V36lg1jcOqDQTPLTlzL7N5xlj/yWJY/aB19hy/HrBmhnguQdGZa3Lp1irmrdzOXtbBNy5q/fjR9a0fwrQ4g4SLPTKPpDG5mnqVnnsLAmaeU/6cM0N4+wc3HvJqZdgajw/SfdEhuhGrUeHD9dUkH+/KLHCS+NI5QF8FMBIP9ZEN9JKkDLBW/GRVdWAV0veQokXslmtwvklusVAaLSD2VYR8Lg0MRBLLwvuT7Ow1ZPxOwqtLGy5Yo9lt8qq3svRwdvZlX18dBhbMuML/tUv9/SMy/31NIkQHMX8hB8Q7ZFDXtczkCOmtJFCKP4mPBR+AMeAsuF8NwUjjsBpagE4NTG9RtxOTvJVfYMThszgK0FYZgwcyLSiahL4lEXdmvgiHo1GIiYXI2Q/oM4vqI4ybWxDLfqdGeiknamaaJByKMraM2aP43RmvYgYjUgVpLu2O5/ao5mo06hz5oNSaOuPKHEwwu7WPpEUbsgCVByFIYigfozBh23NrS5SeMMp9meG+oxTWySWXrtftZ8cgDcSlopkitRs3WyaYySWYdaX+E62+oSQTbdthGHV8LP5cUITMWjWrUqRGDJN6RJZ7MB6q56evDTrfRqYxEvc43I+Llw5BmoAbnIYvrTF9xG9M3bWf5Y4+lb/USkjTrwqxN8D3Y+8PrSNoJfYceSPO4NaRpIFoUCte+AszzCklkSTZfR7Z/nr4nPAgdapKmrksGM6VHhJYUWRVdaF9XQe35RYo+Kvfs76uZ39GVuHJS1XsPFz/rfqw5N19VQ9a/28T+JoPucxcx4l/L22o/75b7v5+Lf68JAL8qELQ/Zp8aZ/IOs16O6ByKc8Oq6jA+gswqPhKcAWfyyy0S7LWluPQ2t9sOASDYcNsFUlqeqnxWIZxZyG3lb4X4h9iSGlw8R+YNzgipMyBxrgsYiUQR1hoNIJuopCqHfYDFZzHex2gu+5UZi4lihBpZGl57XGsEvb/USZrllYcRnLPYWlPFRswn5FazucCpjVEb0Wo7hChPSiFg2SgWjCVzouoFZ2y+fy1AFuHn4DXX2VDBihFMCJYOIdMgEGIii0QRCaLOgaYeMV3pNacGV68HcVTfQTKtJMwQqBOBLKrlCEuPS5JCsUc9Qpabyxe8D1ck2FqU4/Y96nwFKp4zPsMMoKvLq5LHgK6NUxe2K/e46NoV6VioE5epqFeVcq2XU0crAz/Nur0+mUCMSgvPjTb2t7lJtX4T//ZP70U2+bLP579n6d3vAgCAbsRwIyIX4MavZHjwajlXGvaV9hiRubWaOlHrBbwVskoVkJmiArB5NWAqbxIqArH5pQsCmV2BTlNeeC0CRC7U6QohUemKcfpCTZiINLO4XHknGLrb3IbcohqVFzRo/YWAJBJjbA0lxklE5m0IJkR4iRCJUJ+/XjE4VQmechFerWb582EiROKCGkbmhNQpanMRUJX832m7UucSIeHfIE6Nis19p4ufR4FmC2BcKfQLvCkUjXPDEzE4DQFAIlMqEhUmqN6FWYm3kj9/AHYVlZoD0syRecUbCd59ob3TgipNjo7FB4CRM8HmnMyjkcEbG/wQrKDWFLLxqhU5P80BJloR7ixVUHy3xA+qPeYewJ6SI+5Ew2CvavdUDAND9lcHpDnyL1Ind5tYrzPohP8WK8wr2SS3gkohxnlvuXP3qgDwq6qB1qd5bJzIe+zB9qi5I8nSfo/PxGSR4CLBmZAhnAhOuheyuAAOQ1Zk+zIQFBc/ZNzwix3kt1TzKkAKAc7CYCQ8DikCQUxUC5nb59+nq/wbLh658EfxS10Ep7QTIVILFYBGtJ1BbUS9HkuKkCRGjdSxxJhYxKF0OgYnoi5XOhbpti1OLc5GWBuCUEYIQlReSxHAiovtUHWZC7+4+c/E1gJkOJcSEy2ewztqphZUidpp0NiLYlJT09R1EOdzH8f8Z9qVf8UhuT8dpLnijctnBS0TKqPI+y46PPf/cwHvIS62of0AjHN4a+kAaStFmnGYBXXSEAS8UlHz1pK9R6WXL1R7K/1/F9ATpvfqVQqST47PV3UgLueQ5ys9KbT8MtBUIGi4Oq61Nb3FTar1f8/7a/+OFkCe381k/z4fAEpFovOwsols/2UMDd8s74yG7Es6Rxpm1mmKU5sZIbOhHcjyVqC49F7yshVLtqAFsOVlDhfd5B9Xy/+ofJwWajpqylbBiUUw7L1jkM7cEErGfJbgVDGmXrrwCDGYUIWIRjiXEQ3ByME10DpKA6RBPa6zd7ItX/yLO1l5bJNTNh2s/aaPW781L1e8dxenvOEA1p86ymzqtMjWlJnekhjL3GRGe2uLWtQk86Fcj0zcFSbFBMSjRxwGTKTNg0aQ/gjnwUZ13O428zvngvyWIC7zRGIYPWwtW953Ce3BOge8Oph1bN/0Tea37NED3n4mtVXDkDrEhOrKZ57IA8bQytmTXhBnRNUr3hjUwa4XfIS002bpJ16KHWgE/fBcAMZ5ROs1Zt/xTTpb91B/w9OIopjOqz4HR68ge+PTiS+8Cn/YgZgjVqHtNGcDmhzkqV0Jbq2YpuZ4f+nSdkvUXm7LJWV14LrkHa1cePHB4lwcaJJP+mt4dmG5xorudj/kgOyv2NS4GdSwEe5NWf/3ugX4tbcF52PlZKZBX9r5L//D+Ofyr8sm5cCxo0k0CjW33kNTyFccgHxFHnqRDXiB9CMo5RZy32FDYMIGQU2pLNwlEhnimvL+F1u2Xuqh2YH2NAzGSC1C543gUvAT+TjLQGRgOuWwMwZ50ZdXMdtKadRqdCY9P/rUPpYcmnDnpWOkugQxSBvHdV/fxZ3f3ccjzjucAdsP3om3sQqetne0VEm9I6rV2f3du7j4Od+A/lGhMYBpGPWz89CZJuhl5wgrVaj1QTrIad98JssffRDtmTZRo5+b/uUStnzgB0gf6GyGLBlFZ1NO/ukbGLtzH/vOv5S+sx/EwHCDrR/4Jnbdag5ZNoBzWfAYECVtpdz+7I+Tbp8MLYHNhPkp+t/x5/Q9+SQxLsPaSGtAcv123GyHet2isdBpexEj6r1KFkWYfVMkH74Iv3ccee2TcZ2M5PM/QB5/HPFNJ5P+2Udgw0r4z5fAMauDPmBVtTl02VJqVgabEVHVeyD9ZLGRZiH/VaD6CjHOipS0T7VgtTq5Lor9da6Npufxkdo7EDRw8yVjE/faE3EvP1LVIDjbn7//G/6SkRvlQ0vH7ZPHjsfNrpSgtFEqOBW8fR8GZPlKsKAYUhX9pNC+LwhDOTZeuhRjL1oR/OxSh1MvnPR0x/oHZkik+E6Nn38vpt2J+aM/76MxIHRakbgsDQ5CRvHZAGtOGMB7o05TMpsxsz/hh6+bkoe9vsnAihF8rQ+XCfvvnuL2b98Fq2r84C038f2skE30Qsdw7BvWsu4xqzRLHd47ho8a5ZjXnE5tsJ+7Nu9i4ur9svKph2vfgTV8O8WYCFGDjSxRvZ/MW/rWDpI5hxho+YTRJ64X+7mI2oPXM/qMU9j5ph9Sf9ByktFBRh61nrELL2XukluZv2sffnqS5Wc8SWR/qrrUlCvSWJHOlnGSvWPYIw/Ej0+jN92J3TtNbfsY6cw8EkfSSDOwVmnUad+2l/rqYfxoP+pVvPNkdYv/4s9wd9xK9JdnEB+0guSmHcjSBoKnvmEF0b+/gPm//CS8+LPIRa/BxDZk6AD+ZYHRTEn0KVXAK0AfKcCl0m0FKNV5SrUeDYM+zTRfi4jKrCq/jGJ/m7uRAf983l27gg+osBFzbyz573MBoMo43LyRaNlT2IHVp8x+3G8cvphz6ydGdv+hJJoGKzPNm7dugDcVIHDVHkO6FuI5JLiS4/NKoBAMsTmAKMcOiCfNHI/7mykMsxgMadLk+hPqJGnGU95hdWlfJI5REjJSCsitAeq0OmnefDmmxhLMMrjy83Nk7YiZi+a44IxrWXJEg86eNs0Nwo6f7aG2aoRkLCFeKqQ3zXHgi5exAo8TxaUdljx4lDUPXsMATT5/43eZ8C2O+/tTGD5yNZlTGjYmIoK8SUpQ5lxCkqZgBe9SWfLQNUQDw9QPXceap5/Cnjd8jei4Y9j6vV8wds6/w/AG7n7VN/CtGYiWsOeN36B15U6O+cqLSFud4O4jglGDHHUgq37yRub//XtM/NWdZFv3s+/E8/DjYxAFD0Wa/SL1PvY++E068IY/YeQtT6M1N4/GEUzM0f7g95GRAdGXPpwWEK0ZVYZGkFYEjZjGX5yEzxIya5CpWRjuQ60tXc/1V8F5q5p+JcovlP2lcGeBHHNFL5Q/Lis+Z9DYe7kTq1dHolPZZzl+7hW8bGQi7/Udm/D3hbt1nwgAxTk91ycEkOf5TZNf5tKBn7sPHTQbbbj9KFIfq5E0t0kplIPKsXAoxX3BGCzhwqbE/VcBQl2eXM6SE9slB+WQ1VYrMOzi2JDuN6SdJsZMccXX9tE3GmnkG6ixJD7DJR2WPyBidI0Tkw/vLBH7dk3jW+Msf0g/O37eYmCV4qIm1/3Lfg7/24PwWcL+q2D9c1dz+we3s+G5a7nu736Ob6IJDlXFiCVrp0yZWWanZhm7dVxpKJc883OhtDUNiBuYZg1tpzp87FKOff/jyVKHmBivwQSMOY8ZXsbk56/hyv+8GD87A1PT1I47lpWvexrxslXs/dSVJEmNZS84lZpLsIcuYc5luYKTl9QLPp2BrA8L1CIDPoaVS2i85DRkYoZschJxHZIf34DaDv1/dpL0n7BOTb68jWo1Ou/+Pu76ncjx64Ji1IWX43ZOQ9yP2zHF3Av+Q2TPXpgeV793DHlLnXjzm3AHLEE7WYVMUvD8q1z9qrNPAebR3Gm5i/lXVxHzyIIJR8Hckxuiml7tWirp3/HB2gfKvf59IOvfZwMABH3CfGUYyZl87/ZL3SkH3az/fuhUdMaWB4mbG1UvHTXeF3JQJtcO6DIEC9Rg4ZgTNBt9xU045xGo6zoIa8EdKLT5c+ca4zG1mKxtyNSQzsd841kz+S9gG6QPRizMxZz5hT4OPFR0pqWgjjYdbv3eHPEwPP0DB/OBU69ixQnLedynj+R7L7iDI166iu+feZuuf+pBzN4+j8QZ3qWifo6oJlgEJ10FA2qWfTuntb19P1G/YkaC36CJBhGJSSbbzF+1g/q6Jmkco0kaal4JaEtjBZ2ZpPaQ5Sx54RPY91cXQCdl9KSjGTzpGAaImLrwGpKpPg583VPowzBPIkkyozYnUqWqqtKGVibujt2wfx5MHbN+OQOnH43etJfozBNI0jbJsa9CXMqSTz4bqdel056H/iGSS2+m/e7vwMggGln0gkvJ3vwJVUZhyQqo18V//XKoORiKkJUr4bAN+HrcVY/ylctfogCpsPcW03qFhfZNFdSfEzTNndBbOH5hav52dwPD/rm8uXbVb0qcoxcAfr1AEAaEp7AH8WfOfSE9b+3maOOuEw371mpqk8Au7DICfb5M6sKEqxbevioEIhVG4AKjkMJau6IirILHsXc8pT3hGF0X85BXjwT0WybEVrj+h8q+6+sMjvZhSVBJAU8Hz+rjDX1LRulf3g8Mk6T9zN0JT/3EEVxzwS7aN3VY8f4hrtl4K0uOWEpNU8DS11cjrnAXvA8V59ht+/D79nDAGQ/mjz58JtY70BjsELef/0uufsYN9K0ZLE1FCh6sipBqhrZniJYdyOiJR7M/HsL3NZj82A/Y+5ObkYEhWtunIBPuevnHiKSDiSKWvuYJsGpYvMuNK/oG0K372XHc66HRD/39RLMdJl72OdKf3q6rfrlRooOXos4jzmt7ak5YIkgcw74J5l/yKXRmBoYGILXIIx6I+YcXoEcchL/gSvT716r97DnCaUfjI4sZ6ccALnOQpYjmyqAVL0Ptusn8arRfjg0oLr3kenzeaSj9a3jZifFX25qOpedz0vw5PLss+bN77z7tDzQAFAPCjRsx5wHyZ3re3i+nV674WfTRgePsqq1HkGimUVdqrDIJqDgElZ4BFC1BtQKQBX4BDsUJqioSpOcKtKDjrmtTdKzF+mfUecrrY8bxpHiaZNx9S8reyy2mFjR4FMVYS5rAQ85ZxvR+4ZffuB2xyvbN05z/+Bt5xleO4ao37WD40cPIaIfpy3bLMc87lNbulhL10xiq5apG3ZYEPJPX7kdsg/4TDiJyiptL6LiOSL/S2jmmqhHRyoFg/VTxB3R4nM8wo0PMf3crN333PTDvqDUGGL9oC+3PXQZLRiHuA+OY+szFwZK4b4iRlz5KmmsE9V6NAfEWlo1q/ayT8TfvkPTrl8CAYeC8JzPxmH9l/G3fZPDDf45ERtUFRKURIMtI+xvo8mHMQ9ahW8fQbVM0/mgD9jEPlARLsmNc9Rs/wE9OY5YNUWt30FYH5xxEUSHjlTfzVesnLSS/SpUf0WBAUsCAtbj4+d5Ss5y/X8eZ22zsLvOpZp3X8u7Gv9xXS/4/qAAAsGkTfhOgm4nkdC68bXP28FXXyKcOnzMPvfEBkvqaNyRekCr1VysuwdXs7rtVQS6TVbSPTjOcmOBcW5qEOFSCd991FxqgzYoTlGlvaM8ozgozNmN6XwJmniSuMU+K1+Bj3WxYLn7XOFe8cz/ZxBz09zOwapgNf76EC9+4lZlb4UmfPVRu/eQ2RTxrHjPCdf/WguYgts/gyPLXUagVpey7Ygx1A9z6L9ey9QO/RLMOmrSDTJYZgsFV9K0aoYZnvpBK94Fwkwn4ltL/iA2se/mp3Prs/4TEs+HDzyB5y5Nwt4yz7TmfwNuMFf/1lwwfthIkpXnAID5JMCaYl2qnjazuZ+lbz6bz8c2MfeXbuKkp+OOTqJ92qHQuvAbZ8kTMwAjOzWGNgDq89/hGTOMTz8EP9NN56jtQn0Anw7ZnIB5A1g2HSdzlW7AvfBxWlaTZCBX+fBsVy0ILYi1nAFK16AqBQkx1yl+l9mYhdhhDJr+wNXe936dx8mze2fw+G9VwHnpfLPkXH8MfyJHTQ0tw2Ols+cSfpY9q35l8+MjLXdycgKymqr7rkRsursvhXcWWP/fRVV8qCgc9gbzIzj/uIg0cndTR14RbL25yxw/6aBzkWfeYGWZ0DrUeYwV8jWTegG2RNefpkKAmFxkho1YXBlYOcuJrDkJUOejhNdYeO8LYV+c59aOH0Kh5bvvAjCw/8xCaBzV0ds801IWoVigalSoH2NmOjB42LCuftFZWHDko/Wsa0r9hQAaOXM7QA1YTNWKwhnh5P+LSoLFYDDpFqQ3WIOlgDqjRf9JqbF9E56qtuGt3sWz9gcz9Ygt+ehr2zOB+dD1Dhx5A/0HDSBQoPMF12INvQ9YiAbxLAMFIhMXReOPjWfLVlzB86BJCN1MnMgSZFotGaVuj9aNaG+5TcQZEceJxsUFtih63Dlm6Aq7YhhmfwcVW9L8uwXx6M5JVpH0W+PDldKDCvq74sMLhrzrxaOA2YZxkXG5r2bX+FzqaPoJ/bn4/L/kDUPIP4ET8AZ0cM2CM0Pkb9JxtX3O3rbnCvNMca2X/KlJJvS2loURyDQC/ACAUPnZhTmCkFBQtNQdzOfHMC7V+x/69yoXnrcLPKMe9usPytcp8O6Mx4KhRI+40yGaFaKBN1AwW3YJDImEuhSOeW+foc4bVtOpy5afmaM3CYY8Unvq9dax+6AAXPP5GTNPz4PM2AEI6OYvYFt5meKLcXNTS12wSE3P6+x6Bp0ESUIsqxKRYcTS59FmfkPlbdujQQcP02QHSAUO7naAmmINsf/9VuHabma9cxVXfuB60H71qO7PXbadvzQhj7/4JjeMPIt4wyti7f8LAacew7MkPIk1myAo5NdXQy7dSslvvRvdPQdTARjGGlPiRhxPTpJ22UNchOJgGifiA2AHpJIEPEDVB50l9ilBHWolGR6zFPepk3Fd+gfvWdchzHop84VL8V69AbjgcPfJAmEsqkNLuOlC6wz5ZkPGddPX5MtBY1Yzh9Qpb8/vcBRxvX8SfN6b/EEr+P+gAkGMGfAkcepr/lxt+ILevuN79Ry01w9vXSqKpRlIIRBaZf8FAOB8IGglbgMqgUMRIIR0ukbL9euWCV4yy65IGK57Q4rS/Fcgs7ZmU67+VMDQY0b61wfzeQfpX9DM0muDSNkYDuNwjmKZg4oTZPV4lciTOS9KfsPQBhguffQfjl8xxxLlLyTptbv/WXTJ166RGA+HryALyLY4ibv3kDqa37Mf7JGga2giRBpKrASdJyv6rd8FATW750M9125J+6gc1OfC5R+PSjEZc1/0/2SpOlOa6JdQPWc7M9/dgzn4g8UlrufXs/8CPOV318acw+pDV/PKiPbL1xV8jfVeb0acdgYsM5CtUl0TozXcz+YBXgLGQCW6+g8Mg2yZIZvfgdo2p7t8D/X34zOW1VeAUqOS8gcCMKJG6Rh11K2QvfyStb16l6dsvoEZL/K078Q84lGj1CJqk3RZAu2KeXdkurZT7EuC8hSqvC5Beu02MXmFjP+ffzrui1+O5V1B3ewHg1wQOhbmA++oVF3H6ipvsf67PoiPvOIhEvUQ4UOMqvoKFS2xeEYjJs73vwoM1lN3GGDozhi88fw17r6yz4vSdPOcTMwwMRLScp2YjfvSXit87CZJBNMLhL7IsWWKZbBm8ZDlq0aDOYKxgRPCzhiwNPMJrv7CLHV+b1A1vOIAHvmwdX37A5fj9k4Bw0IsPYWh5jXYrA6NYq2z5zJ2Mb96i1OeDOWPUD6YRfrOz+bDfGh6F+iC7P3sdTM4x8LgNrH7BMUiq+CzhqA8+WpP2I9F1S2HeydXr3020dz+7nv8JTa4e58B3ncGapxyMIBzx8afpzX/xVdn5nM9o+tVnM/K0Y6GdopFh6HnH4/ceATFkLoXU0zhyGTFK+7qdOnnmh6CewMwc5vT1ZEN1yLJ8RZtvXtQh09PqZ1uBuiUeicB1ZvGnHY684hHo2y4gef4HlayOvO4M/Gg/MtVCrale/hz6W/GQW8DvD4FBvSAxzt5qY/8L31Hf/mve0fzoH1K//yvvCn/gZ/NmotNPJ/vBtaxcuzv+vF1rT7/lYJO0LZE6yHICUGASWpzGeLU4CdTh4uNAIMr58T6iHkfcedkwl32hyUPP3c3gsoi0FSOmhq03uPYzDfZfl0ETRo6KOPLMJiJC4n0pNIIGtqCJIjqTMd9+fpsVD4k5+dx+mZ9T7rxwVpf+8RL6Bvu442OzzN45Q329Yd2fHkhzsI5zRaCKmb3Dk80W62+LmBoZQuIcqVPERsQ2xpgaagxJkkB/ROPQYawGi3WpRTig44Vkb0tuf8lXGTn1MMTWVJtN1r7sZNKkReY9cWOQsW/ext5v3UD/Ox9HX1zDeMEZg43rmJwF2Sk9XlJRrHa2zzDxmi+iTogOXEHjnJOJjlyGb2fBD5LgdpxqBK/6Am68hfnAnxEP19Es1xRQgzcRfOSH6LdvgIPXoOc+FTPQRBJFJWi5q5ec1SeByFOw+rIcyJEj/XKtvkyuMTV/k9urfekzeUPzR6XPHn8Y/f79MgAAnH8+9uyzcWcptXN/WPtEY5V99s3rJW01xfgUcSZQhl0u0uE0QsWSaeDoF+xBJ1GpG5CpxdTCj6/tIzodi1hTCos0anUES4ILclpJvaIlYHK9gIJ9GFiM1hrQiI4TUgxRvU6aCN5HNBr9WGIcQjv1qDeI5MpFGKJ6jKEWglmug1DQgpUYQ2Aw+lILwQRka8cF5VWJ0NyNJUPoIELdEhETUVeAdicNEuoSLo2tN2ijpKlDXG7oiskNXLowa6eEn42JSESlY2M1CA0siiNN0px8VbgUCg5EahGguNSF9V5oxVRVxWOg3syHshF0UkgJHgAFSEO7OvzBiUeU4vJnEmy2jSBKZq60NXeru01Hs6fymsbN91b6bi8A/D8e3Ygxm/AqcOVF8b/290ev3HKocVPDiiQiGZZMolw6LK8A1JZCHV4Ddbj4e09E4gMdN6gU57RisaAW53M9AQ0aAZg4XP5SfiynGqvpXpT8+crnchax9QBDdoIQREDU5EpAEtR8tFAFwuK9yaXPpOD/B5ERTK4QFHTyJB8gemvzdWcQB/FeCgETUR+4/CK5wIgxudN1wPyrDwI4ztgSS+G1S7LSPMiEmYpBXcGozWE5LmgDaGwrjkwVgd4g0S5q8n9foPrmxB4RnAa1Ji9BHwHT9dfLtfyDeIfkQUCUTEUd0Ml/+zs4+UUU63b3M12XPIMX9N19f7n896sAAKXGgMgm/E8ujv4qtvKefYdHMrHcOE3EZGLLCiDD4iUiyy+75m2Cp2gNisd0s3BVfKNQ6illxiRCKzoESqgyVA1OBK95kDBBvyBIhkeoqZMi4C2xqWOo5dkdXJJLeolFsEithlLPOSvhQhgshhoKkkCuXmQxxApCmmY5WzIEgiyOEGMQb0RVysrHGRs8Q8h1/cLzq/eKc65QFBJqsQblJcnl1nKHRy8Y06SDI+u0UVGyWp8qEca1MM4VIjzqu1afXUNWpUvx1m6AAZG8clFxIsFTrnDoycv7TIJyT27RpUFhRNknXq60sR9LP8vzd7yYDRvaf6jDvvvVEPB/HA4qbIbo4adl7//2T+zO4RvdZzlCmvtXSSqJWnL6T9gGFKKTed+ecwbCpa2sDwtn4orlWOF26nJzsZJJWEqMu9IsVr0B4+mMwfxsvoM2BisRSZrQUTA2pm6FmjFhsm7AjEaBC6CKRtDZmTB3xyyJVUQiLDH1lf0k+zuQOhIcqfogf6Vga4baA1cgsQ2oOGNI98yCM0RRE+/JZbnzS2csIrlKVu6fST1SRvsBxRiLG+9IMjmR62MarFpss046WCf9r0tojfbhnv5AxKfoezcLU5lGL3soMhKhmS9TUjmYLcA8uZOv5nJhFfceLSf+kqN+Khh/qWr+OSAViFXZLcrlNtbJ5B28qf463gRsVPO7luXuVQC/r2ogIAezL15pTx9tmy+219eX7F4dpZlTm+WlfyYh07s8i4d2INcDzKsALzbP7DYXGukqDQtWVSxOrahEoZLQXG5MTV6iGzJnqDctP/3LiJs+Nossa6CuhkQZUV8H32qJmw8wW2KLpn00V/Xzxz8+Cj/iSNoQ9Te59aM7ufFlV+d02z6oD7P6RYew9ytbcdv3QbsFtl+Ia2BbWl9V4/ifPIPaygFIFNvo59ozLmTs+3dhlgyJNGvh0k1OgGtD3sfjEyCFRGmecJiu//YLcD6j2WjKnS/9FlNfuhITtWE+hSUrwTUY+dpzmHrxx3HbJqlfdy614Tqzh74JJNIl178WP1QjSzW3yst1AfNKP3f4zisVQ6npoLLIRVbyKeGi8j8Lb5oERx7uNIarjFHf+Tte33hXZdKv97d7EN1fA4CcTrZ5M9HpD3GbP3u1efTyrclXVnldv/2AOMFrpJrlnvGFbaaUtOEMl/++dXve0McHslGhPhRs4rv2ZardSqIgixerrxTD8IMTDjxDsX2euGnp7DNs35zKwJo+lp4QSSdJNKy2GtK3oo6JfO5S7cnwqFHAccDLjsJ3Guz+rzGaGwbQ2TGGnnYga55zHDXXJO5vctNbfkRn2/6gNqwuZHAShk9cjTMGJxkzP9mH1CMap6xF3Tzh+kWoyxAxWN/U5jEHYiXAiDt4bRy3VKY/1UIedgDmqFWkn7gBTjuQdPUI8bMfjD/3q8S/3E20Zx7d16L5lidR7xtgJm3jJVjD5mm8JPAU5L3CE0JLF/mKX19V+LNwBvGmC+11ILF6ttjIX6kdouRFvL7x2dJ0c9P97/LfrwMAwOlFEDg+veYjN9cftWZb5+trVR9w1wG1RNFI1XVL/6ItkIpgLC4PAsVKWSrSI6biu5vzDEo/Q0o0IngwlixVDn1xxMEvrqEIgzTZfXmd7RdOseoRKzj1fUsYZ14yICKiSYMsbYlzsYoJLa01FjLLyuccLlPf2YOMdBg4rg/mU80m5mnfvpfMxdi+Om4eiPvzzUOAAqdpixV/fxQHcBJTt03odcd/hL5TD5H1X/pzMjpA8BKqIRrl/4oEgj8BSoeU+tOORN5giR7zQAafezL7P/Az4icdRuf93yF561dgeDVzf/dNdGwa6hHtf76YfTdNYD55JrbVRmzo6xEJnp4LyraKq283RBSe0r9C+KNwQg5Kvdxci/WadArbeTqvHfzh/WnY1wsA/0MQOF+xZ0vnzn+7vf8xG3alX17j/EPvOrCZZEYj9S73Hsylw0qvgBz6iu+SinD5mi/nFFAxL81JRL7yOS3ERkVRZzFzg0QqpKrM9gsTt09A0kKNI+3E2PkBOmSk3uOsIjYji8MgsAnUbA1kGN2ZsveLt9F/Yj+61KHW0LpuP3fethv1MUQxzPdRW7EEWxU/UUM6l0AzZeaKXdBpkd2+R+9+zn+BCaIBIgYT10TamS792xOJjl9F5kPV472SzaZqhkel8/6rST54JQhEc/PYYw6APz0JGVpO8t1bYMATPflYZNbD8UvDvsBQejHes1OtBgOh9Pyg4hmZq/2qSon2Uy9g1ckN9Vhvcru12TqDvxm+rHf5ewGgPGcL7vzzsWcfMrfn7br0CQf9fPpLB0jrsdtW9yVYjfCu6yy8QFuwChWmuwYTCyWiUEop+kAhcnRNagXnHfWG4fqPJvzy7fuJlsR4b8G38HNzsMTrnV/cxY4fzCGxQbN5QTsYZ7RvXT8P+PLhRDa0AXgPfTH7LtvH7K0zrDv3aNKGQ2ccq15+Kke++cEytXsKHYi549nfZ/6GWZypzNvzAWZmlPYNe0GUzu4xOndOQG0ETC38wFKBGSf1cx6s/SYYdXiRUs1HM4Mctwr7wGVk79iNyRJGn/UI7LNOJSFj9xHnwvphGh9+Lv10pA2auQ6UTs2Sy4xXUj9SsYLThQKegdkj5TzAe9QFnX9jybi2UfO3JnfoyMxTeOGyG3uXvxcA7hkEzsZtVMzrZGzmND3oqc+94u7Pr3buT3YeMJi4WKKgOW8qG4IuJbhoASgCgpqKvXiuLwDl16KSy1d7vAZXKVMzRKMdassGEQxWhKktMfiEgfVKbZknm1N86lSiOtqJsaMRJkhfkOFxmkGSiqz0xMuU2e/tZujIFcrIAGNf2iHXXLEfp7O4yQla109hlw7RaXeIRuoBDovijZKQ0rplEqTJig/9MY0TV4pNhFoUE8c17njhj2lddje1ZXWULK8gDBYliyy+JZhT1zP4vOOYePvXcWKZ/+bV+G3jdJIUZuZhl5J8+IeoxKhR9MmHIyv6lLSwYi+CbEXVp+L6Fz4IIi9lYMiFPcTn7YFoxtXNmru9fSMrJ5/EM1ffxcbNvcvfCwC/+mwS/EbFvEm2ti9W/vTffy6fXi7Tz9q9aiDJanFeCUhFTEwW9PTkasSBFmu7jxFZMCMgOF+Fjyw6n3hZ8VzhUc+tUcfQsDWkNchXHz1N1umw9mUDNC0MnzJCdFANTQ3GRWTegXGhx8XjLZDOUXtQk5UvW8/2N21h2eMPElOLVYZgZvcUbut++h53AH2HLZV4LlPfp+J8BlhVFYgsbqpN+7b9yNplrHzsUdj+mDaOeo4hyCb2o3Ye0wSDw+VsG288WeqEkRj/vh8w/aELwQqknok3X4S//DawwJII2TFDcs6XSegHEuqXnYNd1V/KtxWsTUqDMCk1PnLJ30LpN//B5mWVCx8KmvHLvpq7a/6XrJ17Ik9fvYvz1XJ27/L3AsD/IgicB15O9s9+35VmfClzf7V39UiSxWJxXgKNuGJMWVxu9RVNAVMy3HxpThsqBhEtVYlCOBAiDWi6VpIiAwnbLvTM/Nwz8qx+9lw2zf73T/PgLw2z5iBhrpPiBzyCgbbHa0pGlMuCCbHrMPrElWw/bw8zN0/j28qyP1tFvMGz9axtLHnjSSRbJpl82eUy88M9DD59DaYddvASR/it4yTbxtGhAe58+UVEqGY+FQyoJqS378QO11QbQUwkuG8rKUonayFz+9H1/egD18Anr4emo/nRR8Puh+G2jNH+h++hSxoMfOwMzKAJysSHDuGdC6jKvJ4qqyXIA4PpCnmWvG4P2DLzewEcmb+mv6bbZ3/KA6bP4PQD9+eX3/V+w3sB4H8VBM5TZOM/qvnrB7u/fte1Zm5wz9Tr0mUjiWvWjDpnCpkwXWA64sKWoJwVFFVAZUugueddEKTBYyWwDR1ZCjJgmdjR5rq3KFgjRzxvGWOXOB2zKbYWo4CJhLHvzYgYr0MnjeANCBmZS4CaRjNWGDNgBskkAusk2zPN6NPXwHAfe57xE9Jd8/SfMoQe1U+SZRoXRhre09k9hQxYsU3D/HdvVhVBTE0lzUSZRec7KmuG8PUIk2QBmFSAcwZryPwMnHEifa94HHOf2Uh29xjxugGiBx5C54aLYU4g8WjqsY85DmUWdYrJvGi+iy/wPQHgY/I5oM/Rfyww9cB7cAYvYDKf+V/213T75I84Zu+fcOpRM6iaP1Q2Xy8A/JaO5CvmY47Bnv2g9PVvvbbW6peJ89KlS9KkGSuZE5UCvx7l/X2e5cV1hUSIgrJQIVEneeAIWjcUWCzvDbV+I3N7Pb94vtf56zOW/tkghz66zt7vWlHfpy5WUhLqjUj2fEnZ8ZExjr20wZI/agQkgEuhv8bUVzK94XM7MYfWpf+EQfbNzuOzDsPrRln1oiPY/fa9DP7FwRz7qRNJaNFppaiNwEZYE7HscRsYvvkAzYwlMpaIwC9I6pEml+7gtkd9jtrBK1k6PEKLhHkcLvGIc7hL7kL7mujXt9D+wV50tEH2/kvwDz8K91Bove372AcdgKow9+oLSR60AjlyCVGnjYssBcintPUWk6v55J9RjyoS0Iz5511AB5pUMn/9QM3vnPweJ+08k+OOm2OjmtwJsHd6AeDXDwIoPqwJk03/eF1d+vzYRrdsJG01m0ZdJl6D2Qam+MV1pbhoEJp1gRuQDwVzG9zuOisny/Y1hf0/i7niVY7pyxP6T4IHvLNGixmyVoZYZP6WadoPCBLj89scLB2gOdQgzg05xXhIUgYe4jjouH6GHr4CO6ogEekU3Pn6a4ky6D9NmP3qbWx9Z8zalx6Gb0Q4IyT7Zpm9fCcSRfgsxaHYuIGxNVyakMWe1s93I3EdfI3Z795ONjlN8uAV6MEj2Cxj/rzv48dB4g5+dBJaYJ7zMPSYVbSf/3l0zy7qH/pTov6Y6cd9EPfczxF95pno4Uugk+KNCdDmEhPsc1RgMTwNGH9ylWd1Qf5dEs30hkZNd4//gBP2dC//pt7l7wWA/1MUQM8ug0DnvH+4Lppv2Mm3d7AZzTo4H5T5c4WfheIiBT9fcgdiX/5idx+niFV+8Y8Nbn3/kDKVMvL4lAd+NKJ2QEKKobmug2bKzW+c4JZzW2EFNtNH44+G6F9noJMRN+vhmdMZ2usT2fCklSgRO748pkjE1Od3MDWHrHnnAzn0Yyu58Yk/4e7XXs7EDyc44gsPlmikqVO3THDHn3wv/4enQCN/A5gFWkANmsPMf+02bvvytcAsjY+eyZLDTkBcQnPTaTSoMfxHB2oyNsveR3wOWbKM9ku/j79kC+Z5j0CevAGJhPobHk3nn39C+vAvop//Y3jUAdDOwCxeAZruprL8dDDqRMA4Sf2tzbrfM/41feTdz2TdQ1u9y98LAL/ZIABu42aiTQ/M3vGaGyNT9/v/2S1Zmvq+psGHdgB1pS+h5nBh8uCglSFg8aSFK5WNYMkJKc0DHOs2zXHIORYfGXw7UY2MHHJOXV2nxdQvDcYOIOrELLGsP6dBPNAmmYOYOLD4YsFIRpY5jBodPXyIxqENBh/az8oXb9ChY4ZFaoYHbX683vXK6+l/9DJkBNJsntqhA6z54EMRCQIhxsQ5wCcXH7W5Pbozoe/G4ZMMOXUVxrdR9QyfeYRSsCDHZkA6sMTAcqX2qocTv+0xGJ/gO1B/6xMww310vnMnHNOPZElJ4c+tfvP5f57tVUXUhADowqDVJJL5m03d7R77HM/6+XORs13v8v86v9q982v9vDZuxm46nexvrov+IR7mLenI0jTpq5nMGdFcO6Dg9LvcalwrlOLC3rtLGw4UYWqWuTFL39IYl0S5FkAUIMfGYKKIDIOljiHKBW0EnwT3H28snUlLtsth10WY/hribBDtGM+IljQDFbnjQQ22UQcMGUqWCs4LPoqp2QZC6MVdjndw+Ws1pZhIV1cjBLUMn4CKpUDiORuRdJTkjglkwwjEBmlEGKdopngxiBE0iunMzqIDTaQjwf48DPlFMeUWIFx8Cfh+l7dSiWR6U1zzO6cv4FlHno1XYeN5wqZNvcvfCwC/vZ/ZaZuxF58u2Tk3xhv7+v15bumytNVomsyplNoB+SX3RKWGAIUOQMllj3MefRDwUGvwSQ2sBYkpNAW8CupyNaKKeo8Xi9ggLQYxaiOMjchScD4Ylygm+P+lISCFib2g3uTKyCYPTuF1BGigKVWKtNQmyD8v+Wst7NXz1118r1w8NWgWGMFbg898idwLd9t0PTkVnAmsPTWRlmogBD2C4te0oDDjQjtlMpPpbbbmd019W58mfwLHpJzXu/y/7rG9H8Gvf7Z+Cj1LsZ9e4TYf+5III61Ha1zPssgYX3LWJV//Fcw/U+EBFIIWXYuycCklGGsUEuXSBRiFZBjUfNRIcNeVgi8vIWt7wae+fL7weYN35F9j8vVG/vWYHHVXfJy/HiNgDRgTZMdteK9G8Ca8BqyUr0Mx+fej3H54Cfh8TYv1R/GuEjg0PNZoQYxaAPcVka44QOnTJyAqmd4hNbdz/HucmD2doeM6cJ6w6fTe5f81j+n9CP6fjl4A/rTNRB86Ot00O63v1Ol9NZOkGblDT5AUz98kGJJo1YBENCcUudJ0JEiH5KxB8SWwqCTriJamJVpBF4THJAGWbPPnrZidL/66qkCu5tZiJYAp/z6lF0Lug+BFSwt1X7xOKNF65R/xFR8FRQuugVQQk8WaT4KsefhcId7n81gSXleuAgi+kPHF6V3U/O6Jn/JH+87kwIfMs3Gj9Hr+XgvwewgDyFlgLhBxz745+nB9iXmJH1iapFEc+Vzwo2gJgq5glLcAoRWgZBnavF2w5d9TlRbLBUa6fxflxZstZcjIvx6Nc6mxUO4XMmTVmUP18SWvQU3OerSVGUX+uaINweSvJVcjRv7bN1+pcHw+0CsVkSoIyoIoVVYm+fqUvEIQzSHAajAiTu8idttnf6FrssfygIeO5yCf3uXvVQC/n+3ABeA3qprPHZW9dH7CfYb2RM16spBlQ9bqZteiIiisyfyCDFw1p9OqJZkWWT3PgtL9u+IaKUU1kXW/tvK8YRPhK96Ila8r/jv30SqrE+lWIAsqD+k+RzXzL3h8yPqquVdvxZWz8u/U3GYxz/K5pFpp4wW5a4cHq063dWK3Y2yLrsyeygMeOs7559ve5e8FgN97ENgEuvFcNUcc/g/Pmx53F6Tt/TWrrgwCxRvle59/XFwUv0C8TqVa3heWNVXnyuBpWJbueWtBESQ0BXF5G7LY7L4SQIoLXXgkSghGXf/DRY6Zsuj7aSVYaTcYVMX6ugFukSd3kAotJyI5qb/ET+YQvwDHjHHsaMdux/R27Z99Msc/dAfnn285++wevLcXAO4dQQBgE5t07JBTnjW9p3Vh0hqrxZAtvPxFNi4IQ9UM7Bf09r60LXPlx1RmCuTPQXnxtVsF4MKiToIBqS5yv9TqfKKULfUhYFTmBSx6XWUwKYLEgoBQwHW1eoEFXHdCoF2lzjLQqJNqZYIUDULu4hHjze525LdO7tdG68mc+sRbepe/NwO4V56Nitkk+KfuWzrYmZnc3Le8/4RabUmaILaYB0BMEAgNYBkKjIAE7XskCgYi+cov9OS20vMXa8AoX8/ZUv+/6N+LuYESl72/ls8ZdT9Xriq7ZiGqtmteUvbr3b8vtxlarBC7fx8g0KaY4edQaPnVgp7VXh+6tUCuQKweiIyaiRS/ZTZ1rv14Tnvyj9m8OeL003uU3l4FcO87BZX468vHZrQ2dMbUxNxdrWQqtoLrZvAMr1mewV3OFXA5082jmpX9vmq3Xai2DyGDB/V/n78PlUKWzxeKjOoK47tyZlBk/gVbCkKVQYlgrP7d4sqku8XwZenf3S5QKCFqsUkosr1f8JzdWUfXlr2oLFCPxqIy01G9a9q6bO65vcvfqwDuM+csxV4guEfd3v+gTtT64cjI8NJ637DreGsKMJDPMzEaNgRoFyTkCWYjSHfi353MR4s+DtLi5XZBQ4VALj9efr9K1veaf16KTUCR+avmJqZSBVQqgDzL64IKwZaVgl+U0f0CzYT8Vy7ffnT1O4tdoMlXjxbpZJlunam5yflX8Iinv693+XsVwH3mXCC40zYT/eiQuWulU/vTvXPTSSeZI3gMu+7grTq9L/f/ioojN7Mrq4bq8K2awVG3cCgnbkFloeXXV+YJ4vIpg6tsByqzCVzOWahkal00uKwM9BYO/hbONbqPCWfh1kPLwWOQR8tQUUyWZOyerrnpiXf1Ln+vArjPntOU6GIhO2Fb3wvNqP/Yimhpgm1ETm3eSwfjzmqvX/TkJfQ278m1rAQq1YBGZYYPUNzKmy76b2zQ3yszfeUxYirfW/JM3/28z70HvUj+uvPXt2BWYBZ4A5ZMSFmMfpRKMJDC5y8MCAMaMLP75mvJzv1f1JOfcxb+fAtn+8qX9c5v8PSgwL/Fs3VTQAteelx61bKXRiPtgeRhQ9JIFWO0XIItHoQVcVkoH1OoCEtXJLMwJgkPXwTE0VwaC6guyUt2olSgyJX8HRB9slBmjy51ecFzFJ+TipsnXaivlnv/ipJv4c1WzT1aqQ+sODM+V8t27b9al9afzsjRKRftg9Mv7l3+XgVwHz0VtOCR22ufGV3WfM4ylqZtg6XM0lEFBViZ7IvtIvByE9Aw/S+qgqIyKJCBUdnTF5sEKkak3Qoi7vb6mmfvwrm4qEyKPl9Nt2KoMBkRU35tmPxLiRD0yoKs303fpqKHIN3+3ytEkZfJ2cjdvf8OL/oIjn/eDnSjQXrknt/m6ekB/PZDrF6gKBvVrIwP+csdY3c8SJdMPWgJw2mCswuy6+L3WhRpvsy0XYfcqj5mEcpNt88uJbUkn65XDTf9gvhfbv2lO6grzXWqRpzl95Iy6xepuSQ6qZYVDJUgEN4qUt/k7YEHiSI1c7O4nXvaXtwzOf7FO9DzLdLb9fcCwB9GEPAo5mK5cfaYnQPP2Ds1c2ltMBqoR32aaSYiklNrCumrkgbf3cOXTkNZvsuvGGRKsVLL8qyeP03uQEzFYBPjUU2BmMJhZ0FQ+dUOW92+Xbrq/KW/YSnhtYgfUOD7FcSYUt9fSmNPBSNImngdm4y13fprTnr5FWzeGCFn94Z+v4PT2wL8DoPAWYq94YDZm+JW9LLtyaRNs7YLSTDLL3G+75fubr5EEkq+15diGt9FFy7eEFQ5BwU8WHO4cQgKxWYgo4vsK7AHOQKvuomQKgzY5SDhxdBm7W4j6G4oyteobhEOILw+IcuYGIuz8cmP+pNe/iE2b4w4fVPv8vdmAH+wM4EIIVu3rf7uxhLzt2vtik4mJi52/t1evMsQ7Pb+skBNKEzxC+GQ6lzAlrOEEkko0YLPV7cLXm3OBDQVVqIpn6+7sZByI6AsFAHx5fvqtL9oMQJ+QIWKrTeoFWfGJuJs19hl/vgDToMbMjjvfmnT3asA7j/HcT72pLVPfd30WHLFbjdWt6KZw2k3Oy9C35VMwoVsui5Dr4Leq6AEQ+WwCPef7/gXYgTS3HgjYARgMQKxQuJZUBHk6MNKhl9YFRQIv4Wfgwy1qmZ22rg9+2d9n3k+cnbCBTdK7/L3KoD7QxVgEPxhdw4cNdGcv3TtwPDAYG3Y+6DxFXQDFmD2owX7f8oJfsD2e82zvVTRgAsxAbCwOtAye1c1C01l+1CtAAJ3oasD8Kt4Ar9iBrBoEKjlHEIgSZ3fOx676bkXctxrPtEr/XsVwP1tKGhv2zB7Uy2rvWRnNmd91tbgHVBh/VXw8pTaAu4eWZ9F2T9/TE7wV0WKTJ3lZp75Y7WqIZCWMwG9RwWQ4/yrlOIFugWLXrN2mYeUaMVipuBQ0UznJmM/OfW53uXvBYD7axBwbCbataZ9fjojn99mp2uRZlmX07+IAHQPWK5WLmlRkmfdS1sM84rnqgzyqAwFkSrf33UHgQvgvNW2QBfQmqk8Nqf34nO68gLKckFusuplZizWvfu3aaP/b9i40fDI83rrvl4AuB+ei/CqmAPi4VdOTHS2783mYot3XtL8ImZln84idqAW7D1dzNwrNgBpfqGzoNKnOX9Aupz+LhMwcAcCvyCtKBaF7+fL15LlM4KicghfV/Ia1C2sDKrzBM3AeJV0TpnYLxh7Dkf/9RjHHNPr+3+PpwcF/n2ei1GOwew9aW5m6G/iWyZt8swhG6kxIooEnG3VSqxqiiu50GYFilvu7Au8rgSlrSobr1QgpjuVLzECeU4IgqRSAo20iuitOht10bw5FZhFsl+6QIJMxTuZ2Vfzk7PvdQ84931s3hjx5L/qZf/eEPB+fjYTcTrZwFb7noGV0Ss26EiaSWwNEb4g8OQrwoLMU6z3gpiIQDG0K9d+VUJQtFBwVKqioItEQAt4sFhU464XwaIBpCuszwpqr0genHLRD+kWmaqCGut1dsLqrj13uBWHHs+yu+d6K79eC9A7AI/EoZgV2dC50+PZneM6H0XivSvWdJK/5b17V2C0mBcskgOTewqAlAO4CgW42050+/4FohxkC76OyvcUKVwPHCIO0fA5WVD2e9QHEJMk88j0fkH4W5a/aKa38rt3nB4U+N5RhymKueOQiakldzdfsyfrfGlImipG8p29duG9kIN+yC9/UchZCp2+MC/ownZ9/riSvVe4GENlfJdX4mUm77YcXdOPouQvfAGkzP4qwa47mJfkct7F9xOccftjPz/7OXf0ey7s4fx7FUDv3DMIOBQ7sbb15XRKv77LzsURzikZqiET+2JVJwvhvn6BUEd3Mk9lELcYDKSaD++KTYH4hWvHUqXYQQEZzjcF1c1DuWUoNw5Z5XukeKNeWvut37tnT9bX/3chKtzQy/y9ANA7v+KogozUG6+ZmuzMTLuWEXFa7vtzwo8n62L6tcADZJXV3aKpvHRxA4WseJjg+4pCr8vhCRV58QUqwjlGQLutw2JUYMk5wOE14A0km1ed22dcKv/I+rfugrN6FN9eAOid/6YK8Chmx4qZ2yThnftsy6rPnC/EQhfAae+Z1Yts7Es/goq4qCz8mjKYaFUENKs8V746rMwPKEFGbtFrWAwOyqsGK45kIvaTM1f6+Qf+B7rRwAW9y98LAL3zPxyPYtbEo++eHfe3Tmg7FnEu7OXTHNHnShy+z1sAXygOk2lXY9B1B4YlDqBoG/LWYnGmL6uNrNQmrCoaQ5qjBos2IgQKkWIwWLQUIOm86NQ+T63+eh7y0jQM/nrSXr0A0Dv/80DwAuTGlftmrTN/N9ZJJMvSXDAzz/Bage1WEIM+SILLAuqudGXGu5ncAS6f4YX/9mWLkJWVwYLgsKjigASVtKD0dmXJizfxjmQs0unWx92hH/whepbl7At6g79eAOid/99zdlgLzq5Jvp7M8aMJk8SR8VlwE+pqBnT78CJT5/29Fv9deP51h3yLXYG6Wv8LLcx+ldZA15koK9GBkOAlRSVBSXJfA1WyKavje2dc/9A/hcHf0b3Mfy88vTXgvbgWUKBuzFum57LTh5qpMaZE+XXXb/muL7DxsgDaUbNQi1+Kr8u/hlyQ2xDAQmq7qL6KFFgAExbP43OQj8lXg+FjpVj5aTefSM3BZE199p8c9sGt6FkW2dTL/r0KoHd+jVbAoZjp1Z3NWYuvT1kXGdFMcfccBopflLGzLqFHC/ced483tKIctAgwRMkyzCjXgOrKVqRUFCrnCgVwCJVkMtL9+2ddY/hfetm/FwB65/9wFKjH8XkzMy7peGcQr+VEX7uknQWT+QXCHl06b7XsX4AFwC9g/XXZfln5PYqAgFSxAw4kHySWn1OHjhnfTj7O2g/fxgW9tV+vBeid/9cqwKOYKZm/pm9H/I3ZoezpI5jEeR+FiyrlA8P0MEcA5qi+wjug/LzY/LIXwUW6KsEVs04WtA/SVSCufB+0eK6iHQAkUpKpyO8fm9ah5f/Wy/69CqB3/q/ngnAjG17fNTubZal3RsVrKNezRXTgbmvgy/K/8nmtWpG7LuJvUSWgVW0A7rkNCOCfbBE+IAPJnPr9xqX+M6z+1F090E8vAPTO//XkG4GJtdll7bZeOGezyIi6hRP6vHyvKgDTJQSRbw+0FOqoaPsVX6d+4UXXherDlLOALIwn8pJfCGtJxCudmUjH9s/R7HtPKCV62b8XAHrnN9IMKGBE3zcz6zRzziyQ5pKKxXYhH14M9yrDwO58QHMDjwqzUNw95MWraL+F70PfL1oZEopzyLjB+S+z9su3oRull/17AaB3fjOzAIciD1jlfpK29NqWdRHGO69VyG8Vk1/N/NW/q1YLukC1554Xv3jcIp3/XOqr2BBIziEga1udmvIS9X0IEC64sac10QsAvfMbOxdhrxJSI3x0xjm8elVxWur/SQD0eF2o6YcutPnuZv3874sAoZWtgFRsyTXrSpLJonlAsSa0OGTS+iS5JDvom5ei0EP99QJA7/wmTxANkb4o+3RnzN/V9j5WvPpi5beA1lsp50UXZP9QDRQyXQVGoDsjUMl3/VU3oaou4T18BjyadsTP7ke8vDeIfJzV+73qBYDe+Q23AcpF2LHlzKjyuXlxouJdN5sXSsC+K/wpi+G83Z7ea64kpLpA/beqMxBwANkiHkBQJyqn/4JXnbQ6NXuzM4dcGFZ/PcZfLwD0zm+jCvAADdynWuM6n6Y+VuO9akX+S7oXXKuXHb+g10eqRKFCwLMy6Msvvl9MOZZuu6CagToP04I1n2bDp9pcdJrtMf56AaB3fjtVgEcxM2u5zWf6rbZVA3jFawgCuvCCV0RBFlQI1YqgauBZioS5LlVYqxuFqvFITvpx05GfmBz30fBnwqzi4l727wWA3vmthgHARub9nTnUO4yiwgK3n8XCob7U/l9g6kF3S9AVAdFyLuArvT+ViiJsBlLEeKcyYTR1X2Ttxds5/yzLJnoBoBcAeue3eP0dGzGvW539JJ33l7WNt2LU+UVOQYUYCBW5sMIMxGvV+KOy3luA9NMKhiDrXvzSwBR8Om91aiKNqH0IgLMu6JX+98Vs0jv3saNYBFfbXjvLjuj5w1ZSFbFdjf8IcrPPQA/O7cE16hqMis0pwhXT0dwi3Bc+AxWcf3hsxQJcYqd+T6x7Jr7q1995RmF42vuf06sAeud3UQUo5pQDk68k4+5nbTRW0cyrX4Tm6yoE+0WW43n2V8Vp1TewQA8WlYTgc5JQdUioSDYnTI877xtvA0rOQu/0KoDe+R1WAdHO6BG2phcNNm2GFZM790hhBU7uCERu861iyqwPVnM3H/FlBSCl9TfY4BEgwe2nSO+iUeZlR83taX1OD7r7Ob3s36sAeuf3UQWcj80OyH6sHc5vxT4GMg9dcE+Z+V0JB17gGaBePF5UFvb/WiEKLRAL0QxQr27S+rHpcc0G/77CSe6dXgDond/pOSsQ8m3mXtUZ1x2J11hEvYpqYc5JpS3wBTJQPb7CELxH27BA3jtX+tEsMP58x/tsnyWtvYJDbtzGBb3s3wsAvfP7qgKUCzCtg9ipczx/ft4Z51DEqy9IO0UgKARBtQLx1QoJqGr7XZH87uIEMoz6VNlb81PJ+/36bZ9jMxFn08P89wJA7/zeztk4NhO5Q9z3mZdz58XV1OFF0Orgr2oUWjL+CuqwViTG6LoEYXwZGERIHLsbft/sJbrutFdzPpZH9i5/LwD0zu//BKKQzdZlb9a9/v0tcTXv1AegjlcpWX5uoa+g5t4C0mUQCpXHhJ4fUU2939Vw+2evacwtPwu5IOGGXE2sd+7jRWTv/GGcMIwzCC7abt5In7y5FkUa12zisbGqyaf53Z0/anNpcVt+ebHrVwwikSNL8LIvduPZt3V6zZ9z9M1jval/rwLonXvjPCC3FcvW+Lf4ef2z9lw62SGti3cq1meI11IQpKIU5EtjUYfiNeAMsgw/Hvv2rtiNJf+qP3viU3qXv1cB9M59oxoISMGbakekw+48K3JWNBpZ4yPERBnWesWiaiRgBUQRg3pEnYs1SvDzLfxceqlJBt/sNox9u3Qk6ZX9vdM795EgkJ94a3yCbLP/brdGd8djNa13mlrPBrSeDmk9HdZ6NqK1ZFCjmT6NdjfnzI7Gt9kx8Cds3BgqxPNDlOj9UHsVQO/ct4KAyf8vh5J9fHTYTs6fLKIPUaPr8H7Uo2KMjCu6TaR+Y1Qb/GVn1b47KBL9+djeqq93eue+HggqFcH/4vHyaz2+d3qnd+4TgSBcbCViMxFKhGLLjzfnFMLeud+c/w9W4qN076mW2QAAAABJRU5ErkJggg==`;
			return `<!DOCTYPE html><html lang="zh-CN" data-theme="light"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>登录 · CFLYHL</title>
<script>try{var PT=localStorage.getItem('pth');if(PT==='dark'||PT==='light')document.documentElement.setAttribute('data-theme',PT);}catch(e){}</script>
<style>
@keyframes cflyhlHue {
  from { filter: hue-rotate(0deg) saturate(1.2); }
  to   { filter: hue-rotate(360deg) saturate(1.2); }
}
@keyframes blurOverlayAppear {
  0% { opacity: 0; -webkit-backdrop-filter: blur(0); backdrop-filter: blur(0); }
  100% { opacity: 1; -webkit-backdrop-filter: blur(14px); backdrop-filter: blur(14px); }
}
@keyframes containerAppear {
  0% { opacity: 0; transform: translateY(30px) scale(0.9); }
  100% { opacity: 1; transform: translateY(0) scale(1); }
}
@keyframes fadeIn {
  from { opacity: 0; }
  to { opacity: 1; }
}
html[data-theme=light]{--bg:#e9edf4;--card:#fdfefe;--tx:#1c2440;--mut:#626d86;--field:#f6f7fb;--line:#d6dce9;--dim:rgba(15,23,42,.45)}
html[data-theme=dark]{--bg:#151a2d;--card:#222940;--tx:#edf0fc;--mut:#a4adc8;--field:#1b2237;--line:#39415e;--dim:rgba(0,0,0,.65)}
*{box-sizing:border-box}
body{
  margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;
  font-family:"Segoe UI","PingFang SC","Microsoft YaHei",sans-serif;color:var(--tx);
  background:var(--bg);position:relative;
}
.overlay{
  position:fixed;inset:0;z-index:0;
  background:var(--dim);
  -webkit-backdrop-filter:blur(14px);backdrop-filter:blur(14px);
  opacity:0;
  animation:blurOverlayAppear 1.5s ease-out forwards .3s;
}
.card{
  position:relative;z-index:1;
  width:min(400px,92vw);padding:36px 28px 28px;border-radius:24px;
  background:
    linear-gradient(var(--card),var(--card)) padding-box,
    linear-gradient(90deg,#ff0000,#ff7f00,#ffff00,#00ff00,#00bfff,#8b00ff,#ff1493) border-box;
  border:3px solid transparent;
  box-shadow:0 20px 60px rgba(0,0,0,.18);
  text-align:center;
  opacity:0;
  animation:containerAppear 1s ease-out .8s forwards, cflyhlHue 8s linear infinite .8s;
}
.theme-toggle{
  position:absolute;top:12px;right:12px;z-index:2;
  font:inherit;border:1px solid var(--line);background:var(--field);color:var(--tx);
  border-radius:999px;padding:8px 11px;cursor:pointer;line-height:1;
  opacity:0;animation:fadeIn .8s ease-out 1.2s forwards;
}
.theme-toggle:hover{border-color:#3d55bd}
.logo-wrap{display:flex;justify-content:center;margin:8px 0 14px;opacity:0;animation:fadeIn .8s ease-out 1.1s forwards}
.logo-wrap img{
  width:112px;height:112px;object-fit:contain;border:none;border-radius:0;
  animation:cflyhlHue 4s linear infinite;filter:saturate(1.15);
}
h1{
  margin:0 0 18px;font-size:26px;font-weight:800;letter-spacing:.02em;
  background-image:linear-gradient(90deg,#ff0000,#ff7f00,#ffff00,#00ff00,#00bfff,#8b00ff,#ff1493);
  -webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent;color:transparent;
  animation:cflyhlHue 4s linear infinite, fadeIn .8s ease-out 1.2s backwards;
}
.err{color:#b94e56;margin:0 0 12px;font-size:13px;font-weight:600}
label{
  display:block;text-align:left;font-size:13px;font-weight:700;margin:0 0 6px;
  background-image:linear-gradient(90deg,#ff0000,#00bfff,#8b00ff);
  -webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent;color:transparent;
  animation:cflyhlHue 4s linear infinite;
}
.pw-wrap{position:relative;display:flex;align-items:center}
.pw-wrap input{
  width:100%;padding:12px 44px 12px 14px;border-radius:12px;font:inherit;color:var(--tx);
  border:2px solid transparent;
  background:
    linear-gradient(var(--field),var(--field)) padding-box,
    linear-gradient(90deg,#ff0000,#ff7f00,#ffff00,#00ff00,#00bfff,#8b00ff,#ff1493) border-box;
  outline:none;
}
.eye{
  position:absolute;right:8px;top:50%;transform:translateY(-50%);
  border:none;background:transparent;cursor:pointer;font-size:18px;line-height:1;
  padding:6px;border-radius:6px;color:var(--mut);
}
.eye:hover{color:var(--tx)}
button[type=submit]{
  margin-top:16px;width:100%;padding:12px 14px;border:none;border-radius:12px;
  font:inherit;font-weight:800;cursor:pointer;color:#fff;
  background:linear-gradient(90deg,#ff0000,#ff7f00,#ffff00,#00ff00,#00bfff,#8b00ff,#ff1493);
  background-size:200% 100%;
  animation:cflyhlHue 4s linear infinite;
}
button[type=submit]:hover{filter:brightness(1.08) saturate(1.2)}
.form-block{opacity:0;animation:fadeIn .8s ease-out 1.4s forwards}
</style></head><body>
<div class="overlay" aria-hidden="true"></div>
<div class="card">
  <button type="button" class="theme-toggle" id="theme-toggle" title="切换深色/浅色" aria-label="切换主题">🌙</button>
  <div class="logo-wrap"><img class="brand-logo" src="${logo}" alt="CFLYHL" width="112" height="112"></div>
  <h1>CFLYHL</h1>
  ${msg}
  <div class="form-block">
  <form method="POST" action="${act}">
    <label for="pw">密码</label>
    <div class="pw-wrap">
      <input id="pw" name="password" type="password" placeholder="请输入管理密码" autocomplete="current-password" required autofocus>
      <button type="button" class="eye" id="eye" title="点击显示/隐藏密码" aria-label="显示密码">👁</button>
    </div>
    <button type="submit">登录</button>
  </form>
  </div>
</div>
<script>
(function(){
  var btn=document.getElementById("theme-toggle");
  function cur(){ return document.documentElement.getAttribute("data-theme")==="dark"?"dark":"light"; }
  function sync(){
    var v=cur();
    if(btn) btn.textContent = v==="dark" ? "☀️" : "🌙";
  }
  function setTheme(v){
    document.documentElement.setAttribute("data-theme", v);
    try{ localStorage.setItem("pth", v); }catch(e){}
    sync();
  }
  if(btn){
    btn.addEventListener("click", function(){ setTheme(cur()==="dark"?"light":"dark"); });
  }
  sync();
  var pw=document.getElementById("pw");
  var eye=document.getElementById("eye");
  var shown=false;
  if(eye && pw){
    eye.addEventListener("click", function(e){
      e.preventDefault();
      shown = !shown;
      pw.type = shown ? "text" : "password";
      eye.textContent = shown ? "🙈" : "👁";
      eye.title = shown ? "点击隐藏密码" : "点击显示密码";
    });
  }
})();
</script>
</body></html>`;
		}
		
function panelPage() {
  return `<!DOCTYPE html>
<html lang="zh-CN" data-theme="light">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>CFLYHL</title>
<script>try{var PT=localStorage.getItem('pth');if(PT==='dark'||PT==='light')document.documentElement.setAttribute('data-theme',PT);}catch(e){}</script>
<style>
:root{--bg:#e9edf4;--card:#fdfefe;--tx:#1c2440;--mut:#626d86;--line:#d6dce9;--soft:#edf0f8;--pri:#3d55bd}
html[data-theme=dark]{--bg:#151a2d;--card:#222940;--tx:#edf0fc;--mut:#a4adc8;--line:#39415e;--soft:#2d3550;--pri:#9dacff}
*{box-sizing:border-box}
body{margin:0;font:14px/1.55 system-ui,"PingFang SC","Microsoft YaHei",sans-serif;background:var(--bg);color:var(--tx)}
header{display:flex;align-items:center;gap:12px;padding:14px 18px;background:#202844;color:#93c5fd}
header .title{font-size:18px;font-weight:750;margin:0}
.themes{margin-left:auto}
button{font:inherit;border:1px solid var(--line);background:var(--soft);color:var(--tx);border-radius:999px;padding:8px 14px;cursor:pointer;font-weight:600}
button.pri{background:var(--pri);color:#fff;border-color:transparent}
.tabs{display:flex;gap:8px;flex-wrap:wrap;padding:12px 18px}
.tab.on{outline:2px solid var(--pri)}
main{padding:0 18px 28px;max-width:960px;margin:0 auto}
.panel{display:none}
.panel.on{display:block}
.box{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:16px;margin:0 0 14px}
.box h2{margin:0 0 10px;font-size:16px}
.hint{color:var(--mut);font-size:12px}
.field{width:100%;padding:10px 12px;border:1px solid var(--line);border-radius:10px;background:var(--soft);color:var(--tx);margin:6px 0}
.row{display:flex;gap:8px;flex-wrap:wrap;align-items:center}
.wrap{overflow:auto;max-height:65vh}
table{width:100%;border-collapse:collapse;font-size:12px}
th,td{border-bottom:1px solid var(--line);padding:8px 6px;text-align:left;vertical-align:top;word-break:break-word}
th{position:sticky;top:0;background:var(--card);z-index:1}
a{color:var(--pri)}
</style>
</head>
<body>
<header>
  <div class="title">CFLYHL</div>
  <div class="themes"><button type="button" id="theme-toggle" title="主题">🌙</button></div>
</header>
<nav class="tabs">
  <button type="button" class="tab on" data-t="t-settings">设置</button>
  <button type="button" class="tab" data-t="t-logs">操作日志</button>
  <button type="button" class="tab" data-t="t-about">关于</button>
</nav>
<main>
  <section class="panel on" id="t-settings">
    <div class="box">
      <h2>面板登录密码</h2>
      <div class="hint" id="pass-stat">加载中…</div>
      <label>当前密码（已设置时必填）</label>
      <input class="field" id="pass-old" type="password" autocomplete="current-password" placeholder="首次可留空">
      <label>新密码</label>
      <input class="field" id="pass-new" type="password" autocomplete="new-password" placeholder="至少 4 位">
      <label>确认新密码</label>
      <input class="field" id="pass-new2" type="password" autocomplete="new-password" placeholder="再输入一次">
      <div class="row" style="margin-top:10px">
        <button type="button" class="pri" id="pass-save">保存</button>
        <button type="button" id="pass-clear">清除</button>
      </div>
      <p class="hint">写入 KV（绑定名必须是 K）。</p>
    </div>
    <div class="box">
      <h2>Workers/Pages 请求用量</h2>
      <p class="hint">与原版相同：可保存 Cloudflare 凭证并查看今日请求用量。</p>
      <p><a href="/usage">打开用量设置页 →</a></p>
    </div>
  </section>
  <section class="panel" id="t-logs">
    <div class="box">
      <h2>操作日志</h2>
      <div class="row" style="margin-bottom:10px">
        <button type="button" id="log-refresh">刷新</button>
        <button type="button" id="log-clear">清空</button>
        <span class="hint" id="log-stat"></span>
      </div>
      <div class="wrap">
        <table>
          <thead><tr><th>时间</th><th>类型</th><th>详情</th><th>IP/地区</th><th>UA</th><th>ASN</th><th>URL</th></tr></thead>
          <tbody id="log-body"><tr><td colspan="7">暂无记录</td></tr></tbody>
        </table>
      </div>
    </div>
  </section>
  <section class="panel" id="t-about">
    <div class="box">
      <h2>关于</h2>
      <p><b>CFLYHL</b> · 精简版</p>
      <p class="hint">已去掉概览圆圈与代理/订阅相关功能。可用：设置密码、操作日志、用量设置、关于。</p>
    </div>
  </section>
</main>
<script>
(function(){
  function $(id){ return document.getElementById(id); }
  function txt(id,s){ var el=$(id); if(el) el.textContent=s; }
  function api(name, opt){
    return fetch('/api/' + name, opt || {}).then(function(r){
      return r.json().then(function(j){ return j; }).catch(function(){ return { ok:false, error:'bad_json', status:r.status }; });
    });
  }
  var H = { 'Content-Type':'application/json' };

  document.querySelectorAll('.tab').forEach(function(b){
    b.addEventListener('click', function(){
      document.querySelectorAll('.tab').forEach(function(x){ x.classList.remove('on'); });
      document.querySelectorAll('.panel').forEach(function(x){ x.classList.remove('on'); });
      b.classList.add('on');
      var id = b.getAttribute('data-t');
      var p = $(id); if(p) p.classList.add('on');
      if(id==='t-logs') loadLogs();
      if(id==='t-settings') loadPass();
    });
  });

  var themeBtn = $('theme-toggle');
  function cur(){ return document.documentElement.getAttribute('data-theme')==='dark'?'dark':'light'; }
  function syncTheme(){ if(themeBtn) themeBtn.textContent = cur()==='dark'?'☀️':'🌙'; }
  if(themeBtn){
    themeBtn.addEventListener('click', function(){
      var v = cur()==='dark'?'light':'dark';
      document.documentElement.setAttribute('data-theme', v);
      try{ localStorage.setItem('pth', v); }catch(e){}
      syncTheme();
    });
  }
  syncTheme();

  function loadPass(){
    api('panel-pass').then(function(d){
      if(!d||!d.ok){ txt('pass-stat','读取失败'); return; }
      if(d.storage==='none') txt('pass-stat','未绑定 KV（K），无法保存密码');
      else if(d.set) txt('pass-stat','已设置面板登录密码');
      else txt('pass-stat','未设置密码（访问无需登录）');
    }).catch(function(e){ txt('pass-stat','读取失败：'+e.message); });
  }
  function savePass(){
    var o=($('pass-old')&&$('pass-old').value)||'';
    var n=($('pass-new')&&$('pass-new').value)||'';
    var n2=($('pass-new2')&&$('pass-new2').value)||'';
    if(n.length<4){ txt('pass-stat','新密码至少 4 位'); return; }
    if(n!==n2){ txt('pass-stat','两次新密码不一致'); return; }
    if(/已设置/.test(($('pass-stat')&&$('pass-stat').textContent)||'') && !o){ txt('pass-stat','请填写当前密码'); return; }
    txt('pass-stat','保存中…');
    api('panel-pass',{method:'POST',headers:H,body:JSON.stringify({password:n,oldPassword:o})}).then(function(d){
      if(!d||!d.ok){
        var e=(d&&d.error)||'失败';
        if(e==='bad_old') e='当前密码错误';
        if(e==='no_kv') e='未绑定 K';
        txt('pass-stat','保存失败：'+e); return;
      }
      txt('pass-stat','密码已保存');
      if($('pass-old')) $('pass-old').value='';
      if($('pass-new')) $('pass-new').value='';
      if($('pass-new2')) $('pass-new2').value='';
      addLog('修改面板密码','已写入 KV');
    }).catch(function(e){ txt('pass-stat','保存失败：'+e.message); });
  }
  function clearPass(){
    var o=($('pass-old')&&$('pass-old').value)||'';
    api('panel-pass',{method:'POST',headers:H,body:JSON.stringify({action:'clear',oldPassword:o})}).then(function(d){
      if(!d||!d.ok){ txt('pass-stat','清除失败：'+((d&&d.error)||'')); return; }
      txt('pass-stat','已清除密码');
      addLog('清除面板密码','');
    });
  }
  if($('pass-save')) $('pass-save').onclick=savePass;
  if($('pass-clear')) $('pass-clear').onclick=clearPass;

  function addLog(type, detail){
    api('logs',{method:'POST',headers:H,body:JSON.stringify({type:type,detail:detail||'',URL:location.href,UA:navigator.userAgent||''})}).catch(function(){});
  }
  function loadLogs(){
    txt('log-stat','加载中…');
    api('logs').then(function(d){
      var arr=(d&&d.logs)||[];
      txt('log-stat','共 '+arr.length+' 条 · '+(d&&d.storage=== 'kv'?'KV':'无 KV'));
      var tb=$('log-body'); if(!tb) return;
      tb.textContent='';
      if(!arr.length){ tb.innerHTML='<tr><td colspan="7">暂无记录</td></tr>'; return; }
      arr.forEach(function(item){
        var tr=document.createElement('tr');
        function c(v){ var td=document.createElement('td'); td.textContent=v||''; return td; }
        tr.appendChild(c(new Date(item.t).toLocaleString('zh-CN',{hour12:false})));
        tr.appendChild(c(item.type));
        tr.appendChild(c(item.detail));
        tr.appendChild(c((item.IP||'')+(item.CC?(' '+item.CC):'')));
        tr.appendChild(c(item.UA));
        tr.appendChild(c(item.ASN));
        tr.appendChild(c(item.URL));
        tb.appendChild(tr);
      });
    }).catch(function(e){ txt('log-stat','读取失败：'+e.message); });
  }
  if($('log-refresh')) $('log-refresh').onclick=loadLogs;
  if($('log-clear')) $('log-clear').onclick=function(){
    api('logs',{method:'POST',headers:H,body:JSON.stringify({action:'clear'})}).then(loadLogs);
  };

  loadPass();
})();
</script>
</body>
</html>`;
}
