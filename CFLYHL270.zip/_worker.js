/**
 * CFLYHL deploy-test (no proxy / no subscription)
 * 仅用于验证 Cloudflare Pages 能否部署，不含代理与订阅逻辑。
 */
export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const path = url.pathname.replace(/\/+$/, "") || "/";

    if (path.endsWith("/api/ping") || path === "/api/ping") {
      return new Response(JSON.stringify({ ok: true, msg: "pong", time: Date.now() }), {
        headers: { "Content-Type": "application/json; charset=utf-8" }
      });
    }

    const html = `<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>CFLYHL · 部署测试</title>
<style>
body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;
font-family:system-ui,"PingFang SC","Microsoft YaHei",sans-serif;background:#0f172a;color:#e2e8f0}
.card{max-width:420px;padding:28px 24px;border-radius:16px;background:#1e293b;border:1px solid #334155;text-align:center}
h1{margin:0 0 8px;font-size:22px}
p{margin:0 0 12px;color:#94a3b8;font-size:14px;line-height:1.5}
code{font-size:12px;color:#38bdf8}
</style>
</head>
<body>
<div class="card">
  <h1>CFLYHL 部署测试</h1>
  <p>本包<strong>不含</strong>代理 / 订阅核心代码，仅用于检测 Pages 是否可部署。</p>
  <p>若本包能反复部署成功，而完整面板包被拦截，说明限制与面板类功能相关。</p>
  <p><code>path: ${path}</code></p>
</div>
</body>
</html>`;

    return new Response(html, {
      headers: {
        "Content-Type": "text/html; charset=utf-8",
        "Cache-Control": "no-store"
      }
    });
  }
};
