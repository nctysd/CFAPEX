/**
 * CFLYHL — 原版界面外观，关闭代理/订阅下发
 */
const LOG_KEY = "cfapex_op_logs";
const PASS_KEY = "cfapex_panel_pass";
const CFAPEX_USAGE_CREDS_KEY = "cfapex_usage_creds";

async function getCloudflareUsage(Email, GlobalAPIKey, AccountID, APIToken) {
	const API = "https://api.cloudflare.com/client/v4";
	const sum = (a) => a?.reduce((t, i) => t + (i?.sum?.requests || 0), 0) || 0;
	const cfg = { "Content-Type": "application/json" };

	try {
		if (!AccountID && (!Email || !GlobalAPIKey)) {
			return { success: false, pages: 0, workers: 0, total: 0, max: 100000, msg: "缺少 AccountID 或 Email+GlobalAPIKey" };
		}

		if (!AccountID) {
			const r = await fetch(`${API}/accounts`, {
				method: "GET",
				headers: { ...cfg, "X-AUTH-EMAIL": Email, "X-AUTH-KEY": GlobalAPIKey }
			});
			if (!r.ok) throw new Error(`账户获取失败: ${r.status}`);
			const d = await r.json();
			if (!d?.result?.length) throw new Error("未找到账户");
			const idx = d.result.findIndex(a => a.name?.toLowerCase().startsWith(Email.toLowerCase()));
			AccountID = d.result[idx >= 0 ? idx : 0]?.id;
		}

		const now = new Date();
		now.setUTCHours(0, 0, 0, 0);
		const hdr = APIToken
			? { ...cfg, "Authorization": `Bearer ${APIToken}` }
			: { ...cfg, "X-AUTH-EMAIL": Email, "X-AUTH-KEY": GlobalAPIKey };

		const res = await fetch(`${API}/graphql`, {
			method: "POST",
			headers: hdr,
			body: JSON.stringify({
				query: `query getBillingMetrics($AccountID: String!, $filter: AccountWorkersInvocationsAdaptiveFilter_InputObject) {
					viewer { accounts(filter: {accountTag: $AccountID}) {
						pagesFunctionsInvocationsAdaptiveGroups(limit: 1000, filter: $filter) { sum { requests } }
						workersInvocationsAdaptive(limit: 10000, filter: $filter) { sum { requests } }
					} }
				}`,
				variables: {
					AccountID,
					filter: { datetime_geq: now.toISOString(), datetime_leq: new Date().toISOString() }
				}
			})
		});

		if (!res.ok) throw new Error(`查询失败: ${res.status}`);
		const result = await res.json();
		if (result.errors?.length) throw new Error(result.errors[0].message);

		const acc = result?.data?.viewer?.accounts?.[0];
		if (!acc) throw new Error("未找到账户数据");

		const pages = sum(acc.pagesFunctionsInvocationsAdaptiveGroups);
		const workers = sum(acc.workersInvocationsAdaptive);
		const total = pages + workers;
		const max = 100000;
		const remaining = Math.max(0, max - total);
		const percent = Math.min(100, Math.round((total / max) * 10000) / 100);

		const resetAt = new Date(now);
		resetAt.setUTCDate(resetAt.getUTCDate() + 1);
		const msLeft = resetAt - Date.now();
		const hLeft = Math.max(0, Math.floor(msLeft / 3600000));
		const mLeft = Math.max(0, Math.floor((msLeft % 3600000) / 60000));
		const sLeft = Math.max(0, Math.floor((msLeft % 60000) / 1000));

		return {
			success: true,
			pages, workers, total, max, remaining, percent,
			resetIn: { h: hLeft, m: mLeft, s: sLeft },
			resetText: `距离重置还有 ${hLeft} 小时 ${mLeft} 分 ${sLeft} 秒`
		};
	} catch (error) {
		console.error("获取使用量错误:", error.message);
		return { success: false, pages: 0, workers: 0, total: 0, max: 100000, msg: error.message };
	}
}

async function loadUsageCreds(env) {
	// 优先级：KV 已保存 > 环境变量
	const fromEnv = {
		Email: (env && env.CF_EMAIL) || "",
		GlobalAPIKey: (env && env.CF_GLOBAL_API_KEY) || "",
		AccountID: (env && env.CF_ACCOUNT_ID) || "",
		APIToken: (env && env.CF_API_TOKEN) || ""
	};
	try {
		const kv = env && env.K;
		if (kv && typeof kv.get === "function") {
			const raw = await kv.get(CFAPEX_USAGE_CREDS_KEY);
			if (raw) {
				const saved = JSON.parse(raw);
				return {
					Email: saved.Email || fromEnv.Email || "",
					GlobalAPIKey: saved.GlobalAPIKey || fromEnv.GlobalAPIKey || "",
					AccountID: saved.AccountID || fromEnv.AccountID || "",
					APIToken: saved.APIToken || fromEnv.APIToken || "",
					source: "kv"
				};
			}
		}
	} catch (e) {
		console.error("loadUsageCreds:", e.message);
	}
	const has = fromEnv.AccountID || fromEnv.APIToken || fromEnv.Email || fromEnv.GlobalAPIKey;
	return { ...fromEnv, source: has ? "env" : "none" };
}

async function saveUsageCreds(env, creds) {
	const kv = env && env.K;
	if (!kv || typeof kv.put !== "function") {
		return { ok: false, msg: "未绑定 KV（变量名需为 K），无法持久保存。可改用环境变量 CF_ACCOUNT_ID / CF_API_TOKEN" };
	}
	const data = {
		Email: (creds.Email || "").trim(),
		GlobalAPIKey: (creds.GlobalAPIKey || "").trim(),
		AccountID: (creds.AccountID || "").trim(),
		APIToken: (creds.APIToken || "").trim()
	};
	await kv.put(CFAPEX_USAGE_CREDS_KEY, JSON.stringify(data));
	return { ok: true, msg: "凭证已保存，之后打开本页将自动显示使用量" };
}

async function clearUsageCreds(env) {
	const kv = env && env.K;
	if (!kv || typeof kv.delete !== "function") return { ok: false, msg: "未绑定 KV" };
	await kv.delete(CFAPEX_USAGE_CREDS_KEY);
	return { ok: true, msg: "已清除保存的凭证" };
}

function maskSecret(s) {
	if (!s || s.length < 8) return s ? "****" : "";
	return s.slice(0, 3) + "****" + s.slice(-3);
}

function renderUsagePage(data, query, saved, notice) {
	const ok = data && data.success;
	const total = data?.total ?? 0;
	const max = data?.max ?? 100000;
	const pct = data?.percent ?? 0;
	const pages = data?.pages ?? 0;
	const workers = data?.workers ?? 0;
	const remaining = data?.remaining ?? (max - total);
	const barColor = pct >= 90 ? "#ef4444" : pct >= 70 ? "#f59e0b" : "#22c55e";
	const resetText = data?.resetText || "";
	const hasSaved = saved && (saved.AccountID || saved.APIToken || saved.Email || saved.GlobalAPIKey);
	const sourceLabel = saved?.source === "kv" ? "已保存（KV）" : saved?.source === "env" ? "环境变量" : "未配置";

	const email = query.get("Email") || (hasSaved ? saved.Email : "") || "";
	const gkey = query.get("GlobalAPIKey") || "";
	const acc = query.get("AccountID") || (hasSaved ? saved.AccountID : "") || "";
	const token = query.get("APIToken") || "";

	return `<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Workers/Pages 请求使用情况</title>
<style>
  :root {
    --bg: #0f172a; --card: #1e293b; --line: #334155; --tx: #e2e8f0; --mut: #94a3b8;
    --pri: #3b82f6; --ok: #22c55e; --warn: #f59e0b; --bad: #ef4444;
  }
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body {
    font-family: system-ui, -apple-system, "Segoe UI", "PingFang SC", "Microsoft YaHei", sans-serif;
    background: var(--bg); color: var(--tx); min-height: 100vh;
    display: flex; align-items: flex-start; justify-content: center; padding: 28px 16px;
  }
  .wrap { width: 100%; max-width: 560px; }
  h1 { font-size: 1.25rem; font-weight: 700; margin-bottom: 4px; }
  .sub { color: var(--mut); font-size: .85rem; margin-bottom: 16px; }
  .badge {
    display: inline-block; font-size: .72rem; padding: 3px 8px; border-radius: 6px;
    background: #1e3a5f; color: #93c5fd; margin-left: 8px; vertical-align: middle;
  }
  .card {
    background: var(--card); border-radius: 14px; padding: 22px 20px;
    box-shadow: 0 12px 40px rgba(0,0,0,.35); margin-bottom: 16px;
  }
  .card h2 { font-size: 1rem; font-weight: 600; margin-bottom: 14px; }
  .progress-label {
    display: flex; justify-content: space-between; align-items: baseline;
    margin-bottom: 8px; font-size: .9rem;
  }
  .progress-label b { font-size: 1.15rem; }
  .bar { height: 12px; background: #334155; border-radius: 6px; overflow: hidden; margin-bottom: 14px; }
  .bar > i { display: block; height: 100%; width: ${pct}%; background: ${barColor}; border-radius: 6px; transition: width .5s ease; }
  .grid { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 8px; align-items: stretch; }
  .stat { background: #0f172a; border-radius: 10px; padding: 12px 10px; text-align: center; }
  .stat .k { font-size: .72rem; color: var(--mut); margin-bottom: 4px; }
  .stat .v { font-size: 1.1rem; font-weight: 700; }
  .reset {
    margin-top: 14px; padding: 10px 12px; border-radius: 8px;
    background: rgba(59,130,246,.12); border: 1px solid rgba(59,130,246,.25);
    font-size: .82rem; color: #93c5fd; line-height: 1.5;
  }
  .err, .okmsg {
    padding: 12px; border-radius: 8px; font-size: .85rem; margin-bottom: 12px;
  }
  .err { background: rgba(239,68,68,.12); border: 1px solid rgba(239,68,68,.3); color: #fca5a5; }
  .okmsg { background: rgba(34,197,94,.12); border: 1px solid rgba(34,197,94,.3); color: #86efac; }
  label { display: block; font-size: .78rem; color: var(--mut); margin: 12px 0 4px; }
  input {
    width: 100%; padding: 10px 12px; border-radius: 8px;
    border: 1px solid var(--line); background: #0f172a; color: var(--tx); font-size: .9rem;
  }
  .btn-row { display: flex; gap: 10px; margin-top: 16px; }
  button, .btn {
    flex: 1; padding: 12px; border: none; border-radius: 8px;
    font-weight: 600; cursor: pointer; font-size: .9rem; text-align: center; text-decoration: none;
  }
  .btn-pri { background: var(--pri); color: #fff; }
  .btn-pri:hover { background: #2563eb; }
  .btn-sec { background: #334155; color: var(--tx); }
  .btn-danger { background: rgba(239,68,68,.2); color: #fca5a5; border: 1px solid rgba(239,68,68,.3); }
  .tip { margin-top: 12px; font-size: .75rem; color: #64748b; line-height: 1.55; }
  details { margin-top: 8px; }
  details summary { cursor: pointer; color: var(--mut); font-size: .85rem; padding: 6px 0; }
  .saved-hint {
    font-size: .8rem; color: var(--mut); margin-bottom: 10px; padding: 8px 10px;
    background: #0f172a; border-radius: 8px;
  }
</style>
</head>
<body>
<div class="wrap">
  <h1>📊 Workers/Pages 请求使用情况 <span class="badge">${sourceLabel}</span></h1>
  <p class="sub">今日 Cloudflare 调用次数 · 免费额度上限 100,000</p>

  ${notice ? `<div class="${notice.ok ? "okmsg" : "err"}">${notice.msg}</div>` : ""}

  ${ok ? `
  <div class="card">
    <h2>请求使用进度</h2>
    <div class="progress-label">
      <span><b>${total.toLocaleString()}</b> <span style="color:var(--mut)">(${pct}%)</span></span>
      <span style="color:var(--mut)">配额 ${max.toLocaleString()}</span>
    </div>
    <div class="bar"><i></i></div>
    <div class="grid">
      <div class="stat"><div class="k">Workers 请求</div><div class="v">${workers.toLocaleString()}</div></div>
      <div class="stat"><div class="k">Pages 请求</div><div class="v">${pages.toLocaleString()}</div></div>
      <div class="stat"><div class="k">剩余额度</div><div class="v" style="color:${barColor}">${remaining.toLocaleString()}</div></div>
    </div>
    <div class="reset">
      ℹ️ <b>每日请求数重置清零</b><br>
      距离重置还有 <span id="usage-reset-live">${resetText.replace("距离重置还有 ","")}</span>，北京时间 (UTC+8) <b>8:00</b> 重置。
<script>
(function(){
  function msToReset(){
    var now=new Date();
    var reset=new Date(Date.UTC(now.getUTCFullYear(),now.getUTCMonth(),now.getUTCDate()+1,0,0,0));
    return Math.max(0,reset-now);
  }
  function fmt(ms){
    var s=Math.floor(ms/1000);
    return Math.floor(s/3600)+" 小时 "+Math.floor((s%3600)/60)+" 分 "+(s%60)+" 秒";
  }
  var el=document.getElementById("usage-reset-live");
  if(!el)return;
  function tick(){ el.textContent=fmt(msToReset()); }
  tick(); setInterval(tick,1000);
})();
</script><br>
      今日使用情况总计： <b>${total.toLocaleString()}</b>
    </div>
  </div>
  ` : (data && data.msg && hasSaved ? `<div class="err">❌ ${data.msg}</div>` : "")}

  <div class="card">
    <h2>${hasSaved ? "更新凭证（一次设置，自动显示）" : "设置凭证（一次设置，自动显示）"}</h2>
    ${hasSaved ? `<div class="saved-hint">当前已配置：AccountID ${maskSecret(saved.AccountID) || "—"} · Token ${maskSecret(saved.APIToken) || "—"} · Email ${maskSecret(saved.Email) || "—"}</div>` : ""}
    <form method="POST" action="/usage">
      <input type="hidden" name="action" value="save">
      <label>Account ID（推荐）</label>
      <input name="AccountID" value="${acc}" placeholder="你的 Cloudflare Account ID" autocomplete="off">
      <label>API Token（推荐，需 Account 读取权限）</label>
      <input name="APIToken" type="password" value="" placeholder="${hasSaved && saved.APIToken ? "已保存，留空则保持不变" : "Bearer Token"}" autocomplete="off">
      <details>
        <summary>或使用 Email + Global API Key</summary>
        <label>Email</label>
        <input name="Email" value="${email}" placeholder="you@example.com" autocomplete="off">
        <label>Global API Key</label>
        <input name="GlobalAPIKey" type="password" value="" placeholder="${hasSaved && saved.GlobalAPIKey ? "已保存，留空则保持不变" : "从 CF 个人资料获取"}" autocomplete="off">
      </details>
      <div class="btn-row">
        <button type="submit" class="btn-pri">保存并显示</button>
      </div>
    </form>
    ${hasSaved ? `
    <form method="POST" action="/usage" style="margin-top:10px">
      <input type="hidden" name="action" value="clear">
      <button type="submit" class="btn-danger" style="width:100%">清除已保存凭证</button>
    </form>` : ""}
    <p class="tip">
      <b>推荐流程：</b>填写 Account ID + API Token → 点「保存并显示」。<br>
      凭证写入 KV（绑定名必须是 <code>K</code>），之后直接打开 <code>/usage</code> 即可自动显示。<br>
      也可在 Pages/Workers 环境变量中设置 <code>CF_ACCOUNT_ID</code>、<code>CF_API_TOKEN</code>。
    </p>
  </div>
</div>
</body>
</html>`;
}



function loginPage(err, action) {
			const msg = err ? `<div class="err">${err}</div>` : "";
			const act = action || "";
			const logo = `data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQAAAAEACAYAAABccqhmAADe00lEQVR42uy9d7zsV1X3/1577+/MnHL7vbm5qZBGQiAQAiG0hCIEkCJo4kO3gQWxozzKY4gIgo8NfFQQFVBBSEDpXWKkhN6SUEJCer39njrz/e69fn/s8t1zgj+7tDP3Na/TZuaeMzNr7bU+6/P5LGH98j11URDAED+u+VG8Svy4flm/rF++W4L+EnAaA//fcvt/823XL9/ZF1l/Cr77T3sBX31vO3BcZ+3RoroVGIFdsiHcCO7rwuS6XADkJCAQ1p/N9cv65Tsr+G31+bbO8JxO+KA3cps3omqMqrGqxqVro51pDnk7/LS3w9/WZss968fS9cNi/bJ++c449XPwK2xthd/yhpvUoGrQYEU7a9vONuPODMednRl3dm7c2Y0TbzcHtVtV3Wbt7Py4k7m3TNh6ZvXY623B+mX98m0e/ALQWh6vhmty4HeGcWdl0jnT+qbpOjfqOjvTdXbWt3aD7+wW39ntXed2tp09YtzaI7yaneplS+tl24sv4jy7trJYv6xjAOuXb6PgF1AFE4TfMcKvAngYI+IAUTGIGOJBbkENKvFzwQIOxSIaP6KNB6zTRRO0/XCr235qxFe+rmBrXGH9sp4A1i/f4uAHuAPmthneZOH7PbQKYgQDBhVBMYixgIkBjgWJXwtN/BqLqEXVoWoRbVRx3unSIDDebcz8D0p3+UfWk8B3x2W9p/vuCH4D2C3CxSn4x4AVEYPE4Ef64EcMIhYxLn4UhxgHxoE0qDQgDokfRcS5TnZMjGzbEcL4HWPucZqA19QWrF/WK4D1y7cuAVgB3wqvdMLzYslPE1/dxPcRSSe9RcUiYmMFIA7BIjgQh+JALaoW1MVKgAYJLt5XnXcsN14Xr14J8w/awGV3aBwzro8J1xPA+uVbFfxjw08M4DVemCjiBAVjYuBjUsDHsl8kJwGXPg4QUtDjQGMSiBhBEz/P31MLOtNZXRh4XbjE6t0fC8stXBzW2YPrLcD65X/wchFYA34VTrbwRwhewcZqPwa/iiAmAX3Gxu+bKgmYJpb+ksv/9DG1ApgmtQTpaxkgiPVsX7Wy5WETue63hYs9nLf+PlqvANYv/8OnvwHUC++1wrlemCA4jEFEyIi/ptJfMBixBGws9aW/ijhUG8ChufTX2B6gDRpcnAyohWAxOgqqAWGfN8HdF959JVwgwoXrrcB6BbB++R8q/cPY8gQrcm4ntCo4jIDJJ7+AsfFqDWosPpX95KpgCg+IX5tUAcQqok8Q4CK0IAMUMchcMOwYegkXxPL/y+uHyXoCWL/8DwS/AOEKGFjlAkRjhW8k/iS3AMamIBdEbN8CWIeYBmNdTA7pZyrxcyUmgljyNykJ2B4kxKHSoIjzsqET2fDklh9+qHDx+lRgPQGsX/4nXjMBvZvl8U44vTN4jFg16ScxG8TR31QiiFVArgpKJZCTQM0LyK1Dnhzg+rEgrtxWGalhuxGR58df7e7rQOB6Ali//PcXASDKcxEQK5pL/1ju2wL6xVM/XtXGoFcxaNUCRFJQ4gikRJExA8htQj75E2+AJrYDKtYz72H++xZ5xunChWG9ClhPAOuX/+bef+J4AIazvaHDYCINyJATgZTAj8FeEoG1KdAjCUilKv1TRVBwgwok1DQRiHyBBmh6IJGRt2wbDBg9b/0VWk8A65f/gYvAT1qDxeAjDzCW/dhc1udrf/rH8V7/MSYIFxNCffrn8j/dVksSqJiC6WOiD9uOGUVmzj/ALxwXsYAL1t9X6wlg/fJffPobAb884mjgB4IhiBOrRiSe/CYh9wZsLOm19P2mQv4TLmBcAQBj35/YgpKEQdInhdIeTFUHDTBAcQKzXcP2uYFpnhp/21PXJwLrCWD98t/xWrnAM51hk1o6RExE/CURf3LJbwoJKLMBNQdyIgL11UCDmPyzPiloUgyK2CpR1AShISqDlAicBOZBR0+7lgtGcH5YNxBZTwDrl/+6018AfwPMGOVH1AJGjFqJp73NAS1Tp7VW7YDkHj+f5HVgG9dXBHnsVzEDI2U4jQVN5ANEYDBWAcjAdMx2I7acvM0OHhd5ARetv7fWE8D65b/qdRLQXZZHWcsJvhGvRgxGECto+hhLf1NKfkmnvZQSf3osmBNCGfmtHQFWgGFJDJRTP4GADqUBGSlsxofRc+KvfOX6SHA9Aaxf/uuKABDheak9D8YJ4vpALzP/guRXp/0Uum+qayYPVQkhg4NTuoA6QbgKHIwcAcURMHbFjIJh/pz9/Pm9hQvDResjwfUEsH75T0d+HP2NeIg4HuaH4nFi1RnUSCrxKxDQ9qBfUQSW075ODBkrsEgB+vJI0BSykEp1+ptBLwwyrlQBmgRDysjPyI7BWOQX429/3voLuJ4A1i//Fae/UX7ZDDDS4HPZj408/8gBsBHxt33g61Twm8L3z6e/phN9Ovgr4G8NTjB921gFlGvkBpglBkGYP/8WLrr7eZwX1keC6wlg/fIfj3wDqM5xKpbH+Ea8ilhNp70YKbz/kCuBTAEW27cGebxnpnt/kagcDGuBwZQkJHsIShYGmTIFUNOgNn00jmAaglhRGfoZdoxaMc8VRNdHgusJYP3yH7+IgHbKT9qGAQ0dRoQU7HnsF0v4dBVTkkKZ46dKQOmrgJ76Kz0BqB4nUlULfBOQMOEDwTqCmaoGzKpxAeaeeg3vOIb1KmA9Aaxf/sOnf1jdwImI/EgYGa/GuNzri43U3hy4Uk0AVCQiB6ZqDWpcYA0paCoRGImnfsYAjAMzKJwBzSNDYwmJUBRsg1qH2oZgRIJpulmzbXOwo59drwLWE8D65T9x+kvgl9yADdrgxRghE39yr2/7oO8VgFkNKFMnfI30M6UNMMVAJAOFRU8wpQnIHy0hE4Yy/mAbNCcE09ixMUF18OPXzV66K1YBup4E1hPA+uXfc/ovb+EYKzzFjwiI2Hyqh1yqFxVgrwXQyvarB/Gmwb84+hOUeJU6QdCrBmMicfExa0AwEY80X22eSEisBIyRYGw3w9atCyvmJ2MVsP5eW08A65d/1+nfjHm+HcomnHQIQqXxz+U6U8QfMz3mmzrxpewGKHLfmj6cJwLWldN/ujWwPbswS4qrRBCMIRiX2gJDZ6xdtSZ4mfmZz8x+ZhewXgWsJ4D1y7/19B9v4VRx/HgYRcOPPtAFs4bYo6Yy/6TS+ku/A6DnBfQlv4pNAV9pAPJ1DSOwBH56/Bzo8cSPVUCwORk4VIx41/gZ2bFjsmJfIIhezMXr77dvt5Nm/Sn49ksAAqHdwBvdjDylm5NWsLY/9SMYF8t8k3T5lbe/WiDZeZO9/NKqr2L7na2/m6LvRxOvXwfx6zBAdYRo/KihEcJIgw7QMCDoANUBXgd4dfjQ4MOANgzovKULjo5Gx96wsjpeWR10pz90fOo1sbqRdfPQ9Qpg/fJNgj+y/rZylrGc52ekEyM2kn0kAW5x/p/L91yia038qcDAerwHleY/twUJB5ju+3svgUgAyo8ZGxG1RrA2If+2XEMGIK0lWIM3IqFxfuS2zutk+OsJC1i/rCeA9cu/nAPAePktMyeOoQSsQV3v6oPtKcB1W6BrKL49BhCLvD5BJNpwKfFj25AnAFE2HI1Da1ux3lDElgQSAz8FvOmTQLCW4FxMEM7Y1RnvRWaf9sHm2tMF9CIuWtcIrCeA9cs3O/1Xt/NYO+SRftZ0WONwFrGGKP3NAZzUf5kJWJF0poxBqilBJAhV1cKdNAHVGJDaPDROAsQ0WjwHraU2IolYgCFYQ3AWb21MAjExiB/YYAfzg+XW/B/Wq4D1BLB+uVPwC4Ceg7OB39J5YCCKMYitpL3V3H9a6Wd64k9B9r/J/H8qQVSUYesq2rCpyv6eCpxBQTW96UgwIlolALWW4CzqDMEZvDP42ArY8VzbObPpCRfbGx96Puf79SpgPQGsX6rXQcC3V5ifdLNyRpgxbez90+gun7S2l/7mj2qqSqBSAAqV5Lci+5DagJ42XM32rYWE6pfbm15shHWKcfl2GhNCzz0oLYHL1UC8qhi0cWrmZq0PM//3knPUpdS3DkKvJ4Dv+dPfAGHpSI4yTn/Lz5ugzhgtjD8pJ38ss6XgAFMqP9aw/oyghnRy5/XgvVloDOTYp0/7BNgiEy57A2pRkXGKcRoi2KeZ/edNLvlNFCblliCBgoqxk/lxOxhsu+/1H9n3y7EKWH//rSeA9YsI6KDjZXaOrTqSSPm1FSU3Bf8Ul99UkmBTndapYqgVg/19shNwcga2rmAIWhaG2qQFMFNbg/JJHyRes5YgGIMXKWrE7E+gSaZcEoA14KyZbJx4mP0/r53fffL5EC5A19+D6wngexr486tH8Hg3kKeFDTIRm8Z+OXATAChry/w1zD+pcAFJIz7WoPf9/ePXIY8Qi6FILQCqCULVMpEyghSCCAEIJn8dK5TgIl05pEQQnMS2ACM6Q2hGo7nVpZmXI6KnrnNR1hPA9zDwp7eexpxBfj/Mi2pjJM/8KUBbD/aJMZEFuEbOq0UcJFVCiD19FvxoVQX0CsHsEuzSbVwF/NneJ6AkkYoGXK4p+IsWwJRrsII6iUnBChoxDTve0nbOzjzhlc3i95+P+IsiK2n9sp4AvueAv7B1D7/dzHFimJUWESvZ5dfFa0H+bVVKW4mvnAiSNwFLZQdWTwSSSEhsWhM+he5XGv9iAJq+NyU3nrYaK7Tf1OdrCnBvBW9SZWCnAz+4eFULzEDYgrZt84pXH7dv05Wg6zqBb83FrT8F37rSvz2Ghxvh5/1G04oTVy/tLMo8DCZz8NO+PiMG1CQWX57dZ6afgEZ2nxGDps8hjRQ13T56iyejEItoQ1YCxuWfBgmJ3Zf+X9VINda8U1Dj46j2m4VDEAJC0HhVhGBAAwTRWC2omG6r70bjwfF7r9cXX4j8HFzigG793bFeAXxPlP56BrMS+BOzycBIyomPM9V6r0rkU/rvXpDTK/kqVl+e9dcOQOTlIHkXYHwcU+7XlMfLSUGk2iqcuQXWoq5nI2Z6cmYAFkKQpKBPD6emrghIkw2xq4f5VlzzM78xXHn4hTysW28F1hPA98Il8v338DK7wZzsN5oWY2wu9yW78pg1Dj95tl+p8kQMUlUGSehfAr++n8g3oQgXC/C1q796d+B6Z0CP8teTCFPakugLYKb8AYKJQR8c4ARtBHWxEtAZFd0mls696tdSK3DBun3YegL4Li/9u9W72scNBvI8v1VaLE5NPbtPgJ7NNF5i6Z6+F+3ApCfwpLGdZEAQ6Uk8SftPZRJSE4nU9Ah/NvnIk4BAZATemSXYg31hKtgNKhQ8IN4mBX/5OnYeUYyoEMSEbb4dzLsTu+tnf+9CkQAvWn9PrieA777LBYnwc+je7HAm/BlbTdCBiNQEnczGW8vTNzI9YzdJIGTrpR+mZ/iZyuefjB/Uhp/93B9c5QgkZaeglO3AtQlINhXp7cb7ZCCJ+BNPfZ9PfxFUIBgIRlGTPhdQURTs5PCuNW74E88drT7hQqQ7b70VWE8A322XF50T13uNFvlzu0mO6ubECxIZfzad6jYCdVpz/tP83liHuHy7HPhoUQPWa8LXuAFJsQRPdt+F7turAbPzb0kc9VbhMgJM7YWJfX5uB0I9EkwMxBz8IX3u8/dSIggZhwTCjIgeHkLw9s+eu23piIsRv04QWk8A3z2l/zk4uZRu9WTzi82s+QG/QSaiWE0BLzau+dI0MhPbe/zF0r8334w9etkHINkIdGorUN3P5x59SkOQen/rSgsQH693/K19A9RM//+9+WcP/vUBH1mB2CoRZDDQamwB6nbAgiombA3ebnVHLC0P3vi8R181/DLIulZgPQF8d/T9l9It35tzGqsv95tp1WExBpP65BxAtb5/6qPNwGAvBy66fmunXYKLsMcU/wCpNPzTir9+m5AWp2DX04tNDy7Gkz+JfUpbYBMtOPsT1KSgngwUbF/2B5OCPn+0CkbxYP0R3WQw487Z97Fjfv9iEX9OnEeuX9YTwHds8BsBv3gGuwadvIEt0uisiFgRXOyZ+2DtA74IgaasvWvbbzt9O1sr9myl8JOqEujXfmslHirW35kqnP5PtdOjxwIw0rcC+etAmv3H2ymJCOQzC7CU/pkLoKU68FbwVlOFgOuO7FrV4XOfvHH1By9FunMiP2D9sp4AvuOCXzgPueg87GjMX9nNHBk2SisYQ5qlS9LOk6+pdJ5qASpTD62AtzppaCrfS7tQc/7tdGuQjUC1HvnZdPKbNdhAtSwklu29H0A+9bMwKIqEepuyCDZSBTslGXhDqgo0AoOJeyQKzCF6RBeYuFf/wBGrJ13Kw9ZBwf/Gy3p2/e+6nIOVi+nGp8uf2k3yaL+ZiSCuLt+nADsyS8+k1jd9VFvIPJKYNSaz8KRi22QgLzH9JB2pqpGhJ8Yi6vokgO1r8cTiQw2CRXPE5mDWJCtGCGpQrRyCEUImJqnBi5GAjSKhfF+NlmSBhAGQvm8UVYmG4f3mAGN24m1nt4136989/bRbz/7bL7ESn4x1N6H1CuA7CPTr7ssvDIby036LTLDicAYaC42JV1ej/elzqfv/6RVf+bahEHlIrL8+qfTMwOkpQo0pSCYJmbWbg2tL8co+PJORMscgG4Dkk76oA1OPL6nHl5gEguTSP43/SB+zZ0HiBWjaOI6KNUd3k8EWd5/dN25/FSIh4gHroOB6AvgOCf7VM3miIH/gt0rLIPn651K/sYjLxJ6e8FM0/mtkv9PAoOmpuFJvA47/fxEHJVS+tv6isgKTNY9dlorGR5lqQTLgV+jCxibU3xTAL8qCexpwCXyjiRaceQGJDyBKlxOCJDC0SBSUAC4c27Vm1j39YdsmL4x4wDoouJ4Avp2D/7yI+B+6P6c4ldezQ5Q5FQxCk8ZxLp7qZVSWHX7WjgNNbwPej+D63l+sTIOFUjkEZ0KPrLEGN9Hxt2gITAXyfTOfwco7QKtxZDb7UCfJAlz66iUHtDA18ss9v1Yswfj9iBFoxgPS8C8oeKc2HONbXPPihxzWPS0mAV1vW9cTwLcp4n8x/tCj2TGjcpHdLpt0k3hqso9LAW96wk9x/K3IP1Jdp8A+6fcCrJ0IlNO9QvfvbB6SXX+k3xYka6cP0xyCPF2QkgQy2GcTc7GfQvRsxb4FKJ8bTdWExnK/YgX6nAQsBKcxKVhQDzqrwtGha5G/uP/Ryw9enwysg4DflsEP6K1PZ27267zVbpV7+K0yIYijSco604t3qMU9YhDtBT2qSbyjESiLbW8f2BFQI4mA0kkfehkw5f8wBE2f5yhE0uPH/l3ybD/vCizRahPQl0d/afyXAcdgSi+vIuX3zrfPcmBF423K86QEJbYLKhEXUFCNAGEcJ1K+LyIEj9EtwVs1w/HNg7eefuzqQy+9fvSVhI769XffegXwrQ7+2H1fgN12rbzRbpKH+G2MERxOEuAnUYKfQT1rqtl9ogBnd9/UCmgluc19eBb8SKH+SmUcWs3rq1EhU+W+i8ShZDpSzEIS53960Ui61qNHE4N7Gn+Q6v80Oc+kE15i116uUgYWapMiMOWcYMAnvADTi4ZwoB7L9tDJkfaw1jf/cPrdlo6Iwb9OF15PAN/q4D8PI0JoP8Rrmzme0O2QCYYm98jYXjdPksRm9F+y428V6IVzb1IZn/v5RK2V5ARUtwqFr29NtcwjTQdsbw8WOQJSRD1USSCrAaMMWEqbUHwCpSceTeETtR2YIZGImA78Mq3UiOWnv0UTAQirhTqsoslFiF4vYEA7LNvb1u40d1teGb3r5JMPbgMJ60lgPQF8a4P/Ynz7EPnjZlae3m5ngsP1wR/7fqykj9USDytTAhopuEAMLpG+p5Y6OdSTgBzwlUdfX1msEQUlRF/smgUhld/gnSYPU6SialRpK2VgdiEWpvj9Pc1AEj0hmYRYgVQd5L4fK5o+pvtooQwHm/aWpvGg7OomZoc5fWVl7u93PvLWufUksJ4AvqXBP36YvMSN+NluJxMZ4MSmsr8EeX+6i6nsvSvDjix7ySe95KRQLwWVmAiMrbX70waiJciLeWiVcKoFI9EotKf9ZjWhiExxBrTeMlQtDa2rlKRKLC1CEfykazCalIDaKwETExArGjlIilhVtVqmJGp73QCmbweC4vSIbsJ2ezbX7rjohEdfNYwvyXoSWE8A/1OXyPLz7SPkwsGQX++OkInMiJU05xdHku3mMR8lIfRz/z7QtcIDcs8utgpYMRUW0N+37PSzmc7bn9rTY756YUhND656eal7filEH9YEebYD722+8hyfvgXIp72JJX4QLRZhKin4G1SaGNihEdT1KwhCqghCriScpglBSiwizhzVTewW+9gD1x33pjOe81kHJqwThdYTwH/7yZ+JPpNHmRe4Ab/Z7ZJWZsRijNAINEyBX9FjM48B+9M4Vwdi+2Aut8vz/imrrZrpJwWYy6Be0RJMLQfNCcBOWYZnWm+WFitS7qNW6M1JcwtAtfBj+lqSQJH/5hI+MwDp72eqyqA4A0lhMIdGCA2oUynBXnCCdPsmYgZixdmj/YTN9ge+/rF7v/nu510+SK/SehL4d1zWx4D/3pP/UrrVx/BLjeN3usOkZZTkcA0JpacKrnp1Vwq6PNbTFPiZ9y/9qE7UphFe4v8HSZx5kMr9V+jdgMt4MdTjvHxb1ugMsndgBBo18fvjSDIi/fXvlOr0xOfvlX/RlTiSdoImVJ8U9KoxAaSxZRzzUUZ9Pk4vVTM1OF9VRUXQ9Hgk3UCgGieaVPSjzh7RTeRW96Rrv37SX6PyFCQ/4rpuYD0B/BdeLskn//fz883A/L4/XFoZaGTFOFPZV/SkHCsGT5UEquDvG//ezDN/LyC9yCfN+CWJc9RDpuqaJMDRcuglezGVFAcpyPMRm/nCmnkIUuzHUYuGylg0VQYapAR+bwfWJxBN3IJoP065BgGf5/r5+xpRfp9+3oF4gWBEFcEHJOTgLwuD0teBkmzitzWGuMW5o7pJe1vzw8Mz2vFE5FmqataTwHoC+K8D/PLJ/3jzv5uGl/pd0jJSQ0Ckkf7Ur224E0++JAQMBArRByrFTArI8jn0ar50KvfVQyLtZCJQrBOi4i+p8rJqUNUgNIgaQv5/Ezkowe7x9vm2aqYdhdPXgSTjxcSgFsEDXjVeBbwoXoUOLT6AVMEfgtKhtChdeoyQRUSKBIjTAaQEf6wMlJBwfk3ZZaoiiJ2/s0d2k3Cbe6a9T9t1n5MfZz0JrCeA/8rgnzyB5zcDfanfKS0zakRFGNBv6Mny3eqU1Jqem05t8T2zrrDrUrmfE4BQVwj0QRsSIJhOdK3aB6GWBqctQDgI9f3yUhBTgrsEvSZwsUoCIbEBfWppRs0Ii2GSBvS5BdEkPxY1aIBJ6AgmxL5eFVHLwCU9lAWnsNBCCJMyfYiswTRO1L6TV00gYpYV07cHObwlKoUdR/oJt7gfs/drg/+0PDs1GIaUX9Yv6wng3xf8cdTXTZ7ErzVD8zK/U1odBCMapfUF0MtoegpqMTmIoKbxonEBiHqTSvTp07o/nfPhlTEAUwg9Gmyv2c+beXKwq60CWOL3kgtQTgqaNP8S1uASkq16Ten34+kfAcEJcN1kL50aViee8UTxxtI5R2cMXqFDaDUwP9yGmhk6AjPDAbcuHuSqvVeze7KfziijZoYts8ewcdMxeA147dL0QWNCCX0rkaAPDSqEoKKantMqQUAKcVEnR/uJ3uZ+Qs6azOqj/ulZXPiwbj0JrCeA/2jw+9Unc0EzMi/yu2hpgpEgEplr+UCVflxW9cbTnpb9z6QyzyCX5SGV+SGV9JoDMUZA4e1rvwZsqszX6lQvegAXvzZJi5ATBLavCDRWC1LdT/PgvdIaNM2A61YXePJHX8liuwKdR1VTVdNEwC+0GDugaye86FHP58T5e7I8hnd+5R1yydXv4OB4SZEmVS9jBkY58cgHctbpz0SaTQRt43OYc2bWERijBT9Qo/hkJg5VdaXxOQsA6jjKT+TW5ql84EEjfZ4+lT+WMReo4cL1JLCeAP614FeEFyFyIb49X17hhvxcd5i2MtQ4U3PpZLY9Ay7P8++06TqX6BX4pqTbZ6COSPhRTadyJsMntU083SMrRjUuAy2CoTxrTC4cGpJjD5EGrCFNCPIacE2VhwiGejpRYRFJnJN9AzX9ft7AnuV9MDmQ2oWZ+PbxiyAdMhjhFTSMWem8eAOv++KfcNlV74HhZggrYBXjhoR2hYk2XHn9h7l9+VYec/avYQfztBrS/x0nCPH5C6JGFAQJmjD+DDgmrCCJpIxGkRGCk6P9BNc8WT8f3s55t/8QF8riehJYTwD//8F/ASa1oWH8v/gTNyc/023XiQyIA3OXJK1Mi2FCSgKS+9dyiMVADfnE1jzWqsZ/eXGHVoSffCKrgU6qLT+mBHVtBebTYw0GDtwIGEBowIzADsEMoLPQuSTMbwitoW0zNGGQ0K8UK36A6fdofWDeDfnZez6BcTcmeME3Dd5ZnBWuv+MGLrn2E+A65kYb5Mgtd+HjN3ySy656N25uF76bcPpxj+CUox+AsSOu3fs1Pn3Ve/FY9uz5Bp/76tt44FnPYnHFR3BP+/wZklWYhiCaxUSaR4Ja7MYUTc83SJwiOI7uJsa5c8NtW9/FeQeezIWyj/PUcvG6inA9AXyT4JcLCZdcgFu9mr8azMszusMSt59szZcQ+tpwo6znjjPu/C+3ABGoSqdpSPfX+ueVlJd+fi8h/bxJ/XmXev4E4vkQH2PgDHbDCJpZDi7C1w8oX9uzyHULnn1dw1gGCJZZ7dhpHMfMz3PClm2cPLOF0YaZmBRaYaxUisLcpsRk1amyyc7yf057Eq1xrHrDqhgmA9iwEX7lfa+NxKHO8/DTHsnRR23mjy/7CDI4jK4d8/B7PI7vv9f/Yu8qTAgcc9Q92LXzeC7+x5cDgW9c/ylOv+8PYNw8IfheTiwKyVmIlFyD1vLinCxKyi2fxRYFJ0d1E7HuHL1j7j08Th/HxbJnPQmsJ4Dp4D8PKxfib/8Z5rdczZubzfJYv1PGWG0kcfWL3L76uoB8pselJI+nkp6/Tga579YK6Zfy4L0XAKkEl5DWdCNoE9sDRQidYdhYcA03LTTy/uuFD962zKdva7nxwCJtN1YYgLg+agTAAxNGznH8xk2cddjhPObwozl7x5HsmN0MXljuYmmd/f3ISQDYM15kYi0TY1jxDheGfPqWa3nHV/8JBrPMmpE88u7fx82LB7ll4VbUOmaH85x9r+9jVVo6O6FTYdIpR+46hUee/XO0oWU0N4yjxeQbWE73afikjAF7nIDpbLD20yAExXFENxHn7q+3+0v4/tUnc7F8nXPUcal06wlgPfitXIw/+Fy2zR7k791WObvbyUQcMfgrno7QC3ekavkVwZiMTBs0WDQkOa2Y0haYPM9P5bYpJh/9BCD3/5Idf4jOvqjBYxlaC7MNX7pJ+LMvr/LW6yfsXswjvjwgtxJBSQUdg06IHbIDcax2gSv37+fK/cv85VXXydFzQ3746OP1p+52P47fdDjL444uxLGcB4KLY0BDuhqHBRrjeOPl70T9IngjDzzlbLbNbuPKfdewMl6EMGbzzFZGozm6LuBGjuFgCA5WPBx/1wfgLTRzsP9QwGtLsKY3EUlBH5966XuD3PdLdhSJ+ABVWtVI3E7YCE52+YkM7D30Ri7h3PETeL98bj0JfI8nAD0HJxfTrfwMJ7hl3up2mtO6bToRi8OmtR5CUezlj5lBp9WPTGK+CYIb+gjOecV3MSlEpJ1+TFjP38sRF28TQUJTOAGK4L0wnLfcsjjg5R8XXnN5YGWs0KQ3euiYa5QTtgy5987N3HXTiO1DS6MB75VxZ7m9bbh6/ypX3LGHaw4t0nYd2AE3Li3r711+GX919Rd47qkP4RdOP4cNYYa9y5Oy+y9k+TKWLsDQzvD526/mozd+AjFDGTWzPOpej2Is0LZeQ7cE2iHqpWuFDkNQz6eueA/L7SoAK6uLtOpBlKPv9mgGWw8HuuSOVLEH0Z7tKCXrxp0DOSdkZpBoP9o0CSqM3GTHjq4V647Um/kQj1p8Kh+Q932vJwH3PR38l9ItP5sHDsZykTlcjuy26kTAFS5NT+pLoz5KKa+55k/IfJe8P1sPn7l1OxMdsnM04eTNq5FiG/qJQAYBezBQ8uSrDL8lsf4Qg5EGNxL+/krh5z825KYDirGxnCdMePARI84/aROPOGLIcTvmGY2G0GoE/oIDbRSG0MxCM2JhoeOqW5b48O4DvOW6W/RTt94OxnGg7Xjx5y7h7TffyB/c/9E8aNvx7B13UfTjpDACNQhi4A2XvwPvJwKBs087l+OPOpKDY89gkMx7xWBco8YIbRC6oFx2+XtZOrAHnIuTATy0S2y7y+mMRkegbdXfS99OoRqrorr3lxj4SiJNhpKeydCAqOT9g9BhZWfXytBs4brRO/Tc5R/n/fI3ERMgfC+yBr/nEkBN8Ol+mvOkk9eaXTLnt+lEVB1CL8VNR3sw0qP8CaCKBUFC5tNozgjsmwx4wt+cyb69M/zgmTfxlqd/mcmiwVotAZ/HgITpkWGfGHpxj2JpbcOLLh3w8o83MDRgldCNefLdHM87faM++LCBuOLl30GXkoe1MEg2RF6UtoVOmLMDzti5lTPuchS/eP/T+cev38LvfvJTfPiWG5CZLXzpwB08+r1/wYVnPIYfu/s5rKTnILYEyszMDJ++6Wt87BuXIc2MDs2QJ9z3UTIJHttYxfWZU0yDGYLxgYEIWzduIoQxrpmV1fGihtARjMU2BhlE5mAgMf0kagCCimKkj05VJCQoVeIcJVOJc/hLqahCrw8yAl4tW0KLEcP1M3/NYyZHc7G8NGaZCwxcGNYTwHdr8CfivFyM757LL1kxv+93od0m7eLJL9V0TgpBTgp1P53W+XjK9X+ayiOCDGCm6RCzgtXlSEBL7jcS+hNNSOShWh0YyS49B1+Fwcjw+/9sefmlAwYbDJPVwGlHGl7+sO08+igPk8BkoopVGAxkXzvkqt0tV+2bcNuhRcYMGbiBzlk43BpO3LSFE3ftZHZ+FhYDYbXj3GOO5dwjjueN136dF3zq09y4cAgzcPzGR97K5h1befJJZ7FneYI3ceToBvDGKz4YhU6t8uB7PZijt+3ijqUV7HAGH9KEXj2+W6VFscOYKB//yJ/Hd51s2DjgTe94FTfd/BUEh2lM9Abo+tM/9Vtatgil+X/hAVVYYOrHIiNI0nOJJlWS9uWEEbRTy6agciItNzQv0cf6I3j3i34OuTB8r3EFvmcSgF4QvfsQdPwz8go7Kz8XDpNWI6/f5LG6FLPNyn9P6ndbJtUkDF96JRyimOxvlzjsWInYWzLayAy+yg9rSvknOQGIQdThVXjKPVve8tXAZ26e5xcf0vDi7xsw52B1QRkNG/Gt8JarW33LN/byyd2WGxYmGsbLEEK/5UdbgTHDwVDvtv0wHnb04Tz52CM5e+eRgGMxCE+995mcc9yp/OQH38m7v/YlnnS/h3Lu3e7JQjtBrKUFZjYM+fyt3+Cj13wOGW2kCfC4Mx7JskfVGTqFDfOzDAczLE9WWVhdgWaCdbMsdzCY2Yr3qmbW0SEgDrENdjSTjUJSJ5T5fhLLDtODghqqz3MvINVMUFI5ltqGKB/WXqZoAC+ic8HI8YzlBvtcfdxvHsXzf/YZXCgLnHOJ49KHdesJ4LtszKcXMN/tkb9wm80P++06YRisiJSxfD7psVrKfzEUaq9kiWyy5bYikYST2HNkFxz1gIuWNy555wuRB7BW7FMscJMlWDUOFLH4YDhmh/I3PwCfuc3z9DMb2iUEER1t3igXfbHl5Zfu43M3L0la9BkjJ9h4nMpqymgjYJZxG/jS7fv50s138MpPfJpHHH24/OoDzuGRJ96DQyutbprZwN8+/mm8+sR78MR73J8hQxY0EKylU2E0MLzhM/9I102gUx5y2kM57shj2bsyxjSG1a6VrYdtZfvWY/TG26/n0OIiX7v+Cu57nweyeEBwRhk4xw03X8Oe3deCczSDGYabt9Hho7FJWgOYE0FJxLmHS92AhhT8dx4BqiZGgBqVzL8o98lAq0d0GJwcr2Nzs3tiuGLL+zlv5WlcPHPt9wo46L4HTn4nF9Kt/AbH+31ykdsq9/GHhbFaGkmOtFKN+jT1+sVyO4/pq7I0QXb4XIjW5WVCyjEuLd+w8ZDXZAmWuP6ZZCNkym8k/8SvbTnyrBja1nLyTuHkIwLjQxOGQ/jGwRn5+fcv8q6vdslNqIHJss4NLffcuZnTjtjKXTYNmQ0tPoge9EO5/pDnS7cf4Irb99GGZdQO+ND1t/GhG/6Bn7jvzbzsEY+WUTtgxav+1H0fyv7Os+Q92jS0Ksw0M3z+hmu55Ip/QpzQBOUJ93sUnQEZxQpcRXEzQ868x/3khuu/rHZmhr9//2tZGK9w1DF3BwvXf+MGPnLpGwjdCrQdR93tvoy2buHAeBzHgAXJT6e2jbV/SIYCZSBgpGIFTrUCJQUgufXqKZqS2IXiQFsRtdpw124ijXuA3iKXcd7qj3OxvDsmAfx3Mzj4XZsAFIQLsHIh3eR/c45dlr81O81R3VadiNBkn36p0P66BYhMv3Qq15LeWuE3Re2NHFUxBmMdSJNstdIb0fQ+AD2ynduBXhdQqo1qkYcxhlYdvjWMRoYPXjXhWX+/wK1LDXZ2gF+Fux02w4+efhhPuOsGTtyxGbdhLrIHl0N8mZsZMENWFuGKG/bzpqtu4o1fvZ7bDoxxwxF/8clP8onrv8FrHvtUjt95FLsnK4gbgLN4bwkqzMzBX7/jbXTdQWiFs077Pk6867Hs78aYRugUjBE9NG7lfvc5h89/5TK55qpP68rcRt7+gdcwmtuOimO8tAfoYLzE7IZd3PPhT2YsIdmBC2vZPtoHf7WIgT74taZgS/mBVE+zpNZBEpW4HxuShUSOo7tWnNupNzRv53GTn+Nd8qeghgtUvltxAfNdeuobALmQbvwC8zTr7QfMLnNUt1Nbseqydx8ubaS1JL9+gSb27CZ/XXv3le9lIZ2UfX3ZEFOsIOJ6tCrdziST0N7FtzIIzTN22/vt92vE49VYwTgDowG3TUZ663KnmFUd+iV9yWO26md+5VT9tUcfyym7ZnC0sLIco2LjHGyeB+eUVa+N99zvqJ38/uMfxmd/4en81EPuRTdZArPM1ftu0H3aqZlrMEOHOkswhs4pMxtn+Pi1X+Efr7gUaTYwHG3lyQ99PF0D3oI3Eq8N6CCozDb6tGf+st7zPg+HSQtdYPXQAcYH90Lnoe04/JhTOOdZL8Aedhhj7WBg+p0C6XXRbAoav9badpy8TbgBSdeo16j8BEWU5FRML3SsjFrT4zkAsRzRdXI3kKb5Ex7TvgyRwIUSOE+/KxeTftcZKGZm3wWKeeGvyUvdUH6tO0wCsyEk+l0y3azeDP08qaj7yvqu2v5K6H34ajuv5OHXoNyxPOCMlz9UbrrF8eQzb+Ktz71OJytDBkLU1gdbrb3J8thU9gdb3tGi0TJXtSESiRowDSE0NDMNr/nIhD+77BCv+aFdnHHcZiZjw2Awgpk59u7t+NK1C1yzr+NgaLBuwA5nOX5+lrvv2M7GDZtkEoyqGTBs5nnjJy/nhe9/L3/45B/hMfc4nVtXlwkMaINlopZJMHjbcOOhvexZ2o8MG2wzYuumw1gOykSgE6VF6ARaYBLAG4s3lquv+So3XPcVDi4coAvK7Pw8hx1zNzYedw9WjWW1XcVbSyeCT/6BHdAitApeoA3gQ0RXOoUutWBe0sekWQiJ+exTW4Wo1O2EhoofUAwLk70YgnYJOlgh6LW20f3+nRy2+hxeP3/bdyMuIN9lJ7+TC+kWf5tdo0V5rd1gzu22aMsodvZqtC/5zTTNNyeA+L1+061kWaxUTj7Z3y+rVLAEdTQauOmgkTNf9iBuvbXhSWfexlt+/ibtJiOcgHopCUA0tgmoSV586Xvq0FiexKDPx1xJGA2qDmeHLIV55pwyWfYM5oZ8ZXfDn1y2wLuu3MP1ew9B21a1seKGcMK2bZx3+iny0w88XXcNN3JooWV2NMctY2HDcAMronjjmPiGiZqYBLCsKkjTYIaGCbAa4MDqhBZoBdooXIxBKzABxl6ZKMhogDTxe8tdTBCtwuJqyzgEvDF0QJdXigOtxvt2EnUIPig+iPoU/NMJIFqR+RC/F8I0n0qD9AKhEvjJIqTYtEFZXOhT69fRcZ0d6K3hOobjH+Fts5d+t5GGviswgErD300u4IFm2fy1PUyO95sZixGHRBMPIZb3dc9PPeojo/49D4B08hsx/SyqUE0lKfOS5n4kbAoeTe3icDDAbGxksGC0nYSkHKycfXOvbypdP3kUaKORR2+4X1mAWToMMwNlQoNsnOH3PniL/Nb7bmNhxUJjswG/EjoIrWDQrhvy1b0rvPi9n9bXXfYlXv6ER/GD9zyNg16Z3zhkJXTAAK8Gbyky5ZCmcRNaJpMU3CLoIA3p06QkoNEbMMWSmtgJTfyESaeMgXFQWk3uwE1MfAFNrsL0zsJJTNVP7yKYH6qJXnETloL4p9eFZCyacECnoqF6s5j4C6qJGUJyJZBGh9iYYdSok7v4iQztXfSmwft53OTnuVheDfDdoij8jk8Ael6cxgE6ucD8rLXyf81hOuo2hIlgmrKbTmpCTxoDiRYpb1mOkQGoPA0owS+9vXaVBLw3DGY78IYv3riND12xg8V2A2bW8pW9O/n7j8F9j9nDMYcvwVLDpHU4lzz9QoIK6O23JZt1FvsuU2y/8pocSTZfbVCGG0f88fv28vyLbsVuGoEsQzvhPsds5z7HHyHHbphR7VquXViRT16/oF++dT+YwI2Lizz1NW/ibb+yhe8/7RTuWGwR6+hC8gLEEpLXQPHqQ4r+PgPuUTmoU7bfsapOtuBZUJSsvnLq8+nnyQBY6s3HMcizO3A1+zdUJKAaLOzH/5KDvFoPoJkjEKpWQPI0Jmo+JPQVApIpR4IqjmN8ZzZKo1c3r9JHtadz6q2/yB/KyndDS/Ad3QLkkv/A77N1/pC8ys6Y8/w2DTqnwSgmWEmmNzHYTXarja4RCfVPRBHpfeam/Pyz1Xey5dKkyRdioLjRmA99fjsvedtJXPaNwxhPZsEWrjC0LYfNHdQfPGsvv/74Q3LUZqVbbVQkmXuoRWQQP4Zc/jdpA0Ys9+Nt4ueS0S4ZRm9BM+TW8Rw//Jpr+Pjl+3nMvTfKr5x9FA+563aazVvANDFxNCOWF9H3ffZ6+e33fYrPX3OrnveIs3jVM56E+IaJOjoavDpaDK3aeA3CWISJxLJ9AoyBVmLZPUFoRZmksr4ViVdgVZVWhAnx1J+U8l2YhOgQ3IrVTlQ6tCSKLj8WpL5e6IKqT8mkv53SKdX3iG7DGmuwkqwyYSiX/OQpQCILhcQhCv3X+JSwfEo+oLJC4Drb6F7/Web8c7ho+Lnv9JZAvkMDP6P8YfJS7mcm8ld2q7lHtzG00iQBfWOmQb58XxODP2/Lgn7eX2y9hMSgy5z2vHwjcvPjCe1wo8AFF53Kiy8+Bp2M49htdsBhW53MNLDvkLJwYAISFBlw9I6BvO6nvsHDT11kcsiqtdnmexCJQ6GZ6vWpMABNn4s0aLq9qCV4S7NhnqtvC3zwq6v89EOPhZWxtMuexo1gOAtuBsbCpDU6mJ2XA6ueP7/sKv2xh53FBpnl0KrizYAWixdHh6VVwyQYWjVR4UcM4EkOaGIyyD1/S7pKTAjjFPAThIkorcb7dQnYa1Vppe/nuxi4dCkBdOnxfAL1ugQAxqvgNVqRd0pJAip58UhMAKEmCIU8CpQyNoyVQvpeBgJ9vq0UPIAA2sUEIkE6ucUO9MawqEx+jnfNvPY7uSX4jksAehFWzo8cnMlL+QWj8jt2q4z8JiagDiNlhFQCOx/i+S82WtF6e9KPIgX0K8yzNDPqFYCGEBzNXMsL33g6L3nzPWGwzMAv8rSzb+KZDz/I3Y42zBjljn1ePn5lo3/yj0fymet3gTQyZxd4/6/fwINO7LRdaTDGISEGfTTuTElAXTzxq++LpKqAASKuVAShExrjYHYj7dgiboRrRnzuq7vlM9cfZDQacf9jd3G3w3fo6sRgZ+doZuZZPOQZd45gGybB4UnBj6VTw0QNExUmRIBvQgpodCr4xwqtKF6EiQitKqvp552gY1XGinQi8dTX9DGJi3LAB+2DfwroU9FcIeRgz+1Gp6kKkLxZSEosB+2ZgpragrVAYDm7Q6oAMhCYE0CuBnzKNJ0gqJd9OL3Ria52r+GMg7/ChdsPfSdWA98xCUAV4fzo1Lvyh9ylWZZX2A3yhLBJAjPBq2I1ufT2Ut5E+1rj3FNeH+lP/2kucG35ZSq00ODVMZjteMfHD+eJL38A0giHbxD+9pc/w8PvfRuMHbRNBPQMMAi0k1n+998dz++/fZfQLXPC4at88uV7dfNACJ0k9D+f+q766KbbAZrkR54qg9wOqEW1IWiDcSPGdo5fe8OXefWHvybdeAIC8zMj/fUnncmv/sDZjFeFrhMCDV4GdDS06ujU0qmjw6QRnEkBH4NxjJSTf5JO6ElMDNqC1JVAvK3SiegEjYlEVPJoLyeAqUBPJ35JAKr5tFefND11AvB1oqgWhuQEoFotE0H6kqD4jUc/gTINSB+loI3pez61AikDxd0OBFYlcIsZ6B5/JSY8l7cNLgX4ThIUme+YU19QuRg/fjFPaxbMp+xh8oRup7bMq2Kw02QQ6RNBqgTE5UWd8eeaST2FcGP6asD2q7n7a1yNbZ1hcXnEC954KkLLMLS86Vc/z8PP3M/qoVkmk0HUvmNp/YDJ8jxWB/zeT1wnz374DeANV988zyvetw0zbyPIVshAfTWSF4XWV7Fpr4BNpKH8uzuHDBpoLG5+wF9+4Gv8yVs+Dc0Mbm4Tbm4zSwzk11/7QT58+Y3Mzs6gSSqszkb+vTOoM6iLyz6DlWglkK6hWvldVnX335PgiAtBbbIhyFejkd2XiDzBanpc6YudsgW4/1oTUUdtgUGyoVEkcFVryLEkklbumCQ9jhaijxgtW5vj+0J7i0XX/01xY3F6fKPxfmVJaXq8RlFRoyN1HNdN5Bh7qmD/kSe1L+Yz2nwnEYfMt/upn0v+hT/lsPZlvH4wb/7W3sXs8Nu1lUZsSBwZmmigWd5MFfNLXH4z9YBf3oYrZSuvIM7EN9Iaxl6W8wYEOxP40OW7+Mot21Hv+JHvu4GzT7+V8T7LYChYF5OHGMFYg2tMXJ+1CC976u0ce5QizVD/7hMDDh0S3GDNVt+poLdIXuddbRCWzBa0/WpxtYJxQmg7HnfmkZx8ylHSTUL60wK6tMLZ9zmJM046kpW2hcbFJOCkMBCz8UcMzpgAfA7kFITB9ddcqNTB7630wW+FLnU4cRtwMhZJ91E3/XiakkPZDFw6IukTQ9oonBNVnzQ0JfUYwIXduTa55J/Z/L7oBZNS7XoQ2/NC8przqOxMSlFXhGJOD/etnAQy617IBd2lnL94r4gHqHCBmvUE8J859c/Ht7/Lo2YOyifcdvPMcKxpwxb1iNjyIqYXvlBtc/CnN0HoF+8m+m1/0pNebMkJIieFHPy2D061Bhx86PIjES80w45nPvJ26EwUlgjpthY1Nq7wTsmm9QPdusvqDz94UdV7rr018OUbh9iRQ8VN/V8lIVjTU4NTQtD8+zuDWBvXg2fDEmMJQTjuLjv42+c/XOdHhvH+A4z37ObonfP8za/+MFvnZ2mVtAI8bvktll8u/n/BmRLA5dS3QkiUXK1P+BLw8dTsjOKN4m28Bit0Jq779q6+n6bqoKfthnptuIPQSNxT4rQkgZCC8E6ViZN0aiN15ablPULBhvokP50kamU2NlYMWiWFXDmI7X8uFkCtzgXhWD+RXe4BsjzzER4/eR4i2lcD355ry7/teAB6AYYvI3I+/uAfs212SS40wnPNkeA36UQkOIXkhSdren2tGHz9Uy4Sp3IhHaJ5jp0xAJM4AL7q/3s2oC1CHWsAb/nyDQ6djNm1bZHjjmyjoaehwg3SPD+v7RKLiRtFuNfRiyCObhWu3+s4a2DRVU0cgGnMIVuGR26LIRRLMVP1M/3OPzUOYwe0i6uccdeNvO+F36dXfuMAXfA8+LS7ccy2eRYWW2QwwKsQ0igzJJJRKPN+TbbcGSdLRAvWrPKuvqcZsU/LQUPVp/vI5pNOMs7WcwRCYinmteE67fUfN50lfkZIYF4hGmUUS+llgdkisTixppc64wFp+3DGfTRoeq9ocXyOXOJUKSYMqdzOkw0gCUHTeyuBik6dHOFbmbfz3GpeqY+ePJF5fo2L5bPfrpMC92136ieEf/UPeKKb2D+w2zmumw9eZ1HAxXJMMgN32rizgjXLm6Py3JSpUV8i/uQtteV7pl/6If2KrCzjbYNwaHUSTThnYTjrwAYk7dzTvLEnRBafFBpvfLzRUOLp4S0r3sZe1IR+c4+kx1E7RTrSalegmryYM28BiiNLEUtAMGJplzsedPddPOiME0AGsBRYWh3HDT7p//Jp7Vh2Di+BrWnMBiUwA3ndd+/MExJQ1xk0IASvBT8L+XGNpvXipI9abfapsGjt5/b19l/NewHyfYJOJZ2yTbSMezQi/slKSCogsFiwJUMR0f7wkMrXvci+TXoSjCA+To8kBX+UGUvVqya+icfq5hCY0SC3N49gt/+YPn7yWzzjbS/nfPHfbpMC9+0S+JxPkPPxy6/mmGZRfts18gy2C34+TAR1SFrLRcXgM9M23ZKWSSh5xp8yfi34yQKf9KYshp/Z0iuvxi4rtaTYcwVvGIw6tm+00Myyf6wsdbNsnkussV6G1lcBxN4ghKg0vGN1DtiIDgJbNqyAtIhz/Zov+r2BVNTfskEY0+8OmEoE+Q1sUHEYaRiHQFhYAW1RM4TBsJz8PkmNI3FGiruOT+M2MCkp6BS7z+eRW1zrHSdkpDXh9FReTXFSVokb8BqS118FxtfU3priWxKSijdxOaiisZ3TPuZCxRYsxiw56isrcSkbhnqdsOb/KL83AqUaKCWj5L0KfeBnM9KcULI7lKb741W0wXK0b9moA7mteYm+/smP5wcnv8rF8pFvp2rgW4oB1CAfinSv5GeHq/JJt9M8wx8jnd8cOgwOJzDQ0sdJmfMr9TYrTXZcEdCZRoUjgNMj+1HiayosIPbYoQLbNMt2rUES+s6s4d6nBGiG3L5/ls9fMwtDxWMRa8U4m3Zg2+h8a6upglc+9AUDrWdupuWko0J80yV0H5sNROLvoMak/YOCGocai5cYvN7EoPdlbJ1WiJn4/6o1GGuwzmKcQ5yLZhvO4E0C/Zoe+AtOYj8vPaCnFQDYTwYS2GeUYKOsLlnwiTc9XuBNDPpgNKHq0wh/xg60evx6IoCdngYEp+XzvC4xS7hr7GAK/6mrxUoGLPXPy2MqZemrlSgrdr2lWy9Rzt+vwUSJ4GK+XQMMQEWtbpLAcb6Vo+xZdPYSHtf+Ic/R7d8uIOG36j+XGuSb/AnnhFeYj9gN5o/lKHN4t4NWR2qwYhiSltxUwM0aCW95ISxIHv0Y0iiPvlooQd+DfBGx7782BWVPoz9rSyIwDtCGx511B2bgYTLhlW/eGt1/HBIReZEY8BZJCacNhuFm4RNfHvCuyyzCitzz2FZOOKaTts2/U0oA1hKMjQGeAMWmceJGVtyslcG8Y7BhwGC+oZm1DGYtzUxDMxrQDBuca4DItW+9MtEowmkNeGvwKQnEQDa0BloCY/WMCYxRxhpYDYGOEGW+EqLaLwe1TR4ABXyLj9ERaDXQqqfTEFd/E6sKFU3ThnifDAjWU4bwTaYE2qB55BesSBFNmjjAF4nVtEoSYRkfDURNP7Yru08zLdxKOTzolySnIFfEaQGFs79AcY6y0++3OnFIDv4MEDalELQc5ls5XkW2ul/gNv85njx5TgEJz1H3rQIJ5VtR7uc+f/Fv2DWzIC9UzE/ZnWL8PC027b+yNTd/7SaeyqaratnLXri8sVeoynpSn5zL+pj/MupfZL/GpBXe/SrvqT4cgwyGPPIXTuOSyzaABF7+vDv41Z++QzhgGY9D8vNzGnEAw2Be2LN3hkf84hFcfh2iy6v87YuFpz3S6/hgwIpDZEAIDSE4hsMmUnh1wGQxyN7FhoUlw8IYlidWvY/rvxvrGLgBo+GImdEsM7MzzI+GzDUjbDOAwSyYIQTL6gQWW0FlgFdLkEj4aUazGDtgHKBV01N+I+kNb2FxAvuX2yLNzXLfwtcXwc5YVoEVYDURhDwxUFoDix0sLbcEIz3NtwIJfaXx77EFSTycRAgKkYPTdUoYOXQmlt9eo19AqN7QqqDLoKtdYvsl5VHeOKqV5Rip/E/gg/rMCJT0tRayUNEG5NvUv3RiE2oPoBRSkbYacYQgHQftgD2gi+H9OP8bvG0QQcJvgQWZ/E8GPuclbEix/k/Mj4mTF5ntHOHnxDPSED20NHnLUWy5pl15q99ceqRW19Y1IlPX0vdLRfclO+/EYiOk/l8qL3CtvMLy+u3BrPCpK2c55yfuzkQasCN+5anL/PozbpFNmxfycZa8sRsu+9I8P/2y7Xzx+llYCTzuYa28/aWesBJUFII3qDYMZkeA5SvXCB++3HLZVwJfvmEst+zrWFkJrLRK2wWNbr/x13JWGFjDwAmDQSMbRwO2zDvdtmWeo7bPs3P7Jo7aPMtpJx/Dyccfy9gbAo5ODYPZGT7+mav43BXXMZidpQ2BLuEDrffxNB+3HHn8sZxy1r1Zbn2yBo88/klQJtawtLLKFz/0CSaTltZGoU/cpWAwzjAZTwgb5thy7oPREPCSGX1SMIdOen5/pPhmWn4K/hh7dEFph47J5VcRvvh1dGYUFYm+Q0MboUI7iI4kdz8BPfk4dMXH5J+Yf71VeF2SJtDQJ0S/Cuq0vKgP/tBnL41BHSXFPkEOXtJt8+Okn3eRQqlIoFWVPa7hDr+qQV/B7Mrvc/HG3f/T+MB/ewKohTsA7V/yJLNqf81sNPdnm+LndBLJ7hnRT3LNKe5+9dtmxWbh90uF3NYJgOLiSxXUmhMC1cy/Ovn7SUC6rVaLARIAF9Ti5sdc9J5tPP3/nEprZkAdJxy5wOMecIecelJgvjHcshv92OVbePenNjFeWYbljvvcO8j7/6DVrbOO4JMKUA12dobLLh/wiouWedcnV1g6FEeQva7BJHGiVqecJslsRuVCvwzUewhtPLoOLvOMH3kEf/6bT+OOg6sYO2B5omzdtoUXvPwN8pevfids2QhdG+tcDaBdfD327efMJz+GX/7dX+DgwgSxsUroiIYfOtNw/ddv5E+e9cJ4HxUh+NSeNbG1CS2g+uDX/habTjuOpaUWNVKEPz6d+EEqsU9k3Wo1VpRM+W2NsvSjL6G7/CswM5PQQB//fwLSzIgeGsP/Olfl159F2DuJhCrV2kSgnyVOXTN6WakH80meAZfqc+3ifcTXt09TA99XEXgttGImBUD0sojT/U7Y52+C8MfsWnw1f7714P9UInD/rYF/apznA7Sv4aHGy2+Yxn4fO6Gb1xarRjSt4soElzozlfl+ivyy+Inydfbj78X7lNurrBntJQMIzeu9S9LJ8//8aW4TpGoP+n1hRmG8OMP5T1hi0/breO6Lj+ea61uuvlr5o69tIyoRLUxWYgJxK6ATnvxo4c9eMNHts0o7ibFmnDAZB375FSv8v7dNxC97mHU0G0WjJj6kNeKZx54/F8nj7JwMMX2LE5ucAS7u7mDrlk3oIAGBqQ9uURnNzmG3bsFtnCF0nWh+pyoYa/DAzIbZ1KvHHt6X8j8CXwcPHMIMBpi5OUIXej/+6MCpxgzpFla5+k3/yOn3OQ5vFE2PXfn/32nEGJEDKYc23mO3DBi/41N019yE7Noa/QVLgo5jgEzCYt8+CYpKYyg8gcDU+6kX/WhPGMiTSZNPb7IFdHqPaN+Kunjf3Jb2FWmqXmtOQch+hYJ0oC2WjRpkYxfY5o5ir3253r7xJ3ji+MW87aVvQMSjKpyP+e9KBO6/O/Anr+MMGcuvWivnyy7Bb9RWnQpBbATntPTkkra55icye7tT+cJXT31VvyTPfqkEPkXcw/TJXzgDksgzUv3/cZSX8QNhrVAoO/OAtUK71HDuQ5b55Buv4VVvmudN7x3KtTc7ltoRhA4ZdWydn3DmqZafPK/jiQ8TaB3dWJCBBdMw0QE/eOEK7/lHj91scRsheKHr4t9ZexLG7qh/g+YwL09E/jtUCdrf0LdjRk5jT28iFyIHtFePbycYP6TzyR8LioLOewO2UWmgM7G095UAhwYO7ttPGI+RkYv9r+SFHXE+EXxQmWm47cOf4JZPPIgND7g73dIErKkIRTn4+4QQXYZi/MURoCEsrrL6Nx+Igde21fKTqgzMxn97DmDaFh2Y/vTOQZn6ftUkDc8EoVBVkFrjUIkCnPv7zBlIv2Ac/8UEUsbOWXBkejxAU2VRjEgjy8rqls7LZvGy357IHfav9Qde+NM8+YW/g8g7U7MhnPdfnwjcf1fg6+s5KYzllzDmR80xDMJG7UKjio/u+AymN+5UG916pl4F9uXgjWuf8+qnEgnVKqlK4CNyJwSxPLaRqkJI5nGl9KeQhHIbUdoJzUkiEm/aBcu2uY7f+Jn98otPNVx1wzw37e3oJoa5mbGccNRY73pMrAi6RYdgMM7hvaGZs/zUS+E9/2RluN0x6XwawucMFlQ1s83SR1mDjPYu2CX4NQ+7M0HGGGbmBkwIdMm52Ct4a6JJjyoaKp/sUmHFJz8Ylc6gXXIt66oq2TWwuG9/XEJS+C3FTyf9PioYA+2qXvfad3CPB54MTapE8vYu8jxfygKfukKnC7B1wOrr/pnuyqtgyyy0bZrB57JI+i2r1sCBBWR5CTZsJtAlK6K699ViF45Jen+TJcPV01ExAcv0yafkHHImTO/B3O9Ln0yyBVn8WSI9hd7EQIMiHkFxeljXySbUHHAP0D28Q5/YvZvB5P9ysVzKxf/1ieA/nQAuugh73pVo7vHHf8u93bI813fmf9mjzLzfFIKf0VY7bMTEpHjjBZQq1rMzVDp9e0poKuj7g670/z2I26P/PbFHqgSga739C2W4J/tQUYRlTQKJe8UidTb+nhZjHLYx4FX8KszOwr1Pa7n3IK6/pmthEvBjwQfBWoUQopXXBuUt7/f85cUdzRbHpKu5rZnZElLQg28DtF3iw6Zv5vamDCqC5mppStzoRmzcthl1li5ZjAcVOmfoCjS+dsNG/8J4AhMbx4Bqe+C7dYJ1sLjvEFPUHmUKp4gBFJD5OTl42eW675++wNbH3IeVQy3eRgp2oQjT24rVhBFtLOHAMqtv+CCMXOype5SIwuJJx7IagUMHlb370e2bi+tPfp+QgOa+w0zbiFTLqU4iLskUkaxqP73Wm90j8KdTlMoeAwjTPGrRZEkedLoN8WIYKXqE7zgMZJ/9fm4dfT/ndR/Qgb6SN8q7YyLIGMF/jlX4H04AehGWK+McH2DyV9zPdjyP1pxvjjHDsAn8bGgJaiSIlYa+RC9BfmcMMmQ6dlXgFjs4Kamgeo9qhfSnZR/TDNOpYJbe6K86RU2fqosRaFILShwFhpoSTCTsLKw2HFocIniC90m3P4wrwTIYh5dNc6Lzs0IIsXJw0tC2A373jSYS0Ip/VfKeSuegSCBMAnTCtsMcx+4YsmnTiGY4UoyjC9CNOyarHSsTz6Flz+LimKXlluUJ0Hm8b2HfHmyS+wYbN/3muX7IvLv01IR80lWVgI9035gATMIb0YjmAwt79idDTe60pie/zuU1sUZu+It36fwjTsO7GPjZbxCtXl3pDwW6AFsc41d9DH/1jci2OfABEdMHf/yoZY2wEWVxDHsPxq1oY00gbzqxM74UKv5/Yvj14HPs/8sIMff4FVaga+nmmYTomQ7+ID3dMfQ/k5C8DzV+Lq64F0X5yFG+ZQeGffZRcgeP0vO7Sxl0r+Svf+dtiPynE4H7DwV+ou0CTP6Gh9hWfk6N/IA5VpzfYrSb11aiysRi0xKOqofvqfuJ1ltpOaSe8km/9y0H/53GgEol5jDF8MMkUIkaG6Av68vXGVyscILS80vmAZiKLuzwwdFscPzm7x3O69+8QYYbO7pgkxmBItn9UgO+bbn4Dyc8/EEd3WIEEgezwpeuMHzhqx4ZxjFgT1iPic8YxY9bjtk1w0uedwLnnLGJbRuHDIdDsc0IzFC9xt+l7WDcGlY7y9Kq4eCC58Bi4NCi57Z9K3z1K9dz1+O2cWgyiUnAxJhqTQ6dCB5k9uw0vqKIiHoTdf5R1xZdfIIRVjwc2n0IjCEEH+OkBOYUTAMakPk5lr7wDdn3oc/ppiediT8wQaxDiNPNKMDXvP0vBseMpb1tgZXXfQCZb+KEo3QauZRLlYckoMQY1Cu6+2B6/yVWYFU3SDaHyQhe0Om+M/RCoJgY+seg5pzUrO2+C5rGCiT9v/k0C73gwdQORaTqIxV0CpYZ4GjfcpgKB9w53GbP4Skv/ARP+fVX8MuDt3Jfaf+jUwP37+rxgb7Ht+f6Tn5OGh5r7grdrIZuVlunanzA5uUbWpaxronb5NSqdflfne55vbOab1YpTKP+xb47g71pwUTdJ0siAtUkoFI5ZNPPohHoyUF9a9BXCY2xrCw4ee9HR+xfVPDZocfEwXCuNTvD1m2OU0+KfoFiI8DHIPCZr05oFwe4TQGfT6RsFS4QgmdutuEtf3B37nffLbQHOyYelicd2nYaBUwhHSyR+tu4AZvnh2w+bMCxxiF2hLFDOh7A/sUxC+MJ6pqIO2XjDiNT1VQBw4r+Jk5T2uQNIDa79URGXzteZfnAIVKD1/dlUmEJU6IfhYHhtte8VzY+6nRlYPvCQVKqr0//1iMbHZPXfBR//W3I9llou+kJdg0cKcmfOL0BbtuLMWiwgkpIwG7dBlb7xUgIvtaAYYU/5aC1lPdeFAkxRSTK6+PVUPgGpQXRfvIgqfuqF5RAv4Jea0+hgNVZQTb5lp0Ce91Zegdn8Yf+8zx9/Eqeev3f8VgZx1Vm8G91JHL/1lO/jPPewGOlNb/KnDnHHi10m9SHgQZarFFjQ956XT3PoTpZCsorvYjCal8hCb0qpB8F5lXP9JOBCvmPFV8/uusBRDOl+isCoRLUUrn/9pwBk09+SXP/4hUYJwCMhCs+P+KaGwUzl9K88VUparAm0LXC/U+dsHNnx2TZlBXhWMMte9LfYFzPTEv1o4gQxi1nnDbL/e7ecOCORWwzC8ahONWqOgmarulv9F7xnY9IfVim0wkBS3AN6pp+7i5EunHyzy6CFl2zalck0nrT+KozGQNQaBwr+w6yemgp0pjLa6ZTYxrNwg+AEJDZAUtfuIrdb/0IW57zcPzeNm0FrqoOBKNKmHNwyyHGb/ggzA9i6T/dCGqx/q3bgfw2uXV3fDg7DQNRV4fJxFlNbx2uUguImE4YIVGAtQr+/AYOFYhoa0KRlAQRkdW+6JOQq5381OVWRIp5aYGuFKuzChu6To4V1X32dLnZvlbffNwv8azVC3m9vJUL/+1tgfvXxDq8KCL7q3/PSW7ZvMTOmh/iGKHbph1NUGmxeCyNVC9d1nhPz+1FpkXcJm/Z1aQmqVZA6xT3R3tdd17TVSuARaaWe2SUMM7xpVLKUX2eT34zvf47twKmP/HzOm9F8MHihoGPfHaebnGOZvMqne8lpuVVNYpOlEeebZQZh19RnE1kejsqpKey37484Vpy1J4DLRNGNHOG1XH6O9P9at19FAxZPCkRpEmFmqQUlCQiEuiy8aYRvKEgXKWMVan0eKYQr4KFNmksyti8gaUDh5gsrUTdRN22VSO0emKTVXPMDLjjrz7A/A8+ADMaxvGhScad+Y4+4OYdS3/yz7Q33YHZNi/a+bSgRVP3JtU7vO8XVUGsRW/bFy2FXU8YLb9i0F7Lb6qxX0gYa9C0NajKZ+XtLPVG0gxSVXbjKW5NJg6tMVSwTGMCWr19yLhDzWxLQ9L+TR/X3N3Fd9wFNbvtPfUq+xb90cl72Nj+Fq+QTwL/qj+h+f8r+UUiut+9yfykm5hP2VPtD/kHmC7chVYGYoyKVSfIUKKXWnaxTr58xtVefNIv1KwFGvnJS1ZL6TaKFY3CjWzVpP1t834/6T9qdcqXysD0231LkjD9mFCT8k9qhaDJdmGSREBRkJNFRMYYaC2XfHoGXKTVaj4m1Be4t+uUZn6Js++fVC0DhzYGb6OycdMmn8rDCp5GUQ2o99jRkC9fA7/5qt0MZ2bYvK2hmY07+FZDvLbEU9xLtOP2Jq3SSoBdl/r2KOLRCPylUZ6mXDR1LOoUx6oP4HzyS7L8MpEEpANY2X+IsDrGZPBVa+hW70Ts0oTSy8yIyVU3cfBNH8XNmUh4yrP21GfrjCPceJDFN/wTsmEm7gVLngn5BdVq8lBRQBML28LeA+jqBBnY4gYV8k6I1KaKyUm0UggmL0MpFmH0YqCmV5kWG7F8v6IYzCpPKV6DVL6DJBs7mjgSL3Z2Ln9f0YEiA0GGIMNYecoQGGpcxz4EMWrEYTnWd/Jw35kzmsfKZPhRfnL8u1xy7ehf8yc0/2LJfyHhwMfZ2r5B3mA3yavk/rLJn6CtNMHQYaNTtaQ/Jv4h1vXqKbG9DFeroJdktEi1oFMs/aIOQ0RFpPhcTK3yKmw9E/GBspW3bPuRsvnHJEsuNYKpVH1ipDxuQXaLBDht6pWkEJReGqxiaUaGm29zfOILDma6Ah4rffo2RtBV4YS7ek6+W8dqG+W3PllvETz3uJtHBiGepEayOr02rMXMNLz8VdfxoP/1aV7xuhu44upDiDVs2jZk07Yhw7kh6gxjSF79SktgIspEAq3p0ftO0h69FPhtzGN4U+potILxMyqPxr18UU0YV3916X5hAAv7D0EXkoleAtlyLas6Rd0qx58q+A6Zc+x93QfQ3UswslGHb3KyV+zIcOj1H6a96VYY2GLgoX2fQLHulWk0CSXKt/cfRA4cRAam2H1JsYSrJcKalKSSDEMlJYFp2zLuZDuX7ORq2XF+XNcrDNUqkrdSN1mqrkijaKNR7j6g31rdEBPDMCYCBpSrDAUdAENBR/E2CIYhhtN8ax4jYo4ZPJ+Ljv4IL1k4jYvFc84l7t/UAuR+f/mDHDO8Xt5mTjCn+7sxwYllglWJQS9TfWNfEon2K6MKSq/VyZDHzmtw4tL/pPpMEpLvE8IrKlNTAhBsEvcUsU7pAPq+3iQE35v+pKstvyThACr94s9C/U23U5NWZQULI8cnPj/LnlvAbI7bKnrsPv4NIpF/e/aZA52bFw4uKMbarN5haWy5732Eux4vXHu9wQwDIWjBOXLG0+CxI/jUZ/fxqY/fymCj4+4nbeJep+3i3vfYxumn7eKud93Kpm1DOhVZWjUsj1U7jXLWPIHqJAlq8uZdUbzGhZwh1aoyhdmHVBrELSpeAxMTV4CrkSjYSa3Agdv39/RaMYnVEorhhqCxP7YZ+u4pzTIaMPnGLex7w6Vs+4XHstr5KBnuAjJq8DfuZ+GNlyLzA+h8H/j5lPdhyt6rnxqld6ARdGmM2XMAPXFn2lRasUaDVoSxCsBUmWYHpvVhVHbhGclXqQK/Jz/27YFNXxvtdxOsbSF0mkaRfx/JY9Ra6ip1saNpyU3+G0IEC7cDj/QTc6W9b/jc7D/xq4tP43fn3/vNpgTumwW/vp+7+j18wJzqTvCnMJaJNnSxkpW6R6/p02mFUwFUqPa3hYQN5BVNpe/VUjZmdp7RKA8lqcSq16Q8ObmR86V3p3CvtYh8pGekFXqwSSh/7P/FGAyWUM37pyTAxhYfviAGH0sVPvrpOUSjS59XShLJr6ASwAjfd86QQMCbuJlcJfoDjr2wdbPh53/C8fO/rNhZJXjtlU4mDaFjO6B2xsDcLJMu8IUrFvnCF67l9eY6mvmRHH/0jN7rHlvlvmfs4p5nHMmRJ2yXZjDQpaXoB4BN4hoTz/e420LpNLUQYc07UCtGZtXCeyIVmKjXxEd/VJZuOVC0B1oTugWh87htc2y476ns+8DnVQYWfJsCMDnobJjljtd+kLnzHojZuZnQdTGfNHDwrz6Mv3UPZtts3MyTT3tjYOLhqB2400+ke+tHYH42thE1DGwM0raw55DqIDMEZQpoVKVw96fXhifsSachkZgIqkDNlWvI8dfjkGtnoULsWERV6nJP1nAw69ei+BTK9Ewlt0nxvZ3GlWJiJSNCMOp4gG/NJrMl/NPw7fzK0nn8nrydi9Ryfp8EzFTPfz5+8ZMcHvbLO+297AnhVB1Lqw0SS3wpfXwu83WqFNeq/BHb8/xrdxZJbrdS9fHFnEHSglxLvF3d75ts1SzpflIEROWwMnWPb5Lffu2qI8WlV2zsL0Lq/YL0+wFEkmNOqjB8sgQTJ4zHAz76hQ3owMY3Sn0oEZ15fSds2en1XqcJix68cfjk5tNKdN/dveL48WeM+MEfhsntKzjr+1Fl5XGlGufjvtNohDwzwG2yuA2NdKHlq1/bI29+45d5/i99gCc96W/5yWdezDveciWCYdOWubicw0QdwFhSKW+E1mjR5PdeB/UBpKWlyZ5+wUjplb2NS0IWbz8Y3YsK8SkSbnIZzqBh108/hmbbFtEuJNFPDgdBBo72xts58NoP4xxIF2hGDVy/l4U3XoLMN6gPa0bAAQ4u0jzuTAbffz+0NWXcJPUUwxgIXvX2fWtMPFKxUvr/3hK8rJAXnd4ePV0U9j1/3i1QWl3p/5+8eyJ5V6pRwelU61FszJ1OORdnJ6Le0VjJuy/MIJmNDCIeQMYHRsmJaKQRK+iwep/QmccaK5PR3/HLCw8vvoR1AsgV4O23Mz/8hrzdnGJO9acwptWGqcU4kuzpMnicgTit3FHSH5DdVLO/mqn7di321lo292r/ApREIpHRlZ1hzZrlGSIF2LFrvl9+nvmwueRPwJ7ma7LRit+3xSabNDfK14AwMwx8+RrHFVePkBlNPnX5sIhb7EQUxlZPO9Wy6wjP0gSCMXRiq6vDS8NiEP74D+Z44g9Be/sSwQuuSYo+DVqUKvQagKCK9wHftUrosEOD2zTAbp5hZSJ8/J9v4H//3HvkaU/6Gz74zq+yceMcnYExUcM/zokgsviS7m8NzVrrFk5zTRMrYIkMQHVCN+5YvmO/ZERbRPo755mrc+y41zHsfNgpcOhQBNSKf19A2xaZH7L/zf8EN+3HDC1DCwt//RHxdxwSGZoo9c27fyIPX3TjnDQ//GCabRthMEQSAKtTtG9URdFrby+gZsYB8qhaTW0V3yeEslDGyNTegOw2pNW+gGIlngK2x8WiMxCNxqsT1Eha7pR3GCQwMQOCDeggLh+JS6HSfTPeNkw/HwQYCgwNDEzBCXSYdDZDkBmBCSbcMwTOZcTK6GJeevAkLhafrcjiq3QxRi4kbPowL3N3tWf602RVJjSabbMNZUU0a0w6ynYaiW5Y9eZdqsxab9jKp7tKBuT65RuS/fgljd0zg6tkYJkCczTdN5g8vosWW+XET57+UlUOUrECiz1YwgFUDCGPzdKK7ICJTD+Uj142YHVvHHsjNiHSWtRvIl7pJjzkgQ3OOloVOky5erHxaiwrHibW8qevPpoX//4RHL7d0e5XwtgjRrEuAopi+uWksRwNqHpUAz7EhBC8YqzDbpzHbRpx1VW75Ref/WZ+77fejwwbxiYGf2s07u8z0ZUnFDterZG1qXI0UqHjbb0qHVHOu7I8YWXfQtwqpJpoxdLzL7wy3L6NZmDZ8bSHIDODZMqZcJ8QokZg4Ghv3cu+v/0I842VybW7Zd8b/xnZMES7NBrVKMwX62BZMeeeBScejo4sMgQNvld/xmY7kvqNwE17RCYILo2FK1A5Vql6p/dqtpfL4J9WVWg+oIztk0M+uYs3YEMJcKlOc6lOdXH1Nqsc6KRgl7Lspt4VK06RQTz9U9DHXbGNRIBwkADFzE0bgbRi9EG0co7byg2j16AZEFQxBfR7F2c3s/anw93NBGjK6Zp5+SZO56hHd/kJTE9iqE57LR/78l7LaVzJdm01KTCy5raR4aOiUo/3ip6gSh51a1ASQaU7oCj8Kv626Qk1me8f8kck8f9jVRDzpeWSy4Ygq7ViLI4sTHzzeR+QQcsD7g+LxGrCY6LjjcTPs+FFMIaxh0Ot4cefcyTveu9JvOA3d3LSCY6wvEq3d4xfCgQfBTzGCibtrpcQKnOQXtIcvMd3PlYGGxp54+++R171W+8ROzMjE0I0/EzBP8lCNkn1u6pOKTSzjVrS7pdluQrBGcaHllk9tJJIPMqduH9eGe7YTAfM3e8Etp17P9FFL+IGff+aRDXMjbj19f8oSwdX2X/RZXQ334oMsiuTqfriIAxndOYnHqkOtNs6B7MG7YJOrYLO1sHOwt5FldVWo82cVgAa1XLYvjIo3oGmL9+jfXuqWK2U6rZ8XSYJUsaD4gRJy1Tq5KClpJc1ySJOBOJkIJ70MujXRpZATxOCuDc2QINKg8bRIfU6yZg0hkCL41w/kRMHZ/O8B/x8HA9iDFfGl705JC829xCjG4LIhMwPY4pkIWvEGinITD3Tl1DUVvW+zTKuWzMqUalHe1K1BEmnYVBMFo3o1EhwKlEUqm9F6zU9O1CFivffj/oiwp/twEw58WMiEHxSCrrGcPu+AZ/+0jCWWh7Rwu2kcBJ07Dn2WLjb3WHJ+56Eo6Yg8Z0KHqPFl18Me1ZbNuxQfuZ527n43SfzuovuwXN+9RjOeNAWNm5w+KUJ3b4V/OIyoZtQppT1302PHYTYJuB2zPPW//cBvnDpV5mZmaFN/IE2rfguMuo8banm97kNKA49ZJvv+PPFOw7SLa0kPKWWKmduvafZMR/vF2DXTz8WmZlHQ6b6V/79zqF793PtBX/Hnnd8CjaMVDuvpZc3FrUOXVhW94DjMWcdj289ZssGNZvne4HPFCEI1DnYvY9waBka2zOBMgfArjl0pMaxdHqsV9aJ6TcxB80afyn7CwtXwKVkYKXf+Vq2G0XX5HzKkxyGp7gCA4mnfhNLfM1JYQA6iK0GA0UHqnXVUBLHMLXfM1geSUDMC3j1oe1cTHByIWFyCvezW83Z/kj1dHHUN0W5TzTFkF+wmrYrcZFEv1Fbcvboxx2mdmrM47Ie4rcyvctdCj0z4crxMXSKU5LenIWmmwM/B1Ut651SB0o58fOpqYktqJqSQvLMV8nsP9g4CHz0y7PcfPNIzNCn0XPorV4CWKeEsXDmfUds3qjsXYmefdl8ND8uYjVEQxL1eeBphNXWs+AVM3CcefYWHnD2USwFwy03dnztK0t86bMHufLz+7jma3vZf+tiJOfPz2EaE1V8BU8O5QRUJ0DD+173Se51zj1ZlZaARuIQPp5y9UhH88yrfzFCCInIFl8Rn97DK7ccQMctdjgidGHanIRo0zXYsSkWA0urbLz/iWx5+D3Y955PIvNNcs9MfNCuQ2adrlx0CdI0yMD12Hie7xoHatBnnk1nwK54mlGD2bZV/bV3VIQMI2XUaAU9uKSydwE5ahM6oZfsaa9ALOzgovyrnGbLUpY8wk6EpXrpSPFfSPSHPFXIT2lhu1a8L9aI5GpCczG21URTpjBM1+7D0LqisZFLPo2rJY3DBOGeoZN7N9v1czwN5BVx1UYr55sTLH4YPBNcJa5KPH2d0t1LoevrmlGHTL9mcCdjj3yf3vwj6b/TE2nTaZMpvvH9GJ9K1eklQDVivdbOa6oULfZUJo3jhIrnknz1yvshBX8SAhGnACBc8tGR6KrFzXq60PsWxAcM6XUPPOjBWeDSy4g1lUNBq68RVJx6NRKXdMSTolPDgZWA1xWwji3HNjzk2K2c8+gjWUa449YxV1+xyKcu2c0/vvMGDu5ZxMwOk3hEp7jyIQjMb+ArX7qNm3YfxG6bYdKG1IoUS7TES86z1H6ImxKJRKu7JMFLeMHK7oNRmScyzWOFMgod7tgYq1+JWOGuZz6Ife/+eEaKeyfn9AaQUZNehMrqK5/Oi6si9zkJeeR9VFa7+PwPDObwbcXoY/qYSMGyOEFuOwD3Oqon+JvecaSM0kLlsGSq2Zz2/BXJhkNJtC1lHdn0cyNVEOSk0s/3+zYl46VS/87ZTkxqExItEwnN37eVHHaqLe9f0jxlk7TYRMGY+6D6JZ7BFVf8mdErGDAjj2Sb9jYbVRCFlNGMVM8Fa9jXRqZsk7TuI3O20p4rYqTinvepF5FoDNkb+yRwcEq2X/P1e8RfpFqQkYJNKhQfsajYct/Ipc/adik78AJShDV5Jx5GWPSGSz/RQNPGoDJMufOIGHwnDLcIp93bsERcEOpTAsnXUJJCBhiJHAMiRhCBwrQF2AlBlPHYc3C1ZffKMovjMXOHjbj/I+/Cr770ofqqdz6Jk+97GGGli/IFrfQFWdDUiB7at6C3XL8PMQavgZA8+8MUumv6E65iNq7lqeSh3HjPAkXM3qceFUKcijROZ3Ztjvs1ncNPPFseciobzjoRXZqAtZhKAVkcdrSuGDOn3iCTDvvMh+FGDgmhVHD2yM0RGJWSyssmQUSVzmNv2z/l7oVRjUuYVLGo1szAPObLAKH0uwEoAKHB2KqNKGvIK8pwtYk4jwMls2VtnArksr+nDEu1AKdH/6VJ7cMAlcaoOIke2rnFyFMEJ2DD1HKU8ja1ikwwHBtUtsq9efNx9zOLX+JkmdUTmFEVH7kKUr+cULshTs1jK6MtFSPJzyWxvyQXjKFWuiYr1Fxhp6g3Ub4RK/H+CQ9S99g9n7/n669R+5VRn6gYoyo2KuiMK712PtkVSxnjiRDElpM58j76j83AcO0Njsu/OoBhRK77niVpDYyITuBuJ4045jjL8iTvxDMlsXTJ8CV32h1Iq1Z8Ov19Sj4ZfyjuOCaSkox1iDT4znJodcINSwfYeZd5/YkLHqLGeNUwVpH0i1VJ3BDQlUUO7FuMAZewC08gaBqeS6UAnhIEJJJX7b6U4nThlv1p/kqJtUIICoo0lmbrhoIoqA+EgWXns88tQE+hIEsv2hKpqHXq49x/aYy5510Z/cCZ6lofuSRZCXr4pjQhjLuSEiWt+EGiit6yt6c1SV3zS0XoUSSud1Q1olijVFT0Mi60gAn92nAT+gU0NVXYCOKiWjvrA2Jwpk3MLnMIKh5AspWQWhOQ+nkzMJq3FvW6m7gqvcciQqG6i9SVQKoCOkW34PUoZzng7meawAl2Vua6xobYmE4l//ImMDIt7ChmClNWWxKnxsleorAeK6Y50/4cfSmeyTgmCcILN8WUKiCNDbU/1dcu9Oy5/ZqsvtXk0Z4pI77i8CP9mK+c/on1l1mfXTAMUT7x6SFLew22map0U+VMFAlN4AH3N4waS+tTRZEcpH02uVShRWSiSD0R6MgVR9qlR961R2pb8t8QATdN68z2dytsPnwDzYYBIVNjp4d4uZGXLvXyQeK2nn69nVarlOOxK1KRgyqjDK0+rtx+sKgAtVIUgKA+YGZG2G0bCjsWE7kDGx91H2bvcxK6NI5BUjtFTKkievdeXVnBPeOh2PkhxivGZJs20F3b4smnVTlcl9QWwo17p7wAC4hd5vlSIBokcVHiQaRSu1bbmnA2XXZrWneeJ2PpTIlVQ54E1CPBoi+oK4VaUFetG6t1M7afPOQtRCV5GDM15RDprfZ6k1lgO9DKcUas2cKMicm47vtqbvQUAz/DNmlpJnVvL1O+ylq8NUWNGE2K6CpIk0Q4CW2yTZfWZrdp25akkzZkW64K+Ov7/IL6S0hASFx7nTbeFhPWGOTx908pv6D/KQnkxZkSV3z/00dHvV0UtcYhW1oLNIH7PQDGtAXb8NonFk/k32MFOxyAswRRWvVMQmDVB1Y9TLzGpRs+MPaarnHXxar3jH2g9VGYM+Nm+eJnb2Z8wGMHwyRdq/jwSAQIh0Md7ZhlQpeSW6wAVNc6APU4VuagT8l6NP7+YWnMyu4D8bQr4HD1IF5xcyPMxll8qJbwdJ7RTMMRP/bwaPZR+Nv0zJt674ERZHWCHL8L+0Nnxaxoey6KAn7HRmQw6BeBUltAKdI49MY9cW2BrVpKW7P7er6JVOPtYghlVet1YmX83ROBNFYPmt5OomWlWAzYmLtLQCtYNClf+7K/CuysVExcA+1JSDr18wSyp/SlPRlS+oRcA/oAMgdY3eoIoaXaTxi3cmVefw/yee0hm1Axl6X6TFVFkkKzgP9aHffV0RnLDSmHTsb8ReoDKfkFSC/0iBVd3Y5IpelPjUlG9XNgai8aCtrfPqQMU4C63B5U5b9xcMeC8KnPORh6fDDTCSebxI4D2w+Hk+8pLIYOFdefsFIBf8awvGg5tF8YzRuakdKMhKETTJKDRYmxJdAQEtPDMyDgGKN0GJSGpSXhfe+9gtdd8DFkIHGluISK2BOd9tUrm3ZuYcddtzL2bUpGWizTanRnShOQWgWdVjuKsY12i0usHlhIdNu+6yCk09F7BtvmaeaHhK7Xn4izdJ1n2+Pvyy1/egzLX7sRmRlENXB5h1XNpzGw0jF61rm4LXOw0oKzZSGKAnrYRpgboeOVmD+yGCH/4tbA7fuQg0vophlog2BMArcqTn76mzWt/i6nppoM7sXAmN5QpTXiP3VgCkz5XQuV6EC0thXTLF7K5sZrt2EVI9P+Pdd7a2pvi4ZOxYYU1Z7cyVQLIbgg3OoX1dP1ugBf+eHndCIJHdapYY9OPwO5EpDaam2Ny0x1/1rfN2UONrXqS4oJSF8hyLRqTvqKpIz2qmQQlL6/F6l6/f62xUij3F/ogmGmgc99ueG662aRUZegXzPFljFGCaueU+7uZPvhqguryU+EYlMcMQAPGweOj3604QU/dzNbd3hGA2Vm85DNmwZs3mQZzloG846ZGctoNMQ2LpXZ0ftvaSXIoYMTdt+8zPVfO6S3fv0ANAYZDERD7WiZTFcE/OKqnvDYu7Jj6zz7VlfBNKXNwFabj7TyruuzQH0og4hagywdWGJyaFnFmv7E0R4j0KA02zdhRw1+te0RcCNop+jsgC3PeDjLv/KXMDdKdN9QqWRSeb7aYo45nNmnPBh8wBtTRneqUTnItg3Ipjn0liUYuGpBQkokTtADC7BvEd02h7S+wjrWBFlZMV6p0KR2TE54/1RJJEX9LMKaJ2OqGiZbMKn0PxctA6dpzk01AcgemVp7Gd6JeiVTJjpGq9tXEi9F4hJHIwccjmt1URftRDeFET5J7GBKr9f3iLIGKqp9eorlVyFZSTXzzM5N/SA0qKQJX+3zr9O+9+l07iu6euYhRcabk0BuV4NUQU9/4tfBH7ROHgn5z0lAo1ORRfjYJ+fQVcGNBO8pZAiRPmPjA2c+wGAwdBpwOXFlwqBIqTSuv2WB1f2eW7wKY6JlbZhEtkxIC+hqyLoYxElCiCSCYwMwc8P49+e1YLXdmQqqHkzgQU8/HZ9si7RaWEMyRSnPsUavwSl+UHWiqSoWWN1zCL+8Gsd2IdQuUmnkFBhs31hGfCKmOEKJEbousOlJZ3HHq95He8tuZNj0Q3VN4J11sLyKPf/BmB0bCKttdPkplnEaZdQbZpCtm+DG26tRdHW4GIMsrBJ2LyAn7iwOT1MeiDLtJl3P+KfOL5OcgkSmAVOmtBD95qmqUIgHV+iPv5hp+v2ztSu8TO/EKCTNaty+1ie3z0fae2oXWyItFA8JiO4GrF5lRudxvV/Vb8iiJBxg2tt52iJ6ajNd+SqNitN4tD/btUzDi8dv7/OXxvsFN64R/4L6G9ZuBa3tvzRbf0klxS79vVSOS1Lss/rdjn0SKOCf1vbtsSVYBT522UyRwdbJvay08mDnLWc8sGE1la3V/sjKHTriD7feuIBoS9MY7IxgZwW7QbCbDG6zxW4ZYLcMsVtGuM1D7OYZzOZZ7JbZ+L1NQ+zmISYFX1zqUZlvJ3NJO2gIdyxy36fej+MffDwL49UIVlaVT8YA0ooOlTWnyZ3KxpR6F27bD+NJ5c9Rvz5xWO62bii/j5T1X8k2ddwy2jbHtmc8FJbbfqadZ/AEaBU5/DCap5+THHbNnY4cgiIDg+zYDD4UtmoNg4gITFq4cXdRv93JgysD1bWzXGGy6p2pw5VGRWpdQWYY1rcX7e3qe5BSxIj2pUQ2N7uzhZ+EyhpPp20N6y1OpWXPXyfnsNyTKxCMwj4sN/pVNupHjQittvpudgtpfWHZRGOmrKGr/1hqzKEHT81a326VKttK+cWmnog17YGWPkcLdbcaG0gmR2hl612X8loFW8/nFyrlXj/3r+b9GfSLg6SYIJqhcuMtA754hYGhR0OlCdU4ohJRwlg55ng47m6OlS6+UcsYT6YTQUfD/r2RzBEBSoMPQvBK6BTvpRQCwWv6fug/th2+6wg+xGlkv/Au+RlEIMk4Q3fHCic9+p784EufyFI7KVOJghDnUyGEqcpLMl6jPSmlPNtx0q6rtx3UOHoLUdWn3OkYG+zakrwzpLbqS249VrWD7U99MO6uh6PjyqdCkwvTwgKjJ5zJ/LHb4xowqUwza0YYwM7NNR1Ye3fghMEEkBv39u6OwvT70KzxyZrykJzeYrVW7q5mjcakJues2UWzhgBYxUePQ0xpGXJzrEk+PbV0pPYT7DEM0VpxWXkUxtUVgesMeoDPcOrbLzcA7ZC/81/vOlkSS8JGVBGvWk2Iq8m/SlXiVxTIO6Hj9KCh9gOqO5dWU8bQMjWDXmusIP3WGJUeQFlb3pd5vkyf6qFOFrliyOh/5U7chUihvuLKIQd3N7hBIsMmApAk3ry1HpkI9zlzyPxc0ElLRTaqKg5NdlooS4sDEdeIJj/AinHH2u0IOk1pTEyfkCVIpa8TE9S4OIwPi2P8gTH3e9bpPOf1T8XNWIL3qOmnNjY5Lql60HE6MWrZppZlJZLWN+dWrgOWbk0+AFVjVhiYqeF1mQOQu5GqdDdGkLbF7djExqc/HFY8ONsvR/GKbJxl5lkPif93X1KriNW6ZQmAHrU5rSfL2og8v0gggHHCdXfUdmcyzcyr5OMlYcXjN57wZsoXYGpT0BR3TksiKNus1jJTy1qyvuDqHdTSarF0kuU1hxoQ9YimMlJDXFdfyTT7+2TMS3sr8+JVG2zQyxE0vJHzz/curlLhy+M3+PcMbmie4E8xE5nEjb29L+za2Wy/Q1Iq/7g1GMYU9ReddmtW1WrB5RrSURwOa59YlGpgTL9JlrI+rKcgmSoZmNTTm3Ta9gCflglA+n520k1NS7S1UD5yyQBd8nR5wWRtF6tRdEPXcuaDZjXgUGkJFZe8n0bE3nfcBm65cYK24Lvk9mr6xFJAzjvtQl8LnaZEHeLMXZfHMOlgZsBxZx2lD/+Zs7jnuXdj0ipd14F1yX08/kZl+7VoBuDSaZcmCSE1MWGChlDe9z6t9F64eU8CEC0qedCae1sPjWVm5+bc/KmuHS+jkU0XYPtTHsiB13+YcOBgMl8FDrQMzjuHmbsfFYFAa7WmGZvK/V8Ac+S2RLJKz45Y0CRbUg/Wq968J767bD1FCtO8faoqdQrvqjwTQr2qrp969QC8icFd4QAqtdyiGC0VF/W1dnd5RiAyDZD3LU4cc/fse4mcu3osXi1B0QC6QYJ8AaeXd3dwj+U3g4rLf9riYfpC85XuXHOYs7otqExqqms1nKlsvaOnmsn7I/pA1jKKFp0agWgFXCQQJG0AKaSOKjEXg6r0xwSlEFQKb19q/ZpUttg96Bff+GZNkCcnIO1vF98OpvCzFzrDDTdZjjixZThvCD4Qghc0RGa4iXlgNDKcem9liS6NIPkmk4ZIXFkdtxxxVNCV5cCkHcjSQmB1dYyOU5+gaxfWV+48AlMGdNYio4ZNm0dsO2qeY+93JKc86kSOP+tonG1YXFmJAhpp0iQkgJrEAYCWUKYAJnQQXG9vrYDv0C7ahnTZCs8KbetZuuX26J4UTPT885OerdkqZmaemR2bMVMakunlL4gSxi2DI7aw5QfPZO8fvRPZthntJsjMgLkffxg2j6A1THnjiYiKRs6YAdyxO+hm5qLnWfBpEUC8n/ooOuK2RWRpAkMbuRE6hcT3YVYJdnRq2Um9vir2UXlHu04dfjo931LTn2dUZ1uVGr6Ze79m4o5OJVGRehluT+6ZggVEplesYRVz0Ab9EA43uYBnb97HRRoN0i66CHv++fiFi/iF+Z3uD/1ZMsHiCFXuUpn27+trvWmPQK05AtLvUJtCByL4kdFXBcl6+v4UnLJ5J9AzN8rMXs2a0t8W7734s7w8w5bbF5BQExNQbZIDRyF4vH3GBSyLy7MIwwjsaSaaUn4fYRBXW41CWgITWRsGqwGbtu7Z9H9BwGKYYbLasLRiWFgMHDrkObQfFg4Ky4uB1UUYryrjMbRtLPW8V4wz2EHDcLZhZvMMc9vmmd81x+bD55jdMYu4ES3CeBwIwYBtEtHJlefG579PDcE6Vu5YZmXPEp0YWiV5IPbvnOAV2boJd+R2tItLN73C8jduox23cdtwen3bEJgksoazjsEJh+Mbpz6RlkIaS4V0VGQ2YmsMYWFF/HW3Q2PpVBk7ByfswmhettYzF71YAiEBrfH0MKst3Tduw2sPivZryuOyF2kc4fjDIyAXSvhpL27rCW2q06BbTaoUlbzHrE8UeidgLp51QSthkFY7EDOkobUL03S+qcKpwgZETb0Tj2r+VoMNvfRQRTCzdPp3ZqCfm7yFPxuexw9Gg1BZawi68kb569Hxg2f4+zIh+Ea0KnN0zZIHXUMb1r40TWs3you9tqOPB3lIf4OR3sQzqwR1ataQZyVFVksKKiiB3TP6bFX25+Az5edTty1JwBY8IAt1VGzqm13crkOVdNQUlqBi6YKtKgwbF4iKSzBZzzgMieCDcWAzC9Ehif+pifATyUAukYEcSlP9bhaPoyNafU2AyQQ6Hx8/nvr5d47B7xOPtXgdaBQqmUGDoaFDaDF0xYAjOSpjGaOMxx0k6nIQsANXwM1cq3RQfAYV6DofhxTxlS4thyLVNCbRnm0xHpGkk6Abd9lkvGwPVklU6QrbURAvFtz0Il6+GabehbT5NyeAdLSrVkRmmcandA3BR6uJtVYLQevJw52SQkbia8VgdlCviFb1Gux66qRaj+Wl3uGiaysGWbMcd5N08i4zCB/oLuecgw/mGdsWuADhQgm9K/B5BL0Aw1P02eM3tEcMxT3CnyETVJy2FblnzbQO7clCUxum8ws0hRXUfOSaQ4jmCq/e9KSy9nnPTK3MNwipZ5VpDb+mxFMx/lSk3zdfbjPtzByknxB4jY8XuvqNS2EIBjFoML1VWmkrqt9dVXJFUZbGpNfY+0DoTBbkoHi8Cp6Ax+FxqXJpUyJw5TTPgZ3pzNlt2Fqbgr0HOjPjr/crThVMfM/jJx2t+kRbTmvGal5FenwrsfrJgGW7Mil8G18B0/kNEEzURyh6JwGZrlk/RYZVujbrCMEYrJisWJweD+djQXuwzqhHx0k5rv1pqDW/JPcLd6I+a2GfSb8QcIpaXHZZqqSzuteTq+oazsv0oahTSGggb4EoeaGACD0tul+OKmVFY6HdhZ5xXyYE3Jmyr41F5n0n7zODcEl3Oyes/DDP2H6o3hZkasl8+jhePDM8efLV9r32U2agnXiaoKUJrCzkNFRbTkOaioQKvUx71iUjkUF7uaoGsSppMY724+uqRJpeU5dGhKmq6KchGsvBrFir3tz9r6b1abFm3l9PCqTcr97y1D/Z2o97Kp26Jq88rUC8oiWokk+/KTqLlbSIZMQYjIvX6DAbpaPGWow18epMpTbLXojR4kvXrEfLp2hOAIHQC4AkpHFe4l9UBqtiBWPTchMTRUdqKqpvrv+yZVY2zqz8GK0TnDFV35+nJnXwaY/3ZqzJmCjyKWo209uGFUp1foObXh2qFXZss+t0ej5s/v1MtcZ3zakiSr0jqR845eG2Vvsq05it1vtHFVwWwPYBXKH4OUNKFRvlBfFRMaa+J4+ol/S15s+FVkUniHZAK+kKEi2eykfGOUd0nbzTDsKHw3UctvhoXrDxK5yntl4VNrUy6MJLUb0AM/dDrNq/580P/FjY0eyX+zMQYXPwdGpI+9IlBXdpDRJwLNqvN+751X02NbmPqmw8MkXCSDV+mRr7JURdezeinrtPhe6bfr6/ltsvNTBYm3WYqnWgKAP770mlFch8gvz/pMeoaFu5reiCTcpDmSInRfzBlsfNKpKgFh8MXvL3ozrEY+hCcaGMvAHJnAVTEkz+fbsQQbMu25kj1d9k1wCUTLEiQ0aw01jU52SYzENCsg3M9uoRJ9G8EL3A1vlxvQ95fV98kU0SfHc+RrjpBbpTOzJ6LwpRREJQ0Sju6ik5PjIaxEjFHraVKC3y7SVT1afeWlMrTDOK1xe2aqY0EjK1Nq1OIlXAB6accHKFENXWMjWTF60W4GaGmqfElFYxlpNH/JlJCULLqRUP3HRatSnrzxDsAVHeZZtwuf8IJ02ewP/e+LV/dTEIgFyYWgHBC/ozK29sv9TcYn/Xniob/IlMaDCsqMnMIltKv34rkKRKIJJ6euS+JOBQLzlMlZdKbyGe35zVmDDPNmsWnmohraYADSkgp6cDoZIc9xOC6eUsYYonINNtQi6ji0V2/Ls6r9GlyucTPjPJDJtGI1pgadKioilQTN+jloQWk8Bo2NAiLE4Ur3lNOTjbMDsYsYqyPA69kEey0KiqihRmhyMUy77O430PbGl5l9q+Fchgl2hNW6fT+DvY4QDBstJ2dAHMaIQDQjvJgR9ZCWivocgaEmtpBpYJ0C23GAE1Ae8cZhj3a/vVri7PJQesSLaliCy/ASYamLY+ti1B0VF0rKcN1cg5aP8GNH2DnbpySdWnGCldQkXUnebTTs3nq3lbSAO24t2lpaTPdhaJ9FBZjPW2YNF7dc33U8BrAphN+lwrkD2Xt7LWVq9ytKJBMRr4nGvCJ0EXJn/EL1//Ak46afzNgv9f4HtWi2ovjstCFt7OaaMD5k/dYe5BnBAIhzFRL1baPnNLlQBKiVgLo0z/JEum1U7RJU3lDdAv/ERIOnjKCR5qU4/k4phP7VA0/tnZwZZTV4slV972Y3tgrTqVCwiYHzc/htiIDaSFyKNG2XcIBnMz+M4JxqrIAAkjPvWPlu2HdbLrHhopleqqk7hJIKZDGWCk4aufXWR5JXDMmVsjMGcaBmaWpd3CtZ88xPwJs2w/eQMTDyqW1ue/KZaprVqCbbjlU3egC4EtZx5NmB8QPIj0z48kcbnX6EAUzwBTyl1VocUysY6Va/fSHlzB3O1IGA1Y/MINYlrVTfc+mrYxdF6KdiYxKMWrQmPxe5e444NXsuHM4xideBghVqYs3rqfhfd9kS0POYW5E3amvYZE/4Su02jOEreIdyhmzyH8Z28hnHlX2u0jxqueSeMI7/8Czc5NmFOPwg9cxoVUdRptiFWXTvFQpsZshQOilTFf2WKt6RSX6WCvT6EaCNTprb4J+VREJWjfDvQ87AocqjcF93ZlPRDWJ4qK9x6/PYjQkNxiG/0i6NX+q8x2z+eVo3f9axuC/8WtoRdeCBdejOoFuOFPcevD/0H/+vCP6h3mOr2bWWKHsWLCnLZiiKtpQ6VGrBJpoShWa+EyCChr1Ev1ikrqcrCWd+d5vql89TKjr8z0kypQTWkHQvpap4Q/fbnfawHqvr137S3fQ/DBMBoIX/iM8ivf37BKIw954Ayr3smGZk6uurKVX3z0frn5hiUe/Yw5sTJkxswhRmg17ukrbYZa1DT89jOu4P1/eSMP/dET0EY5dIeRQTsjX/vcAX7/By5hYWGVE886nAN7JvhVxY4cmpSOHcJKAO+G/N2z3i4f+cOPc8oz7s1g6wyhU6xxOBkiZoRKnDJkBWDvZ5mehwBtF7DDWS756b/k0xf8Nbue/lAZbtsiH3nKH3Llqz/CCc86GzM/pGt9PrklkYKZdAEzarjm/32Ir/7Mn7G8DM32jRy84nomw4Y73voJbv7p/8uCnWWwcQNLV9/O4jdup50ZIBtmCSFIUEScwTWWPf90Jbc/8fcYrwT08feiG1jCFTew+ojfoLt6D4NnPxxnDT5bhOn0rsY7K2CrA748B3ce94n2RCxZyzWvAMDMJZKkQJOscgsSXaP9mtKS0rNKqQhCZP+VttpX/HEP4kG6WOpLC9oqdEK0MxMvt0vD56zVj/vd7PEv45yDz+YFGy/nPLV8+UVw6TdjGfwLLcA3aQk6vQBjhE4Jf7L/Et4wdy0/K9fzHHeEOZqjFL9VW7UqjGNzHEzSUxudZrBmb/+pTc4yvT2IalcblXlrpunWq7RrPKBiHqpoKd11ijFYIfHaE49CvfmmAgrrZBuStbWmLKdeGDQjFryRv/p1OPpY5fprOy59825WBRjBVV8N/OTDbkJlIIOZDXSLlqf+5lDv/4hNLI7jG7YZOkZYZmcE4wJbDpvhms/tkd957KeY27EZPw6C83z2zV/jyo/cRGCIsbM8//2P0vljHe1YGUuAkZOAsrpvmbljN8nMXbaqt4YNMzN84V1f4VO/9zmaWcdkaR9qPbSGM37mEdzzKfdlYXUMKYjMaMQMTTSHtAOCDGhDiIs3RgPEqiyFoAOEZnaEAdq2TTsJlNH8kP1fvkmu/8OLkJnA3n/4Z/a+67Nw+43MPfXBtFfvBjuni399CV9+4yfjjr8Dt7LhrS9k55PPFJ0EwmiAv/o29v3z1UxQzHHbGL/53YRjRrhjdtK96ZPocAZO2EX7N5fBMdvgIScRJp2oiW+mkEhn9YErFU25N/rUYuum1cmv1K7BqGa2s07jXpr7zbp1KESqNGAM2hNbAtJTdntkWEO/X7AHzdMcPyUIQlK7OhQjnlvtQL+B1Wv9Mr57A5va3+blszfwF/Avlfz/7gRQcAEQLsLIwzgA/PbBD/o/m7lWn2Fv5jl2hzmFIwx+h3Y0QU0rVjXbEVdiHl8bMGi1PKSWPsZILOuWK536lJtAJTzok7P2PX16fK1689gnh0oDkPt5oZ5V1xXW9Mc8i1EWJoFT7mX4P381w689coV3X7TKSfd0LI+XuP1Gx3DzLMfdY47J8iFWVwPjLtCqwbgB4Gj9mNlZ4RPvu5VLXrfC7usFH4b84bO/wEOedBQP+/G78OE//wY7T97CA599CmGp5SOv3cNgyxwPfNoxuHmRznsNChuGc7zv97/ANf90Dct7xpjRjL7jx99GWFnisJOPYua4XdzxyW+I7BoyaDrCuKW9YYmDTzyUtn1G9ZE0M1z1pk+z/4s3yanPf0J8dwTP7PyQbcZitcG3HePgGRnLV3737Ww7/a7seORptKtj3MCxeu1uvvSUV+EPLbHjH36dxb/8Z1bf80WOfu+L2Pv6DzD51JVsff2viL/6gB586dvZ9uc/QnPPozBHbIU2rvZyBpY/fz2Lz34lMr8RBg20He0L/5LODVC3FWYOx7/1iyy/5iPYH30YzTknRcCtcsPVKYmTjduU1rLS8kFT4INCQP0m1+xeXZf6plgmSdXjFwAslZaSArmeCBQhTwruuF0uJQEvKcGkx0SikKdVletdw3VYvbHbqx2vZ4d/NS8bXQXAOeq4FP9vCf5/cwIoIXd+GgVfjJFHshfCH938Gf585xc4X2+R57lt5j4cJYQddDJCtcWWAj/5rEV5cuZrJ4TVpBM/UKi0ksxXyuitGvWEapN95AVoZfqhZaw4PRIMCQw02SeHIDkhSEUg6WWh+f8J2qsUNVmL2QZaOh7xIMeffmSOzUcFtuyEjTvneNVzlnjGbzsO7m5Y3D/Pc39vV5rNt6y0IgcnE41VnnLrzWM+997bsFs2YdxGrnjPPh75Iyfpj7/kQfKVS3ezutJx7vPP4OavHuSf/+hjPPqCE3nSj53CdRxipe0QLAbL/i8v6Y3/fKvI/EbUN9zy0Ztob1yQxTOD3v2Ew5F2P6c89/Hc72cfzXVv/Tz//Ky/AQkySVNzVJkzDTe89Ut84y0fZsOPnkPQFkLgjku+xswpyxFYGwx0KI6vXPgWvv6iN8mGB9yDsx54khoXF64u3XaQycIhNvzYY/Bfvo0N5z8QWW1pt8yy4QlnYkZzDB92b7q77JHhZ65Tv2nE7ClH4oYNeN+zQ4YG3ALNzz4R85xH0x1cEH3eqwnX3KEzF/1vmiO3M/7yzYx/6JWYQbVBunbAmXLo8FOU37IQSUxPzJnuPVNPH5FOU+nr6z6/WDXUaHI+KYJU4/LqNEnCHemVYtXapXQAhv52DEwM/Gtto1+BcJu/AauvZ+eh1/CSbTdGHo9aLiIg0vHvuDj+nZfM/SiJ4L4sQ3jdJcrfPuBV/vHN7fJcs1kewQmWsEM7dUF1kpYyu7RFKGdR06Ojapkyai17MafZxeVF7fF4E+Wo9A6zoXAGAqoWn2jHoWJ7hYTMZ3S/JIViET5d/lMpCrEwXhrw5tcOWV2dMCuGYx40YRvKG1+6yKYTLCfd2/OSH13WiVp51LM7urCCHQY2HTnEiEWtcGjScZ8f2sG9vv9oXvnMr3PHDZ6//tz5/MNfXsFbXvAFFnYri7cs8QfnfoCF2yId+FNvvpZPvvZLnP5jJ3O/Hz2ZJd+ysrrAE//f/bnrubv0bU97n9zvpWfLg37s3vy/s96gg+0bUCaoX9LhsJG5YYOdi4nMGIvipVNVkSBKoNk8i9m4MZ6Wdgiyic8+9c/5+kNPZbB5FuOEzz/vtf9fe+8dZ1ld3/8/35/PObdMn+0Lu8suvaiASABFEbuxBQzEltiVaGJiiSUxLKvG2BJjjd3YogG72MuCihRBkF6Wssv23enl3nvO+Xzevz8+55x7ZjD5xW8sIPezj3nMMHvnzt1hPu/6Kuz7ymU0H3wUR/7Ls3B1i888WZLSf8rBPGTLu5n68RZuPP11DD71YYycfjw7T34jsmwAaqPMfHmjYjqYUUhefDnZcx/Pqnc/H5IOXgKC1HqBaAj3nZ+jV9+Kaqx+xxxok84/X0gSCczNQDaB+rSrUJWLbISoZroY2/zy+5ygXIXKVg1rim1Wd+1UZPZFRiB+IQ8/709Lowvx2p3w++4Uv9prSq79QiY5RkC6eBknqBEvXpU7bMxt4He5m3D+PRw/91+8cnSyvPhHo2wS99+P9H+DAeC/DQSBJPYV0K+kH9InyDXZ39kR+yjWWrKlPtOah0yNGEPhJqvFHrGktFf0RH2xfq3MA0qXouKCV8REqtLVFBlfcpBQVQcgXPMwMKxe/O46rbsm6yIzyw1E3s3MzcF/vM2RtVJlKuLMd2WyZtozfVsHlg7z2id4laYB63nlyTfD/BRLHzTCeT8+hIaVoDOHZXA4oj7cILIgmnHNtXsYn00ki2OGDo4wQzWMNyw/vI8VxzRx8/O4TlCqSPGk6nGaMdo3wOS2GXCw/KHLmdcOnd1jNE9fGwRIqWFtjJLRSZPSCj3/twpAB59vKuKgBWHqUGty5KYnsuLYA7nh4xfhJmbZ991fsvLZD+PwdzybvgOWknZaiDF49SSZYfLiG9A7d7F60/OpHbGKbO0ofR94IbZRI5IYI0qnEZFcdwfJW78EA4PUgDTX8yugviBQrxP1D0BspdPox3fm1NYtph6gxkgKUUwMZKaAaWuhyUYBMwzcTpUqwm+hIEp3naG5Z3K53tNKoPAL13fVgWCg52r5cVn25xe6CASq4fKX2d9J3gLkrYGVgGy7M4r1LtC9/jaM+zdOH/sUf7F6jk8vyPiO/8OJ+D+eMhDkMwLOwovwHfDfST8hfyw36OuiwfgRrLW4VWmqxotkxqipbgtyb0rbXRVqxTcwuJkL6hUvwXEmV5HMK4AiCNAt3VVKlOCCfj//43IySTcwmJK3oJXHsjgo5DyQeCjh/T+ocenFRj77NwkOYe2xjj/915X0DQ7iXSJfee+8iqY8+e+XkyWj9I0aNEo18aFwj03E3i2ea75/N+N3TZCMO3nn477Gi3/0GB7/ynVc+bWdXPiG23nEKzdw+JOWMj7Tpt4YpL/WR2ZTZpIWxsRIDiG++9Kd2AOarDx+BXdfvBVmd8nSw0/TWqMhEOF8SrvEvLn8T1DvCa1N/i+2DWxswadgHUf89ak0RpdxzQe+AlmH49/3Ig5+waky5xKy2RlsLUZFcV6JI8vk+Zfqro/8hxz0009gts2w5y/ehtZiJR2AwSExri3NVz9e+//kVEne+nVMvaYxAbxkNDAVM9+BdB/R6U+Wwb94HNYljL/683TGJrEvfBjxmlH0pm34H14HtRibY2C6jlJdWbAulT38YqgssIGqsFoqq7lyj18xKPHVjVZlVVdy9jW/5ItWe8VUvwT8aKkUI4VEkssxYR7P3TbWW0F3ujux/n08LP4YL7IzfLQY7uG54P8t4//GA8DiGUFBLOJsvLzAfQvhW+0PZ38aXWNea5ebE1mnZCtIxQTmidhuua8VWyRf9E4mh0laSvBQyM22q1orBUjHL2zFChrw4j9SBfVQCRSmu2lYvFHQ/PKjeC+IVQ47ps2Wu8FlGS6tUbMNHv7HI8S1Op1M+eaHUjE+5YTH9mOiOj5Nmd3ZYWC1JU2Fgf4+vveJvWz+5y2wPCOywpPfeQLfe9ctfPJn02jcwO2f5wsv/ym8Cmoj/YCQ3D3DKf/0YB7+t8fSns+o99XZs32cOy7axuBBwwxIgzu/fzdgdcUp6+nsbgeLMx/8AEJ/maHe5/9uLWXCvWZgIupRHOqdbI79e2cYGBjAZ06pG1Y+7YGS0SG2hnigj3aalqhBC0RDA0i0jChxJFv3kN2+n/5zn0X/IWuQ/bPsefWnqd+5T/o2rAbaaGc+KH51qeBkcy1wHTrv+Tp7//WikC2GaiAdOk9+Ix06YPvA1fEzrUBACkkkLxRL9H6u7OAriqULZTS1XM35BehV1YUroQWXv9IKBORed3KfyyOUiD51lbLGd99rnv1zCcSMnVLT26zVbe5O8B/k+LmP8crRST4JbNSITf/74d7vPAAsCAaLA8FL3BdV3VeSD5u/MGP8Q7RaDmEdZMs0FY+VrLBcLvy2q+JJuSqJL6yacqRf7j2nFfFMVd9108kz/4JVYGXwF8r50Aq4Crko0IQlDzNaGQDSDQQ4vBfmnCdtB6H3oXqT975Quf3be2DIQNqBvkCg+LtjboFmH0zWOO01AzzvnUuYSBPaOI5/0mqWrFsql3zqJsb3zPDwl25g6KAaF8+2uPuySU58yWGsOXKQPXfM8LOP7GTk0AYnvnIDy44b1cwrkZjAge+rc+gZ67jtM7fw2Seez/TWGYZPPZYVf3Qwt3/+KjB1IlOjBjifBbEMLX4mXd5l2AikpD5sGHBtYaCm9biBSAMwzEzOYpYOMPfLHTCf0DxuLWmY8gQn4DRFM9WBekyn1hD6lpPdtF/mb5/EdGah3kKtJ/MKzKsmLdK8EhFriYHm40/Afv2dUG+q11hcs0brvPPJrrpWap/4G7WrV2IJycGvX5bbrQsLlblz9oJo4VaD3gMMtJC9t5DaXtWZq6wJ/cI9sVSGReLyi5+7uqiv4vsrrUCO0iTCyQSGW23N3+6mSNJ3c+Tsv/H6JVNlj38Bnk2/3nDv9xoAflUgCCxO/8nx7/Plgds4x+7jVdEGsyI7ECeD6iVViwafs4LOXfw+FgObUjUrh7UWsF7F54CfhTJfKtW877tMPi2GgFJm9QJfUEAwVXy5hfDqSxsrn/MInCoDVrHWYMwAXuv8+Wvr3PLEeSQGn9b48rvHkASedu5KfC0ibcGG4xt4L8SRZTbJ2HByxJEPG+WKr9bQPTXGJ2bY8NhBvvXWBD8zhzGW4x57ID/69HZMlvGwTUfwoKccTMt10DTD2Djs7/sjnvSxp8lVJ1zOT15/CWgfKx59MMNxH3FcDxnM1Bign0ZUz4GzjkILKPwy2EA4ylq4ZoxIhojqxI9vgTXj2OYoUp8VjMH7mB3fuY4tf/9FPfY7r2TpY48jm5vPq97wrHUjeCtgLfG65choP519u0E8kXpiEYUmRAFP4L1im5bxj/6UmW9cg1k5iPrCGt7jd+wBC+4b16Mje8JA1ijZ3Ax2pIl9x7PwjThcQOny+as2Kd1bvggksKifv+fbQg2+Rfjxco8fnMykMtlXqoSfgtxDjJc5UW61sd7uvXayT7M0ezNva24J67zNERc/8jee8X+nAaAaCEocwWOZAv/28U/x+YHb5bxouzxfNhibrdMUq0acLBAiCi1ClwUSKgGp7Px9DvX1lbI/p/JKnunLgaB2H19hFFaxh11kZmVmUHDR8/7ZeaHR77j6F47//KdBfKPONz7SZu0DUv7k5ZaIQK/95UUWTfp45l+twKHM0ybBMduZRaSWQ5ID0982+pGapd7o005zjid99Gi544tj/Oxjd3P5f+6BOVhx8ggHPKQfmKchgTvgJWDj43rMxNg4d1+2DTShtqyP7Z++ju8MfJmlhwwg/XDTxy7lzi/dTDIzh/T34b0jzascZ2B+aoZkLkOa/dz8j1+Wicu3qCaeG5/1Hhl81CnY0QHQDNtXY8CAjs1ADXwtKmvhGoiJG0A/iRfa7TmY2Yuf2KemM4mOTwht0XjpMoaXDrJLhpBaM8A/NFiXte/cQ/vHN8JoE7Ikl7vq4JMZwQj+0uvx0RBqIkRTaM3C4Qdgva8Q9UvIbkWMsmD9SMXTVLrT/epksESBVYd9uQhuuOiyECVGqdGnLp/oZxVV2CyvDIJjkNMttsaNoOP+Yvo65/LRvh8vyPgX/3Yy/u8lANwDR3AeVp7LNnAvaH2Mz8Q3mDdHe+RheojBHeBTHNZ4wUcVrkAVE62LcJ2FxZUUQ8AwTSmrgQVKwfnaTxYCj8PjTWVYmGedArJbrBK9UouVrVtg4xmDdHYLDz1njpsvU975+EmWnhiz6tAGUaODFYM2Y33rOROoiZibnKWvv82f/stKak1LzTTYetMMN31nH2N3eEzcYHa3Y/tPZ9l+87juun5K3NwsfatG6D9miL0/38unH/oTjn/O4ZzwvMPpP6hBkjm8jbh781Yu/oeLdfzSrax71vGc/I+n8b2X/oC7v3M7Qy84EvUZ2dwsrtlQ9Yq6PrHUMPi8gmjw01d8nm1fuELpH2TPf1wh0Zo+GT39WEaOOpBVTzqWG9/9bXTvXq55yYe13mww/tMtmOUj9B28IqziDESgYutIPMSsCO6wFTSffCw6Nonf2aY+NKg85mQ6t40zkdwIJsKljhTwxpAkGYOvfSJL//axOGtIVUk1kH9mnvVeTX6+RQa/+0bq65eTpZ6OQqYeYw3SrJXc/VJ3r6uLL1Q9K7Q7WF4wEMx1IO7BJOtedFkwBCxZecVEv7rbD0FAs3w2YHGyX63eGNV0m7+TWnYen6l/Grdonfc7PBG/45NX6lmFbLR5o/pHvP4DvCweZ2N0sCzLDtZMBzySiSkt60uvdKnoE1elg6vdfr76y9eA3f2+r4CzfJcaXKAGWYgH6OIG8pYg5yMkDlYeIBxxvDJ61Ky+4p8b7Nxq5Rsf6OeazQ1uucziWh0V1w6vJRrA1GL8eIdjn1RjcKiPmVZK3PTMjmV883V3KX01TnrhenTe8J9n3g7aou8QePCLD+TEFx3KsgOXcv3XdnHJh7dz2Xt36/onbaBxCGSJUmtYbv78HYxfOs6Rr3o4x7/pEfT19/HoTz6BWscyedcscb2fw15xkj7kZY9m13du4qd/+V36lg1jcOqDQTPLTlzL7N5xlj/yWJY/aB19hy/HrBmhnguQdGZa3Lp1irmrdzOXtbBNy5q/fjR9a0fwrQ4g4SLPTKPpDG5mnqVnnsLAmaeU/6cM0N4+wc3HvJqZdgajw/SfdEhuhGrUeHD9dUkH+/KLHCS+NI5QF8FMBIP9ZEN9JKkDLBW/GRVdWAV0veQokXslmtwvklusVAaLSD2VYR8Lg0MRBLLwvuT7Ow1ZPxOwqtLGy5Yo9lt8qq3svRwdvZlX18dBhbMuML/tUv9/SMy/31NIkQHMX8hB8Q7ZFDXtczkCOmtJFCKP4mPBR+AMeAsuF8NwUjjsBpagE4NTG9RtxOTvJVfYMThszgK0FYZgwcyLSiahL4lEXdmvgiHo1GIiYXI2Q/oM4vqI4ybWxDLfqdGeiknamaaJByKMraM2aP43RmvYgYjUgVpLu2O5/ao5mo06hz5oNSaOuPKHEwwu7WPpEUbsgCVByFIYigfozBh23NrS5SeMMp9meG+oxTWySWXrtftZ8cgDcSlopkitRs3WyaYySWYdaX+E62+oSQTbdthGHV8LP5cUITMWjWrUqRGDJN6RJZ7MB6q56evDTrfRqYxEvc43I+Llw5BmoAbnIYvrTF9xG9M3bWf5Y4+lb/USkjTrwqxN8D3Y+8PrSNoJfYceSPO4NaRpIFoUCte+AszzCklkSTZfR7Z/nr4nPAgdapKmrksGM6VHhJYUWRVdaF9XQe35RYo+Kvfs76uZ39GVuHJS1XsPFz/rfqw5N19VQ9a/28T+JoPucxcx4l/L22o/75b7v5+Lf68JAL8qELQ/Zp8aZ/IOs16O6ByKc8Oq6jA+gswqPhKcAWfyyy0S7LWluPQ2t9sOASDYcNsFUlqeqnxWIZxZyG3lb4X4h9iSGlw8R+YNzgipMyBxrgsYiUQR1hoNIJuopCqHfYDFZzHex2gu+5UZi4lihBpZGl57XGsEvb/USZrllYcRnLPYWlPFRswn5FazucCpjVEb0Wo7hChPSiFg2SgWjCVzouoFZ2y+fy1AFuHn4DXX2VDBihFMCJYOIdMgEGIii0QRCaLOgaYeMV3pNacGV68HcVTfQTKtJMwQqBOBLKrlCEuPS5JCsUc9Qpabyxe8D1ck2FqU4/Y96nwFKp4zPsMMoKvLq5LHgK6NUxe2K/e46NoV6VioE5epqFeVcq2XU0crAz/Nur0+mUCMSgvPjTb2t7lJtX4T//ZP70U2+bLP579n6d3vAgCAbsRwIyIX4MavZHjwajlXGvaV9hiRubWaOlHrBbwVskoVkJmiArB5NWAqbxIqArH5pQsCmV2BTlNeeC0CRC7U6QohUemKcfpCTZiINLO4XHknGLrb3IbcohqVFzRo/YWAJBJjbA0lxklE5m0IJkR4iRCJUJ+/XjE4VQmechFerWb582EiROKCGkbmhNQpanMRUJX832m7UucSIeHfIE6Nis19p4ufR4FmC2BcKfQLvCkUjXPDEzE4DQFAIlMqEhUmqN6FWYm3kj9/AHYVlZoD0syRecUbCd59ob3TgipNjo7FB4CRM8HmnMyjkcEbG/wQrKDWFLLxqhU5P80BJloR7ixVUHy3xA+qPeYewJ6SI+5Ew2CvavdUDAND9lcHpDnyL1Ind5tYrzPohP8WK8wr2SS3gkohxnlvuXP3qgDwq6qB1qd5bJzIe+zB9qi5I8nSfo/PxGSR4CLBmZAhnAhOuheyuAAOQ1Zk+zIQFBc/ZNzwix3kt1TzKkAKAc7CYCQ8DikCQUxUC5nb59+nq/wbLh658EfxS10Ep7QTIVILFYBGtJ1BbUS9HkuKkCRGjdSxxJhYxKF0OgYnoi5XOhbpti1OLc5GWBuCUEYIQlReSxHAiovtUHWZC7+4+c/E1gJkOJcSEy2ewztqphZUidpp0NiLYlJT09R1EOdzH8f8Z9qVf8UhuT8dpLnijctnBS0TKqPI+y46PPf/cwHvIS62of0AjHN4a+kAaStFmnGYBXXSEAS8UlHz1pK9R6WXL1R7K/1/F9ATpvfqVQqST47PV3UgLueQ5ys9KbT8MtBUIGi4Oq61Nb3FTar1f8/7a/+OFkCe381k/z4fAEpFovOwsols/2UMDd8s74yG7Es6Rxpm1mmKU5sZIbOhHcjyVqC49F7yshVLtqAFsOVlDhfd5B9Xy/+ofJwWajpqylbBiUUw7L1jkM7cEErGfJbgVDGmXrrwCDGYUIWIRjiXEQ3ByME10DpKA6RBPa6zd7ItX/yLO1l5bJNTNh2s/aaPW781L1e8dxenvOEA1p86ymzqtMjWlJnekhjL3GRGe2uLWtQk86Fcj0zcFSbFBMSjRxwGTKTNg0aQ/gjnwUZ13O428zvngvyWIC7zRGIYPWwtW953Ce3BOge8Oph1bN/0Tea37NED3n4mtVXDkDrEhOrKZ57IA8bQytmTXhBnRNUr3hjUwa4XfIS002bpJ16KHWgE/fBcAMZ5ROs1Zt/xTTpb91B/w9OIopjOqz4HR68ge+PTiS+8Cn/YgZgjVqHtNGcDmhzkqV0Jbq2YpuZ4f+nSdkvUXm7LJWV14LrkHa1cePHB4lwcaJJP+mt4dmG5xorudj/kgOyv2NS4GdSwEe5NWf/3ugX4tbcF52PlZKZBX9r5L//D+Ofyr8sm5cCxo0k0CjW33kNTyFccgHxFHnqRDXiB9CMo5RZy32FDYMIGQU2pLNwlEhnimvL+F1u2Xuqh2YH2NAzGSC1C543gUvAT+TjLQGRgOuWwMwZ50ZdXMdtKadRqdCY9P/rUPpYcmnDnpWOkugQxSBvHdV/fxZ3f3ccjzjucAdsP3om3sQqetne0VEm9I6rV2f3du7j4Od+A/lGhMYBpGPWz89CZJuhl5wgrVaj1QTrIad98JssffRDtmTZRo5+b/uUStnzgB0gf6GyGLBlFZ1NO/ukbGLtzH/vOv5S+sx/EwHCDrR/4Jnbdag5ZNoBzWfAYECVtpdz+7I+Tbp8MLYHNhPkp+t/x5/Q9+SQxLsPaSGtAcv123GyHet2isdBpexEj6r1KFkWYfVMkH74Iv3ccee2TcZ2M5PM/QB5/HPFNJ5P+2Udgw0r4z5fAMauDPmBVtTl02VJqVgabEVHVeyD9ZLGRZiH/VaD6CjHOipS0T7VgtTq5Lor9da6Npufxkdo7EDRw8yVjE/faE3EvP1LVIDjbn7//G/6SkRvlQ0vH7ZPHjsfNrpSgtFEqOBW8fR8GZPlKsKAYUhX9pNC+LwhDOTZeuhRjL1oR/OxSh1MvnPR0x/oHZkik+E6Nn38vpt2J+aM/76MxIHRakbgsDQ5CRvHZAGtOGMB7o05TMpsxsz/hh6+bkoe9vsnAihF8rQ+XCfvvnuL2b98Fq2r84C038f2skE30Qsdw7BvWsu4xqzRLHd47ho8a5ZjXnE5tsJ+7Nu9i4ur9svKph2vfgTV8O8WYCFGDjSxRvZ/MW/rWDpI5hxho+YTRJ64X+7mI2oPXM/qMU9j5ph9Sf9ByktFBRh61nrELL2XukluZv2sffnqS5Wc8SWR/qrrUlCvSWJHOlnGSvWPYIw/Ej0+jN92J3TtNbfsY6cw8EkfSSDOwVmnUad+2l/rqYfxoP+pVvPNkdYv/4s9wd9xK9JdnEB+0guSmHcjSBoKnvmEF0b+/gPm//CS8+LPIRa/BxDZk6AD+ZYHRTEn0KVXAK0AfKcCl0m0FKNV5SrUeDYM+zTRfi4jKrCq/jGJ/m7uRAf983l27gg+osBFzbyz573MBoMo43LyRaNlT2IHVp8x+3G8cvphz6ydGdv+hJJoGKzPNm7dugDcVIHDVHkO6FuI5JLiS4/NKoBAMsTmAKMcOiCfNHI/7mykMsxgMadLk+hPqJGnGU95hdWlfJI5REjJSCsitAeq0OmnefDmmxhLMMrjy83Nk7YiZi+a44IxrWXJEg86eNs0Nwo6f7aG2aoRkLCFeKqQ3zXHgi5exAo8TxaUdljx4lDUPXsMATT5/43eZ8C2O+/tTGD5yNZlTGjYmIoK8SUpQ5lxCkqZgBe9SWfLQNUQDw9QPXceap5/Cnjd8jei4Y9j6vV8wds6/w/AG7n7VN/CtGYiWsOeN36B15U6O+cqLSFud4O4jglGDHHUgq37yRub//XtM/NWdZFv3s+/E8/DjYxAFD0Wa/SL1PvY++E068IY/YeQtT6M1N4/GEUzM0f7g95GRAdGXPpwWEK0ZVYZGkFYEjZjGX5yEzxIya5CpWRjuQ60tXc/1V8F5q5p+JcovlP2lcGeBHHNFL5Q/Lis+Z9DYe7kTq1dHolPZZzl+7hW8bGQi7/Udm/D3hbt1nwgAxTk91ycEkOf5TZNf5tKBn7sPHTQbbbj9KFIfq5E0t0kplIPKsXAoxX3BGCzhwqbE/VcBQl2eXM6SE9slB+WQ1VYrMOzi2JDuN6SdJsZMccXX9tE3GmnkG6ixJD7DJR2WPyBidI0Tkw/vLBH7dk3jW+Msf0g/O37eYmCV4qIm1/3Lfg7/24PwWcL+q2D9c1dz+we3s+G5a7nu736Ob6IJDlXFiCVrp0yZWWanZhm7dVxpKJc883OhtDUNiBuYZg1tpzp87FKOff/jyVKHmBivwQSMOY8ZXsbk56/hyv+8GD87A1PT1I47lpWvexrxslXs/dSVJEmNZS84lZpLsIcuYc5luYKTl9QLPp2BrA8L1CIDPoaVS2i85DRkYoZschJxHZIf34DaDv1/dpL0n7BOTb68jWo1Ou/+Pu76ncjx64Ji1IWX43ZOQ9yP2zHF3Av+Q2TPXpgeV793DHlLnXjzm3AHLEE7WYVMUvD8q1z9qrNPAebR3Gm5i/lXVxHzyIIJR8Hckxuiml7tWirp3/HB2gfKvf59IOvfZwMABH3CfGUYyZl87/ZL3SkH3az/fuhUdMaWB4mbG1UvHTXeF3JQJtcO6DIEC9Rg4ZgTNBt9xU045xGo6zoIa8EdKLT5c+ca4zG1mKxtyNSQzsd841kz+S9gG6QPRizMxZz5hT4OPFR0pqWgjjYdbv3eHPEwPP0DB/OBU69ixQnLedynj+R7L7iDI166iu+feZuuf+pBzN4+j8QZ3qWifo6oJlgEJ10FA2qWfTuntb19P1G/YkaC36CJBhGJSSbbzF+1g/q6Jmkco0kaal4JaEtjBZ2ZpPaQ5Sx54RPY91cXQCdl9KSjGTzpGAaImLrwGpKpPg583VPowzBPIkkyozYnUqWqqtKGVibujt2wfx5MHbN+OQOnH43etJfozBNI0jbJsa9CXMqSTz4bqdel056H/iGSS2+m/e7vwMggGln0gkvJ3vwJVUZhyQqo18V//XKoORiKkJUr4bAN+HrcVY/ylctfogCpsPcW03qFhfZNFdSfEzTNndBbOH5hav52dwPD/rm8uXbVb0qcoxcAfr1AEAaEp7AH8WfOfSE9b+3maOOuEw371mpqk8Au7DICfb5M6sKEqxbevioEIhVG4AKjkMJau6IirILHsXc8pT3hGF0X85BXjwT0WybEVrj+h8q+6+sMjvZhSVBJAU8Hz+rjDX1LRulf3g8Mk6T9zN0JT/3EEVxzwS7aN3VY8f4hrtl4K0uOWEpNU8DS11cjrnAXvA8V59ht+/D79nDAGQ/mjz58JtY70BjsELef/0uufsYN9K0ZLE1FCh6sipBqhrZniJYdyOiJR7M/HsL3NZj82A/Y+5ObkYEhWtunIBPuevnHiKSDiSKWvuYJsGpYvMuNK/oG0K372XHc66HRD/39RLMdJl72OdKf3q6rfrlRooOXos4jzmt7ak5YIkgcw74J5l/yKXRmBoYGILXIIx6I+YcXoEcchL/gSvT716r97DnCaUfjI4sZ6ccALnOQpYjmyqAVL0Ptusn8arRfjg0oLr3kenzeaSj9a3jZifFX25qOpedz0vw5PLss+bN77z7tDzQAFAPCjRsx5wHyZ3re3i+nV674WfTRgePsqq1HkGimUVdqrDIJqDgElZ4BFC1BtQKQBX4BDsUJqioSpOcKtKDjrmtTdKzF+mfUecrrY8bxpHiaZNx9S8reyy2mFjR4FMVYS5rAQ85ZxvR+4ZffuB2xyvbN05z/+Bt5xleO4ao37WD40cPIaIfpy3bLMc87lNbulhL10xiq5apG3ZYEPJPX7kdsg/4TDiJyiptL6LiOSL/S2jmmqhHRyoFg/VTxB3R4nM8wo0PMf3crN333PTDvqDUGGL9oC+3PXQZLRiHuA+OY+szFwZK4b4iRlz5KmmsE9V6NAfEWlo1q/ayT8TfvkPTrl8CAYeC8JzPxmH9l/G3fZPDDf45ERtUFRKURIMtI+xvo8mHMQ9ahW8fQbVM0/mgD9jEPlARLsmNc9Rs/wE9OY5YNUWt30FYH5xxEUSHjlTfzVesnLSS/SpUf0WBAUsCAtbj4+d5Ss5y/X8eZ22zsLvOpZp3X8u7Gv9xXS/4/qAAAsGkTfhOgm4nkdC68bXP28FXXyKcOnzMPvfEBkvqaNyRekCr1VysuwdXs7rtVQS6TVbSPTjOcmOBcW5qEOFSCd991FxqgzYoTlGlvaM8ozgozNmN6XwJmniSuMU+K1+Bj3WxYLn7XOFe8cz/ZxBz09zOwapgNf76EC9+4lZlb4UmfPVRu/eQ2RTxrHjPCdf/WguYgts/gyPLXUagVpey7Ygx1A9z6L9ey9QO/RLMOmrSDTJYZgsFV9K0aoYZnvpBK94Fwkwn4ltL/iA2se/mp3Prs/4TEs+HDzyB5y5Nwt4yz7TmfwNuMFf/1lwwfthIkpXnAID5JMCaYl2qnjazuZ+lbz6bz8c2MfeXbuKkp+OOTqJ92qHQuvAbZ8kTMwAjOzWGNgDq89/hGTOMTz8EP9NN56jtQn0Anw7ZnIB5A1g2HSdzlW7AvfBxWlaTZCBX+fBsVy0ILYi1nAFK16AqBQkx1yl+l9mYhdhhDJr+wNXe936dx8mze2fw+G9VwHnpfLPkXH8MfyJHTQ0tw2Ols+cSfpY9q35l8+MjLXdycgKymqr7rkRsursvhXcWWP/fRVV8qCgc9gbzIzj/uIg0cndTR14RbL25yxw/6aBzkWfeYGWZ0DrUeYwV8jWTegG2RNefpkKAmFxkho1YXBlYOcuJrDkJUOejhNdYeO8LYV+c59aOH0Kh5bvvAjCw/8xCaBzV0ds801IWoVigalSoH2NmOjB42LCuftFZWHDko/Wsa0r9hQAaOXM7QA1YTNWKwhnh5P+LSoLFYDDpFqQ3WIOlgDqjRf9JqbF9E56qtuGt3sWz9gcz9Ygt+ehr2zOB+dD1Dhx5A/0HDSBQoPMF12INvQ9YiAbxLAMFIhMXReOPjWfLVlzB86BJCN1MnMgSZFotGaVuj9aNaG+5TcQZEceJxsUFtih63Dlm6Aq7YhhmfwcVW9L8uwXx6M5JVpH0W+PDldKDCvq74sMLhrzrxaOA2YZxkXG5r2bX+FzqaPoJ/bn4/L/kDUPIP4ET8AZ0cM2CM0Pkb9JxtX3O3rbnCvNMca2X/KlJJvS2loURyDQC/ACAUPnZhTmCkFBQtNQdzOfHMC7V+x/69yoXnrcLPKMe9usPytcp8O6Mx4KhRI+40yGaFaKBN1AwW3YJDImEuhSOeW+foc4bVtOpy5afmaM3CYY8Unvq9dax+6AAXPP5GTNPz4PM2AEI6OYvYFt5meKLcXNTS12wSE3P6+x6Bp0ESUIsqxKRYcTS59FmfkPlbdujQQcP02QHSAUO7naAmmINsf/9VuHabma9cxVXfuB60H71qO7PXbadvzQhj7/4JjeMPIt4wyti7f8LAacew7MkPIk1myAo5NdXQy7dSslvvRvdPQdTARjGGlPiRhxPTpJ22UNchOJgGifiA2AHpJIEPEDVB50l9ilBHWolGR6zFPepk3Fd+gfvWdchzHop84VL8V69AbjgcPfJAmEsqkNLuOlC6wz5ZkPGddPX5MtBY1Yzh9Qpb8/vcBRxvX8SfN6b/EEr+P+gAkGMGfAkcepr/lxt+ILevuN79Ry01w9vXSqKpRlIIRBaZf8FAOB8IGglbgMqgUMRIIR0ukbL9euWCV4yy65IGK57Q4rS/Fcgs7ZmU67+VMDQY0b61wfzeQfpX9DM0muDSNkYDuNwjmKZg4oTZPV4lciTOS9KfsPQBhguffQfjl8xxxLlLyTptbv/WXTJ166RGA+HryALyLY4ibv3kDqa37Mf7JGga2giRBpKrASdJyv6rd8FATW750M9125J+6gc1OfC5R+PSjEZc1/0/2SpOlOa6JdQPWc7M9/dgzn4g8UlrufXs/8CPOV318acw+pDV/PKiPbL1xV8jfVeb0acdgYsM5CtUl0TozXcz+YBXgLGQCW6+g8Mg2yZIZvfgdo2p7t8D/X34zOW1VeAUqOS8gcCMKJG6Rh11K2QvfyStb16l6dsvoEZL/K078Q84lGj1CJqk3RZAu2KeXdkurZT7EuC8hSqvC5Beu02MXmFjP+ffzrui1+O5V1B3ewHg1wQOhbmA++oVF3H6ipvsf67PoiPvOIhEvUQ4UOMqvoKFS2xeEYjJs73vwoM1lN3GGDozhi88fw17r6yz4vSdPOcTMwwMRLScp2YjfvSXit87CZJBNMLhL7IsWWKZbBm8ZDlq0aDOYKxgRPCzhiwNPMJrv7CLHV+b1A1vOIAHvmwdX37A5fj9k4Bw0IsPYWh5jXYrA6NYq2z5zJ2Mb96i1OeDOWPUD6YRfrOz+bDfGh6F+iC7P3sdTM4x8LgNrH7BMUiq+CzhqA8+WpP2I9F1S2HeydXr3020dz+7nv8JTa4e58B3ncGapxyMIBzx8afpzX/xVdn5nM9o+tVnM/K0Y6GdopFh6HnH4/ceATFkLoXU0zhyGTFK+7qdOnnmh6CewMwc5vT1ZEN1yLJ8RZtvXtQh09PqZ1uBuiUeicB1ZvGnHY684hHo2y4gef4HlayOvO4M/Gg/MtVCrale/hz6W/GQW8DvD4FBvSAxzt5qY/8L31Hf/mve0fzoH1K//yvvCn/gZ/NmotNPJ/vBtaxcuzv+vF1rT7/lYJO0LZE6yHICUGASWpzGeLU4CdTh4uNAIMr58T6iHkfcedkwl32hyUPP3c3gsoi0FSOmhq03uPYzDfZfl0ETRo6KOPLMJiJC4n0pNIIGtqCJIjqTMd9+fpsVD4k5+dx+mZ9T7rxwVpf+8RL6Bvu442OzzN45Q329Yd2fHkhzsI5zRaCKmb3Dk80W62+LmBoZQuIcqVPERsQ2xpgaagxJkkB/ROPQYawGi3WpRTig44Vkb0tuf8lXGTn1MMTWVJtN1r7sZNKkReY9cWOQsW/ext5v3UD/Ox9HX1zDeMEZg43rmJwF2Sk9XlJRrHa2zzDxmi+iTogOXEHjnJOJjlyGb2fBD5LgdpxqBK/6Am68hfnAnxEP19Es1xRQgzcRfOSH6LdvgIPXoOc+FTPQRBJFJWi5q5ec1SeByFOw+rIcyJEj/XKtvkyuMTV/k9urfekzeUPzR6XPHn8Y/f79MgAAnH8+9uyzcWcptXN/WPtEY5V99s3rJW01xfgUcSZQhl0u0uE0QsWSaeDoF+xBJ1GpG5CpxdTCj6/tIzodi1hTCos0anUES4ILclpJvaIlYHK9gIJ9GFiM1hrQiI4TUgxRvU6aCN5HNBr9WGIcQjv1qDeI5MpFGKJ6jKEWglmug1DQgpUYQ2Aw+lILwQRka8cF5VWJ0NyNJUPoIELdEhETUVeAdicNEuoSLo2tN2ijpKlDXG7oiskNXLowa6eEn42JSESlY2M1CA0siiNN0px8VbgUCg5EahGguNSF9V5oxVRVxWOg3syHshF0UkgJHgAFSEO7OvzBiUeU4vJnEmy2jSBKZq60NXeru01Hs6fymsbN91b6bi8A/D8e3Ygxm/AqcOVF8b/290ev3HKocVPDiiQiGZZMolw6LK8A1JZCHV4Ddbj4e09E4gMdN6gU57RisaAW53M9AQ0aAZg4XP5SfiynGqvpXpT8+crnchax9QBDdoIQREDU5EpAEtR8tFAFwuK9yaXPpOD/B5ERTK4QFHTyJB8gemvzdWcQB/FeCgETUR+4/CK5wIgxudN1wPyrDwI4ztgSS+G1S7LSPMiEmYpBXcGozWE5LmgDaGwrjkwVgd4g0S5q8n9foPrmxB4RnAa1Ji9BHwHT9dfLtfyDeIfkQUCUTEUd0Ml/+zs4+UUU63b3M12XPIMX9N19f7n896sAAKXGgMgm/E8ujv4qtvKefYdHMrHcOE3EZGLLCiDD4iUiyy+75m2Cp2gNisd0s3BVfKNQ6illxiRCKzoESqgyVA1OBK95kDBBvyBIhkeoqZMi4C2xqWOo5dkdXJJLeolFsEithlLPOSvhQhgshhoKkkCuXmQxxApCmmY5WzIEgiyOEGMQb0RVysrHGRs8Q8h1/cLzq/eKc65QFBJqsQblJcnl1nKHRy8Y06SDI+u0UVGyWp8qEca1MM4VIjzqu1afXUNWpUvx1m6AAZG8clFxIsFTrnDoycv7TIJyT27RpUFhRNknXq60sR9LP8vzd7yYDRvaf6jDvvvVEPB/HA4qbIbo4adl7//2T+zO4RvdZzlCmvtXSSqJWnL6T9gGFKKTed+ecwbCpa2sDwtn4orlWOF26nJzsZJJWEqMu9IsVr0B4+mMwfxsvoM2BisRSZrQUTA2pm6FmjFhsm7AjEaBC6CKRtDZmTB3xyyJVUQiLDH1lf0k+zuQOhIcqfogf6Vga4baA1cgsQ2oOGNI98yCM0RRE+/JZbnzS2csIrlKVu6fST1SRvsBxRiLG+9IMjmR62MarFpss046WCf9r0tojfbhnv5AxKfoezcLU5lGL3soMhKhmS9TUjmYLcA8uZOv5nJhFfceLSf+kqN+Khh/qWr+OSAViFXZLcrlNtbJ5B28qf463gRsVPO7luXuVQC/r2ogIAezL15pTx9tmy+219eX7F4dpZlTm+WlfyYh07s8i4d2INcDzKsALzbP7DYXGukqDQtWVSxOrahEoZLQXG5MTV6iGzJnqDctP/3LiJs+Nossa6CuhkQZUV8H32qJmw8wW2KLpn00V/Xzxz8+Cj/iSNoQ9Te59aM7ufFlV+d02z6oD7P6RYew9ytbcdv3QbsFtl+Ia2BbWl9V4/ifPIPaygFIFNvo59ozLmTs+3dhlgyJNGvh0k1OgGtD3sfjEyCFRGmecJiu//YLcD6j2WjKnS/9FlNfuhITtWE+hSUrwTUY+dpzmHrxx3HbJqlfdy614Tqzh74JJNIl178WP1QjSzW3yst1AfNKP3f4zisVQ6npoLLIRVbyKeGi8j8Lb5oERx7uNIarjFHf+Tte33hXZdKv97d7EN1fA4CcTrZ5M9HpD3GbP3u1efTyrclXVnldv/2AOMFrpJrlnvGFbaaUtOEMl/++dXve0McHslGhPhRs4rv2ZardSqIgixerrxTD8IMTDjxDsX2euGnp7DNs35zKwJo+lp4QSSdJNKy2GtK3oo6JfO5S7cnwqFHAccDLjsJ3Guz+rzGaGwbQ2TGGnnYga55zHDXXJO5vctNbfkRn2/6gNqwuZHAShk9cjTMGJxkzP9mH1CMap6xF3Tzh+kWoyxAxWN/U5jEHYiXAiDt4bRy3VKY/1UIedgDmqFWkn7gBTjuQdPUI8bMfjD/3q8S/3E20Zx7d16L5lidR7xtgJm3jJVjD5mm8JPAU5L3CE0JLF/mKX19V+LNwBvGmC+11ILF6ttjIX6kdouRFvL7x2dJ0c9P97/LfrwMAwOlFEDg+veYjN9cftWZb5+trVR9w1wG1RNFI1XVL/6ItkIpgLC4PAsVKWSrSI6biu5vzDEo/Q0o0IngwlixVDn1xxMEvrqEIgzTZfXmd7RdOseoRKzj1fUsYZ14yICKiSYMsbYlzsYoJLa01FjLLyuccLlPf2YOMdBg4rg/mU80m5mnfvpfMxdi+Om4eiPvzzUOAAqdpixV/fxQHcBJTt03odcd/hL5TD5H1X/pzMjpA8BKqIRrl/4oEgj8BSoeU+tOORN5giR7zQAafezL7P/Az4icdRuf93yF561dgeDVzf/dNdGwa6hHtf76YfTdNYD55JrbVRmzo6xEJnp4LyraKq283RBSe0r9C+KNwQg5Kvdxci/WadArbeTqvHfzh/WnY1wsA/0MQOF+xZ0vnzn+7vf8xG3alX17j/EPvOrCZZEYj9S73Hsylw0qvgBz6iu+SinD5mi/nFFAxL81JRL7yOS3ERkVRZzFzg0QqpKrM9gsTt09A0kKNI+3E2PkBOmSk3uOsIjYji8MgsAnUbA1kGN2ZsveLt9F/Yj+61KHW0LpuP3fethv1MUQxzPdRW7EEWxU/UUM6l0AzZeaKXdBpkd2+R+9+zn+BCaIBIgYT10TamS792xOJjl9F5kPV472SzaZqhkel8/6rST54JQhEc/PYYw6APz0JGVpO8t1bYMATPflYZNbD8UvDvsBQejHes1OtBgOh9Pyg4hmZq/2qSon2Uy9g1ckN9Vhvcru12TqDvxm+rHf5ewGgPGcL7vzzsWcfMrfn7br0CQf9fPpLB0jrsdtW9yVYjfCu6yy8QFuwChWmuwYTCyWiUEop+kAhcnRNagXnHfWG4fqPJvzy7fuJlsR4b8G38HNzsMTrnV/cxY4fzCGxQbN5QTsYZ7RvXT8P+PLhRDa0AXgPfTH7LtvH7K0zrDv3aNKGQ2ccq15+Kke++cEytXsKHYi549nfZ/6GWZypzNvzAWZmlPYNe0GUzu4xOndOQG0ETC38wFKBGSf1cx6s/SYYdXiRUs1HM4Mctwr7wGVk79iNyRJGn/UI7LNOJSFj9xHnwvphGh9+Lv10pA2auQ6UTs2Sy4xXUj9SsYLThQKegdkj5TzAe9QFnX9jybi2UfO3JnfoyMxTeOGyG3uXvxcA7hkEzsZtVMzrZGzmND3oqc+94u7Pr3buT3YeMJi4WKKgOW8qG4IuJbhoASgCgpqKvXiuLwDl16KSy1d7vAZXKVMzRKMdassGEQxWhKktMfiEgfVKbZknm1N86lSiOtqJsaMRJkhfkOFxmkGSiqz0xMuU2e/tZujIFcrIAGNf2iHXXLEfp7O4yQla109hlw7RaXeIRuoBDovijZKQ0rplEqTJig/9MY0TV4pNhFoUE8c17njhj2lddje1ZXWULK8gDBYliyy+JZhT1zP4vOOYePvXcWKZ/+bV+G3jdJIUZuZhl5J8+IeoxKhR9MmHIyv6lLSwYi+CbEXVp+L6Fz4IIi9lYMiFPcTn7YFoxtXNmru9fSMrJ5/EM1ffxcbNvcvfCwC/+mwS/EbFvEm2ti9W/vTffy6fXi7Tz9q9aiDJanFeCUhFTEwW9PTkasSBFmu7jxFZMCMgOF+Fjyw6n3hZ8VzhUc+tUcfQsDWkNchXHz1N1umw9mUDNC0MnzJCdFANTQ3GRWTegXGhx8XjLZDOUXtQk5UvW8/2N21h2eMPElOLVYZgZvcUbut++h53AH2HLZV4LlPfp+J8BlhVFYgsbqpN+7b9yNplrHzsUdj+mDaOeo4hyCb2o3Ye0wSDw+VsG288WeqEkRj/vh8w/aELwQqknok3X4S//DawwJII2TFDcs6XSegHEuqXnYNd1V/KtxWsTUqDMCk1PnLJ30LpN//B5mWVCx8KmvHLvpq7a/6XrJ17Ik9fvYvz1XJ27/L3AsD/IgicB15O9s9+35VmfClzf7V39UiSxWJxXgKNuGJMWVxu9RVNAVMy3HxpThsqBhEtVYlCOBAiDWi6VpIiAwnbLvTM/Nwz8qx+9lw2zf73T/PgLw2z5iBhrpPiBzyCgbbHa0pGlMuCCbHrMPrElWw/bw8zN0/j28qyP1tFvMGz9axtLHnjSSRbJpl82eUy88M9DD59DaYddvASR/it4yTbxtGhAe58+UVEqGY+FQyoJqS378QO11QbQUwkuG8rKUonayFz+9H1/egD18Anr4emo/nRR8Puh+G2jNH+h++hSxoMfOwMzKAJysSHDuGdC6jKvJ4qqyXIA4PpCnmWvG4P2DLzewEcmb+mv6bbZ3/KA6bP4PQD9+eX3/V+w3sB4H8VBM5TZOM/qvnrB7u/fte1Zm5wz9Tr0mUjiWvWjDpnCpkwXWA64sKWoJwVFFVAZUugueddEKTBYyWwDR1ZCjJgmdjR5rq3KFgjRzxvGWOXOB2zKbYWo4CJhLHvzYgYr0MnjeANCBmZS4CaRjNWGDNgBskkAusk2zPN6NPXwHAfe57xE9Jd8/SfMoQe1U+SZRoXRhre09k9hQxYsU3D/HdvVhVBTE0lzUSZRec7KmuG8PUIk2QBmFSAcwZryPwMnHEifa94HHOf2Uh29xjxugGiBx5C54aLYU4g8WjqsY85DmUWdYrJvGi+iy/wPQHgY/I5oM/Rfyww9cB7cAYvYDKf+V/213T75I84Zu+fcOpRM6iaP1Q2Xy8A/JaO5CvmY47Bnv2g9PVvvbbW6peJ89KlS9KkGSuZE5UCvx7l/X2e5cV1hUSIgrJQIVEneeAIWjcUWCzvDbV+I3N7Pb94vtf56zOW/tkghz66zt7vWlHfpy5WUhLqjUj2fEnZ8ZExjr20wZI/agQkgEuhv8bUVzK94XM7MYfWpf+EQfbNzuOzDsPrRln1oiPY/fa9DP7FwRz7qRNJaNFppaiNwEZYE7HscRsYvvkAzYwlMpaIwC9I6pEml+7gtkd9jtrBK1k6PEKLhHkcLvGIc7hL7kL7mujXt9D+wV50tEH2/kvwDz8K91Bove372AcdgKow9+oLSR60AjlyCVGnjYssBcintPUWk6v55J9RjyoS0Iz5511AB5pUMn/9QM3vnPweJ+08k+OOm2OjmtwJsHd6AeDXDwIoPqwJk03/eF1d+vzYRrdsJG01m0ZdJl6D2Qam+MV1pbhoEJp1gRuQDwVzG9zuOisny/Y1hf0/i7niVY7pyxP6T4IHvLNGixmyVoZYZP6WadoPCBLj89scLB2gOdQgzg05xXhIUgYe4jjouH6GHr4CO6ogEekU3Pn6a4ky6D9NmP3qbWx9Z8zalx6Gb0Q4IyT7Zpm9fCcSRfgsxaHYuIGxNVyakMWe1s93I3EdfI3Z795ONjlN8uAV6MEj2Cxj/rzv48dB4g5+dBJaYJ7zMPSYVbSf/3l0zy7qH/pTov6Y6cd9EPfczxF95pno4Uugk+KNCdDmEhPsc1RgMTwNGH9ylWd1Qf5dEs30hkZNd4//gBP2dC//pt7l7wWA/1MUQM8ug0DnvH+4Lppv2Mm3d7AZzTo4H5T5c4WfheIiBT9fcgdiX/5idx+niFV+8Y8Nbn3/kDKVMvL4lAd+NKJ2QEKKobmug2bKzW+c4JZzW2EFNtNH44+G6F9noJMRN+vhmdMZ2usT2fCklSgRO748pkjE1Od3MDWHrHnnAzn0Yyu58Yk/4e7XXs7EDyc44gsPlmikqVO3THDHn3wv/4enQCN/A5gFWkANmsPMf+02bvvytcAsjY+eyZLDTkBcQnPTaTSoMfxHB2oyNsveR3wOWbKM9ku/j79kC+Z5j0CevAGJhPobHk3nn39C+vAvop//Y3jUAdDOwCxeAZruprL8dDDqRMA4Sf2tzbrfM/41feTdz2TdQ1u9y98LAL/ZIABu42aiTQ/M3vGaGyNT9/v/2S1Zmvq+psGHdgB1pS+h5nBh8uCglSFg8aSFK5WNYMkJKc0DHOs2zXHIORYfGXw7UY2MHHJOXV2nxdQvDcYOIOrELLGsP6dBPNAmmYOYOLD4YsFIRpY5jBodPXyIxqENBh/az8oXb9ChY4ZFaoYHbX683vXK6+l/9DJkBNJsntqhA6z54EMRCQIhxsQ5wCcXH7W5Pbozoe/G4ZMMOXUVxrdR9QyfeYRSsCDHZkA6sMTAcqX2qocTv+0xGJ/gO1B/6xMww310vnMnHNOPZElJ4c+tfvP5f57tVUXUhADowqDVJJL5m03d7R77HM/6+XORs13v8v86v9q982v9vDZuxm46nexvrov+IR7mLenI0jTpq5nMGdFcO6Dg9LvcalwrlOLC3rtLGw4UYWqWuTFL39IYl0S5FkAUIMfGYKKIDIOljiHKBW0EnwT3H28snUlLtsth10WY/hribBDtGM+IljQDFbnjQQ22UQcMGUqWCs4LPoqp2QZC6MVdjndw+Ws1pZhIV1cjBLUMn4CKpUDiORuRdJTkjglkwwjEBmlEGKdopngxiBE0iunMzqIDTaQjwf48DPlFMeUWIFx8Cfh+l7dSiWR6U1zzO6cv4FlHno1XYeN5wqZNvcvfCwC/vZ/ZaZuxF58u2Tk3xhv7+v15bumytNVomsyplNoB+SX3RKWGAIUOQMllj3MefRDwUGvwSQ2sBYkpNAW8CupyNaKKeo8Xi9ggLQYxaiOMjchScD4Ylygm+P+lISCFib2g3uTKyCYPTuF1BGigKVWKtNQmyD8v+Wst7NXz1118r1w8NWgWGMFbg898idwLd9t0PTkVnAmsPTWRlmogBD2C4te0oDDjQjtlMpPpbbbmd019W58mfwLHpJzXu/y/7rG9H8Gvf7Z+Cj1LsZ9e4TYf+5III61Ha1zPssgYX3LWJV//Fcw/U+EBFIIWXYuycCklGGsUEuXSBRiFZBjUfNRIcNeVgi8vIWt7wae+fL7weYN35F9j8vVG/vWYHHVXfJy/HiNgDRgTZMdteK9G8Ca8BqyUr0Mx+fej3H54Cfh8TYv1R/GuEjg0PNZoQYxaAPcVka44QOnTJyAqmd4hNbdz/HucmD2doeM6cJ6w6fTe5f81j+n9CP6fjl4A/rTNRB86Ot00O63v1Ol9NZOkGblDT5AUz98kGJJo1YBENCcUudJ0JEiH5KxB8SWwqCTriJamJVpBF4THJAGWbPPnrZidL/66qkCu5tZiJYAp/z6lF0Lug+BFSwt1X7xOKNF65R/xFR8FRQuugVQQk8WaT4KsefhcId7n81gSXleuAgi+kPHF6V3U/O6Jn/JH+87kwIfMs3Gj9Hr+XgvwewgDyFlgLhBxz745+nB9iXmJH1iapFEc+Vzwo2gJgq5glLcAoRWgZBnavF2w5d9TlRbLBUa6fxflxZstZcjIvx6Nc6mxUO4XMmTVmUP18SWvQU3OerSVGUX+uaINweSvJVcjRv7bN1+pcHw+0CsVkSoIyoIoVVYm+fqUvEIQzSHAajAiTu8idttnf6FrssfygIeO5yCf3uXvVQC/n+3ABeA3qprPHZW9dH7CfYb2RM16spBlQ9bqZteiIiisyfyCDFw1p9OqJZkWWT3PgtL9u+IaKUU1kXW/tvK8YRPhK96Ila8r/jv30SqrE+lWIAsqD+k+RzXzL3h8yPqquVdvxZWz8u/U3GYxz/K5pFpp4wW5a4cHq063dWK3Y2yLrsyeygMeOs7559ve5e8FgN97ENgEuvFcNUcc/g/Pmx53F6Tt/TWrrgwCxRvle59/XFwUv0C8TqVa3heWNVXnyuBpWJbueWtBESQ0BXF5G7LY7L4SQIoLXXgkSghGXf/DRY6Zsuj7aSVYaTcYVMX6ugFukSd3kAotJyI5qb/ET+YQvwDHjHHsaMdux/R27Z99Msc/dAfnn285++wevLcXAO4dQQBgE5t07JBTnjW9p3Vh0hqrxZAtvPxFNi4IQ9UM7Bf09r60LXPlx1RmCuTPQXnxtVsF4MKiToIBqS5yv9TqfKKULfUhYFTmBSx6XWUwKYLEgoBQwHW1eoEFXHdCoF2lzjLQqJNqZYIUDULu4hHjze525LdO7tdG68mc+sRbepe/NwO4V56Nitkk+KfuWzrYmZnc3Le8/4RabUmaILaYB0BMEAgNYBkKjIAE7XskCgYi+cov9OS20vMXa8AoX8/ZUv+/6N+LuYESl72/ls8ZdT9Xriq7ZiGqtmteUvbr3b8vtxlarBC7fx8g0KaY4edQaPnVgp7VXh+6tUCuQKweiIyaiRS/ZTZ1rv14Tnvyj9m8OeL003uU3l4FcO87BZX468vHZrQ2dMbUxNxdrWQqtoLrZvAMr1mewV3OFXA5082jmpX9vmq3Xai2DyGDB/V/n78PlUKWzxeKjOoK47tyZlBk/gVbCkKVQYlgrP7d4sqku8XwZenf3S5QKCFqsUkosr1f8JzdWUfXlr2oLFCPxqIy01G9a9q6bO65vcvfqwDuM+csxV4guEfd3v+gTtT64cjI8NJ637DreGsKMJDPMzEaNgRoFyTkCWYjSHfi353MR4s+DtLi5XZBQ4VALj9efr9K1veaf16KTUCR+avmJqZSBVQqgDzL64IKwZaVgl+U0f0CzYT8Vy7ffnT1O4tdoMlXjxbpZJlunam5yflX8Iinv693+XsVwH3mXCC40zYT/eiQuWulU/vTvXPTSSeZI3gMu+7grTq9L/f/ioojN7Mrq4bq8K2awVG3cCgnbkFloeXXV+YJ4vIpg6tsByqzCVzOWahkal00uKwM9BYO/hbONbqPCWfh1kPLwWOQR8tQUUyWZOyerrnpiXf1Ln+vArjPntOU6GIhO2Fb3wvNqP/Yimhpgm1ETm3eSwfjzmqvX/TkJfQ278m1rAQq1YBGZYYPUNzKmy76b2zQ3yszfeUxYirfW/JM3/28z70HvUj+uvPXt2BWYBZ4A5ZMSFmMfpRKMJDC5y8MCAMaMLP75mvJzv1f1JOfcxb+fAtn+8qX9c5v8PSgwL/Fs3VTQAteelx61bKXRiPtgeRhQ9JIFWO0XIItHoQVcVkoH1OoCEtXJLMwJgkPXwTE0VwaC6guyUt2olSgyJX8HRB9slBmjy51ecFzFJ+TipsnXaivlnv/ipJv4c1WzT1aqQ+sODM+V8t27b9al9afzsjRKRftg9Mv7l3+XgVwHz0VtOCR22ufGV3WfM4ylqZtg6XM0lEFBViZ7IvtIvByE9Aw/S+qgqIyKJCBUdnTF5sEKkak3Qoi7vb6mmfvwrm4qEyKPl9Nt2KoMBkRU35tmPxLiRD0yoKs303fpqKHIN3+3ytEkZfJ2cjdvf8OL/oIjn/eDnSjQXrknt/m6ekB/PZDrF6gKBvVrIwP+csdY3c8SJdMPWgJw2mCswuy6+L3WhRpvsy0XYfcqj5mEcpNt88uJbUkn65XDTf9gvhfbv2lO6grzXWqRpzl95Iy6xepuSQ6qZYVDJUgEN4qUt/k7YEHiSI1c7O4nXvaXtwzOf7FO9DzLdLb9fcCwB9GEPAo5mK5cfaYnQPP2Ds1c2ltMBqoR32aaSYiklNrCumrkgbf3cOXTkNZvsuvGGRKsVLL8qyeP03uQEzFYBPjUU2BmMJhZ0FQ+dUOW92+Xbrq/KW/YSnhtYgfUOD7FcSYUt9fSmNPBSNImngdm4y13fprTnr5FWzeGCFn94Z+v4PT2wL8DoPAWYq94YDZm+JW9LLtyaRNs7YLSTDLL3G+75fubr5EEkq+15diGt9FFy7eEFQ5BwU8WHO4cQgKxWYgo4vsK7AHOQKvuomQKgzY5SDhxdBm7W4j6G4oyteobhEOILw+IcuYGIuz8cmP+pNe/iE2b4w4fVPv8vdmAH+wM4EIIVu3rf7uxhLzt2vtik4mJi52/t1evMsQ7Pb+skBNKEzxC+GQ6lzAlrOEEkko0YLPV7cLXm3OBDQVVqIpn6+7sZByI6AsFAHx5fvqtL9oMQJ+QIWKrTeoFWfGJuJs19hl/vgDToMbMjjvfmnT3asA7j/HcT72pLVPfd30WHLFbjdWt6KZw2k3Oy9C35VMwoVsui5Dr4Leq6AEQ+WwCPef7/gXYgTS3HgjYARgMQKxQuJZUBHk6MNKhl9YFRQIv4Wfgwy1qmZ22rg9+2d9n3k+cnbCBTdK7/L3KoD7QxVgEPxhdw4cNdGcv3TtwPDAYG3Y+6DxFXQDFmD2owX7f8oJfsD2e82zvVTRgAsxAbCwOtAye1c1C01l+1CtAAJ3oasD8Kt4Ar9iBrBoEKjlHEIgSZ3fOx676bkXctxrPtEr/XsVwP1tKGhv2zB7Uy2rvWRnNmd91tbgHVBh/VXw8pTaAu4eWZ9F2T9/TE7wV0WKTJ3lZp75Y7WqIZCWMwG9RwWQ4/yrlOIFugWLXrN2mYeUaMVipuBQ0UznJmM/OfW53uXvBYD7axBwbCbataZ9fjojn99mp2uRZlmX07+IAHQPWK5WLmlRkmfdS1sM84rnqgzyqAwFkSrf33UHgQvgvNW2QBfQmqk8Nqf34nO68gLKckFusuplZizWvfu3aaP/b9i40fDI83rrvl4AuB+ei/CqmAPi4VdOTHS2783mYot3XtL8ImZln84idqAW7D1dzNwrNgBpfqGzoNKnOX9Aupz+LhMwcAcCvyCtKBaF7+fL15LlM4KicghfV/Ia1C2sDKrzBM3AeJV0TpnYLxh7Dkf/9RjHHNPr+3+PpwcF/n2ei1GOwew9aW5m6G/iWyZt8swhG6kxIooEnG3VSqxqiiu50GYFilvu7Au8rgSlrSobr1QgpjuVLzECeU4IgqRSAo20iuitOht10bw5FZhFsl+6QIJMxTuZ2Vfzk7PvdQ84931s3hjx5L/qZf/eEPB+fjYTcTrZwFb7noGV0Ss26EiaSWwNEb4g8OQrwoLMU6z3gpiIQDG0K9d+VUJQtFBwVKqioItEQAt4sFhU464XwaIBpCuszwpqr0genHLRD+kWmaqCGut1dsLqrj13uBWHHs+yu+d6K79eC9A7AI/EoZgV2dC50+PZneM6H0XivSvWdJK/5b17V2C0mBcskgOTewqAlAO4CgW42050+/4FohxkC76OyvcUKVwPHCIO0fA5WVD2e9QHEJMk88j0fkH4W5a/aKa38rt3nB4U+N5RhymKueOQiakldzdfsyfrfGlImipG8p29duG9kIN+yC9/UchZCp2+MC/ownZ9/riSvVe4GENlfJdX4mUm77YcXdOPouQvfAGkzP4qwa47mJfkct7F9xOccftjPz/7OXf0ey7s4fx7FUDv3DMIOBQ7sbb15XRKv77LzsURzikZqiET+2JVJwvhvn6BUEd3Mk9lELcYDKSaD++KTYH4hWvHUqXYQQEZzjcF1c1DuWUoNw5Z5XukeKNeWvut37tnT9bX/3chKtzQy/y9ANA7v+KogozUG6+ZmuzMTLuWEXFa7vtzwo8n62L6tcADZJXV3aKpvHRxA4WseJjg+4pCr8vhCRV58QUqwjlGQLutw2JUYMk5wOE14A0km1ed22dcKv/I+rfugrN6FN9eAOid/6YK8Chmx4qZ2yThnftsy6rPnC/EQhfAae+Z1Yts7Es/goq4qCz8mjKYaFUENKs8V746rMwPKEFGbtFrWAwOyqsGK45kIvaTM1f6+Qf+B7rRwAW9y98LAL3zPxyPYtbEo++eHfe3Tmg7FnEu7OXTHNHnShy+z1sAXygOk2lXY9B1B4YlDqBoG/LWYnGmL6uNrNQmrCoaQ5qjBos2IgQKkWIwWLQUIOm86NQ+T63+eh7y0jQM/nrSXr0A0Dv/80DwAuTGlftmrTN/N9ZJJMvSXDAzz/Bage1WEIM+SILLAuqudGXGu5ncAS6f4YX/9mWLkJWVwYLgsKjigASVtKD0dmXJizfxjmQs0unWx92hH/whepbl7At6g79eAOid/99zdlgLzq5Jvp7M8aMJk8SR8VlwE+pqBnT78CJT5/29Fv9deP51h3yLXYG6Wv8LLcx+ldZA15koK9GBkOAlRSVBSXJfA1WyKavje2dc/9A/hcHf0b3Mfy88vTXgvbgWUKBuzFum57LTh5qpMaZE+XXXb/muL7DxsgDaUbNQi1+Kr8u/hlyQ2xDAQmq7qL6KFFgAExbP43OQj8lXg+FjpVj5aTefSM3BZE199p8c9sGt6FkW2dTL/r0KoHd+jVbAoZjp1Z3NWYuvT1kXGdFMcfccBopflLGzLqFHC/ced483tKIctAgwRMkyzCjXgOrKVqRUFCrnCgVwCJVkMtL9+2ddY/hfetm/FwB65/9wFKjH8XkzMy7peGcQr+VEX7uknQWT+QXCHl06b7XsX4AFwC9g/XXZfln5PYqAgFSxAw4kHySWn1OHjhnfTj7O2g/fxgW9tV+vBeid/9cqwKOYKZm/pm9H/I3ZoezpI5jEeR+FiyrlA8P0MEcA5qi+wjug/LzY/LIXwUW6KsEVs04WtA/SVSCufB+0eK6iHQAkUpKpyO8fm9ah5f/Wy/69CqB3/q/ngnAjG17fNTubZal3RsVrKNezRXTgbmvgy/K/8nmtWpG7LuJvUSWgVW0A7rkNCOCfbBE+IAPJnPr9xqX+M6z+1F090E8vAPTO//XkG4GJtdll7bZeOGezyIi6hRP6vHyvKgDTJQSRbw+0FOqoaPsVX6d+4UXXherDlLOALIwn8pJfCGtJxCudmUjH9s/R7HtPKCV62b8XAHrnN9IMKGBE3zcz6zRzziyQ5pKKxXYhH14M9yrDwO58QHMDjwqzUNw95MWraL+F70PfL1oZEopzyLjB+S+z9su3oRull/17AaB3fjOzAIciD1jlfpK29NqWdRHGO69VyG8Vk1/N/NW/q1YLukC1554Xv3jcIp3/XOqr2BBIziEga1udmvIS9X0IEC64sac10QsAvfMbOxdhrxJSI3x0xjm8elVxWur/SQD0eF2o6YcutPnuZv3874sAoZWtgFRsyTXrSpLJonlAsSa0OGTS+iS5JDvom5ei0EP99QJA7/wmTxANkb4o+3RnzN/V9j5WvPpi5beA1lsp50UXZP9QDRQyXQVGoDsjUMl3/VU3oaou4T18BjyadsTP7ke8vDeIfJzV+73qBYDe+Q23AcpF2LHlzKjyuXlxouJdN5sXSsC+K/wpi+G83Z7ea64kpLpA/beqMxBwANkiHkBQJyqn/4JXnbQ6NXuzM4dcGFZ/PcZfLwD0zm+jCvAADdynWuM6n6Y+VuO9akX+S7oXXKuXHb+g10eqRKFCwLMy6Msvvl9MOZZuu6CagToP04I1n2bDp9pcdJrtMf56AaB3fjtVgEcxM2u5zWf6rbZVA3jFawgCuvCCV0RBFlQI1YqgauBZioS5LlVYqxuFqvFITvpx05GfmBz30fBnwqzi4l727wWA3vmthgHARub9nTnUO4yiwgK3n8XCob7U/l9g6kF3S9AVAdFyLuArvT+ViiJsBlLEeKcyYTR1X2Ttxds5/yzLJnoBoBcAeue3eP0dGzGvW539JJ33l7WNt2LU+UVOQYUYCBW5sMIMxGvV+KOy3luA9NMKhiDrXvzSwBR8Om91aiKNqH0IgLMu6JX+98Vs0jv3saNYBFfbXjvLjuj5w1ZSFbFdjf8IcrPPQA/O7cE16hqMis0pwhXT0dwi3Bc+AxWcf3hsxQJcYqd+T6x7Jr7q1995RmF42vuf06sAeud3UQUo5pQDk68k4+5nbTRW0cyrX4Tm6yoE+0WW43n2V8Vp1TewQA8WlYTgc5JQdUioSDYnTI877xtvA0rOQu/0KoDe+R1WAdHO6BG2phcNNm2GFZM790hhBU7uCERu861iyqwPVnM3H/FlBSCl9TfY4BEgwe2nSO+iUeZlR83taX1OD7r7Ob3s36sAeuf3UQWcj80OyH6sHc5vxT4GMg9dcE+Z+V0JB17gGaBePF5UFvb/WiEKLRAL0QxQr27S+rHpcc0G/77CSe6dXgDond/pOSsQ8m3mXtUZ1x2J11hEvYpqYc5JpS3wBTJQPb7CELxH27BA3jtX+tEsMP58x/tsnyWtvYJDbtzGBb3s3wsAvfP7qgKUCzCtg9ipczx/ft4Z51DEqy9IO0UgKARBtQLx1QoJqGr7XZH87uIEMoz6VNlb81PJ+/36bZ9jMxFn08P89wJA7/zeztk4NhO5Q9z3mZdz58XV1OFF0Orgr2oUWjL+CuqwViTG6LoEYXwZGERIHLsbft/sJbrutFdzPpZH9i5/LwD0zu//BKKQzdZlb9a9/v0tcTXv1AegjlcpWX5uoa+g5t4C0mUQCpXHhJ4fUU2939Vw+2evacwtPwu5IOGGXE2sd+7jRWTv/GGcMIwzCC7abt5In7y5FkUa12zisbGqyaf53Z0/anNpcVt+ebHrVwwikSNL8LIvduPZt3V6zZ9z9M1jval/rwLonXvjPCC3FcvW+Lf4ef2z9lw62SGti3cq1meI11IQpKIU5EtjUYfiNeAMsgw/Hvv2rtiNJf+qP3viU3qXv1cB9M59oxoISMGbakekw+48K3JWNBpZ4yPERBnWesWiaiRgBUQRg3pEnYs1SvDzLfxceqlJBt/sNox9u3Qk6ZX9vdM795EgkJ94a3yCbLP/brdGd8djNa13mlrPBrSeDmk9HdZ6NqK1ZFCjmT6NdjfnzI7Gt9kx8Cds3BgqxPNDlOj9UHsVQO/ct4KAyf8vh5J9fHTYTs6fLKIPUaPr8H7Uo2KMjCu6TaR+Y1Qb/GVn1b47KBL9+djeqq93eue+HggqFcH/4vHyaz2+d3qnd+4TgSBcbCViMxFKhGLLjzfnFMLeud+c/w9W4qN076mW2QAAAABJRU5ErkJggg==`;
			return `<!DOCTYPE html><html lang="zh-CN" data-theme="light"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>登录 · CFLYHL</title>
<script>try{var PT=localStorage.getItem('pth');if(PT==='dark'||PT==='light')document.documentElement.setAttribute('data-theme',PT);}catch(e){}</script>
<style>
@keyframes cflyhlHue {
  from { filter: hue-rotate(0deg) saturate(1.2); }
  to   { filter: hue-rotate(360deg) saturate(1.2); }
}
@keyframes blurOverlayAppear {
  0% { opacity: 0; -webkit-backdrop-filter: blur(0); backdrop-filter: blur(0); }
  100% { opacity: 1; -webkit-backdrop-filter: blur(14px); backdrop-filter: blur(14px); }
}
@keyframes containerAppear {
  0% { opacity: 0; transform: translateY(30px) scale(0.9); }
  100% { opacity: 1; transform: translateY(0) scale(1); }
}
@keyframes fadeIn {
  from { opacity: 0; }
  to { opacity: 1; }
}
html[data-theme=light]{--bg:#e9edf4;--card:#fdfefe;--tx:#1c2440;--mut:#626d86;--field:#f6f7fb;--line:#d6dce9;--dim:rgba(15,23,42,.45)}
html[data-theme=dark]{--bg:#151a2d;--card:#222940;--tx:#edf0fc;--mut:#a4adc8;--field:#1b2237;--line:#39415e;--dim:rgba(0,0,0,.65)}
*{box-sizing:border-box}
body{
  margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;
  font-family:"Segoe UI","PingFang SC","Microsoft YaHei",sans-serif;color:var(--tx);
  background:var(--bg);position:relative;
}
.overlay{
  position:fixed;inset:0;z-index:0;
  background:var(--dim);
  -webkit-backdrop-filter:blur(14px);backdrop-filter:blur(14px);
  opacity:0;
  animation:blurOverlayAppear 1.5s ease-out forwards .3s;
}
.card{
  position:relative;z-index:1;
  width:min(400px,92vw);padding:36px 28px 28px;border-radius:24px;
  background:
    linear-gradient(var(--card),var(--card)) padding-box,
    linear-gradient(90deg,#ff0000,#ff7f00,#ffff00,#00ff00,#00bfff,#8b00ff,#ff1493) border-box;
  border:3px solid transparent;
  box-shadow:0 20px 60px rgba(0,0,0,.18);
  text-align:center;
  opacity:0;
  animation:containerAppear 1s ease-out .8s forwards, cflyhlHue 8s linear infinite .8s;
}
.theme-toggle{
  position:absolute;top:12px;right:12px;z-index:2;
  font:inherit;border:1px solid var(--line);background:var(--field);color:var(--tx);
  border-radius:999px;padding:8px 11px;cursor:pointer;line-height:1;
  opacity:0;animation:fadeIn .8s ease-out 1.2s forwards;
}
.theme-toggle:hover{border-color:#3d55bd}
.logo-wrap{display:flex;justify-content:center;margin:8px 0 14px;opacity:0;animation:fadeIn .8s ease-out 1.1s forwards}
.logo-wrap img{
  width:112px;height:112px;object-fit:contain;border:none;border-radius:0;
  animation:cflyhlHue 4s linear infinite;filter:saturate(1.15);
}
h1{
  margin:0 0 18px;font-size:26px;font-weight:800;letter-spacing:.02em;
  background-image:linear-gradient(90deg,#ff0000,#ff7f00,#ffff00,#00ff00,#00bfff,#8b00ff,#ff1493);
  -webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent;color:transparent;
  animation:cflyhlHue 4s linear infinite, fadeIn .8s ease-out 1.2s backwards;
}
.err{color:#b94e56;margin:0 0 12px;font-size:13px;font-weight:600}
label{
  display:block;text-align:left;font-size:13px;font-weight:700;margin:0 0 6px;
  background-image:linear-gradient(90deg,#ff0000,#00bfff,#8b00ff);
  -webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent;color:transparent;
  animation:cflyhlHue 4s linear infinite;
}
.pw-wrap{position:relative;display:flex;align-items:center}
.pw-wrap input{
  width:100%;padding:12px 44px 12px 14px;border-radius:12px;font:inherit;color:var(--tx);
  border:2px solid transparent;
  background:
    linear-gradient(var(--field),var(--field)) padding-box,
    linear-gradient(90deg,#ff0000,#ff7f00,#ffff00,#00ff00,#00bfff,#8b00ff,#ff1493) border-box;
  outline:none;
}
.eye{
  position:absolute;right:8px;top:50%;transform:translateY(-50%);
  border:none;background:transparent;cursor:pointer;font-size:18px;line-height:1;
  padding:6px;border-radius:6px;color:var(--mut);
}
.eye:hover{color:var(--tx)}
button[type=submit]{
  margin-top:16px;width:100%;padding:12px 14px;border:none;border-radius:12px;
  font:inherit;font-weight:800;cursor:pointer;color:#fff;
  background:linear-gradient(90deg,#ff0000,#ff7f00,#ffff00,#00ff00,#00bfff,#8b00ff,#ff1493);
  background-size:200% 100%;
  animation:cflyhlHue 4s linear infinite;
}
button[type=submit]:hover{filter:brightness(1.08) saturate(1.2)}
.form-block{opacity:0;animation:fadeIn .8s ease-out 1.4s forwards}
</style></head><body>
<div class="overlay" aria-hidden="true"></div>
<div class="card">
  <button type="button" class="theme-toggle" id="theme-toggle" title="切换深色/浅色" aria-label="切换主题">🌙</button>
  <div class="logo-wrap"><img class="brand-logo" src="${logo}" alt="CFLYHL" width="112" height="112"></div>
  <h1>CFLYHL</h1>
  ${msg}
  <div class="form-block">
  <form method="POST" action="${act}">
    <label for="pw">密码</label>
    <div class="pw-wrap">
      <input id="pw" name="password" type="password" placeholder="请输入管理密码" autocomplete="current-password" required autofocus>
      <button type="button" class="eye" id="eye" title="点击显示/隐藏密码" aria-label="显示密码">👁</button>
    </div>
    <button type="submit">登录</button>
  </form>
  </div>
</div>
<script>
(function(){
  var btn=document.getElementById("theme-toggle");
  function cur(){ return document.documentElement.getAttribute("data-theme")==="dark"?"dark":"light"; }
  function sync(){
    var v=cur();
    if(btn) btn.textContent = v==="dark" ? "☀️" : "🌙";
  }
  function setTheme(v){
    document.documentElement.setAttribute("data-theme", v);
    try{ localStorage.setItem("pth", v); }catch(e){}
    sync();
  }
  if(btn){
    btn.addEventListener("click", function(){ setTheme(cur()==="dark"?"light":"dark"); });
  }
  sync();
  var pw=document.getElementById("pw");
  var eye=document.getElementById("eye");
  var shown=false;
  if(eye && pw){
    eye.addEventListener("click", function(e){
      e.preventDefault();
      shown = !shown;
      pw.type = shown ? "text" : "password";
      eye.textContent = shown ? "🙈" : "👁";
      eye.title = shown ? "点击隐藏密码" : "点击显示密码";
    });
  }
})();
</script>
</body></html>`;
		}
		

const PANEL_HTML = `<!DOCTYPE html>
<html lang="zh-CN" data-theme="light"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title>CFLYHL</title>
<script>try{var PT=localStorage.getItem('pth');if(PT==='dark'||PT==='light'){document.documentElement.setAttribute('data-theme',PT);if(PT==='dark')document.documentElement.classList.add('dark-mode');else document.documentElement.classList.remove('dark-mode');}}catch(e){}</script>
<style>
:root{--rad:13px}
html[data-theme=light]{--bg:#e9edf4;--card:#fdfefe;--line:#d6dce9;--tx:#1c2440;--mut:#626d86;--ok:#287a68;--bad:#b94e56;--pri:#3d55bd;--onpri:#fff;--soft:#edf0f8;--chipBg:#ebefff;--chipTx:#324cac;--field:#f6f7fb;--codeBg:#eaecf5;--warnBg:#fff8e9;--warnBd:#eed9a8;--warnTx:#795a22}
html[data-theme=dark]{--bg:#151a2d;--card:#222940;--line:#39415e;--tx:#edf0fc;--mut:#a4adc8;--ok:#77c8ab;--bad:#f3a1a6;--pri:#9dacff;--onpri:#1c2440;--soft:#2d3550;--chipBg:#343f6c;--chipTx:#ccd4ff;--field:#1b2237;--codeBg:#303956;--warnBg:#3c3428;--warnBd:#726047;--warnTx:#f1d39e}
*{box-sizing:border-box}
body{margin:0;min-height:100vh;background:var(--bg);color:var(--tx);font:14px/1.55 "Segoe UI Variable","PingFang SC","Microsoft YaHei",sans-serif}
header{min-height:76px;padding:16px max(28px,calc((100vw - 1290px)/2 + 34px));display:flex;align-items:center;gap:10px;flex-wrap:wrap;background:#202844;color:#93c5fd;position:sticky;top:0;z-index:1000;backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px)}
html[data-theme=dark] header{background:#101529}
header h1{font-size:19px;font-weight:720;letter-spacing:-.035em;margin:0 16px 0 0;white-space:nowrap}
header h1::before{content:"";display:inline-block;width:24px;height:24px;vertical-align:-6px;margin-right:12px;border-radius:7px;transform:rotate(-24deg);background:#94a8ff;box-shadow:inset 9px 0 #fff}
.tag{display:inline-block;font-size:12px;color:var(--mut);background:var(--soft);border-radius:6px;padding:5px 9px}
header .tag{background:transparent;border-left:1px solid #53607d;border-radius:0;padding:0 0 0 12px;color:#93c5fd}
.themes{margin-left:auto;display:flex;gap:5px}
button{font:inherit;font-weight:600;border:1px solid var(--line);background:var(--soft);color:var(--tx);border-radius:999px;padding:8px 13px;cursor:pointer;transition:background-color .2s,color .2s,border-color .2s,transform .2s}
button:hover:not(:disabled){border-color:var(--pri);transform:translateY(-1px)}button:active:not(:disabled){transform:translateY(0)}
button.pri{background:var(--pri);border-color:var(--pri);color:var(--onpri)}button.pri:hover:not(:disabled){filter:brightness(.94)}
button:disabled{opacity:.5;cursor:default}
button:focus-visible,input:focus-visible,textarea:focus-visible,summary:focus-visible{outline:3px solid var(--pri);outline-offset:2px}
header .th{font-size:11px;line-height:1;padding:4px 14px;height:26px;background:transparent;border-color:#53607d;color:#93c5fd;border-radius:999px;display:inline-flex;align-items:center;justify-content:center;text-align:center}
header .th.on{}
main{max-width:1290px;margin:0 auto;padding:32px 34px 40px}
.cards{display:grid;grid-template-columns:1.42fr repeat(3,minmax(0,1fr));gap:0;background:var(--card);border:1px solid var(--line);border-radius:15px;overflow:hidden;margin-bottom:25px;box-shadow:0 12px 30px rgba(33,46,85,.055);animation:stripEnter .48s cubic-bezier(.18,.7,.2,1) both}
.card{min-height:132px;padding:22px 26px;border-right:1px solid var(--line);display:flex;flex-direction:column;justify-content:space-between}
.card:last-child{border-right:0}
.card:first-child{background:#384fb1;border:0;color:#fff;position:relative;overflow:hidden}
html[data-theme=dark] .card:first-child{background:#4559ac}
.card:first-child::after{content:"";position:absolute;right:-46px;bottom:-96px;width:196px;height:196px;border:1px solid rgba(255,255,255,.19);border-radius:50%;box-shadow:0 0 0 28px rgba(255,255,255,.045),0 0 0 58px rgba(255,255,255,.035)}
.card .k{font-size:12px;font-weight:600;color:var(--mut)}.card .v{font-size:30px;font-weight:680;line-height:1.25;letter-spacing:-.035em}
.card:first-child .k{color:#d9e2ff}.card:first-child .v{font-size:52px;line-height:1;letter-spacing:-.06em;position:relative;z-index:1}
.card .v#v-store{font-size:17px;letter-spacing:0}.card .v#v-src{font-size:13px;letter-spacing:0;font-weight:600}
.tabs{display:flex;gap:14px;overflow-x:auto;white-space:nowrap;border-bottom:1px solid var(--line);margin:0 0 17px}
.tab{flex:0 0 auto;border:0;border-radius:7px 7px 0 0;background:transparent;padding:10px 17px 15px;min-height:46px;font-size:14px;font-weight:620;color:var(--mut)}
.tab.on{color:var(--pri);box-shadow:inset 0 -3px var(--pri)}.tab:hover{background:var(--soft)}
.panel{display:none;min-width:0}.panel.on{display:block;animation:panelEnter .26s cubic-bezier(.2,.7,.2,1) both}
#t-over.on{display:grid;grid-template-columns:minmax(0,.9fr) minmax(0,1.1fr);gap:16px}
.box{min-width:0;background:var(--card);border:1px solid var(--line);border-radius:var(--rad);padding:25px 27px;margin-bottom:14px;box-shadow:0 8px 24px rgba(40,53,89,.035)}
.box h2{font-size:16px;font-weight:700;letter-spacing:-.02em;margin:0 0 22px}
#t-over .box{margin:0}#t-over .links-box{grid-column:1/-1;border-top:3px solid var(--pri)}
#t-rp .box:first-child,#t-pool .box:first-child{border-top:3px solid var(--pri)}
#regions{display:flex;flex-wrap:wrap;align-content:flex-start;gap:10px}
.chip{display:inline-block;background:var(--chipBg);color:var(--chipTx);border:1px solid var(--line);border-radius:6px;padding:8px 12px;font-size:12px;font-weight:650}
dl{display:grid;grid-template-columns:125px minmax(0,1fr);gap:0 24px;margin:0;font-size:13px}dt,dd{padding:10px 0;border-bottom:1px solid var(--line)}dt{color:var(--mut)}dd{margin:0;font-weight:550;overflow-wrap:anywhere}
.row{display:flex;gap:9px;align-items:center;flex-wrap:wrap;margin-bottom:16px}
.wrap{overflow:auto;max-height:620px}table{width:100%;border-collapse:collapse;font-size:13px}th,td{text-align:left;padding:13px 14px;border-bottom:1px solid var(--line);white-space:nowrap}th{background:var(--soft);color:var(--mut);font-weight:650;font-size:12px}tbody tr:hover{background:var(--field)}tbody tr:last-child td{border-bottom:0}
.empty{color:var(--mut);padding:18px;text-align:center}
.ta{width:100%;min-height:310px;font:13px/1.8 ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;padding:17px 18px;border:1px solid var(--line);border-radius:8px;background:var(--field);color:var(--tx);resize:vertical}
.ta.compact{min-height:120px;margin:10px 0 16px}
.hint{color:var(--mut);font-size:13px;line-height:1.9;overflow-wrap:anywhere}.hint code{background:var(--codeBg);border-radius:4px;padding:1px 5px;font-size:12px}
.warn{background:var(--warnBg);border:1px solid var(--warnBd);color:var(--warnTx);border-radius:8px;padding:15px 17px;font-size:12.5px;line-height:1.7;margin-top:14px}
.lnk{display:flex;gap:8px;align-items:center;border-bottom:1px solid var(--line);padding-bottom:12px;margin-bottom:12px}.lnk .k{flex:0 0 76px;font-size:13px;font-weight:650;color:var(--mut)}
.lnk input{flex:1;min-width:0;width:0;font:12px/1.5 ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;padding:10px 12px;border:1px solid var(--line);border-radius:8px;background:var(--field);color:var(--tx)}.lnk select{flex:0 0 auto;max-width:130px;padding:9px 6px;border:1px solid var(--line);border-radius:8px;background:var(--field);color:var(--tx)}.lnk button{flex:0 0 auto;padding:9px 15px}
.import-row{margin:18px 0 12px}
details{border-top:1px solid var(--line);padding-top:14px;margin-top:12px}summary{cursor:pointer;color:var(--mut);font-size:13px;font-weight:600}details .hint{margin-top:12px}
.foot{color:var(--mut);font-size:12px;margin:16px 0 0;border-top:1px solid var(--line);padding:17px 2px}
@keyframes panelEnter{from{opacity:.25;transform:translateY(7px)}to{opacity:1;transform:translateY(0)}}
@keyframes stripEnter{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:translateY(0)}}
@media(max-width:1050px){main{padding:24px}#t-over.on{grid-template-columns:1fr}.cards{grid-template-columns:repeat(4,minmax(0,1fr))}.card:nth-child(2){border-right:0}.card:nth-child(-n+2){border-bottom:1px solid var(--line)}}
@media(max-width:680px){header{padding:15px 18px;gap:8px}header h1{width:100%;margin:0 0 3px}.themes{margin-left:auto}.tag{font-size:11px}main{padding:20px 16px}.cards{margin-bottom:20px}.card{min-height:112px;padding:16px}.card:first-child .v{font-size:40px}.card .v{font-size:22px}.tabs{gap:0}.tab{font-size:12px;padding:10px 12px;min-height:39px}.box{padding:19px 16px;box-shadow:none}.lnk{flex-wrap:wrap}.lnk .k{flex:0 0 100%}dl{grid-template-columns:100px minmax(0,1fr);gap:0 10px}}
@media(max-width:380px){.card .v#v-src,.card .v#v-store{font-size:14px}}
@media(prefers-reduced-motion:reduce){.cards,.panel.on{animation:none}button{transition:none}button:hover:not(:disabled){transform:none}}

main{padding-bottom:140px}
.global-actions{position:fixed;z-index:20;right:max(22px,env(safe-area-inset-right));bottom:max(22px,env(safe-area-inset-bottom));display:flex;align-items:flex-end;flex-direction:column;gap:10px;max-width:calc(100vw - 32px);pointer-events:none}
.global-buttons{display:flex;gap:9px;padding:8px;background:var(--card);border:1px solid var(--line);border-radius:12px;box-shadow:0 10px 30px rgba(20,30,65,.18);pointer-events:auto}
.global-buttons button{min-height:43px;padding:10px 18px}.global-status{max-width:420px;border-radius:9px;background:var(--card);color:var(--tx);font-size:12px;padding:9px 13px;border:1px solid var(--line);box-shadow:0 6px 20px rgba(20,30,65,.1);overflow-wrap:anywhere;pointer-events:auto}.global-status:empty{display:none}
@media(max-width:680px){main{padding-bottom:135px}.global-actions{right:max(16px,env(safe-area-inset-right));bottom:max(16px,env(safe-area-inset-bottom))}.global-buttons button{padding:10px 14px}}

.field{display:block;width:100%;min-width:0;border:1px solid var(--line);border-radius:8px;background:var(--field);color:var(--tx);font:inherit;font-size:13px;line-height:1.6;padding:11px 12px;margin:8px 0 20px}
select.field{max-width:420px}a{color:var(--pri);text-underline-offset:3px}.license{white-space:pre-wrap;overflow-wrap:anywhere;font:12px/1.8 ui-monospace,monospace;color:var(--mut)}

/* CF usage block (edgetunnel style) */
#cf-usage-box{margin:0 0 18px;padding:18px 18px 16px;border-radius:var(--rad);background:var(--card);border:1px solid var(--line);box-shadow:0 6px 20px rgba(20,30,65,.06)}
#cf-usage-box h2{margin:0 0 12px;font-size:15px;font-weight:700;display:flex;align-items:center;gap:8px;flex-wrap:wrap}
#cf-usage-box h2 .badge{font-size:11px;font-weight:600;padding:3px 8px;border-radius:6px;background:var(--chipBg);color:var(--chipTx)}
#cf-usage-box .ulabel{display:flex;justify-content:space-between;align-items:baseline;margin-bottom:8px;font-size:13px}
#cf-usage-box .ulabel b{font-size:18px}
#cf-usage-box .ubar{
  height:10px;
  border-radius:5px;
  overflow:hidden;
  margin-bottom:12px;
  background-image:linear-gradient(90deg,#ff0000,#ff7f00,#ffff00,#00ff00,#00bfff,#8b00ff,#ff1493) !important;
  background-color:transparent !important;
  animation:cflyhlHue 4s linear infinite !important;
}
#cf-usage-box .ubar>i{display:block;height:100%;width:0;border-radius:5px;transition:width .45s ease;animation:none !important;filter:none !important;background-image:none !important}
#cf-usage-box .ugrid{display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;align-items:stretch}
#cf-usage-box .ustat{background:var(--field);border-radius:10px;padding:11px 8px;text-align:center}
#cf-usage-box .ustat .k{font-size:11px;color:var(--mut);margin-bottom:3px}
#cf-usage-box .ustat .v{font-size:15px;font-weight:700;white-space:nowrap}
#cf-usage-box .ureset{margin-top:12px;padding:10px 12px;border-radius:9px;background:var(--soft);border:1px solid var(--line);font-size:12px;color:var(--mut);line-height:1.55}
#cf-usage-box .ureset b{color:var(--tx)}
#cf-usage-box .uerr,#cf-usage-box .uempty{font-size:13px;color:var(--mut);padding:4px 0}
#cf-usage-box .uerr{color:var(--bad)}
#cf-usage-box .usetup{display:inline-block;margin-top:8px;font-size:12px;color:var(--pri);text-decoration:none;font-weight:600}
#cf-usage-box .usetup:hover{text-decoration:underline}
@media(max-width:520px){#cf-usage-box .ugrid{gap:6px}#cf-usage-box .ustat{padding:9px 4px}#cf-usage-box .ustat .v{font-size:14px}}

/* layout overrides: theme buttons + cards one row */
header{
  flex-wrap:nowrap !important;
  min-height:auto !important;
  gap:8px !important;
  padding-top:12px !important;
  padding-bottom:12px !important;
}
header h1{margin-right:8px !important;white-space:nowrap}
header .tag{
  white-space:nowrap;
  font-size:12px;
  padding-left:10px !important;
  border-left:1px solid #53607d;
  line-height:1.2;
}
header .themes{
  margin-left:auto !important;
  display:flex !important;
  flex-direction:row !important;
  align-items:center;
  gap:6px !important;
  flex-shrink:0;
}
header .th{
  font-size:11px !important;
  line-height:1 !important;
  padding:4px 14px !important;
  min-height:0 !important;
  height:26px !important;
  border-radius:999px !important;
  white-space:nowrap;
  display:inline-flex !important;
  align-items:center;
  gap:4px;
}
header .th i{
  width:8px !important;
  height:8px !important;
  border-radius:50%;
  display:inline-block;
}
.cards{
  display:grid !important;
  grid-template-columns:repeat(4,minmax(0,1fr)) !important;
  gap:0 !important;
}
.cards .card{
  min-height:0 !important;
  padding:14px 16px !important;
  border-right:1px solid var(--line);
}
.cards .card:last-child{border-right:none}
.cards .card .k{font-size:12px}
.cards .card .v{font-size:18px;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
@media(max-width:1050px){
  .cards{grid-template-columns:repeat(4,minmax(0,1fr)) !important}
}
@media(max-width:680px){
  header{flex-wrap:wrap !important}
  header h1{width:auto !important;margin:0 8px 0 0 !important}
  header .themes{margin-left:auto !important}
  .cards{grid-template-columns:repeat(4,minmax(0,1fr)) !important}
  .cards .card{padding:12px 10px !important}
  .cards .card .v{font-size:15px}
}
@media(max-width:420px){
  .cards .card{padding:10px 6px !important}
  .cards .card .k{font-size:11px}
  .cards .card .v{font-size:13px}
  header .th{padding:4px 10px !important;font-size:10px !important}
}

/* theme btn center + dark pressed black */
header .th{
  justify-content:center !important;
  text-align:center !important;
}
header .th[data-th="dark"].on,
header .th[data-th="dark"]:active{
  background:#000 !important;
  color:#fff !important;
  border-color:#000 !important;
}
header .th[data-th="light"].on,
header .th[data-th="light"]:active{
  background:#f3f5ff !important;
  color:#26315b !important;
  border-color:#f3f5ff !important;
}
.cards .card .v#v-src{
  font-size:13px !important;
  font-weight:600 !important;
  letter-spacing:0 !important;
  line-height:1.25 !important;
  white-space:normal !important;
}

/* branding + white text -> light blue */
header, header h1, header .tag, header .th {
  color: #93c5fd !important;
}
header h1 { color: #93c5fd !important; }
header .th[data-th="dark"].on,
header .th[data-th="dark"]:active {
  background: #000 !important;
  color: #93c5fd !important;
  border-color: #000 !important;
}
header .th[data-th="light"].on,
header .th[data-th="light"]:active {
  background: #1e293b !important;
  color: #93c5fd !important;
  border-color: #334155 !important;
}
header .th {
  justify-content: center !important;
  text-align: center !important;
}

/* sun/moon theme toggle */
.theme-toggle{
  width:34px;height:34px;border-radius:50%;
  border:1px solid #53607d;background:transparent;
  color:#93c5fd;font-size:16px;line-height:1;
  display:inline-flex;align-items:center;justify-content:center;
  cursor:pointer;padding:0;margin:0;
  transition:background .15s,transform .15s;
}
.theme-toggle:hover{background:rgba(147,197,253,.12);transform:scale(1.06)}
.theme-toggle:active{transform:scale(.96)}
html[data-theme=dark] .theme-toggle{border-color:#4b556a;color:#93c5fd}

/* four stats as circles in one row */
.cards{
  display:flex !important;
  flex-direction:row !important;
  flex-wrap:nowrap !important;
  justify-content:space-between !important;
  align-items:center !important;
  gap:12px !important;
  background:transparent !important;
  border:none !important;
  box-shadow:none !important;
  border-radius:0 !important;
  overflow:visible !important;
  margin-bottom:22px !important;
  padding:4px 0 !important;
  grid-template-columns:none !important;
}
.cards .card{
  flex:1 1 0;
  max-width:120px;
  width:100%;
  aspect-ratio:1 / 1;
  min-height:0 !important;
  height:auto !important;
  border-radius:50% !important;
  border:1px solid var(--line) !important;
  border-right:1px solid var(--line) !important;
  background:var(--card) !important;
  box-shadow:0 8px 20px rgba(20,30,65,.08);
  display:flex !important;
  flex-direction:column !important;
  align-items:center !important;
  justify-content:center !important;
  text-align:center !important;
  padding:10px 8px !important;
  margin:0 auto;
}
.cards .card .k{
  font-size:11px !important;
  font-weight:600;
  color:var(--mut);
  margin-bottom:4px;
  line-height:1.2;
  max-width:90%;
}
.cards .card .v{
  font-size:15px !important;
  font-weight:700 !important;
  line-height:1.15 !important;
  max-width:92%;
  white-space:nowrap !important;
  overflow:hidden;
  text-overflow:ellipsis;
}
.cards .card .v#v-src{
  font-size:11px !important;
  white-space:normal !important;
  line-height:1.2 !important;
}
@media(max-width:680px){
  .cards{gap:8px !important}
  .cards .card{max-width:88px;padding:8px 4px !important}
  .cards .card .k{font-size:10px !important}
  .cards .card .v{font-size:13px !important}
  .cards .card .v#v-src{font-size:10px !important}
}
@media(max-width:420px){
  .cards{gap:6px !important}
  .cards .card{max-width:72px;padding:6px 2px !important}
  .cards .card .k{font-size:9px !important}
  .cards .card .v{font-size:11px !important}
}

/* 下发总数、地区分组数值绿色 */
.cards .card .v#v-total,
.cards .card .v#v-reg{
  color: #22c55e !important;
}
/* 默认 / 保存 椭圆形按钮 */
.global-buttons button,
#g-reset, #g-save{
  border-radius: 999px !important;
  min-height: 40px !important;
  padding: 10px 28px !important;
  min-width: 96px;
}
#cf-usage-box #cf-reset-live{
  font-variant-numeric: tabular-nums;
  color: var(--tx);
  font-weight: 700;
}

/* remove outer frame around 默认/保存 */
.global-buttons{
  background: transparent !important;
  border: none !important;
  box-shadow: none !important;
  padding: 0 !important;
  border-radius: 0 !important;
}
.global-buttons button{
  border-radius: 999px !important;
}
/* 仅动态数值绿色，标题/说明/时分秒单位恢复原色 */
#cf-usage-box .ulabel b,
#cf-usage-box .ureset .unum,
#cf-usage-box #cf-reset-live .unum{
  color: #22c55e !important;
}
#cf-usage-box #cf-reset-live{
  color: inherit;
  font-weight: 700;
  font-variant-numeric: tabular-nums;
}
#cf-usage-box #cf-reset-live .uunit{
  color: var(--mut) !important;
  font-weight: 500;
}
#cf-usage-box .ureset b{
  color: var(--tx) !important;
}
#cf-usage-box .ureset{
  color: var(--mut);
}
/* network info block (edgetunnel style) */
#net-info-box{
  margin: 0 0 18px;
  padding: 16px 16px 14px;
  border-radius: var(--rad);
  background: var(--card);
  border: 1px solid var(--line);
  box-shadow: 0 6px 20px rgba(20,30,65,.06);
}
#net-info-box h2{
  margin: 0 0 12px;
  font-size: 15px;
  font-weight: 700;
}
.net-cards{
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 10px;
}
.net-card{
  background: var(--field);
  border: 1px solid var(--line);
  border-radius: 12px;
  padding: 12px 12px 10px;
  min-height: 110px;
}
.net-card .ntitle{
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 8px;
}
.net-card .dot{
  width: 8px; height: 8px; border-radius: 50%;
  background: #94a3b8; flex-shrink: 0;
}
.net-card .dot.ok{ background: #22c55e; }
.net-card .dot.err{ background: #ef4444; }
.net-card .dot.loading{ background: #f59e0b; animation: netpulse 1s infinite; }
@keyframes netpulse{ 50%{ opacity: .4; } }
.net-card .nmain{ font-size: 13px; font-weight: 700; color: var(--tx); line-height: 1.2; }
.net-card .nsub{ font-size: 11px; color: var(--mut); }
.net-card .nip{
  font-size: 13px; font-weight: 700; color: #22c55e;
  word-break: break-all; line-height: 1.3; margin-bottom: 4px;
  font-variant-numeric: tabular-nums;
}
.net-card .nloc{ font-size: 12px; color: var(--tx); margin-bottom: 4px; min-height: 1.2em; }
.net-card .ntip{ font-size: 11px; color: var(--mut); line-height: 1.4; }
#net-info-box .net-hint{
  margin-top: 10px;
  font-size: 12px;
  color: var(--mut);
  line-height: 1.55;
}
@media(max-width:900px){
  .net-cards{ grid-template-columns: repeat(2, minmax(0, 1fr)); }
}
@media(max-width:480px){
  .net-cards{ grid-template-columns: 1fr; }
}

/* ===== 当前网络信息（完整） ===== */
#net-info-box{
  margin:0 0 18px;padding:16px;border-radius:var(--rad);
  background:var(--card);border:1px solid var(--line);
  box-shadow:0 6px 20px rgba(20,30,65,.06);
}
#net-info-box h2{margin:0 0 12px;font-size:15px;font-weight:700;display:flex;align-items:center;gap:8px}
.net-cards{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px}
.net-card{
  background:var(--field);border:1px solid var(--line);border-radius:12px;
  padding:12px;min-height:118px;transition:border-color .15s,box-shadow .15s;
}
.net-card:hover{border-color:var(--pri);box-shadow:0 4px 14px rgba(61,85,189,.12)}
.net-card .ntitle{display:flex;align-items:center;gap:8px;margin-bottom:8px}
.net-card .dot{width:9px;height:9px;border-radius:50%;background:#94a3b8;flex-shrink:0}
.net-card .dot.ok{background:#22c55e;box-shadow:0 0 0 3px rgba(34,197,94,.2)}
.net-card .dot.err{background:#ef4444;box-shadow:0 0 0 3px rgba(239,68,68,.18)}
.net-card .dot.loading{background:#f59e0b;animation:netpulse 1s infinite}
@keyframes netpulse{50%{opacity:.35}}
.net-card .nmain{font-size:13px;font-weight:700;color:var(--tx);line-height:1.2}
.net-card .nsub{font-size:11px;color:var(--mut)}
.net-card .nip{
  font-size:13px;font-weight:700;color:#22c55e;word-break:break-all;line-height:1.35;
  margin-bottom:4px;cursor:pointer;text-decoration:underline dotted rgba(34,197,94,.5);
  font-variant-numeric:tabular-nums;
}
.net-card .nip:hover{color:#16a34a}
.net-card .nip.loading{color:#f59e0b;cursor:default;text-decoration:none}
.net-card .nip.err{color:#ef4444;cursor:default;text-decoration:none}
.net-card .nloc{font-size:12px;color:var(--tx);margin-bottom:4px;min-height:1.2em}
.net-card .ntip{font-size:11px;color:var(--mut);line-height:1.4}
#net-info-box .net-hint{margin-top:10px;font-size:12px;color:var(--mut);line-height:1.55}

/* latency section */
.net-latency-title{
  margin:16px 0 10px;font-size:14px;font-weight:700;color:var(--tx);
  display:flex;align-items:center;justify-content:space-between;gap:8px;
}
.net-latency-title button{
  font-size:12px;padding:5px 12px;border-radius:999px;border:1px solid var(--line);
  background:var(--soft);color:var(--tx);cursor:pointer;font-weight:600;
}
.net-latency-title button:hover{border-color:var(--pri);color:var(--pri)}
.latency-grid{
  display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px;
}
.lat-card{
  background:var(--field);border:1px solid var(--line);border-radius:12px;
  padding:12px;display:flex;flex-direction:column;gap:6px;
}
.lat-card .lh{display:flex;align-items:center;gap:8px}
.lat-card .lico{
  width:28px;height:28px;border-radius:8px;display:flex;align-items:center;justify-content:center;
  font-size:14px;font-weight:700;color:#fff;flex-shrink:0;
}
.lat-card .lname{font-size:13px;font-weight:700;color:var(--tx)}
.lat-card .lreg{
  font-size:10px;font-weight:700;padding:2px 6px;border-radius:999px;display:inline-block;
}
.lat-card .lreg[data-r="国内"]{background:rgba(34,197,94,.15);color:#16a34a}
.lat-card .lreg[data-r="国际"]{background:rgba(59,130,246,.15);color:#2563eb}
.lat-card .lms{
  font-size:18px;font-weight:800;font-variant-numeric:tabular-nums;line-height:1.2;
}
.lat-card .lms .unit{font-size:11px;font-weight:600;color:var(--mut);margin-left:2px}
.lat-card .lms.good{color:#22c55e}
.lat-card .lms.mid{color:#f59e0b}
.lat-card .lms.bad{color:#ef4444}
.lat-card .lms.wait{color:var(--mut);font-size:13px;font-weight:600}
.lat-card .lbar{height:4px;background:var(--soft);border-radius:2px;overflow:hidden}
.lat-card .lbar>i{display:block;height:100%;width:0;border-radius:2px;transition:width .35s}
.lat-card .lbar>i.good{background:#22c55e}
.lat-card .lbar>i.mid{background:#f59e0b}
.lat-card .lbar>i.bad{background:#ef4444}
.lat-card .lbar>i.wait{background:#94a3b8;width:30%;animation:netpulse 1s infinite}

/* IP detail modal */
.ip-modal-mask{
  position:fixed;inset:0;background:rgba(15,23,42,.55);z-index:9999;
  display:flex;align-items:center;justify-content:center;padding:16px;
  backdrop-filter:blur(4px);
}
.ip-modal{
  width:min(520px,100%);max-height:min(86vh,720px);overflow:auto;
  background:var(--card);color:var(--tx);border-radius:16px;border:1px solid var(--line);
  box-shadow:0 24px 60px rgba(0,0,0,.35);
}
.ip-modal-hd{
  display:flex;align-items:center;justify-content:space-between;gap:10px;
  padding:14px 16px;border-bottom:1px solid var(--line);position:sticky;top:0;
  background:var(--card);z-index:1;
}
.ip-modal-hd h3{margin:0;font-size:15px;font-weight:700}
.ip-modal-hd .src{font-size:11px;color:var(--mut);font-weight:500}
.ip-modal-x{
  border:none;background:var(--soft);width:32px;height:32px;border-radius:50%;
  cursor:pointer;font-size:18px;line-height:1;color:var(--tx);
}
.ip-modal-bd{padding:14px 16px 18px}
.ip-row{
  display:flex;justify-content:space-between;gap:12px;padding:9px 0;
  border-bottom:1px dashed var(--line);font-size:13px;
}
.ip-row:last-child{border-bottom:none}
.ip-row .k{color:var(--mut);flex-shrink:0}
.ip-row .v{text-align:right;font-weight:600;word-break:break-all}
.ip-badge{
  display:inline-block;padding:2px 8px;border-radius:999px;font-size:11px;font-weight:700;
}
.ip-badge.clean{background:rgba(34,197,94,.15);color:#16a34a}
.ip-badge.warn{background:rgba(245,158,11,.15);color:#d97706}
.ip-badge.danger{background:rgba(239,68,68,.15);color:#dc2626}
.ip-badge.info{background:rgba(59,130,246,.15);color:#2563eb}
@media(max-width:900px){
  .net-cards,.latency-grid{grid-template-columns:repeat(2,minmax(0,1fr))}
}
@media(max-width:480px){
  .net-cards,.latency-grid{grid-template-columns:1fr}
}

/* ===== 当前网络信息（edgetunnel 同款折叠延迟） ===== */
:root{
  --latency-49:#22c55e;
  --latency-149:#84cc16;
  --latency-299:#eab308;
  --latency-999:#f97316;
  --latency-1000:#ef4444;
  --destructive:#ef4444;
}
#net-info-box{
  margin:0 0 18px;padding:0;border-radius:var(--rad);
  background:var(--card);border:1px solid var(--line);
  box-shadow:0 6px 20px rgba(20,30,65,.06);overflow:hidden;
}
#net-info-box .net-title{
  margin:0;padding:14px 16px;font-size:15px;font-weight:700;
  display:flex;align-items:center;justify-content:space-between;gap:10px;
  cursor:pointer;user-select:none;
}
#net-info-box .net-title:hover{background:var(--soft)}
#net-info-box .collapse-icon{
  width:20px;height:20px;fill:var(--mut);flex-shrink:0;
  transition:transform .2s ease;transform:rotate(90deg);
}
#net-info-box.is-expanded .collapse-icon{transform:rotate(0deg)}
#net-info-box .net-body{padding:0 16px 14px}
.net-cards{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px}
.net-card{
  background:var(--field);border:1px solid var(--line);border-radius:12px;
  padding:12px;min-height:118px;
}
.net-card .ntitle{display:flex;align-items:center;gap:8px;margin-bottom:8px}
.net-card .dot{width:9px;height:9px;border-radius:50%;background:#94a3b8;flex-shrink:0}
.net-card .dot.ok{background:#22c55e;box-shadow:0 0 0 3px rgba(34,197,94,.2)}
.net-card .dot.err{background:#ef4444;box-shadow:0 0 0 3px rgba(239,68,68,.18)}
.net-card .dot.loading{background:#f59e0b;animation:netpulse 1s infinite}
@keyframes netpulse{50%{opacity:.35}}
.net-card .nmain{font-size:13px;font-weight:700;color:var(--tx);line-height:1.2}
.net-card .nsub{font-size:11px;color:var(--mut)}
.net-card .nip{
  font-size:13px;font-weight:700;color:#22c55e;word-break:break-all;line-height:1.35;
  margin-bottom:4px;cursor:pointer;text-decoration:underline dotted rgba(34,197,94,.5);
  font-variant-numeric:tabular-nums;
}
.net-card .nip:hover{color:#16a34a}
.net-card .nip.loading{color:#f59e0b;cursor:default;text-decoration:none}
.net-card .nip.err{color:#ef4444;cursor:default;text-decoration:none}
.net-card .nloc{font-size:12px;color:var(--tx);margin-bottom:4px;min-height:1.2em}
.net-card .ntip{font-size:11px;color:var(--mut);line-height:1.4}
#net-info-box .net-hint{margin-top:10px;font-size:12px;color:var(--mut);line-height:1.55}

/* latency collapsed by default */
#network-module-content{display:none;margin-top:12px}
.latency-cards{
  display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;
}
.latency-card{
  background:var(--field);border:1px solid var(--line);border-radius:12px;padding:12px;
}
.latency-card-header{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:8px}
.latency-card-info{display:flex;align-items:center;gap:8px;min-width:0}
.latency-card-icon-wrapper{
  width:28px;height:28px;border-radius:8px;display:flex;align-items:center;justify-content:center;
  overflow:hidden;flex-shrink:0;background:var(--soft);
}
.latency-card-icon-wrapper svg{width:18px;height:18px}
.latency-card-text{display:flex;flex-direction:column;min-width:0}
.latency-card-name{font-size:13px;font-weight:700;color:var(--tx);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.latency-card-region{
  font-size:10px;font-weight:700;padding:1px 6px;border-radius:999px;width:fit-content;margin-top:2px;
}
.latency-card-region[data-region="国内"]{background:rgba(34,197,94,.15);color:#16a34a}
.latency-card-region[data-region="国际"]{background:rgba(59,130,246,.15);color:#2563eb}
.latency-status{font-size:16px;font-weight:800;font-variant-numeric:tabular-nums;color:#f6821f;white-space:nowrap}
.latency-status .unit{font-size:11px;font-weight:600;margin-left:1px;opacity:.85}
.latency-graph-container{position:relative;height:48px;background:rgba(0,0,0,.03);border-radius:8px;overflow:hidden}
html[data-theme=dark] .latency-graph-container{background:rgba(255,255,255,.04)}
.latency-ecg{width:100%;height:100%;display:block}
.ecg-path-bg{stroke:var(--line);stroke-width:1;fill:none}
.ecg-path{stroke:#22c55e;stroke-width:2;fill:none;stroke-linecap:round;stroke-linejoin:round}
.ecg-cursor{fill:#22c55e}

/* IP modal kept if already present */
@media(max-width:900px){
  .net-cards{grid-template-columns:repeat(2,minmax(0,1fr))}
  .latency-cards{grid-template-columns:1fr}
}
@media(max-width:480px){
  .net-cards{grid-template-columns:1fr}
}

/* ===== edgetunnel 同款：当前网络信息 + 折叠延迟 ===== */
:root{
  --latency-49:#4CAF50;
  --latency-149:#83DA00;
  --latency-299:#f58722;
  --latency-999:#ff404a;
  --latency-1000:#c40003;
  --destructive:#ff404a;
}
#net-info-box{
  margin:0 0 18px;border-radius:var(--rad);
  background:var(--card);border:1px solid var(--line);
  box-shadow:0 6px 20px rgba(20,30,65,.06);overflow:hidden;
}
#net-info-box .module-title{
  margin:0;padding:14px 16px;font-size:15px;font-weight:700;
  display:flex;align-items:center;justify-content:space-between;gap:10px;
  cursor:pointer;user-select:none;color:var(--tx);
}
#net-info-box .module-title:hover{background:var(--soft)}
#net-info-box .collapse-icon{
  width:22px;height:22px;fill:var(--mut);flex-shrink:0;
  transition:transform .25s ease;transform:rotate(90deg);
}
#net-info-box.is-expanded .collapse-icon{transform:rotate(0deg)}
#net-info-box .module-content{padding:0 16px 16px}
.network-cards-container{
  display:grid;grid-template-columns:repeat(4,minmax(0,1fr));
  gap:16px;margin-bottom:10px;margin-top:2px;
}
.network-card{
  background:var(--field);border:1px solid var(--line);border-radius:12px;padding:14px 12px;
}
.network-card-title{display:flex;align-items:center;gap:10px;font-size:15px;font-weight:600;margin-bottom:12px;color:var(--tx)}
.title-text{display:flex;flex-direction:column;min-width:0}
.title-main{font-size:14px;font-weight:700;line-height:1.2}
.title-subtitle{font-size:11px;color:var(--mut);margin-top:2px}
.status-indicator{display:inline-block;width:10px;height:10px;border-radius:50%;flex-shrink:0}
.status-indicator.status-loading{background:#ffa500;box-shadow:0 0 5px #ffa500;animation:netpulse 1.5s infinite}
.status-indicator.status-success{background:#4caf50;box-shadow:0 0 5px #4caf50}
.status-indicator.status-error{background:#f44336;box-shadow:0 0 5px #f44336}
@keyframes netpulse{0%,100%{opacity:1}50%{opacity:.5}}
.network-info-content{padding-left:20px}
.ip-text{
  font-size:16px;font-weight:700;color:var(--tx);word-break:break-all;margin-bottom:8px;
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis;display:block;transition:color .2s;
}
.ip-text.clickable{cursor:pointer;color:#2196F3}
.ip-text.clickable:hover{color:#1976D2}
html[data-theme=dark] .ip-text.clickable{color:#64b5f6}
html[data-theme=dark] .ip-text.clickable:hover{color:#90caf9}
.location-text,.country-text{font-size:12px;color:var(--mut);margin-bottom:6px;min-height:1.2em}
.network-tip{font-size:11px;color:var(--mut);line-height:1.4}
.net-hint-small{font-size:12px;color:#9ca3af;margin-top:6px;display:block;line-height:1.55}
html[data-theme=dark] .net-hint-small{color:#9ca3af}

#network-module-content{display:none;overflow:hidden}
.latency-cards{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px;margin-top:8px}
.latency-card{background:var(--field);border:1px solid var(--line);border-radius:12px;padding:12px}
.latency-card-header{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:8px}
.latency-card-info{display:flex;align-items:center;gap:10px;min-width:0}
.latency-card-icon-wrapper{
  width:32px;height:32px;border-radius:8px;display:flex;align-items:center;justify-content:center;
  overflow:hidden;flex-shrink:0;background:var(--soft);
}
.latency-card-icon-wrapper svg{width:20px;height:20px}
.latency-card-text{display:flex;flex-direction:column;min-width:0}
.latency-card-name{font-size:13px;font-weight:700;color:var(--tx)}
.latency-card-region{font-size:10px;font-weight:700;padding:1px 6px;border-radius:999px;width:fit-content;margin-top:2px}
.latency-card-region[data-region="国内"]{background:rgba(76,175,80,.15);color:#2e7d32}
.latency-card-region[data-region="国际"]{background:rgba(33,150,243,.15);color:#1565c0}
.latency-status{font-size:16px;font-weight:800;font-variant-numeric:tabular-nums;color:#f6821f;white-space:nowrap}
.latency-status .unit{font-size:11px;font-weight:600;margin-left:1px;opacity:.85}
.latency-graph-container{position:relative;height:52px;border-radius:8px;overflow:hidden;background:rgba(0,0,0,.03)}
html[data-theme=dark] .latency-graph-container{background:rgba(255,255,255,.04)}
.latency-ecg{width:100%;height:100%;display:block}
.ecg-path-bg{stroke:var(--line);stroke-width:1;fill:none}
.ecg-path{stroke:#4CAF50;stroke-width:2;fill:none;stroke-linecap:round;stroke-linejoin:round}
.ecg-cursor{fill:#4CAF50}

/* IP detail modal */
.ip-modal-mask{position:fixed;inset:0;background:rgba(15,23,42,.55);z-index:9999;display:flex;align-items:center;justify-content:center;padding:16px;backdrop-filter:blur(4px)}
.ip-modal{width:min(560px,100%);max-height:min(86vh,740px);overflow:auto;background:var(--card);color:var(--tx);border-radius:16px;border:1px solid var(--line);box-shadow:0 24px 60px rgba(0,0,0,.35)}
.ip-modal-hd{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:14px 16px;border-bottom:1px solid var(--line);position:sticky;top:0;background:var(--card);z-index:1}
.ip-modal-hd h3{margin:0;font-size:15px;font-weight:700}
.ip-modal-hd .src{font-size:11px;color:var(--mut);font-weight:500}
.ip-modal-x{border:none;background:var(--soft);width:32px;height:32px;border-radius:50%;cursor:pointer;font-size:18px;line-height:1;color:var(--tx)}
.ip-modal-bd{padding:14px 16px 18px}
.ip-row{display:flex;justify-content:space-between;gap:12px;padding:9px 0;border-bottom:1px dashed var(--line);font-size:13px}
.ip-row:last-child{border-bottom:none}
.ip-row .k{color:var(--mut);flex-shrink:0}
.ip-row .v{text-align:right;font-weight:600;word-break:break-all}
.ip-badge{display:inline-block;padding:2px 8px;border-radius:999px;font-size:11px;font-weight:700}
.ip-badge.clean{background:rgba(76,175,80,.15);color:#2e7d32}
.ip-badge.warn{background:rgba(245,158,11,.15);color:#d97706}
.ip-badge.danger{background:rgba(244,67,54,.15);color:#c62828}
.ip-badge.info{background:rgba(33,150,243,.15);color:#1565c0}
@media(max-width:900px){
  .network-cards-container{grid-template-columns:repeat(2,minmax(0,1fr))}
  .latency-cards{grid-template-columns:1fr}
}
@media(max-width:480px){
  .network-cards-container{grid-template-columns:1fr}
}

/* IP detail map */
.ip-detail-map-container{
  height:280px;width:100%;position:relative;
  background:var(--soft);border-bottom:1px solid var(--line);
}
#ip-detail-map{width:100%;height:100%;z-index:1}
.ip-detail-popup-content{font-size:12px;line-height:1.5;min-width:140px}
.ip-detail-popup-city{font-weight:700;font-size:13px;margin-bottom:6px}
.ip-detail-popup-item{display:flex;gap:6px;margin:2px 0}
.ip-detail-popup-label{color:#888;flex-shrink:0}
.ip-detail-popup-value{font-weight:600;word-break:break-all}
.leaflet-popup-content-wrapper{
  border-radius:10px;box-shadow:0 8px 24px rgba(0,0,0,.18);
}
html[data-theme=dark] .leaflet-popup-content-wrapper{
  background:#1e293b;color:#e2e8f0;
}
html[data-theme=dark] .leaflet-popup-tip{background:#1e293b}
html[data-theme=dark] .leaflet-tile-pane{filter:brightness(.85) contrast(1.05)}
.ip-modal{padding:0;overflow:hidden;display:flex;flex-direction:column}
.ip-modal-bd{padding:14px 16px 18px;overflow:auto}

/* edgetunnel theme vars + 墙外字幕 */
:root{
  --bg-primary:#ffffff;
  --bg-secondary:rgba(255,255,255,0.95);
  --text-primary:#1f2937;
  --text-secondary:#666;
  --border-color:#e5e7eb;
  --border-light:rgba(255,255,255,0.1);
  --input-bg:#f3f4f6;
  --input-border:#e5e7eb;
  --overlay-bg:rgba(255,255,255,0.7);
  --blur-overlay:rgba(0,0,0,0.3);
  --admin-bg-base:#f8fafc;
  --latency-49:#4CAF50;
  --latency-149:#83DA00;
  --latency-299:#f58722;
  --latency-999:#ff404a;
  --latency-1000:#c40003;
  --destructive:#ff404a;
}
html[data-theme=dark], html.dark-mode{
  --bg-primary:#1a1a1a;
  --bg-secondary:#0f0d0a;
  --text-primary:#e5e5e5;
  --text-secondary:#a0a0a0;
  --border-color:#333333;
  --border-light:rgba(255,255,255,0.1);
  --input-bg:#2a2a2a;
  --input-border:#444444;
  --overlay-bg:rgba(32,32,32,0.7);
  --blur-overlay:rgba(0,0,0,0.8);
  --admin-bg-base:#070b12;
}
.cf-subtitle-sep{color:var(--text-secondary,#666)}
.cf-subtitle-switch{cursor:pointer;text-decoration:underline;text-underline-offset:2px;opacity:.75}
.cf-subtitle-switch:hover{opacity:1}
.tw-subtitle-google{color:#3A7AE7;font-weight:700}
.tw-subtitle-twitter{color:#04ABE7;font-weight:700}
.title-subtitle .tw-subtitle-google,
.title-subtitle .tw-subtitle-twitter{font-size:11px}

.ip-detail-modal {
			position: fixed;
			top: 0;
			left: 0;
			right: 0;
			bottom: 0;
			background: rgba(0, 0, 0, 0.4);
			-webkit-backdrop-filter: blur(8px);
			backdrop-filter: blur(8px);
			display: flex;
			align-items: center;
			justify-content: center;
			z-index: 2000000001;
			padding: 20px;
			animation: fadeIn 0.3s ease;
		}

		.ip-detail-content {
			background: rgba(255, 255, 255, 0.9);
			-webkit-backdrop-filter: blur(20px);
			backdrop-filter: blur(20px);
			border: 1px solid rgba(255, 255, 255, 0.3);
			border-radius: 24px;
			max-width: 900px;
			width: 100%;
			max-height: 90vh;
			overflow-y: auto;
			padding: 0;
			box-shadow: 0 40px 100px rgba(0, 0, 0, 0.2);
			position: relative;
			animation: slideUp 0.4s cubic-bezier(0.16, 1, 0.3, 1);
			display: flex;
			flex-direction: column;
		}

		html.dark-mode .ip-detail-content {
			background: rgba(30, 30, 35, 0.85);
			border-color: rgba(255, 255, 255, 0.05);
			box-shadow: 0 40px 100px rgba(0, 0, 0, 0.5);
			color: #f0f0f0;
		}

		/* Modal Header */
		.ip-detail-header {
			padding: 24px 30px;
			border-bottom: 1px solid rgba(0, 0, 0, 0.05);
			display: flex;
			justify-content: space-between;
			align-items: center;
			position: sticky;
			top: 0;
			background: inherit;
			z-index: 10;
		}

		html.dark-mode .ip-detail-header {
			border-bottom-color: rgba(255, 255, 255, 0.05);
		}

		.ip-detail-title {
			font-size: 20px;
			font-weight: 800;
			margin: 0;
			background: linear-gradient(135deg, #f6821f 0%, #faab41 100%);
			-webkit-background-clip: text;
			background-clip: text;
			-webkit-text-fill-color: transparent;
			font-family: 'Orbitron', sans-serif;
			display: flex;
			align-items: baseline;
			gap: 8px;
		}

		.ip-detail-source-tag {
			font-size: 10px;
			font-weight: 500;
			color: #6b7280;
			-webkit-text-fill-color: #6b7280;
			opacity: 0.6;
			font-family: 'Inter', sans-serif;
			text-transform: none;
			letter-spacing: normal;
		}

		html.dark-mode .ip-detail-source-tag {
			color: #9ca3af;
			-webkit-text-fill-color: #9ca3af;
		}

		.ip-detail-close {
			width: 36px;
			height: 36px;
			border-radius: 50%;
			background: rgba(0, 0, 0, 0.05);
			border: none;
			cursor: pointer;
			display: flex;
			align-items: center;
			justify-content: center;
			font-size: 20px;
			color: #666;
			transition: all 0.2s;
		}

		html.dark-mode .ip-detail-close {
			background: rgba(255, 255, 255, 0.05);
			color: #aaa;
		}

		.ip-detail-close:hover {
			background: #ef4444;
			color: white;
			transform: rotate(90deg);
		}

		/* Modal Body Layout */
		.ip-detail-body {
			padding: 0;
			display: flex;
			flex-direction: column;
		}

		/* Map Section */
		.ip-detail-map-container {
			height: 350px;
			width: 100%;
			position: relative;
			background: #f0f0f0;
			border-bottom: 1px solid rgba(0, 0, 0, 0.05);
		}

		html.dark-mode .ip-detail-map-container {
			background: #1a1a1a;
			border-bottom-color: rgba(255, 255, 255, 0.05);
		}

		#ip-detail-map {
			width: 100%;
			height: 100%;
			z-index: 1;
		}

		/* Data Grid Section */
		.ip-detail-grid-container {
			padding: 30px;
			display: grid;
			grid-template-columns: 1fr 1fr;
			gap: 24px;
			align-items: start;
		}

		.ip-detail-left-col,
		.ip-detail-right-col {
			display: flex;
			flex-direction: column;
			gap: 24px;
		}

		.ip-detail-card {
			background: rgba(0, 0, 0, 0.02);
			border-radius: 16px;
			padding: 20px;
			border: 1px solid rgba(0, 0, 0, 0.03);
			transition: transform 0.2s, box-shadow 0.2s;
		}

		html.dark-mode .ip-detail-card {
			background: rgba(255, 255, 255, 0.02);
			border-color: rgba(255, 255, 255, 0.03);
		}

		.ip-detail-card:hover {
			transform: translateY(-2px);
			box-shadow: 0 10px 20px rgba(0, 0, 0, 0.05);
		}

		.ip-detail-section-title {
			font-size: 14px;
			font-weight: 700;
			color: #f6821f;
			text-transform: uppercase;
			letter-spacing: 1px;
			margin-bottom: 16px;
			display: flex;
			align-items: center;
			gap: 8px;
		}

		.ip-detail-item {
			display: flex;
			justify-content: space-between;
			align-items: center;
			padding: 8px 0;
			font-size: 13px;
		}

		.ip-detail-item:not(:last-child) {
			border-bottom: 1px dashed rgba(0, 0, 0, 0.05);
		}

		html.dark-mode .ip-detail-item:not(:last-child) {
			border-bottom-color: rgba(255, 255, 255, 0.05);
		}

		.ip-detail-label {
			color: #6b7280;
			font-weight: 500;
		}

		html.dark-mode .ip-detail-label {
			color: #9ca3af;
		}

		.ip-detail-value {
			font-family: 'Fira Code', monospace;
			font-weight: 600;
			color: #1f2937;
			text-align: right;
		}

		html.dark-mode .ip-detail-value {
			color: #e5e7eb;
		}

		/* Status & Badges - More vibrant for risk assessment */
		.ip-detail-badge {
			padding: 4px 12px;
			border-radius: 8px;
			font-size: 11px;
			font-weight: 800;
			text-transform: uppercase;
			box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
		}

		.badge-critical {
			background: #ef4444;
			color: white;
		}

		.badge-high {
			background: #f97316;
			color: white;
		}

		.badge-elevated {
			background: #eab308;
			color: white;
		}

		.badge-low {
			background: #ebfef2;
			color: #059669;
			border: 1px solid #10b981;
		}

		.badge-verylow {
			background: #10b981;
			color: white;
		}

		.badge-success {
			background: #10b981;
			color: white;
		}

		.badge-info {
			background: #3b82f6;
			color: white;
		}

		.badge-warning {
			background: #f59e0b;
			color: white;
		}

		.badge-danger {
			background: #ef4444;
			color: white;
		}

		.success-text {
			color: #10b981;
			font-weight: 700;
		}

		.warning-text {
			color: #f59e0b;
			font-weight: 700;
		}

		.danger-text {
			color: #ef4444;
			font-weight: 700;
		}

		/* Map Popup Styling */
		.leaflet-popup-content-wrapper {
			background: rgba(255, 255, 255, 0.8) !important;
			-webkit-backdrop-filter: blur(10px);
			backdrop-filter: blur(10px);
			border-radius: 12px !important;
			border: 1px solid rgba(255, 255, 255, 0.3);
			color: #374151 !important;
			box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
		}

		html.dark-mode .leaflet-popup-content-wrapper {
			background: rgba(31, 41, 55, 0.8) !important;
			border-color: rgba(255, 255, 255, 0.1);
			color: #e5e7eb !important;
		}

		.leaflet-popup-tip {
			background: rgba(255, 255, 255, 0.8) !important;
			-webkit-backdrop-filter: blur(10px);
			backdrop-filter: blur(10px);
		}

		html.dark-mode .leaflet-popup-tip {
			background: rgba(31, 41, 55, 0.8) !important;
		}

		.ip-detail-popup-content {
			font-family: 'Inter', sans-serif;
			padding: 2px;
			max-width: 180px;
		}

		.ip-detail-popup-city {
			font-size: 14px;
			font-weight: 800;
			margin-bottom: 4px;
			display: flex;
			align-items: center;
			gap: 4px;
			color: #f6821f;
		}

		.ip-detail-popup-item {
			font-size: 11px;
			margin-bottom: 2px;
			display: flex;
			gap: 4px;
			line-height: 1.2;
		}

		.ip-detail-popup-label {
			opacity: 0.7;
			min-width: 45px;
		}

		.ip-detail-popup-value {
			font-weight: 600;
			word-break: break-all;
		}

		.ip-detail-security-grid {
			display: grid;
			grid-template-columns: 1fr 1fr;
			gap: 0 24px;
		}

		/* Mobile Adaptation */
		@media (max-width: 640px) {
			.ip-detail-modal {
				padding: 10px;
				/* 确保模态框充分利用屏幕空间 */
				align-items: flex-end;
			}

			.ip-detail-content {
				/* 使用 dvh (动态视口高度) 或回退到 vh，以适应移动浏览器地址栏的动态变化 */
				max-height: calc(100dvh - 20px);
				max-height: calc(100vh - 20px);
				/* 从底部弹出的样式 */
				border-radius: 20px 20px 0 0;
				margin-top: auto;
				/* 确保内容可滚动 */
				overflow-y: auto;
				/* 为带有刘海屏的设备添加安全区域内边距 */
				padding-bottom: env(safe-area-inset-bottom, 0px);
			}

			.ip-detail-grid-container {
				padding: 20px;
				/* 大幅增加底部内边距 */
				padding-bottom: calc(60px + env(safe-area-inset-bottom, 20px));
				grid-template-columns: 1fr;
			}

			.ip-detail-security-grid {
				grid-template-columns: 1fr 1fr;
				gap: 0 16px;
			}

			.ip-detail-map-container {
				height: 200px;
				/* 在移动设备上减小地图高度以留出更多空间给内容 */
			}

			.ip-detail-popup-content {
				max-width: 150px;
			}

			.ip-detail-popup-city {
				font-size: 13px;
			}

			.ip-detail-popup-item {
				font-size: 10px;
			}

			.ip-detail-header {
				padding: 16px 20px;
				/* 粘性头部，防止滚动时遮挡内容 */
				position: sticky;
				top: 0;
				z-index: 10;
				background: inherit;
			}

			/* 在移动设备上为 body 添加额外的下内边距，确保底部内容可见 */
			.ip-detail-body {
				padding-bottom: 60px;
			}
		}

		.badge-elevated {
			background-color: #fff9c4;
			color: #f57f17;
		}

		.badge-low {
			background-color: #c8e6c9;
			color: #1b5e20;
		}

		.badge-verylow {
			background-color: #a5d6a7;
			color: #00320c;
		}

		html.dark-mode .badge-success {
			background-color: #1b5e20;
			color: #81c784;
		}

		html.dark-mode .badge-info {
			background-color: #0d47a1;
			color: #64b5f6;
		}

		html.dark-mode .badge-warning {
			background-color: #e65100;
			color: #ffb74d;
		}

		html.dark-mode .badge-danger {
			background-color: #b71c1c;
			color: #ef5350;
		}

		/* IP 类型样式 */
		.ip-type-residential {
			color: #2e7d32;
			font-weight: bold;
		}

		.ip-type-business {
			color: #f59e0b;
			font-weight: bold;
		}

		.ip-type-hosting {
			font-weight: bold;
		}

		.ip-type-unknown {
			font-weight: bold;
		}

		html.dark-mode .ip-type-residential {
			color: #81c784;
			font-weight: bold;
		}

		html.dark-mode .ip-type-business {
			color: #fbbf24;
			font-weight: bold;
		}

		html.dark-mode .ip-type-hosting {
			font-weight: bold;
		}

		html.dark-mode .ip-type-unknown {
			font-weight: bold;
		}

		/* 风险等级文本样式 */
		.success-text {
			color: #2e7d32;
		}

		.warning-text {
			color: #e65100;
		}

		.danger-text {
			color: #c62828;
		}

		html.dark-mode .success-text {
			color: #81c784;
		}

		html.dark-mode .warning-text {
			color: #ffb74d;
		}

		html.dark-mode .danger-text {
			color: #ef5350;
		}

		/* 评分算法说明气泡 */
		.score-help-icon {
			display: inline-block;
			width: 18px;
			height: 18px;
			line-height: 18px;
			text-align: center;
			background-color: #2196F3;
			color: white;
			border-radius: 50%;
			cursor: pointer;
			font-size: 12px;
			font-weight: bold;
			transition: background-color 0.2s;
		}

		.score-help-icon:hover {
			background-color: #1976D2;
		}

		html.dark-mode .score-help-icon {
			background-color: #1976D2;
		}

		html.dark-mode .score-help-icon:hover {
			background-color: #64B5F6;
		}

		.score-tooltip {
			display: none;
			position: fixed;
			background: white;
			border: 1px solid #e0e0e0;
			border-radius: 8px;
			padding: 15px;
			min-width: 300px;
			max-width: 350px;
			box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
			z-index: 1001;
			font-size: 13px;
			line-height: 1.6;
		}

		/* 气泡位置调整类 */
		.score-tooltip.tooltip-bottom {
			display: none;
		}

		.score-tooltip.tooltip-left {
			display: none;
		}

		.score-tooltip.tooltip-right {
			display: none;
		}

		html.dark-mode .score-tooltip {
			background: #3c3c3c;
			border-color: #444;
			color: #e0e0e0;
		}

		.score-tooltip.show {
			display: block;
		}

		#transportGrpcModal {
			z-index: 2100000000;
		}

		#transportGrpcModal .modal {
			max-width: 500px;
			z-index: 2100000001;
		}

		#ssTLSDisableModal {
			z-index: 2100000000;
		}

		#ssTLSDisableModal .modal {
			max-width: 540px;
			z-index: 2100000001;
		}

		.grpc-modal-path {
			margin: 0 0 16px 0;
			padding: 12px;
			border-radius: 8px;
			background: #fff5f5;
			border: 1px solid #ffcdd2;
			text-align: left;
			font-size: 13px;
			font-family: Consolas, Monaco, 'Courier New', monospace;
			line-height: 1.7;
			color: #b71c1c;
			display: flex;
			align-items: center;
			gap: 8px;
		}

		html.dark-mode .grpc-modal-path {
			background: #4a2424;
			border-color: #7f1d1d;
			color: #ffb4ae;
		}

		.grpc-modal-path-icon {
			width: 16px;
			height: 16px;
			flex-shrink: 0;
			fill: currentColor;
		}

		.grpc-modal-confirm-btn {
			flex: 1;
			background: linear-gradient(135deg, #22c55e 0%, #16a34a 100%);
			color: #fff;
			box-shadow: 0 4px 12px rgba(22, 163, 74, 0.35);
		}

		.grpc-modal-confirm-btn:hover

/* ===== brand logo: fixed size + circle (force) ===== */
header a.brand{
  display:inline-flex !important;
  align-items:center !important;
  gap:10px !important;
  text-decoration:none !important;
  color:inherit !important;
  flex-shrink:0 !important;
  margin-right:8px !important;
}
header a.brand .brand-logo,
header img.brand-logo{
  width:56px !important;
  height:56px !important;
  min-width:56px !important;
  min-height:56px !important;
  max-width:56px !important;
  max-height:56px !important;
  object-fit:contain !important;
  object-position:center !important;
  border-radius:0 !important;
  -webkit-border-radius:0 !important;
  display:block !important;
  overflow:visible !important;
  box-shadow:none !important;
  border:none !important;
  flex:0 0 56px !important;
  padding:0 !important;
  margin:0 !important;
}
header a.brand .brand-text{
  display:inline !important;
  visibility:visible !important;
  opacity:1 !important;
  font-size:19px !important;
  font-weight:800 !important;
  letter-spacing:.02em !important;
  color:#93c5fd !important;
  white-space:nowrap !important;
  flex-shrink:0 !important;
  line-height:1 !important;
}
html[data-theme=light] header a.brand .brand-text{color:#1c2440 !important}
@media(max-width:520px){
  header a.brand .brand-text{display:inline !important}
  header a.brand .brand-logo,
  header img.brand-logo{
    width:44px !important;height:44px !important;
    min-width:44px !important;min-height:44px !important;
    max-width:44px !important;max-height:44px !important;
    flex:0 0 44px !important;
    border-radius:50% !important;
  }
}

/* ===== panel top bar layout fix (highest priority) ===== */
body > header{
  position: relative !important;
  top: auto !important;
  display: flex !important;
  flex-direction: row !important;
  flex-wrap: wrap !important;
  align-items: center !important;
  justify-content: flex-start !important;
  gap: 10px 12px !important;
  padding: 12px 18px !important;
  margin: 0 !important;
  min-height: 72px !important;
  box-sizing: border-box !important;
  width: 100% !important;
  z-index: 20 !important;
  background: #202844 !important;
  border-bottom: none !important;
}
html[data-theme=dark] body > header,
html.dark-mode body > header{
  background: #101529 !important;
}
body > header > a.brand{
  order: 0 !important;
  display: inline-flex !important;
  flex-direction: row !important;
  align-items: center !important;
  justify-content: flex-start !important;
  gap: 10px !important;
  margin: 0 12px 0 0 !important;
  padding: 0 !important;
  flex: 0 0 auto !important;
  max-width: none !important;
  position: relative !important;
  left: auto !important;
  right: auto !important;
  top: auto !important;
  float: none !important;
}
body > header > a.brand .brand-logo,
body > header img.brand-logo{
  width: 56px !important;
  height: 56px !important;
  border-radius: 50% !important;
  object-fit: cover !important;
  display: block !important;
  flex: 0 0 56px !important;
  margin: 0 !important;
}
body > header > a.brand .brand-text{
  display: inline !important;
  visibility: visible !important;
  position: static !important;
  font-size: 19px !important;
  font-weight: 800 !important;
  color: #93c5fd !important;
  margin: 0 !important;
  line-height: 1 !important;
}
html[data-theme=light] body > header > a.brand .brand-text{
  color: #1c2440 !important;
}
body > header > .tag{
  order: 1 !important;
  position: static !important;
  margin: 0 !important;
}
body > header > .themes{
  order: 2 !important;
  margin-left: auto !important;
  position: static !important;
  display: flex !important;
  align-items: center !important;
}

body > header,
header{
  border-bottom: none !important;
  border-image: none !important;
  box-shadow: none !important;
}

/* remove underline under CFLYHL */
body > header > a.brand,
body > header > a.brand:hover,
body > header > a.brand:focus,
body > header > a.brand:active,
header a.brand,
header a.brand:hover,
header a.brand:focus,
header a.brand:active{
  text-decoration: none !important;
  border-bottom: none !important;
  box-shadow: none !important;
  background-image: none !important;
}
body > header > a.brand .brand-text,
header a.brand .brand-text{
  text-decoration: none !important;
  border-bottom: none !important;
  box-shadow: none !important;
}



/* custom v2.1.7 full: sticky header + rainbow text + hue 4s */
@keyframes cflyhlHue {
  from { filter: hue-rotate(0deg) saturate(1.25); }
  to   { filter: hue-rotate(360deg) saturate(1.25); }
}
header, body > header {
  position: sticky !important;
  top: 0 !important;
  z-index: 1000 !important;
}
header img.brand-logo,
header a.brand .brand-logo {
  animation: cflyhlHue 4s linear infinite !important;
}
/* rainbow text on static light/white-ish labels & titles */
header a.brand .brand-text,
body > header > a.brand .brand-text,
header .tag,
header .th,
header h1,
.tab,
.card .k,
.card .v,
.card:first-child .k,
.card:first-child .v,
h2, h3, h4,
.hint,
.box > h2,
.panel h2,
.panel h3,
.module-title,
.network-card-title,
.network-tip,
.country-text,
.location-text,
.ip-text,
.latency-card-name,
.latency-card-region,
.latency-card-text,
.ip-detail-title,
.ip-detail-section-title,
.ip-detail-label,
.ip-detail-value,
.ip-detail-popup-label,
.ip-detail-popup-value,
.ip-detail-popup-city,
label,
.lnk > .k,
.foot,
.badge,
.field > span,
.row > span:first-child,
.global-status,
summary {
  background-image: linear-gradient(90deg, #ff0000, #ff7f00, #ffff00, #00ff00, #00bfff, #8b00ff, #ff1493) !important;
  -webkit-background-clip: text !important;
  background-clip: text !important;
  -webkit-text-fill-color: transparent !important;
  color: transparent !important;
  animation: cflyhlHue 4s linear infinite !important;
}
/* light mode header */
html[data-theme=light] header,
html[data-theme=light] body > header {
  background: #e9edf4 !important;
  color: #1c2440 !important;
  border-bottom: 1px solid #d6dce9 !important;
}
html[data-theme=light] header .tag { border-left-color: #c5cddc !important; }
html[data-theme=light] header .th { border-color: #c5cddc !important; }
html[data-theme=light] .theme-toggle { border-color: #c5cddc !important; color: #1c2440 !important; }

/* copy buttons: rainbow text + hue */
button.cp,
.cp {
  display: inline-flex !important;
  align-items: center !important;
  justify-content: center !important;
  min-width: 56px !important;
  padding: 8px 16px !important;
  border-radius: 999px !important;
  cursor: pointer !important;
  font-weight: 700 !important;
  opacity: 1 !important;
  visibility: visible !important;
  position: relative !important;
  isolation: isolate !important;
  border: none !important;
  border-image: none !important;
  background-color: transparent !important;
  background-image: linear-gradient(90deg, #ff0000, #ff7f00, #ffff00, #00ff00, #00bfff, #8b00ff, #ff1493) !important;
  -webkit-background-clip: text !important;
  background-clip: text !important;
  -webkit-text-fill-color: transparent !important;
  color: transparent !important;
  animation: cflyhlHue 4s linear infinite !important;
}
button.cp::before,
.cp::before {
  content: "" !important;
  position: absolute !important;
  inset: 0 !important;
  border-radius: 999px !important;
  padding: 2px !important;
  background: linear-gradient(90deg, #ff0000, #ff7f00, #ffff00, #00ff00, #00bfff, #8b00ff, #ff1493) !important;
  -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0) !important;
  -webkit-mask-composite: xor !important;
  mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0) !important;
  mask-composite: exclude !important;
  pointer-events: none !important;
  z-index: -1 !important;
  animation: cflyhlHue 4s linear infinite !important;
}
button.cp:hover,
.cp:hover {
  filter: saturate(1.35) brightness(1.08) !important;
}
/* inputs: keep scrollable overflow text; hue cycle via filter */
.lnk input,
.lnk select {
  background-image: none !important;
  background-color: var(--field, #f6f7fb) !important;
  -webkit-background-clip: border-box !important;
  background-clip: border-box !important;
  -webkit-text-fill-color: #ff3d00 !important;
  color: #ff3d00 !important;
  caret-color: #00bfff !important;
  animation: cflyhlHue 4s linear infinite !important;
  overflow-x: auto !important;
}
html[data-theme=dark] .lnk input,
html[data-theme=dark] .lnk select {
  background-color: var(--field, #1b2237) !important;
  -webkit-text-fill-color: #ff8a50 !important;
  color: #ff8a50 !important;
}
/* 运行参数 dt/dd + 地区分布 */
.box dl dt,
.box dl dd,
#d-src, #d-code, #d-cust, #d-compl, #d-relay, #d-exit, #d-mask, #d-plain, #d-time,
#regions,
#regions span,
#regions .tag,
#regions .empty {
  background-image: linear-gradient(90deg, #ff0000, #ff7f00, #ffff00, #00ff00, #00bfff, #8b00ff, #ff1493) !important;
  -webkit-background-clip: text !important;
  background-clip: text !important;
  -webkit-text-fill-color: transparent !important;
  color: transparent !important;
  animation: cflyhlHue 4s linear infinite !important;
}
/* 保存 / 默认 全局按钮 */
#g-save,
#g-reset,
button#g-save,
button#g-reset {
  background-color: transparent !important;
  background-image: linear-gradient(90deg, #ff0000, #ff7f00, #ffff00, #00ff00, #00bfff, #8b00ff, #ff1493) !important;
  -webkit-background-clip: text !important;
  background-clip: text !important;
  -webkit-text-fill-color: transparent !important;
  color: transparent !important;
  border: none !important;
  border-image: none !important;
  animation: cflyhlHue 4s linear infinite !important;
  font-weight: 700 !important;
}

/* 复制全部节点链接 + 未取回 */
#b-copyall,
button#b-copyall,
button.pri#b-copyall,
#s-hint,
span#s-hint.tag {
  background-color: transparent !important;
  background-image: linear-gradient(90deg, #ff0000, #ff7f00, #ffff00, #00ff00, #00bfff, #8b00ff, #ff1493) !important;
  -webkit-background-clip: text !important;
  background-clip: text !important;
  -webkit-text-fill-color: transparent !important;
  color: transparent !important;
  animation: cflyhlHue 4s linear infinite !important;
  font-weight: 700 !important;
  border-color: transparent !important;
}
#b-copyall,
button#b-copyall {
  border: none !important;
  border-image: none !important;
}

#cf-usage-box .tz-line{
  display:flex;
  align-items:baseline;
  justify-content:flex-start;
  gap:0;
  line-height:1.55;
  margin:0;
  margin-left:0;
  padding:0;
  font-variant-numeric:tabular-nums;
}
#cf-usage-box .tz-time{
  margin-left:0;
  white-space:nowrap;
  font-variant-numeric:tabular-nums;
}
#cf-usage-box .tz-grid{
  display:grid;
  grid-template-columns:max-content max-content;
  justify-content:start;
  justify-items:start;
  column-gap:0;
  row-gap:0;
  margin:0;
  padding:0;
  width:max-content;
  max-width:100%;
}
#cf-usage-box .tz-grid .tz-line{
  display:contents;
}
#cf-usage-box .tz-grid .tz-label{
  grid-column:1;
  display:inline;
  min-width:0;
  width:auto;
  margin:0;
  padding:0;
  font-weight:600;
  color:var(--mut);
  white-space:nowrap;
  line-height:1.55;
}
#cf-usage-box .tz-grid .tz-time{
  grid-column:2;
  margin:0;
  padding:0;
  white-space:nowrap;
  font-variant-numeric:tabular-nums;
  line-height:1.55;
}
#cf-usage-box .tz-label{
  display:inline;
  min-width:0 !important;
  width:auto !important;
  font-weight:600;
  color:var(--mut);
  white-space:nowrap;
  line-height:1.55;
  margin:0 !important;
  padding:0 !important;
}
#cf-usage-box .tz-time{
  margin-left:0 !important;
  padding-left:0 !important;
}
#cf-usage-box .tz-line{
  display:block;
  margin:0 !important;
  padding:0 !important;
  line-height:1.55;
  font-variant-numeric:tabular-nums;
}
#cf-usage-box .tz-line > span[id$="-live"],
#cf-usage-box .tz-time > span[id$="-live"]{
  display:inline;
  margin-left:0 !important;
  padding-left:0 !important;
  font-variant-numeric:tabular-nums;
}
#cf-usage-box .tz-on{
  color:#ef4444 !important;
  font-weight:800 !important;
}
#cf-usage-box .tz-off{
  color:var(--mut) !important;
  font-weight:500 !important;
}
#cf-usage-box #cf-bj-live,
#cf-usage-box #cf-utc-live,
#cf-usage-box #cf-ny-live,
#cf-usage-box #cf-la-live,
#cf-usage-box #cf-tk-live,
#cf-usage-box #cf-sy-live,
#cf-usage-box #cf-ki-live{font-variant-numeric:tabular-nums;font-weight:700;color:inherit}
#cf-usage-box #cf-bj-live .unum,
#cf-usage-box #cf-utc-live .unum,
#cf-usage-box #cf-ny-live .unum,
#cf-usage-box #cf-la-live .unum,
#cf-usage-box #cf-tk-live .unum,
#cf-usage-box #cf-sy-live .unum,
#cf-usage-box #cf-ki-live .unum{color:#22c55e !important}
#cf-usage-box #cf-bj-live .uunit,
#cf-usage-box #cf-utc-live .uunit,
#cf-usage-box #cf-ny-live .uunit,
#cf-usage-box #cf-la-live .uunit,
#cf-usage-box #cf-tk-live .uunit,
#cf-usage-box #cf-sy-live .uunit,
#cf-usage-box #cf-ki-live .uunit{color:var(--mut) !important;font-weight:500}

#cf-usage-box #cf-reset-live{
  display:inline;
  margin-left:0 !important;
  font-variant-numeric:tabular-nums;
  font-weight:700;
}
#cf-usage-box #cf-reset-live .unum{color:#22c55e !important}
#cf-usage-box #cf-reset-live .uunit{color:var(--mut) !important;font-weight:500}









/* 仅重置行：不改动上方7行时区 */
#cf-usage-box .tz-reset-line{
  display:block !important;
  white-space:nowrap !important;
  line-height:1.55;
  margin:0;
  padding:0;
}
#cf-usage-box .tz-reset-head{
  letter-spacing:normal;
}
#cf-usage-box .tz-reset-tail{
  white-space:nowrap !important;
}
#cf-usage-box .tz-reset-label{
  letter-spacing:-0.01em;
}
#cf-usage-box .tz-reset-tail #cf-reset-live{
  letter-spacing:normal !important;
}

#panel-pass-save,
#panel-pass-clear,
button#panel-pass-save,
button#panel-pass-clear {
  border-radius: 999px !important;
  min-height: 40px !important;
  padding: 10px 28px !important;
  min-width: 96px;
  background-color: transparent !important;
  background-image: linear-gradient(90deg, #ff0000, #ff7f00, #ffff00, #00ff00, #00bfff, #8b00ff, #ff1493) !important;
  -webkit-background-clip: text !important;
  background-clip: text !important;
  -webkit-text-fill-color: transparent !important;
  color: transparent !important;
  border: none !important;
  border-image: none !important;
  animation: cflyhlHue 4s linear infinite !important;
  font-weight: 700 !important;
  cursor: pointer !important;
}

/* 按钮更圆 */
button,
button.cp,
.cp,
button.pri,
.pri,
#g-save,
#g-reset,
#b-copyall,
#panel-pass-save,
#panel-pass-clear,
#log-refresh,
#log-clear,
#b-prev,
#b-next {
  border-radius: 999px !important;
}
button.cp,
.cp {
  border-radius: 999px !important;
  padding: 8px 14px !important;
}


/* 胶囊彩虹描边（不用 border-image，圆角生效）+ 彩虹字 */
button.cp, .cp,
#g-save, #g-reset, button#g-save, button#g-reset,
#b-copyall, button#b-copyall, button.pri#b-copyall,
#panel-pass-save, #panel-pass-clear,
button#panel-pass-save, button#panel-pass-clear {
  position: relative !important;
  isolation: isolate !important;
  border-radius: 999px !important;
  border: none !important;
  border-image: none !important;
  overflow: visible !important;
  background-color: transparent !important;
  background-image: linear-gradient(90deg, #ff0000, #ff7f00, #ffff00, #00ff00, #00bfff, #8b00ff, #ff1493) !important;
  -webkit-background-clip: text !important;
  background-clip: text !important;
  -webkit-text-fill-color: transparent !important;
  color: transparent !important;
  padding: 8px 18px !important;
  min-height: 36px !important;
  animation: cflyhlHue 4s linear infinite !important;
}
button.cp::before, .cp::before,
#g-save::before, #g-reset::before,
#b-copyall::before,
#panel-pass-save::before, #panel-pass-clear::before {
  content: "" !important;
  position: absolute !important;
  inset: 0 !important;
  border-radius: 999px !important;
  padding: 2px !important;
  background: linear-gradient(90deg, #ff0000, #ff7f00, #ffff00, #00ff00, #00bfff, #8b00ff, #ff1493) !important;
  -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0) !important;
  -webkit-mask-composite: xor !important;
  mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0) !important;
  mask-composite: exclude !important;
  pointer-events: none !important;
  z-index: -1 !important;
  animation: cflyhlHue 4s linear infinite !important;
}



/* 操作日志表头居中冻结 + 列宽 */
#t-logs .wrap {
  overflow: auto !important;
  max-width: 100% !important;
  max-height: 70vh !important;
}
#t-logs table {
  table-layout: fixed !important;
  width: 100% !important;
  border-collapse: separate !important;
  border-spacing: 0 !important;
}
#t-logs table thead th {
  position: sticky !important;
  top: 0 !important;
  z-index: 6 !important;
  text-align: center !important;
  font-weight: 700 !important;
  box-shadow: 0 1px 0 var(--line) !important;
  /* 实心底保证吸顶可见，文字用伪元素/渐变 */
  background-color: var(--card) !important;
  background-image: linear-gradient(90deg, #ff0000, #ff7f00, #ffff00, #00ff00, #00bfff, #8b00ff, #ff1493) !important;
  -webkit-background-clip: text !important;
  background-clip: text !important;
  -webkit-text-fill-color: transparent !important;
  color: transparent !important;
  animation: cflyhlHue 4s linear infinite !important;
}
/* 吸顶遮罩层：在文字下方铺实色，避免透出滚动内容 */
#t-logs table thead th::before {
  content: "" !important;
  position: absolute !important;
  inset: 0 !important;
  background: var(--card) !important;
  z-index: -1 !important;
  pointer-events: none !important;
}
#t-logs table thead th {
  position: sticky !important;
}
#t-logs table th,
#t-logs table td {
  width: 7.2em !important;
  min-width: 7.2em !important;
  max-width: 7.2em !important;
  box-sizing: border-box !important;
  white-space: pre-wrap !important;
  word-break: break-word !important;
  overflow-wrap: anywhere !important;
  vertical-align: top !important;
  line-height: 1.35 !important;
  padding: 6px 4px !important;
  text-align: center !important;
}
#t-logs table th:nth-child(4),
#t-logs table td:nth-child(4) {
  width: 9.2em !important;
  min-width: 9.2em !important;
  max-width: 9.2em !important;
}
#t-logs table tr.log-row td {
  border-bottom: 1px solid var(--line) !important;
}
#t-logs table td,
#t-logs table thead th,
#log-stat {
  background-image: linear-gradient(90deg, #ff0000, #ff7f00, #ffff00, #00ff00, #00bfff, #8b00ff, #ff1493) !important;
  -webkit-background-clip: text !important;
  background-clip: text !important;
  -webkit-text-fill-color: transparent !important;
  color: transparent !important;
  animation: cflyhlHue 4s linear infinite !important;
}

/* 刷新/清空：彩虹胶囊 */
#log-refresh, #log-clear,
button#log-refresh, button#log-clear {
  position: relative !important;
  isolation: isolate !important;
  border-radius: 999px !important;
  border: none !important;
  border-image: none !important;
  background-color: transparent !important;
  background-image: linear-gradient(90deg, #ff0000, #ff7f00, #ffff00, #00ff00, #00bfff, #8b00ff, #ff1493) !important;
  -webkit-background-clip: text !important;
  background-clip: text !important;
  -webkit-text-fill-color: transparent !important;
  color: transparent !important;
  padding: 8px 18px !important;
  min-height: 36px !important;
  font-weight: 700 !important;
  animation: cflyhlHue 4s linear infinite !important;
  cursor: pointer !important;
}
#log-refresh::before, #log-clear::before {
  content: "" !important;
  position: absolute !important;
  inset: 0 !important;
  border-radius: 999px !important;
  padding: 2px !important;
  background: linear-gradient(90deg, #ff0000, #ff7f00, #ffff00, #00ff00, #00bfff, #8b00ff, #ff1493) !important;
  -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0) !important;
  -webkit-mask-composite: xor !important;
  mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0) !important;
  mask-composite: exclude !important;
  pointer-events: none !important;
  z-index: -1 !important;
  animation: cflyhlHue 4s linear infinite !important;
}
</style>
<style id="shell-hide-proxy">
/* 隐藏代理相关页签与面板 */
.tab[data-t="t-nodes"],
.tab[data-t="t-pool"],
.tab[data-t="t-rp"],
.tab[data-t="t-exit"],
#t-nodes, #t-pool, #t-rp, #t-exit { display: none !important; }
/* 确保设置/日志/关于面板在激活时可见 */
#t-settings.on, #t-logs.on, #t-about.on {
  display: block !important;
  visibility: visible !important;
  opacity: 1 !important;
}
#t-settings.on .box, #t-logs.on .box, #t-about.on .box {
  display: block !important;
  visibility: visible !important;
}
/* 去掉订阅地址整块 */
.links-box { display: none !important; }
/* 去掉地区分布、运行参数 */
.box:has(#regions),
.box:has(#d-src),
#regions { display: none !important; }
</style>
</head>
<body>
<header>
  <a class="brand" href="#" onclick="return false" title="CFLYHL" style="text-decoration:none!important;border-bottom:none!important"><img class="brand-logo" width="56" height="56" style="width:56px;height:56px;border-radius:0;object-fit:contain;display:block;"  src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQAAAAEACAYAAABccqhmAADe00lEQVR42uy9d7zsV1X3/1577+/MnHL7vbm5qZBGQiAQAiG0hCIEkCJo4kO3gQWxozzKY4gIgo8NfFQQFVBBSEDpXWKkhN6SUEJCer39njrz/e69fn/s8t1zgj+7tDP3Na/TZuaeMzNr7bU+6/P5LGH98j11URDAED+u+VG8Svy4flm/rF++W4L+EnAaA//fcvt/823XL9/ZF1l/Cr77T3sBX31vO3BcZ+3RoroVGIFdsiHcCO7rwuS6XADkJCAQ1p/N9cv65Tsr+G31+bbO8JxO+KA3cps3omqMqrGqxqVro51pDnk7/LS3w9/WZss968fS9cNi/bJ++c449XPwK2xthd/yhpvUoGrQYEU7a9vONuPODMednRl3dm7c2Y0TbzcHtVtV3Wbt7Py4k7m3TNh6ZvXY623B+mX98m0e/ALQWh6vhmty4HeGcWdl0jnT+qbpOjfqOjvTdXbWt3aD7+wW39ntXed2tp09YtzaI7yaneplS+tl24sv4jy7trJYv6xjAOuXb6PgF1AFE4TfMcKvAngYI+IAUTGIGOJBbkENKvFzwQIOxSIaP6KNB6zTRRO0/XCr235qxFe+rmBrXGH9sp4A1i/f4uAHuAPmthneZOH7PbQKYgQDBhVBMYixgIkBjgWJXwtN/BqLqEXVoWoRbVRx3unSIDDebcz8D0p3+UfWk8B3x2W9p/vuCH4D2C3CxSn4x4AVEYPE4Ef64EcMIhYxLn4UhxgHxoE0qDQgDokfRcS5TnZMjGzbEcL4HWPucZqA19QWrF/WK4D1y7cuAVgB3wqvdMLzYslPE1/dxPcRSSe9RcUiYmMFIA7BIjgQh+JALaoW1MVKgAYJLt5XnXcsN14Xr14J8w/awGV3aBwzro8J1xPA+uVbFfxjw08M4DVemCjiBAVjYuBjUsDHsl8kJwGXPg4QUtDjQGMSiBhBEz/P31MLOtNZXRh4XbjE6t0fC8stXBzW2YPrLcD65X/wchFYA34VTrbwRwhewcZqPwa/iiAmAX3Gxu+bKgmYJpb+ksv/9DG1ApgmtQTpaxkgiPVsX7Wy5WETue63hYs9nLf+PlqvANYv/8OnvwHUC++1wrlemCA4jEFEyIi/ptJfMBixBGws9aW/ijhUG8ChufTX2B6gDRpcnAyohWAxOgqqAWGfN8HdF959JVwgwoXrrcB6BbB++R8q/cPY8gQrcm4ntCo4jIDJJ7+AsfFqDWosPpX95KpgCg+IX5tUAcQqok8Q4CK0IAMUMchcMOwYegkXxPL/y+uHyXoCWL/8DwS/AOEKGFjlAkRjhW8k/iS3AMamIBdEbN8CWIeYBmNdTA7pZyrxcyUmgljyNykJ2B4kxKHSoIjzsqET2fDklh9+qHDx+lRgPQGsX/4nXjMBvZvl8U44vTN4jFg16ScxG8TR31QiiFVArgpKJZCTQM0LyK1Dnhzg+rEgrtxWGalhuxGR58df7e7rQOB6Ali//PcXASDKcxEQK5pL/1ju2wL6xVM/XtXGoFcxaNUCRFJQ4gikRJExA8htQj75E2+AJrYDKtYz72H++xZ5xunChWG9ClhPAOuX/+bef+J4AIazvaHDYCINyJATgZTAj8FeEoG1KdAjCUilKv1TRVBwgwok1DQRiHyBBmh6IJGRt2wbDBg9b/0VWk8A65f/gYvAT1qDxeAjDzCW/dhc1udrf/rH8V7/MSYIFxNCffrn8j/dVksSqJiC6WOiD9uOGUVmzj/ALxwXsYAL1t9X6wlg/fJffPobAb884mjgB4IhiBOrRiSe/CYh9wZsLOm19P2mQv4TLmBcAQBj35/YgpKEQdInhdIeTFUHDTBAcQKzXcP2uYFpnhp/21PXJwLrCWD98t/xWrnAM51hk1o6RExE/CURf3LJbwoJKLMBNQdyIgL11UCDmPyzPiloUgyK2CpR1AShISqDlAicBOZBR0+7lgtGcH5YNxBZTwDrl/+6018AfwPMGOVH1AJGjFqJp73NAS1Tp7VW7YDkHj+f5HVgG9dXBHnsVzEDI2U4jQVN5ANEYDBWAcjAdMx2I7acvM0OHhd5ARetv7fWE8D65b/qdRLQXZZHWcsJvhGvRgxGECto+hhLf1NKfkmnvZQSf3osmBNCGfmtHQFWgGFJDJRTP4GADqUBGSlsxofRc+KvfOX6SHA9Aaxf/uuKABDheak9D8YJ4vpALzP/guRXp/0Uum+qayYPVQkhg4NTuoA6QbgKHIwcAcURMHbFjIJh/pz9/Pm9hQvDResjwfUEsH75T0d+HP2NeIg4HuaH4nFi1RnUSCrxKxDQ9qBfUQSW075ODBkrsEgB+vJI0BSykEp1+ptBLwwyrlQBmgRDysjPyI7BWOQX429/3voLuJ4A1i//Fae/UX7ZDDDS4HPZj408/8gBsBHxt33g61Twm8L3z6e/phN9Ovgr4G8NTjB921gFlGvkBpglBkGYP/8WLrr7eZwX1keC6wlg/fIfj3wDqM5xKpbH+Ea8ilhNp70YKbz/kCuBTAEW27cGebxnpnt/kagcDGuBwZQkJHsIShYGmTIFUNOgNn00jmAaglhRGfoZdoxaMc8VRNdHgusJYP3yH7+IgHbKT9qGAQ0dRoQU7HnsF0v4dBVTkkKZ46dKQOmrgJ76Kz0BqB4nUlULfBOQMOEDwTqCmaoGzKpxAeaeeg3vOIb1KmA9Aaxf/sOnf1jdwImI/EgYGa/GuNzri43U3hy4Uk0AVCQiB6ZqDWpcYA0paCoRGImnfsYAjAMzKJwBzSNDYwmJUBRsg1qH2oZgRIJpulmzbXOwo59drwLWE8D65T9x+kvgl9yADdrgxRghE39yr2/7oO8VgFkNKFMnfI30M6UNMMVAJAOFRU8wpQnIHy0hE4Yy/mAbNCcE09ixMUF18OPXzV66K1YBup4E1hPA+uXfc/ovb+EYKzzFjwiI2Hyqh1yqFxVgrwXQyvarB/Gmwb84+hOUeJU6QdCrBmMicfExa0AwEY80X22eSEisBIyRYGw3w9atCyvmJ2MVsP5eW08A65d/1+nfjHm+HcomnHQIQqXxz+U6U8QfMz3mmzrxpewGKHLfmj6cJwLWldN/ujWwPbswS4qrRBCMIRiX2gJDZ6xdtSZ4mfmZz8x+ZhewXgWsJ4D1y7/19B9v4VRx/HgYRcOPPtAFs4bYo6Yy/6TS+ku/A6DnBfQlv4pNAV9pAPJ1DSOwBH56/Bzo8cSPVUCwORk4VIx41/gZ2bFjsmJfIIhezMXr77dvt5Nm/Sn49ksAAqHdwBvdjDylm5NWsLY/9SMYF8t8k3T5lbe/WiDZeZO9/NKqr2L7na2/m6LvRxOvXwfx6zBAdYRo/KihEcJIgw7QMCDoANUBXgd4dfjQ4MOANgzovKULjo5Gx96wsjpeWR10pz90fOo1sbqRdfPQ9Qpg/fJNgj+y/rZylrGc52ekEyM2kn0kAW5x/p/L91yia038qcDAerwHleY/twUJB5ju+3svgUgAyo8ZGxG1RrA2If+2XEMGIK0lWIM3IqFxfuS2zutk+OsJC1i/rCeA9cu/nAPAePktMyeOoQSsQV3v6oPtKcB1W6BrKL49BhCLvD5BJNpwKfFj25AnAFE2HI1Da1ux3lDElgQSAz8FvOmTQLCW4FxMEM7Y1RnvRWaf9sHm2tMF9CIuWtcIrCeA9cs3O/1Xt/NYO+SRftZ0WONwFrGGKP3NAZzUf5kJWJF0poxBqilBJAhV1cKdNAHVGJDaPDROAsQ0WjwHraU2IolYgCFYQ3AWb21MAjExiB/YYAfzg+XW/B/Wq4D1BLB+uVPwC4Ceg7OB39J5YCCKMYitpL3V3H9a6Wd64k9B9r/J/H8qQVSUYesq2rCpyv6eCpxBQTW96UgwIlolALWW4CzqDMEZvDP42ArY8VzbObPpCRfbGx96Puf79SpgPQGsX6rXQcC3V5ifdLNyRpgxbez90+gun7S2l/7mj2qqSqBSAAqV5Lci+5DagJ42XM32rYWE6pfbm15shHWKcfl2GhNCzz0oLYHL1UC8qhi0cWrmZq0PM//3knPUpdS3DkKvJ4Dv+dPfAGHpSI4yTn/Lz5ugzhgtjD8pJ38ss6XgAFMqP9aw/oyghnRy5/XgvVloDOTYp0/7BNgiEy57A2pRkXGKcRoi2KeZ/edNLvlNFCblliCBgoqxk/lxOxhsu+/1H9n3y7EKWH//rSeA9YsI6KDjZXaOrTqSSPm1FSU3Bf8Ul99UkmBTndapYqgVg/19shNwcga2rmAIWhaG2qQFMFNbg/JJHyRes5YgGIMXKWrE7E+gSaZcEoA14KyZbJx4mP0/r53fffL5EC5A19+D6wngexr486tH8Hg3kKeFDTIRm8Z+OXATAChry/w1zD+pcAFJIz7WoPf9/ePXIY8Qi6FILQCqCULVMpEyghSCCAEIJn8dK5TgIl05pEQQnMS2ACM6Q2hGo7nVpZmXI6KnrnNR1hPA9zDwp7eexpxBfj/Mi2pjJM/8KUBbD/aJMZEFuEbOq0UcJFVCiD19FvxoVQX0CsHsEuzSbVwF/NneJ6AkkYoGXK4p+IsWwJRrsII6iUnBChoxDTve0nbOzjzhlc3i95+P+IsiK2n9sp4AvueAv7B1D7/dzHFimJUWESvZ5dfFa0H+bVVKW4mvnAiSNwFLZQdWTwSSSEhsWhM+he5XGv9iAJq+NyU3nrYaK7Tf1OdrCnBvBW9SZWCnAz+4eFULzEDYgrZt84pXH7dv05Wg6zqBb83FrT8F37rSvz2Ghxvh5/1G04oTVy/tLMo8DCZz8NO+PiMG1CQWX57dZ6afgEZ2nxGDps8hjRQ13T56iyejEItoQ1YCxuWfBgmJ3Zf+X9VINda8U1Dj46j2m4VDEAJC0HhVhGBAAwTRWC2omG6r70bjwfF7r9cXX4j8HFzigG793bFeAXxPlP56BrMS+BOzycBIyomPM9V6r0rkU/rvXpDTK/kqVl+e9dcOQOTlIHkXYHwcU+7XlMfLSUGk2iqcuQXWoq5nI2Z6cmYAFkKQpKBPD6emrghIkw2xq4f5VlzzM78xXHn4hTysW28F1hPA98Il8v338DK7wZzsN5oWY2wu9yW78pg1Dj95tl+p8kQMUlUGSehfAr++n8g3oQgXC/C1q796d+B6Z0CP8teTCFPakugLYKb8AYKJQR8c4ARtBHWxEtAZFd0mls696tdSK3DBun3YegL4Li/9u9W72scNBvI8v1VaLE5NPbtPgJ7NNF5i6Z6+F+3ApCfwpLGdZEAQ6Uk8SftPZRJSE4nU9Ah/NvnIk4BAZATemSXYg31hKtgNKhQ8IN4mBX/5OnYeUYyoEMSEbb4dzLsTu+tnf+9CkQAvWn9PrieA777LBYnwc+je7HAm/BlbTdCBiNQEnczGW8vTNzI9YzdJIGTrpR+mZ/iZyuefjB/Uhp/93B9c5QgkZaeglO3AtQlINhXp7cb7ZCCJ+BNPfZ9PfxFUIBgIRlGTPhdQURTs5PCuNW74E88drT7hQqQ7b70VWE8A322XF50T13uNFvlzu0mO6ubECxIZfzad6jYCdVpz/tP83liHuHy7HPhoUQPWa8LXuAFJsQRPdt+F7turAbPzb0kc9VbhMgJM7YWJfX5uB0I9EkwMxBz8IX3u8/dSIggZhwTCjIgeHkLw9s+eu23piIsRv04QWk8A3z2l/zk4uZRu9WTzi82s+QG/QSaiWE0BLzau+dI0MhPbe/zF0r8334w9etkHINkIdGorUN3P5x59SkOQen/rSgsQH693/K19A9RM//+9+WcP/vUBH1mB2CoRZDDQamwB6nbAgiombA3ebnVHLC0P3vi8R181/DLIulZgPQF8d/T9l9It35tzGqsv95tp1WExBpP65BxAtb5/6qPNwGAvBy66fmunXYKLsMcU/wCpNPzTir9+m5AWp2DX04tNDy7Gkz+JfUpbYBMtOPsT1KSgngwUbF/2B5OCPn+0CkbxYP0R3WQw487Z97Fjfv9iEX9OnEeuX9YTwHds8BsBv3gGuwadvIEt0uisiFgRXOyZ+2DtA74IgaasvWvbbzt9O1sr9myl8JOqEujXfmslHirW35kqnP5PtdOjxwIw0rcC+etAmv3H2ymJCOQzC7CU/pkLoKU68FbwVlOFgOuO7FrV4XOfvHH1By9FunMiP2D9sp4AvuOCXzgPueg87GjMX9nNHBk2SisYQ5qlS9LOk6+pdJ5qASpTD62AtzppaCrfS7tQc/7tdGuQjUC1HvnZdPKbNdhAtSwklu29H0A+9bMwKIqEepuyCDZSBTslGXhDqgo0AoOJeyQKzCF6RBeYuFf/wBGrJ13Kw9ZBwf/Gy3p2/e+6nIOVi+nGp8uf2k3yaL+ZiSCuLt+nADsyS8+k1jd9VFvIPJKYNSaz8KRi22QgLzH9JB2pqpGhJ8Yi6vokgO1r8cTiQw2CRXPE5mDWJCtGCGpQrRyCEUImJqnBi5GAjSKhfF+NlmSBhAGQvm8UVYmG4f3mAGN24m1nt4136989/bRbz/7bL7ESn4x1N6H1CuA7CPTr7ssvDIby036LTLDicAYaC42JV1ej/elzqfv/6RVf+bahEHlIrL8+qfTMwOkpQo0pSCYJmbWbg2tL8co+PJORMscgG4Dkk76oA1OPL6nHl5gEguTSP43/SB+zZ0HiBWjaOI6KNUd3k8EWd5/dN25/FSIh4gHroOB6AvgOCf7VM3miIH/gt0rLIPn651K/sYjLxJ6e8FM0/mtkv9PAoOmpuFJvA47/fxEHJVS+tv6isgKTNY9dlorGR5lqQTLgV+jCxibU3xTAL8qCexpwCXyjiRaceQGJDyBKlxOCJDC0SBSUAC4c27Vm1j39YdsmL4x4wDoouJ4Avp2D/7yI+B+6P6c4ldezQ5Q5FQxCk8ZxLp7qZVSWHX7WjgNNbwPej+D63l+sTIOFUjkEZ0KPrLEGN9Hxt2gITAXyfTOfwco7QKtxZDb7UCfJAlz66iUHtDA18ss9v1Yswfj9iBFoxgPS8C8oeKc2HONbXPPihxzWPS0mAV1vW9cTwLcp4n8x/tCj2TGjcpHdLpt0k3hqso9LAW96wk9x/K3IP1Jdp8A+6fcCrJ0IlNO9QvfvbB6SXX+k3xYka6cP0xyCPF2QkgQy2GcTc7GfQvRsxb4FKJ8bTdWExnK/YgX6nAQsBKcxKVhQDzqrwtGha5G/uP/Ryw9enwysg4DflsEP6K1PZ27267zVbpV7+K0yIYijSco604t3qMU9YhDtBT2qSbyjESiLbW8f2BFQI4mA0kkfehkw5f8wBE2f5yhE0uPH/l3ybD/vCizRahPQl0d/afyXAcdgSi+vIuX3zrfPcmBF423K86QEJbYLKhEXUFCNAGEcJ1K+LyIEj9EtwVs1w/HNg7eefuzqQy+9fvSVhI769XffegXwrQ7+2H1fgN12rbzRbpKH+G2MERxOEuAnUYKfQT1rqtl9ogBnd9/UCmgluc19eBb8SKH+SmUcWs3rq1EhU+W+i8ShZDpSzEIS53960Ui61qNHE4N7Gn+Q6v80Oc+kE15i116uUgYWapMiMOWcYMAnvADTi4ZwoB7L9tDJkfaw1jf/cPrdlo6Iwb9OF15PAN/q4D8PI0JoP8Rrmzme0O2QCYYm98jYXjdPksRm9F+y428V6IVzb1IZn/v5RK2V5ARUtwqFr29NtcwjTQdsbw8WOQJSRD1USSCrAaMMWEqbUHwCpSceTeETtR2YIZGImA78Mq3UiOWnv0UTAQirhTqsoslFiF4vYEA7LNvb1u40d1teGb3r5JMPbgMJ60lgPQF8a4P/Ynz7EPnjZlae3m5ngsP1wR/7fqykj9USDytTAhopuEAMLpG+p5Y6OdSTgBzwlUdfX1msEQUlRF/smgUhld/gnSYPU6SialRpK2VgdiEWpvj9Pc1AEj0hmYRYgVQd5L4fK5o+pvtooQwHm/aWpvGg7OomZoc5fWVl7u93PvLWufUksJ4AvqXBP36YvMSN+NluJxMZ4MSmsr8EeX+6i6nsvSvDjix7ySe95KRQLwWVmAiMrbX70waiJciLeWiVcKoFI9EotKf9ZjWhiExxBrTeMlQtDa2rlKRKLC1CEfykazCalIDaKwETExArGjlIilhVtVqmJGp73QCmbweC4vSIbsJ2ezbX7rjohEdfNYwvyXoSWE8A/1OXyPLz7SPkwsGQX++OkInMiJU05xdHku3mMR8lIfRz/z7QtcIDcs8utgpYMRUW0N+37PSzmc7bn9rTY756YUhND656eal7filEH9YEebYD722+8hyfvgXIp72JJX4QLRZhKin4G1SaGNihEdT1KwhCqghCriScpglBSiwizhzVTewW+9gD1x33pjOe81kHJqwThdYTwH/7yZ+JPpNHmRe4Ab/Z7ZJWZsRijNAINEyBX9FjM48B+9M4Vwdi+2Aut8vz/imrrZrpJwWYy6Be0RJMLQfNCcBOWYZnWm+WFitS7qNW6M1JcwtAtfBj+lqSQJH/5hI+MwDp72eqyqA4A0lhMIdGCA2oUynBXnCCdPsmYgZixdmj/YTN9ge+/rF7v/nu510+SK/SehL4d1zWx4D/3pP/UrrVx/BLjeN3usOkZZTkcA0JpacKrnp1Vwq6PNbTFPiZ9y/9qE7UphFe4v8HSZx5kMr9V+jdgMt4MdTjvHxb1ugMsndgBBo18fvjSDIi/fXvlOr0xOfvlX/RlTiSdoImVJ8U9KoxAaSxZRzzUUZ9Pk4vVTM1OF9VRUXQ9Hgk3UCgGieaVPSjzh7RTeRW96Rrv37SX6PyFCQ/4rpuYD0B/BdeLskn//fz883A/L4/XFoZaGTFOFPZV/SkHCsGT5UEquDvG//ezDN/LyC9yCfN+CWJc9RDpuqaJMDRcuglezGVFAcpyPMRm/nCmnkIUuzHUYuGylg0VQYapAR+bwfWJxBN3IJoP065BgGf5/r5+xpRfp9+3oF4gWBEFcEHJOTgLwuD0teBkmzitzWGuMW5o7pJe1vzw8Mz2vFE5FmqataTwHoC+K8D/PLJ/3jzv5uGl/pd0jJSQ0Ckkf7Ur224E0++JAQMBArRByrFTArI8jn0ar50KvfVQyLtZCJQrBOi4i+p8rJqUNUgNIgaQv5/Ezkowe7x9vm2aqYdhdPXgSTjxcSgFsEDXjVeBbwoXoUOLT6AVMEfgtKhtChdeoyQRUSKBIjTAaQEf6wMlJBwfk3ZZaoiiJ2/s0d2k3Cbe6a9T9t1n5MfZz0JrCeA/8rgnzyB5zcDfanfKS0zakRFGNBv6Mny3eqU1Jqem05t8T2zrrDrUrmfE4BQVwj0QRsSIJhOdK3aB6GWBqctQDgI9f3yUhBTgrsEvSZwsUoCIbEBfWppRs0Ii2GSBvS5BdEkPxY1aIBJ6AgmxL5eFVHLwCU9lAWnsNBCCJMyfYiswTRO1L6TV00gYpYV07cHObwlKoUdR/oJt7gfs/drg/+0PDs1GIaUX9Yv6wng3xf8cdTXTZ7ErzVD8zK/U1odBCMapfUF0MtoegpqMTmIoKbxonEBiHqTSvTp07o/nfPhlTEAUwg9Gmyv2c+beXKwq60CWOL3kgtQTgqaNP8S1uASkq16Ten34+kfAcEJcN1kL50aViee8UTxxtI5R2cMXqFDaDUwP9yGmhk6AjPDAbcuHuSqvVeze7KfziijZoYts8ewcdMxeA147dL0QWNCCX0rkaAPDSqEoKKantMqQUAKcVEnR/uJ3uZ+Qs6azOqj/ulZXPiwbj0JrCeA/2jw+9Unc0EzMi/yu2hpgpEgEplr+UCVflxW9cbTnpb9z6QyzyCX5SGV+SGV9JoDMUZA4e1rvwZsqszX6lQvegAXvzZJi5ATBLavCDRWC1LdT/PgvdIaNM2A61YXePJHX8liuwKdR1VTVdNEwC+0GDugaye86FHP58T5e7I8hnd+5R1yydXv4OB4SZEmVS9jBkY58cgHctbpz0SaTQRt43OYc2bWERijBT9Qo/hkJg5VdaXxOQsA6jjKT+TW5ql84EEjfZ4+lT+WMReo4cL1JLCeAP614FeEFyFyIb49X17hhvxcd5i2MtQ4U3PpZLY9Ay7P8++06TqX6BX4pqTbZ6COSPhRTadyJsMntU083SMrRjUuAy2CoTxrTC4cGpJjD5EGrCFNCPIacE2VhwiGejpRYRFJnJN9AzX9ft7AnuV9MDmQ2oWZ+PbxiyAdMhjhFTSMWem8eAOv++KfcNlV74HhZggrYBXjhoR2hYk2XHn9h7l9+VYec/avYQfztBrS/x0nCPH5C6JGFAQJmjD+DDgmrCCJpIxGkRGCk6P9BNc8WT8f3s55t/8QF8riehJYTwD//8F/ASa1oWH8v/gTNyc/023XiQyIA3OXJK1Mi2FCSgKS+9dyiMVADfnE1jzWqsZ/eXGHVoSffCKrgU6qLT+mBHVtBebTYw0GDtwIGEBowIzADsEMoLPQuSTMbwitoW0zNGGQ0K8UK36A6fdofWDeDfnZez6BcTcmeME3Dd5ZnBWuv+MGLrn2E+A65kYb5Mgtd+HjN3ySy656N25uF76bcPpxj+CUox+AsSOu3fs1Pn3Ve/FY9uz5Bp/76tt44FnPYnHFR3BP+/wZklWYhiCaxUSaR4Ja7MYUTc83SJwiOI7uJsa5c8NtW9/FeQeezIWyj/PUcvG6inA9AXyT4JcLCZdcgFu9mr8azMszusMSt59szZcQ+tpwo6znjjPu/C+3ABGoSqdpSPfX+ueVlJd+fi8h/bxJ/XmXev4E4vkQH2PgDHbDCJpZDi7C1w8oX9uzyHULnn1dw1gGCJZZ7dhpHMfMz3PClm2cPLOF0YaZmBRaYaxUisLcpsRk1amyyc7yf057Eq1xrHrDqhgmA9iwEX7lfa+NxKHO8/DTHsnRR23mjy/7CDI4jK4d8/B7PI7vv9f/Yu8qTAgcc9Q92LXzeC7+x5cDgW9c/ylOv+8PYNw8IfheTiwKyVmIlFyD1vLinCxKyi2fxRYFJ0d1E7HuHL1j7j08Th/HxbJnPQmsJ4Dp4D8PKxfib/8Z5rdczZubzfJYv1PGWG0kcfWL3L76uoB8pselJI+nkp6/Tga579YK6Zfy4L0XAKkEl5DWdCNoE9sDRQidYdhYcA03LTTy/uuFD962zKdva7nxwCJtN1YYgLg+agTAAxNGznH8xk2cddjhPObwozl7x5HsmN0MXljuYmmd/f3ISQDYM15kYi0TY1jxDheGfPqWa3nHV/8JBrPMmpE88u7fx82LB7ll4VbUOmaH85x9r+9jVVo6O6FTYdIpR+46hUee/XO0oWU0N4yjxeQbWE73afikjAF7nIDpbLD20yAExXFENxHn7q+3+0v4/tUnc7F8nXPUcal06wlgPfitXIw/+Fy2zR7k791WObvbyUQcMfgrno7QC3ekavkVwZiMTBs0WDQkOa2Y0haYPM9P5bYpJh/9BCD3/5Idf4jOvqjBYxlaC7MNX7pJ+LMvr/LW6yfsXswjvjwgtxJBSQUdg06IHbIDcax2gSv37+fK/cv85VXXydFzQ3746OP1p+52P47fdDjL444uxLGcB4KLY0BDuhqHBRrjeOPl70T9IngjDzzlbLbNbuPKfdewMl6EMGbzzFZGozm6LuBGjuFgCA5WPBx/1wfgLTRzsP9QwGtLsKY3EUlBH5966XuD3PdLdhSJ+ABVWtVI3E7YCE52+YkM7D30Ri7h3PETeL98bj0JfI8nAD0HJxfTrfwMJ7hl3up2mtO6bToRi8OmtR5CUezlj5lBp9WPTGK+CYIb+gjOecV3MSlEpJ1+TFjP38sRF28TQUJTOAGK4L0wnLfcsjjg5R8XXnN5YGWs0KQ3euiYa5QTtgy5987N3HXTiO1DS6MB75VxZ7m9bbh6/ypX3LGHaw4t0nYd2AE3Li3r711+GX919Rd47qkP4RdOP4cNYYa9y5Oy+y9k+TKWLsDQzvD526/mozd+AjFDGTWzPOpej2Is0LZeQ7cE2iHqpWuFDkNQz6eueA/L7SoAK6uLtOpBlKPv9mgGWw8HuuSOVLEH0Z7tKCXrxp0DOSdkZpBoP9o0CSqM3GTHjq4V647Um/kQj1p8Kh+Q932vJwH3PR38l9ItP5sHDsZykTlcjuy26kTAFS5NT+pLoz5KKa+55k/IfJe8P1sPn7l1OxMdsnM04eTNq5FiG/qJQAYBezBQ8uSrDL8lsf4Qg5EGNxL+/krh5z825KYDirGxnCdMePARI84/aROPOGLIcTvmGY2G0GoE/oIDbRSG0MxCM2JhoeOqW5b48O4DvOW6W/RTt94OxnGg7Xjx5y7h7TffyB/c/9E8aNvx7B13UfTjpDACNQhi4A2XvwPvJwKBs087l+OPOpKDY89gkMx7xWBco8YIbRC6oFx2+XtZOrAHnIuTATy0S2y7y+mMRkegbdXfS99OoRqrorr3lxj4SiJNhpKeydCAqOT9g9BhZWfXytBs4brRO/Tc5R/n/fI3ERMgfC+yBr/nEkBN8Ol+mvOkk9eaXTLnt+lEVB1CL8VNR3sw0qP8CaCKBUFC5tNozgjsmwx4wt+cyb69M/zgmTfxlqd/mcmiwVotAZ/HgITpkWGfGHpxj2JpbcOLLh3w8o83MDRgldCNefLdHM87faM++LCBuOLl30GXkoe1MEg2RF6UtoVOmLMDzti5lTPuchS/eP/T+cev38LvfvJTfPiWG5CZLXzpwB08+r1/wYVnPIYfu/s5rKTnILYEyszMDJ++6Wt87BuXIc2MDs2QJ9z3UTIJHttYxfWZU0yDGYLxgYEIWzduIoQxrpmV1fGihtARjMU2BhlE5mAgMf0kagCCimKkj05VJCQoVeIcJVOJc/hLqahCrw8yAl4tW0KLEcP1M3/NYyZHc7G8NGaZCwxcGNYTwHdr8CfivFyM757LL1kxv+93od0m7eLJL9V0TgpBTgp1P53W+XjK9X+ayiOCDGCm6RCzgtXlSEBL7jcS+hNNSOShWh0YyS49B1+Fwcjw+/9sefmlAwYbDJPVwGlHGl7+sO08+igPk8BkoopVGAxkXzvkqt0tV+2bcNuhRcYMGbiBzlk43BpO3LSFE3ftZHZ+FhYDYbXj3GOO5dwjjueN136dF3zq09y4cAgzcPzGR97K5h1befJJZ7FneYI3ceToBvDGKz4YhU6t8uB7PZijt+3ijqUV7HAGH9KEXj2+W6VFscOYKB//yJ/Hd51s2DjgTe94FTfd/BUEh2lM9Abo+tM/9Vtatgil+X/hAVVYYOrHIiNI0nOJJlWS9uWEEbRTy6agciItNzQv0cf6I3j3i34OuTB8r3EFvmcSgF4QvfsQdPwz8go7Kz8XDpNWI6/f5LG6FLPNyn9P6ndbJtUkDF96JRyimOxvlzjsWInYWzLayAy+yg9rSvknOQGIQdThVXjKPVve8tXAZ26e5xcf0vDi7xsw52B1QRkNG/Gt8JarW33LN/byyd2WGxYmGsbLEEK/5UdbgTHDwVDvtv0wHnb04Tz52CM5e+eRgGMxCE+995mcc9yp/OQH38m7v/YlnnS/h3Lu3e7JQjtBrKUFZjYM+fyt3+Cj13wOGW2kCfC4Mx7JskfVGTqFDfOzDAczLE9WWVhdgWaCdbMsdzCY2Yr3qmbW0SEgDrENdjSTjUJSJ5T5fhLLDtODghqqz3MvINVMUFI5ltqGKB/WXqZoAC+ic8HI8YzlBvtcfdxvHsXzf/YZXCgLnHOJ49KHdesJ4LtszKcXMN/tkb9wm80P++06YRisiJSxfD7psVrKfzEUaq9kiWyy5bYikYST2HNkFxz1gIuWNy555wuRB7BW7FMscJMlWDUOFLH4YDhmh/I3PwCfuc3z9DMb2iUEER1t3igXfbHl5Zfu43M3L0la9BkjJ9h4nMpqymgjYJZxG/jS7fv50s138MpPfJpHHH24/OoDzuGRJ96DQyutbprZwN8+/mm8+sR78MR73J8hQxY0EKylU2E0MLzhM/9I102gUx5y2kM57shj2bsyxjSG1a6VrYdtZfvWY/TG26/n0OIiX7v+Cu57nweyeEBwRhk4xw03X8Oe3deCczSDGYabt9Hho7FJWgOYE0FJxLmHS92AhhT8dx4BqiZGgBqVzL8o98lAq0d0GJwcr2Nzs3tiuGLL+zlv5WlcPHPt9wo46L4HTn4nF9Kt/AbH+31ykdsq9/GHhbFaGkmOtFKN+jT1+sVyO4/pq7I0QXb4XIjW5WVCyjEuLd+w8ZDXZAmWuP6ZZCNkym8k/8SvbTnyrBja1nLyTuHkIwLjQxOGQ/jGwRn5+fcv8q6vdslNqIHJss4NLffcuZnTjtjKXTYNmQ0tPoge9EO5/pDnS7cf4Irb99GGZdQO+ND1t/GhG/6Bn7jvzbzsEY+WUTtgxav+1H0fyv7Os+Q92jS0Ksw0M3z+hmu55Ip/QpzQBOUJ93sUnQEZxQpcRXEzQ868x/3khuu/rHZmhr9//2tZGK9w1DF3BwvXf+MGPnLpGwjdCrQdR93tvoy2buHAeBzHgAXJT6e2jbV/SIYCZSBgpGIFTrUCJQUgufXqKZqS2IXiQFsRtdpw124ijXuA3iKXcd7qj3OxvDsmAfx3Mzj4XZsAFIQLsHIh3eR/c45dlr81O81R3VadiNBkn36p0P66BYhMv3Qq15LeWuE3Re2NHFUxBmMdSJNstdIb0fQ+AD2ynduBXhdQqo1qkYcxhlYdvjWMRoYPXjXhWX+/wK1LDXZ2gF+Fux02w4+efhhPuOsGTtyxGbdhLrIHl0N8mZsZMENWFuGKG/bzpqtu4o1fvZ7bDoxxwxF/8clP8onrv8FrHvtUjt95FLsnK4gbgLN4bwkqzMzBX7/jbXTdQWiFs077Pk6867Hs78aYRugUjBE9NG7lfvc5h89/5TK55qpP68rcRt7+gdcwmtuOimO8tAfoYLzE7IZd3PPhT2YsIdmBC2vZPtoHf7WIgT74taZgS/mBVE+zpNZBEpW4HxuShUSOo7tWnNupNzRv53GTn+Nd8qeghgtUvltxAfNdeuobALmQbvwC8zTr7QfMLnNUt1Nbseqydx8ubaS1JL9+gSb27CZ/XXv3le9lIZ2UfX3ZEFOsIOJ6tCrdziST0N7FtzIIzTN22/vt92vE49VYwTgDowG3TUZ663KnmFUd+iV9yWO26md+5VT9tUcfyym7ZnC0sLIco2LjHGyeB+eUVa+N99zvqJ38/uMfxmd/4en81EPuRTdZArPM1ftu0H3aqZlrMEOHOkswhs4pMxtn+Pi1X+Efr7gUaTYwHG3lyQ99PF0D3oI3Eq8N6CCozDb6tGf+st7zPg+HSQtdYPXQAcYH90Lnoe04/JhTOOdZL8Aedhhj7WBg+p0C6XXRbAoav9badpy8TbgBSdeo16j8BEWU5FRML3SsjFrT4zkAsRzRdXI3kKb5Ex7TvgyRwIUSOE+/KxeTftcZKGZm3wWKeeGvyUvdUH6tO0wCsyEk+l0y3azeDP08qaj7yvqu2v5K6H34ajuv5OHXoNyxPOCMlz9UbrrF8eQzb+Ktz71OJytDBkLU1gdbrb3J8thU9gdb3tGi0TJXtSESiRowDSE0NDMNr/nIhD+77BCv+aFdnHHcZiZjw2Awgpk59u7t+NK1C1yzr+NgaLBuwA5nOX5+lrvv2M7GDZtkEoyqGTBs5nnjJy/nhe9/L3/45B/hMfc4nVtXlwkMaINlopZJMHjbcOOhvexZ2o8MG2wzYuumw1gOykSgE6VF6ARaYBLAG4s3lquv+So3XPcVDi4coAvK7Pw8hx1zNzYedw9WjWW1XcVbSyeCT/6BHdAitApeoA3gQ0RXOoUutWBe0sekWQiJ+exTW4Wo1O2EhoofUAwLk70YgnYJOlgh6LW20f3+nRy2+hxeP3/bdyMuIN9lJ7+TC+kWf5tdo0V5rd1gzu22aMsodvZqtC/5zTTNNyeA+L1+061kWaxUTj7Z3y+rVLAEdTQauOmgkTNf9iBuvbXhSWfexlt+/ibtJiOcgHopCUA0tgmoSV586Xvq0FiexKDPx1xJGA2qDmeHLIV55pwyWfYM5oZ8ZXfDn1y2wLuu3MP1ew9B21a1seKGcMK2bZx3+iny0w88XXcNN3JooWV2NMctY2HDcAMronjjmPiGiZqYBLCsKkjTYIaGCbAa4MDqhBZoBdooXIxBKzABxl6ZKMhogDTxe8tdTBCtwuJqyzgEvDF0QJdXigOtxvt2EnUIPig+iPoU/NMJIFqR+RC/F8I0n0qD9AKhEvjJIqTYtEFZXOhT69fRcZ0d6K3hOobjH+Fts5d+t5GGviswgErD300u4IFm2fy1PUyO95sZixGHRBMPIZb3dc9PPeojo/49D4B08hsx/SyqUE0lKfOS5n4kbAoeTe3icDDAbGxksGC0nYSkHKycfXOvbypdP3kUaKORR2+4X1mAWToMMwNlQoNsnOH3PniL/Nb7bmNhxUJjswG/EjoIrWDQrhvy1b0rvPi9n9bXXfYlXv6ER/GD9zyNg16Z3zhkJXTAAK8Gbyky5ZCmcRNaJpMU3CLoIA3p06QkoNEbMMWSmtgJTfyESaeMgXFQWk3uwE1MfAFNrsL0zsJJTNVP7yKYH6qJXnETloL4p9eFZCyacECnoqF6s5j4C6qJGUJyJZBGh9iYYdSok7v4iQztXfSmwft53OTnuVheDfDdoij8jk8Ael6cxgE6ucD8rLXyf81hOuo2hIlgmrKbTmpCTxoDiRYpb1mOkQGoPA0owS+9vXaVBLw3DGY78IYv3riND12xg8V2A2bW8pW9O/n7j8F9j9nDMYcvwVLDpHU4lzz9QoIK6O23JZt1FvsuU2y/8pocSTZfbVCGG0f88fv28vyLbsVuGoEsQzvhPsds5z7HHyHHbphR7VquXViRT16/oF++dT+YwI2Lizz1NW/ibb+yhe8/7RTuWGwR6+hC8gLEEpLXQPHqQ4r+PgPuUTmoU7bfsapOtuBZUJSsvnLq8+nnyQBY6s3HMcizO3A1+zdUJKAaLOzH/5KDvFoPoJkjEKpWQPI0Jmo+JPQVApIpR4IqjmN8ZzZKo1c3r9JHtadz6q2/yB/KyndDS/Ad3QLkkv/A77N1/pC8ys6Y8/w2DTqnwSgmWEmmNzHYTXarja4RCfVPRBHpfeam/Pyz1Xey5dKkyRdioLjRmA99fjsvedtJXPaNwxhPZsEWrjC0LYfNHdQfPGsvv/74Q3LUZqVbbVQkmXuoRWQQP4Zc/jdpA0Ys9+Nt4ueS0S4ZRm9BM+TW8Rw//Jpr+Pjl+3nMvTfKr5x9FA+563aazVvANDFxNCOWF9H3ffZ6+e33fYrPX3OrnveIs3jVM56E+IaJOjoavDpaDK3aeA3CWISJxLJ9AoyBVmLZPUFoRZmksr4ViVdgVZVWhAnx1J+U8l2YhOgQ3IrVTlQ6tCSKLj8WpL5e6IKqT8mkv53SKdX3iG7DGmuwkqwyYSiX/OQpQCILhcQhCv3X+JSwfEo+oLJC4Drb6F7/Web8c7ho+Lnv9JZAvkMDP6P8YfJS7mcm8ld2q7lHtzG00iQBfWOmQb58XxODP2/Lgn7eX2y9hMSgy5z2vHwjcvPjCe1wo8AFF53Kiy8+Bp2M49htdsBhW53MNLDvkLJwYAISFBlw9I6BvO6nvsHDT11kcsiqtdnmexCJQ6GZ6vWpMABNn4s0aLq9qCV4S7NhnqtvC3zwq6v89EOPhZWxtMuexo1gOAtuBsbCpDU6mJ2XA6ueP7/sKv2xh53FBpnl0KrizYAWixdHh6VVwyQYWjVR4UcM4EkOaGIyyD1/S7pKTAjjFPAThIkorcb7dQnYa1Vppe/nuxi4dCkBdOnxfAL1ugQAxqvgNVqRd0pJAip58UhMAKEmCIU8CpQyNoyVQvpeBgJ9vq0UPIAA2sUEIkE6ucUO9MawqEx+jnfNvPY7uSX4jksAehFWzo8cnMlL+QWj8jt2q4z8JiagDiNlhFQCOx/i+S82WtF6e9KPIgX0K8yzNDPqFYCGEBzNXMsL33g6L3nzPWGwzMAv8rSzb+KZDz/I3Y42zBjljn1ePn5lo3/yj0fymet3gTQyZxd4/6/fwINO7LRdaTDGISEGfTTuTElAXTzxq++LpKqAASKuVAShExrjYHYj7dgiboRrRnzuq7vlM9cfZDQacf9jd3G3w3fo6sRgZ+doZuZZPOQZd45gGybB4UnBj6VTw0QNExUmRIBvQgpodCr4xwqtKF6EiQitKqvp552gY1XGinQi8dTX9DGJi3LAB+2DfwroU9FcIeRgz+1Gp6kKkLxZSEosB+2ZgpragrVAYDm7Q6oAMhCYE0CuBnzKNJ0gqJd9OL3Ria52r+GMg7/ChdsPfSdWA98xCUAV4fzo1Lvyh9ylWZZX2A3yhLBJAjPBq2I1ufT2Ut5E+1rj3FNeH+lP/2kucG35ZSq00ODVMZjteMfHD+eJL38A0giHbxD+9pc/w8PvfRuMHbRNBPQMMAi0k1n+998dz++/fZfQLXPC4at88uV7dfNACJ0k9D+f+q766KbbAZrkR54qg9wOqEW1IWiDcSPGdo5fe8OXefWHvybdeAIC8zMj/fUnncmv/sDZjFeFrhMCDV4GdDS06ujU0qmjw6QRnEkBH4NxjJSTf5JO6ElMDNqC1JVAvK3SiegEjYlEVPJoLyeAqUBPJ35JAKr5tFefND11AvB1oqgWhuQEoFotE0H6kqD4jUc/gTINSB+loI3pez61AikDxd0OBFYlcIsZ6B5/JSY8l7cNLgX4ThIUme+YU19QuRg/fjFPaxbMp+xh8oRup7bMq2Kw02QQ6RNBqgTE5UWd8eeaST2FcGP6asD2q7n7a1yNbZ1hcXnEC954KkLLMLS86Vc/z8PP3M/qoVkmk0HUvmNp/YDJ8jxWB/zeT1wnz374DeANV988zyvetw0zbyPIVshAfTWSF4XWV7Fpr4BNpKH8uzuHDBpoLG5+wF9+4Gv8yVs+Dc0Mbm4Tbm4zSwzk11/7QT58+Y3Mzs6gSSqszkb+vTOoM6iLyz6DlWglkK6hWvldVnX335PgiAtBbbIhyFejkd2XiDzBanpc6YudsgW4/1oTUUdtgUGyoVEkcFVryLEkklbumCQ9jhaijxgtW5vj+0J7i0XX/01xY3F6fKPxfmVJaXq8RlFRoyN1HNdN5Bh7qmD/kSe1L+Yz2nwnEYfMt/upn0v+hT/lsPZlvH4wb/7W3sXs8Nu1lUZsSBwZmmigWd5MFfNLXH4z9YBf3oYrZSuvIM7EN9Iaxl6W8wYEOxP40OW7+Mot21Hv+JHvu4GzT7+V8T7LYChYF5OHGMFYg2tMXJ+1CC976u0ce5QizVD/7hMDDh0S3GDNVt+poLdIXuddbRCWzBa0/WpxtYJxQmg7HnfmkZx8ylHSTUL60wK6tMLZ9zmJM046kpW2hcbFJOCkMBCz8UcMzpgAfA7kFITB9ddcqNTB7630wW+FLnU4cRtwMhZJ91E3/XiakkPZDFw6IukTQ9oonBNVnzQ0JfUYwIXduTa55J/Z/L7oBZNS7XoQ2/NC8przqOxMSlFXhGJOD/etnAQy617IBd2lnL94r4gHqHCBmvUE8J859c/Ht7/Lo2YOyifcdvPMcKxpwxb1iNjyIqYXvlBtc/CnN0HoF+8m+m1/0pNebMkJIieFHPy2D061Bhx86PIjES80w45nPvJ26EwUlgjpthY1Nq7wTsmm9QPdusvqDz94UdV7rr018OUbh9iRQ8VN/V8lIVjTU4NTQtD8+zuDWBvXg2fDEmMJQTjuLjv42+c/XOdHhvH+A4z37ObonfP8za/+MFvnZ2mVtAI8bvktll8u/n/BmRLA5dS3QkiUXK1P+BLw8dTsjOKN4m28Bit0Jq779q6+n6bqoKfthnptuIPQSNxT4rQkgZCC8E6ViZN0aiN15ablPULBhvokP50kamU2NlYMWiWFXDmI7X8uFkCtzgXhWD+RXe4BsjzzER4/eR4i2lcD355ry7/teAB6AYYvI3I+/uAfs212SS40wnPNkeA36UQkOIXkhSdren2tGHz9Uy4Sp3IhHaJ5jp0xAJM4AL7q/3s2oC1CHWsAb/nyDQ6djNm1bZHjjmyjoaehwg3SPD+v7RKLiRtFuNfRiyCObhWu3+s4a2DRVU0cgGnMIVuGR26LIRRLMVP1M/3OPzUOYwe0i6uccdeNvO+F36dXfuMAXfA8+LS7ccy2eRYWW2QwwKsQ0igzJJJRKPN+TbbcGSdLRAvWrPKuvqcZsU/LQUPVp/vI5pNOMs7WcwRCYinmteE67fUfN50lfkZIYF4hGmUUS+llgdkisTixppc64wFp+3DGfTRoeq9ocXyOXOJUKSYMqdzOkw0gCUHTeyuBik6dHOFbmbfz3GpeqY+ePJF5fo2L5bPfrpMC92136ieEf/UPeKKb2D+w2zmumw9eZ1HAxXJMMgN32rizgjXLm6Py3JSpUV8i/uQtteV7pl/6If2KrCzjbYNwaHUSTThnYTjrwAYk7dzTvLEnRBafFBpvfLzRUOLp4S0r3sZe1IR+c4+kx1E7RTrSalegmryYM28BiiNLEUtAMGJplzsedPddPOiME0AGsBRYWh3HDT7p//Jp7Vh2Di+BrWnMBiUwA3ndd+/MExJQ1xk0IASvBT8L+XGNpvXipI9abfapsGjt5/b19l/NewHyfYJOJZ2yTbSMezQi/slKSCogsFiwJUMR0f7wkMrXvci+TXoSjCA+To8kBX+UGUvVqya+icfq5hCY0SC3N49gt/+YPn7yWzzjbS/nfPHfbpMC9+0S+JxPkPPxy6/mmGZRfts18gy2C34+TAR1SFrLRcXgM9M23ZKWSSh5xp8yfi34yQKf9KYshp/Z0iuvxi4rtaTYcwVvGIw6tm+00Myyf6wsdbNsnkussV6G1lcBxN4ghKg0vGN1DtiIDgJbNqyAtIhz/Zov+r2BVNTfskEY0+8OmEoE+Q1sUHEYaRiHQFhYAW1RM4TBsJz8PkmNI3FGiruOT+M2MCkp6BS7z+eRW1zrHSdkpDXh9FReTXFSVokb8BqS118FxtfU3priWxKSijdxOaiisZ3TPuZCxRYsxiw56isrcSkbhnqdsOb/KL83AqUaKCWj5L0KfeBnM9KcULI7lKb741W0wXK0b9moA7mteYm+/smP5wcnv8rF8pFvp2rgW4oB1CAfinSv5GeHq/JJt9M8wx8jnd8cOgwOJzDQ0sdJmfMr9TYrTXZcEdCZRoUjgNMj+1HiayosIPbYoQLbNMt2rUES+s6s4d6nBGiG3L5/ls9fMwtDxWMRa8U4m3Zg2+h8a6upglc+9AUDrWdupuWko0J80yV0H5sNROLvoMak/YOCGocai5cYvN7EoPdlbJ1WiJn4/6o1GGuwzmKcQ5yLZhvO4E0C/Zoe+AtOYj8vPaCnFQDYTwYS2GeUYKOsLlnwiTc9XuBNDPpgNKHq0wh/xg60evx6IoCdngYEp+XzvC4xS7hr7GAK/6mrxUoGLPXPy2MqZemrlSgrdr2lWy9Rzt+vwUSJ4GK+XQMMQEWtbpLAcb6Vo+xZdPYSHtf+Ic/R7d8uIOG36j+XGuSb/AnnhFeYj9gN5o/lKHN4t4NWR2qwYhiSltxUwM0aCW95ISxIHv0Y0iiPvlooQd+DfBGx7782BWVPoz9rSyIwDtCGx511B2bgYTLhlW/eGt1/HBIReZEY8BZJCacNhuFm4RNfHvCuyyzCitzz2FZOOKaTts2/U0oA1hKMjQGeAMWmceJGVtyslcG8Y7BhwGC+oZm1DGYtzUxDMxrQDBuca4DItW+9MtEowmkNeGvwKQnEQDa0BloCY/WMCYxRxhpYDYGOEGW+EqLaLwe1TR4ABXyLj9ERaDXQqqfTEFd/E6sKFU3ThnifDAjWU4bwTaYE2qB55BesSBFNmjjAF4nVtEoSYRkfDURNP7Yru08zLdxKOTzolySnIFfEaQGFs79AcY6y0++3OnFIDv4MEDalELQc5ls5XkW2ul/gNv85njx5TgEJz1H3rQIJ5VtR7uc+f/Fv2DWzIC9UzE/ZnWL8PC027b+yNTd/7SaeyqaratnLXri8sVeoynpSn5zL+pj/MupfZL/GpBXe/SrvqT4cgwyGPPIXTuOSyzaABF7+vDv41Z++QzhgGY9D8vNzGnEAw2Be2LN3hkf84hFcfh2iy6v87YuFpz3S6/hgwIpDZEAIDSE4hsMmUnh1wGQxyN7FhoUlw8IYlidWvY/rvxvrGLgBo+GImdEsM7MzzI+GzDUjbDOAwSyYIQTL6gQWW0FlgFdLkEj4aUazGDtgHKBV01N+I+kNb2FxAvuX2yLNzXLfwtcXwc5YVoEVYDURhDwxUFoDix0sLbcEIz3NtwIJfaXx77EFSTycRAgKkYPTdUoYOXQmlt9eo19AqN7QqqDLoKtdYvsl5VHeOKqV5Rip/E/gg/rMCJT0tRayUNEG5NvUv3RiE2oPoBRSkbYacYQgHQftgD2gi+H9OP8bvG0QQcJvgQWZ/E8GPuclbEix/k/Mj4mTF5ntHOHnxDPSED20NHnLUWy5pl15q99ceqRW19Y1IlPX0vdLRfclO+/EYiOk/l8qL3CtvMLy+u3BrPCpK2c55yfuzkQasCN+5anL/PozbpFNmxfycZa8sRsu+9I8P/2y7Xzx+llYCTzuYa28/aWesBJUFII3qDYMZkeA5SvXCB++3HLZVwJfvmEst+zrWFkJrLRK2wWNbr/x13JWGFjDwAmDQSMbRwO2zDvdtmWeo7bPs3P7Jo7aPMtpJx/Dyccfy9gbAo5ODYPZGT7+mav43BXXMZidpQ2BLuEDrffxNB+3HHn8sZxy1r1Zbn2yBo88/klQJtawtLLKFz/0CSaTltZGoU/cpWAwzjAZTwgb5thy7oPREPCSGX1SMIdOen5/pPhmWn4K/hh7dEFph47J5VcRvvh1dGYUFYm+Q0MboUI7iI4kdz8BPfk4dMXH5J+Yf71VeF2SJtDQJ0S/Cuq0vKgP/tBnL41BHSXFPkEOXtJt8+Okn3eRQqlIoFWVPa7hDr+qQV/B7Mrvc/HG3f/T+MB/ewKohTsA7V/yJLNqf81sNPdnm+LndBLJ7hnRT3LNKe5+9dtmxWbh90uF3NYJgOLiSxXUmhMC1cy/Ovn7SUC6rVaLARIAF9Ti5sdc9J5tPP3/nEprZkAdJxy5wOMecIecelJgvjHcshv92OVbePenNjFeWYbljvvcO8j7/6DVrbOO4JMKUA12dobLLh/wiouWedcnV1g6FEeQva7BJHGiVqecJslsRuVCvwzUewhtPLoOLvOMH3kEf/6bT+OOg6sYO2B5omzdtoUXvPwN8pevfids2QhdG+tcDaBdfD327efMJz+GX/7dX+DgwgSxsUroiIYfOtNw/ddv5E+e9cJ4HxUh+NSeNbG1CS2g+uDX/habTjuOpaUWNVKEPz6d+EEqsU9k3Wo1VpRM+W2NsvSjL6G7/CswM5PQQB//fwLSzIgeGsP/Olfl159F2DuJhCrV2kSgnyVOXTN6WakH80meAZfqc+3ifcTXt09TA99XEXgttGImBUD0sojT/U7Y52+C8MfsWnw1f7714P9UInD/rYF/apznA7Sv4aHGy2+Yxn4fO6Gb1xarRjSt4soElzozlfl+ivyy+Inydfbj78X7lNurrBntJQMIzeu9S9LJ8//8aW4TpGoP+n1hRmG8OMP5T1hi0/breO6Lj+ea61uuvlr5o69tIyoRLUxWYgJxK6ATnvxo4c9eMNHts0o7ibFmnDAZB375FSv8v7dNxC97mHU0G0WjJj6kNeKZx54/F8nj7JwMMX2LE5ucAS7u7mDrlk3oIAGBqQ9uURnNzmG3bsFtnCF0nWh+pyoYa/DAzIbZ1KvHHt6X8j8CXwcPHMIMBpi5OUIXej/+6MCpxgzpFla5+k3/yOn3OQ5vFE2PXfn/32nEGJEDKYc23mO3DBi/41N019yE7Noa/QVLgo5jgEzCYt8+CYpKYyg8gcDU+6kX/WhPGMiTSZNPb7IFdHqPaN+Kunjf3Jb2FWmqXmtOQch+hYJ0oC2WjRpkYxfY5o5ir3253r7xJ3ji+MW87aVvQMSjKpyP+e9KBO6/O/Anr+MMGcuvWivnyy7Bb9RWnQpBbATntPTkkra55icye7tT+cJXT31VvyTPfqkEPkXcw/TJXzgDksgzUv3/cZSX8QNhrVAoO/OAtUK71HDuQ5b55Buv4VVvmudN7x3KtTc7ltoRhA4ZdWydn3DmqZafPK/jiQ8TaB3dWJCBBdMw0QE/eOEK7/lHj91scRsheKHr4t9ZexLG7qh/g+YwL09E/jtUCdrf0LdjRk5jT28iFyIHtFePbycYP6TzyR8LioLOewO2UWmgM7G095UAhwYO7ttPGI+RkYv9r+SFHXE+EXxQmWm47cOf4JZPPIgND7g73dIErKkIRTn4+4QQXYZi/MURoCEsrrL6Nx+Igde21fKTqgzMxn97DmDaFh2Y/vTOQZn6ftUkDc8EoVBVkFrjUIkCnPv7zBlIv2Ac/8UEUsbOWXBkejxAU2VRjEgjy8rqls7LZvGy357IHfav9Qde+NM8+YW/g8g7U7MhnPdfnwjcf1fg6+s5KYzllzDmR80xDMJG7UKjio/u+AymN+5UG916pl4F9uXgjWuf8+qnEgnVKqlK4CNyJwSxPLaRqkJI5nGl9KeQhHIbUdoJzUkiEm/aBcu2uY7f+Jn98otPNVx1wzw37e3oJoa5mbGccNRY73pMrAi6RYdgMM7hvaGZs/zUS+E9/2RluN0x6XwawucMFlQ1s83SR1mDjPYu2CX4NQ+7M0HGGGbmBkwIdMm52Ct4a6JJjyoaKp/sUmHFJz8Ylc6gXXIt66oq2TWwuG9/XEJS+C3FTyf9PioYA+2qXvfad3CPB54MTapE8vYu8jxfygKfukKnC7B1wOrr/pnuyqtgyyy0bZrB57JI+i2r1sCBBWR5CTZsJtAlK6K699ViF45Jen+TJcPV01ExAcv0yafkHHImTO/B3O9Ln0yyBVn8WSI9hd7EQIMiHkFxeljXySbUHHAP0D28Q5/YvZvB5P9ysVzKxf/1ieA/nQAuugh73pVo7vHHf8u93bI813fmf9mjzLzfFIKf0VY7bMTEpHjjBZQq1rMzVDp9e0poKuj7g670/z2I26P/PbFHqgSga739C2W4J/tQUYRlTQKJe8UidTb+nhZjHLYx4FX8KszOwr1Pa7n3IK6/pmthEvBjwQfBWoUQopXXBuUt7/f85cUdzRbHpKu5rZnZElLQg28DtF3iw6Zv5vamDCqC5mppStzoRmzcthl1li5ZjAcVOmfoCjS+dsNG/8J4AhMbx4Bqe+C7dYJ1sLjvEFPUHmUKp4gBFJD5OTl42eW675++wNbH3IeVQy3eRgp2oQjT24rVhBFtLOHAMqtv+CCMXOype5SIwuJJx7IagUMHlb370e2bi+tPfp+QgOa+w0zbiFTLqU4iLskUkaxqP73Wm90j8KdTlMoeAwjTPGrRZEkedLoN8WIYKXqE7zgMZJ/9fm4dfT/ndR/Qgb6SN8q7YyLIGMF/jlX4H04AehGWK+McH2DyV9zPdjyP1pxvjjHDsAn8bGgJaiSIlYa+RC9BfmcMMmQ6dlXgFjs4Kamgeo9qhfSnZR/TDNOpYJbe6K86RU2fqosRaFILShwFhpoSTCTsLKw2HFocIniC90m3P4wrwTIYh5dNc6Lzs0IIsXJw0tC2A373jSYS0Ip/VfKeSuegSCBMAnTCtsMcx+4YsmnTiGY4UoyjC9CNOyarHSsTz6Flz+LimKXlluUJ0Hm8b2HfHmyS+wYbN/3muX7IvLv01IR80lWVgI9035gATMIb0YjmAwt79idDTe60pie/zuU1sUZu+It36fwjTsO7GPjZbxCtXl3pDwW6AFsc41d9DH/1jci2OfABEdMHf/yoZY2wEWVxDHsPxq1oY00gbzqxM74UKv5/Yvj14HPs/8sIMff4FVaga+nmmYTomQ7+ID3dMfQ/k5C8DzV+Lq64F0X5yFG+ZQeGffZRcgeP0vO7Sxl0r+Svf+dtiPynE4H7DwV+ou0CTP6Gh9hWfk6N/IA5VpzfYrSb11aiysRi0xKOqofvqfuJ1ltpOaSe8km/9y0H/53GgEol5jDF8MMkUIkaG6Av68vXGVyscILS80vmAZiKLuzwwdFscPzm7x3O69+8QYYbO7pgkxmBItn9UgO+bbn4Dyc8/EEd3WIEEgezwpeuMHzhqx4ZxjFgT1iPic8YxY9bjtk1w0uedwLnnLGJbRuHDIdDsc0IzFC9xt+l7WDcGlY7y9Kq4eCC58Bi4NCi57Z9K3z1K9dz1+O2cWgyiUnAxJhqTQ6dCB5k9uw0vqKIiHoTdf5R1xZdfIIRVjwc2n0IjCEEH+OkBOYUTAMakPk5lr7wDdn3oc/ppiediT8wQaxDiNPNKMDXvP0vBseMpb1tgZXXfQCZb+KEo3QauZRLlYckoMQY1Cu6+2B6/yVWYFU3SDaHyQhe0Om+M/RCoJgY+seg5pzUrO2+C5rGCiT9v/k0C73gwdQORaTqIxV0CpYZ4GjfcpgKB9w53GbP4Skv/ARP+fVX8MuDt3Jfaf+jUwP37+rxgb7Ht+f6Tn5OGh5r7grdrIZuVlunanzA5uUbWpaxronb5NSqdflfne55vbOab1YpTKP+xb47g71pwUTdJ0siAtUkoFI5ZNPPohHoyUF9a9BXCY2xrCw4ee9HR+xfVPDZocfEwXCuNTvD1m2OU0+KfoFiI8DHIPCZr05oFwe4TQGfT6RsFS4QgmdutuEtf3B37nffLbQHOyYelicd2nYaBUwhHSyR+tu4AZvnh2w+bMCxxiF2hLFDOh7A/sUxC+MJ6pqIO2XjDiNT1VQBw4r+Jk5T2uQNIDa79URGXzteZfnAIVKD1/dlUmEJU6IfhYHhtte8VzY+6nRlYPvCQVKqr0//1iMbHZPXfBR//W3I9llou+kJdg0cKcmfOL0BbtuLMWiwgkpIwG7dBlb7xUgIvtaAYYU/5aC1lPdeFAkxRSTK6+PVUPgGpQXRfvIgqfuqF5RAv4Jea0+hgNVZQTb5lp0Ce91Zegdn8Yf+8zx9/Eqeev3f8VgZx1Vm8G91JHL/1lO/jPPewGOlNb/KnDnHHi10m9SHgQZarFFjQ956XT3PoTpZCsorvYjCal8hCb0qpB8F5lXP9JOBCvmPFV8/uusBRDOl+isCoRLUUrn/9pwBk09+SXP/4hUYJwCMhCs+P+KaGwUzl9K88VUparAm0LXC/U+dsHNnx2TZlBXhWMMte9LfYFzPTEv1o4gQxi1nnDbL/e7ecOCORWwzC8ahONWqOgmarulv9F7xnY9IfVim0wkBS3AN6pp+7i5EunHyzy6CFl2zalck0nrT+KozGQNQaBwr+w6yemgp0pjLa6ZTYxrNwg+AEJDZAUtfuIrdb/0IW57zcPzeNm0FrqoOBKNKmHNwyyHGb/ggzA9i6T/dCGqx/q3bgfw2uXV3fDg7DQNRV4fJxFlNbx2uUguImE4YIVGAtQr+/AYOFYhoa0KRlAQRkdW+6JOQq5381OVWRIp5aYGuFKuzChu6To4V1X32dLnZvlbffNwv8azVC3m9vJUL/+1tgfvXxDq8KCL7q3/PSW7ZvMTOmh/iGKHbph1NUGmxeCyNVC9d1nhPz+1FpkXcJm/Z1aQmqVZA6xT3R3tdd17TVSuARaaWe2SUMM7xpVLKUX2eT34zvf47twKmP/HzOm9F8MHihoGPfHaebnGOZvMqne8lpuVVNYpOlEeebZQZh19RnE1kejsqpKey37484Vpy1J4DLRNGNHOG1XH6O9P9at19FAxZPCkRpEmFmqQUlCQiEuiy8aYRvKEgXKWMVan0eKYQr4KFNmksyti8gaUDh5gsrUTdRN22VSO0emKTVXPMDLjjrz7A/A8+ADMaxvGhScad+Y4+4OYdS3/yz7Q33YHZNi/a+bSgRVP3JtU7vO8XVUGsRW/bFy2FXU8YLb9i0F7Lb6qxX0gYa9C0NajKZ+XtLPVG0gxSVXbjKW5NJg6tMVSwTGMCWr19yLhDzWxLQ9L+TR/X3N3Fd9wFNbvtPfUq+xb90cl72Nj+Fq+QTwL/qj+h+f8r+UUiut+9yfykm5hP2VPtD/kHmC7chVYGYoyKVSfIUKKXWnaxTr58xtVefNIv1KwFGvnJS1ZL6TaKFY3CjWzVpP1t834/6T9qdcqXysD0231LkjD9mFCT8k9qhaDJdmGSREBRkJNFRMYYaC2XfHoGXKTVaj4m1Be4t+uUZn6Js++fVC0DhzYGb6OycdMmn8rDCp5GUQ2o99jRkC9fA7/5qt0MZ2bYvK2hmY07+FZDvLbEU9xLtOP2Jq3SSoBdl/r2KOLRCPylUZ6mXDR1LOoUx6oP4HzyS7L8MpEEpANY2X+IsDrGZPBVa+hW70Ts0oTSy8yIyVU3cfBNH8XNmUh4yrP21GfrjCPceJDFN/wTsmEm7gVLngn5BdVq8lBRQBML28LeA+jqBBnY4gYV8k6I1KaKyUm0UggmL0MpFmH0YqCmV5kWG7F8v6IYzCpPKV6DVL6DJBs7mjgSL3Z2Ln9f0YEiA0GGIMNYecoQGGpcxz4EMWrEYTnWd/Jw35kzmsfKZPhRfnL8u1xy7ehf8yc0/2LJfyHhwMfZ2r5B3mA3yavk/rLJn6CtNMHQYaNTtaQ/Jv4h1vXqKbG9DFeroJdktEi1oFMs/aIOQ0RFpPhcTK3yKmw9E/GBspW3bPuRsvnHJEsuNYKpVH1ipDxuQXaLBDht6pWkEJReGqxiaUaGm29zfOILDma6Ah4rffo2RtBV4YS7ek6+W8dqG+W3PllvETz3uJtHBiGepEayOr02rMXMNLz8VdfxoP/1aV7xuhu44upDiDVs2jZk07Yhw7kh6gxjSF79SktgIspEAq3p0ftO0h69FPhtzGN4U+potILxMyqPxr18UU0YV3916X5hAAv7D0EXkoleAtlyLas6Rd0qx58q+A6Zc+x93QfQ3UswslGHb3KyV+zIcOj1H6a96VYY2GLgoX2fQLHulWk0CSXKt/cfRA4cRAam2H1JsYSrJcKalKSSDEMlJYFp2zLuZDuX7ORq2XF+XNcrDNUqkrdSN1mqrkijaKNR7j6g31rdEBPDMCYCBpSrDAUdAENBR/E2CIYhhtN8ax4jYo4ZPJ+Ljv4IL1k4jYvFc84l7t/UAuR+f/mDHDO8Xt5mTjCn+7sxwYllglWJQS9TfWNfEon2K6MKSq/VyZDHzmtw4tL/pPpMEpLvE8IrKlNTAhBsEvcUsU7pAPq+3iQE35v+pKstvyThACr94s9C/U23U5NWZQULI8cnPj/LnlvAbI7bKnrsPv4NIpF/e/aZA52bFw4uKMbarN5haWy5732Eux4vXHu9wQwDIWjBOXLG0+CxI/jUZ/fxqY/fymCj4+4nbeJep+3i3vfYxumn7eKud93Kpm1DOhVZWjUsj1U7jXLWPIHqJAlq8uZdUbzGhZwh1aoyhdmHVBrELSpeAxMTV4CrkSjYSa3Agdv39/RaMYnVEorhhqCxP7YZ+u4pzTIaMPnGLex7w6Vs+4XHstr5KBnuAjJq8DfuZ+GNlyLzA+h8H/j5lPdhyt6rnxqld6ARdGmM2XMAPXFn2lRasUaDVoSxCsBUmWYHpvVhVHbhGclXqQK/Jz/27YFNXxvtdxOsbSF0mkaRfx/JY9Ra6ip1saNpyU3+G0IEC7cDj/QTc6W9b/jc7D/xq4tP43fn3/vNpgTumwW/vp+7+j18wJzqTvCnMJaJNnSxkpW6R6/p02mFUwFUqPa3hYQN5BVNpe/VUjZmdp7RKA8lqcSq16Q8ObmR86V3p3CvtYh8pGekFXqwSSh/7P/FGAyWUM37pyTAxhYfviAGH0sVPvrpOUSjS59XShLJr6ASwAjfd86QQMCbuJlcJfoDjr2wdbPh53/C8fO/rNhZJXjtlU4mDaFjO6B2xsDcLJMu8IUrFvnCF67l9eY6mvmRHH/0jN7rHlvlvmfs4p5nHMmRJ2yXZjDQpaXoB4BN4hoTz/e420LpNLUQYc07UCtGZtXCeyIVmKjXxEd/VJZuOVC0B1oTugWh87htc2y476ns+8DnVQYWfJsCMDnobJjljtd+kLnzHojZuZnQdTGfNHDwrz6Mv3UPZtts3MyTT3tjYOLhqB2400+ke+tHYH42thE1DGwM0raw55DqIDMEZQpoVKVw96fXhifsSachkZgIqkDNlWvI8dfjkGtnoULsWERV6nJP1nAw69ei+BTK9Ewlt0nxvZ3GlWJiJSNCMOp4gG/NJrMl/NPw7fzK0nn8nrydi9Ryfp8EzFTPfz5+8ZMcHvbLO+297AnhVB1Lqw0SS3wpfXwu83WqFNeq/BHb8/xrdxZJbrdS9fHFnEHSglxLvF3d75ts1SzpflIEROWwMnWPb5Lffu2qI8WlV2zsL0Lq/YL0+wFEkmNOqjB8sgQTJ4zHAz76hQ3owMY3Sn0oEZ15fSds2en1XqcJix68cfjk5tNKdN/dveL48WeM+MEfhsntKzjr+1Fl5XGlGufjvtNohDwzwG2yuA2NdKHlq1/bI29+45d5/i99gCc96W/5yWdezDveciWCYdOWubicw0QdwFhSKW+E1mjR5PdeB/UBpKWlyZ5+wUjplb2NS0IWbz8Y3YsK8SkSbnIZzqBh108/hmbbFtEuJNFPDgdBBo72xts58NoP4xxIF2hGDVy/l4U3XoLMN6gPa0bAAQ4u0jzuTAbffz+0NWXcJPUUwxgIXvX2fWtMPFKxUvr/3hK8rJAXnd4ePV0U9j1/3i1QWl3p/5+8eyJ5V6pRwelU61FszJ1OORdnJ6Le0VjJuy/MIJmNDCIeQMYHRsmJaKQRK+iwep/QmccaK5PR3/HLCw8vvoR1AsgV4O23Mz/8hrzdnGJO9acwptWGqcU4kuzpMnicgTit3FHSH5DdVLO/mqn7di321lo292r/ApREIpHRlZ1hzZrlGSIF2LFrvl9+nvmwueRPwJ7ma7LRit+3xSabNDfK14AwMwx8+RrHFVePkBlNPnX5sIhb7EQUxlZPO9Wy6wjP0gSCMXRiq6vDS8NiEP74D+Z44g9Be/sSwQuuSYo+DVqUKvQagKCK9wHftUrosEOD2zTAbp5hZSJ8/J9v4H//3HvkaU/6Gz74zq+yceMcnYExUcM/zokgsviS7m8NzVrrFk5zTRMrYIkMQHVCN+5YvmO/ZERbRPo755mrc+y41zHsfNgpcOhQBNSKf19A2xaZH7L/zf8EN+3HDC1DCwt//RHxdxwSGZoo9c27fyIPX3TjnDQ//GCabRthMEQSAKtTtG9URdFrby+gZsYB8qhaTW0V3yeEslDGyNTegOw2pNW+gGIlngK2x8WiMxCNxqsT1Eha7pR3GCQwMQOCDeggLh+JS6HSfTPeNkw/HwQYCgwNDEzBCXSYdDZDkBmBCSbcMwTOZcTK6GJeevAkLhafrcjiq3QxRi4kbPowL3N3tWf602RVJjSabbMNZUU0a0w6ynYaiW5Y9eZdqsxab9jKp7tKBuT65RuS/fgljd0zg6tkYJkCczTdN5g8vosWW+XET57+UlUOUrECiz1YwgFUDCGPzdKK7ICJTD+Uj142YHVvHHsjNiHSWtRvIl7pJjzkgQ3OOloVOky5erHxaiwrHibW8qevPpoX//4RHL7d0e5XwtgjRrEuAopi+uWksRwNqHpUAz7EhBC8YqzDbpzHbRpx1VW75Ref/WZ+77fejwwbxiYGf2s07u8z0ZUnFDterZG1qXI0UqHjbb0qHVHOu7I8YWXfQtwqpJpoxdLzL7wy3L6NZmDZ8bSHIDODZMqZcJ8QokZg4Ghv3cu+v/0I842VybW7Zd8b/xnZMES7NBrVKMwX62BZMeeeBScejo4sMgQNvld/xmY7kvqNwE17RCYILo2FK1A5Vql6p/dqtpfL4J9WVWg+oIztk0M+uYs3YEMJcKlOc6lOdXH1Nqsc6KRgl7Lspt4VK06RQTz9U9DHXbGNRIBwkADFzE0bgbRi9EG0co7byg2j16AZEFQxBfR7F2c3s/anw93NBGjK6Zp5+SZO56hHd/kJTE9iqE57LR/78l7LaVzJdm01KTCy5raR4aOiUo/3ip6gSh51a1ASQaU7oCj8Kv626Qk1me8f8kck8f9jVRDzpeWSy4Ygq7ViLI4sTHzzeR+QQcsD7g+LxGrCY6LjjcTPs+FFMIaxh0Ot4cefcyTveu9JvOA3d3LSCY6wvEq3d4xfCgQfBTzGCibtrpcQKnOQXtIcvMd3PlYGGxp54+++R171W+8ROzMjE0I0/EzBP8lCNkn1u6pOKTSzjVrS7pdluQrBGcaHllk9tJJIPMqduH9eGe7YTAfM3e8Etp17P9FFL+IGff+aRDXMjbj19f8oSwdX2X/RZXQ334oMsiuTqfriIAxndOYnHqkOtNs6B7MG7YJOrYLO1sHOwt5FldVWo82cVgAa1XLYvjIo3oGmL9+jfXuqWK2U6rZ8XSYJUsaD4gRJy1Tq5KClpJc1ySJOBOJkIJ70MujXRpZATxOCuDc2QINKg8bRIfU6yZg0hkCL41w/kRMHZ/O8B/x8HA9iDFfGl705JC829xCjG4LIhMwPY4pkIWvEGinITD3Tl1DUVvW+zTKuWzMqUalHe1K1BEmnYVBMFo3o1EhwKlEUqm9F6zU9O1CFivffj/oiwp/twEw58WMiEHxSCrrGcPu+AZ/+0jCWWh7Rwu2kcBJ07Dn2WLjb3WHJ+56Eo6Yg8Z0KHqPFl18Me1ZbNuxQfuZ527n43SfzuovuwXN+9RjOeNAWNm5w+KUJ3b4V/OIyoZtQppT1302PHYTYJuB2zPPW//cBvnDpV5mZmaFN/IE2rfguMuo8banm97kNKA49ZJvv+PPFOw7SLa0kPKWWKmduvafZMR/vF2DXTz8WmZlHQ6b6V/79zqF793PtBX/Hnnd8CjaMVDuvpZc3FrUOXVhW94DjMWcdj289ZssGNZvne4HPFCEI1DnYvY9waBka2zOBMgfArjl0pMaxdHqsV9aJ6TcxB80afyn7CwtXwKVkYKXf+Vq2G0XX5HzKkxyGp7gCA4mnfhNLfM1JYQA6iK0GA0UHqnXVUBLHMLXfM1geSUDMC3j1oe1cTHByIWFyCvezW83Z/kj1dHHUN0W5TzTFkF+wmrYrcZFEv1Fbcvboxx2mdmrM47Ie4rcyvctdCj0z4crxMXSKU5LenIWmmwM/B1Ut651SB0o58fOpqYktqJqSQvLMV8nsP9g4CHz0y7PcfPNIzNCn0XPorV4CWKeEsXDmfUds3qjsXYmefdl8ND8uYjVEQxL1eeBphNXWs+AVM3CcefYWHnD2USwFwy03dnztK0t86bMHufLz+7jma3vZf+tiJOfPz2EaE1V8BU8O5QRUJ0DD+173Se51zj1ZlZaARuIQPp5y9UhH88yrfzFCCInIFl8Rn97DK7ccQMctdjgidGHanIRo0zXYsSkWA0urbLz/iWx5+D3Y955PIvNNcs9MfNCuQ2adrlx0CdI0yMD12Hie7xoHatBnnk1nwK54mlGD2bZV/bV3VIQMI2XUaAU9uKSydwE5ahM6oZfsaa9ALOzgovyrnGbLUpY8wk6EpXrpSPFfSPSHPFXIT2lhu1a8L9aI5GpCczG21URTpjBM1+7D0LqisZFLPo2rJY3DBOGeoZN7N9v1czwN5BVx1UYr55sTLH4YPBNcJa5KPH2d0t1LoevrmlGHTL9mcCdjj3yf3vwj6b/TE2nTaZMpvvH9GJ9K1eklQDVivdbOa6oULfZUJo3jhIrnknz1yvshBX8SAhGnACBc8tGR6KrFzXq60PsWxAcM6XUPPOjBWeDSy4g1lUNBq68RVJx6NRKXdMSTolPDgZWA1xWwji3HNjzk2K2c8+gjWUa449YxV1+xyKcu2c0/vvMGDu5ZxMwOk3hEp7jyIQjMb+ArX7qNm3YfxG6bYdKG1IoUS7TES86z1H6ImxKJRKu7JMFLeMHK7oNRmScyzWOFMgod7tgYq1+JWOGuZz6Ife/+eEaKeyfn9AaQUZNehMrqK5/Oi6si9zkJeeR9VFa7+PwPDObwbcXoY/qYSMGyOEFuOwD3Oqon+JvecaSM0kLlsGSq2Zz2/BXJhkNJtC1lHdn0cyNVEOSk0s/3+zYl46VS/87ZTkxqExItEwnN37eVHHaqLe9f0jxlk7TYRMGY+6D6JZ7BFVf8mdErGDAjj2Sb9jYbVRCFlNGMVM8Fa9jXRqZsk7TuI3O20p4rYqTinvepF5FoDNkb+yRwcEq2X/P1e8RfpFqQkYJNKhQfsajYct/Ipc/adik78AJShDV5Jx5GWPSGSz/RQNPGoDJMufOIGHwnDLcIp93bsERcEOpTAsnXUJJCBhiJHAMiRhCBwrQF2AlBlPHYc3C1ZffKMovjMXOHjbj/I+/Cr770ofqqdz6Jk+97GGGli/IFrfQFWdDUiB7at6C3XL8PMQavgZA8+8MUumv6E65iNq7lqeSh3HjPAkXM3qceFUKcijROZ3Ztjvs1ncNPPFseciobzjoRXZqAtZhKAVkcdrSuGDOn3iCTDvvMh+FGDgmhVHD2yM0RGJWSyssmQUSVzmNv2z/l7oVRjUuYVLGo1szAPObLAKH0uwEoAKHB2KqNKGvIK8pwtYk4jwMls2VtnArksr+nDEu1AKdH/6VJ7cMAlcaoOIke2rnFyFMEJ2DD1HKU8ja1ikwwHBtUtsq9efNx9zOLX+JkmdUTmFEVH7kKUr+cULshTs1jK6MtFSPJzyWxvyQXjKFWuiYr1Fxhp6g3Ub4RK/H+CQ9S99g9n7/n669R+5VRn6gYoyo2KuiMK712PtkVSxnjiRDElpM58j76j83AcO0Njsu/OoBhRK77niVpDYyITuBuJ4045jjL8iTvxDMlsXTJ8CV32h1Iq1Z8Ov19Sj4ZfyjuOCaSkox1iDT4znJodcINSwfYeZd5/YkLHqLGeNUwVpH0i1VJ3BDQlUUO7FuMAZewC08gaBqeS6UAnhIEJJJX7b6U4nThlv1p/kqJtUIICoo0lmbrhoIoqA+EgWXns88tQE+hIEsv2hKpqHXq49x/aYy5510Z/cCZ6lofuSRZCXr4pjQhjLuSEiWt+EGiit6yt6c1SV3zS0XoUSSud1Q1olijVFT0Mi60gAn92nAT+gU0NVXYCOKiWjvrA2Jwpk3MLnMIKh5AspWQWhOQ+nkzMJq3FvW6m7gqvcciQqG6i9SVQKoCOkW34PUoZzng7meawAl2Vua6xobYmE4l//ImMDIt7ChmClNWWxKnxsleorAeK6Y50/4cfSmeyTgmCcILN8WUKiCNDbU/1dcu9Oy5/ZqsvtXk0Z4pI77i8CP9mK+c/on1l1mfXTAMUT7x6SFLew22map0U+VMFAlN4AH3N4waS+tTRZEcpH02uVShRWSiSD0R6MgVR9qlR961R2pb8t8QATdN68z2dytsPnwDzYYBIVNjp4d4uZGXLvXyQeK2nn69nVarlOOxK1KRgyqjDK0+rtx+sKgAtVIUgKA+YGZG2G0bCjsWE7kDGx91H2bvcxK6NI5BUjtFTKkievdeXVnBPeOh2PkhxivGZJs20F3b4smnVTlcl9QWwo17p7wAC4hd5vlSIBokcVHiQaRSu1bbmnA2XXZrWneeJ2PpTIlVQ54E1CPBoi+oK4VaUFetG6t1M7afPOQtRCV5GDM15RDprfZ6k1lgO9DKcUas2cKMicm47vtqbvQUAz/DNmlpJnVvL1O+ylq8NUWNGE2K6CpIk0Q4CW2yTZfWZrdp25akkzZkW64K+Ov7/IL6S0hASFx7nTbeFhPWGOTx908pv6D/KQnkxZkSV3z/00dHvV0UtcYhW1oLNIH7PQDGtAXb8NonFk/k32MFOxyAswRRWvVMQmDVB1Y9TLzGpRs+MPaarnHXxar3jH2g9VGYM+Nm+eJnb2Z8wGMHwyRdq/jwSAQIh0Md7ZhlQpeSW6wAVNc6APU4VuagT8l6NP7+YWnMyu4D8bQr4HD1IF5xcyPMxll8qJbwdJ7RTMMRP/bwaPZR+Nv0zJt674ERZHWCHL8L+0Nnxaxoey6KAn7HRmQw6BeBUltAKdI49MY9cW2BrVpKW7P7er6JVOPtYghlVet1YmX83ROBNFYPmt5OomWlWAzYmLtLQCtYNClf+7K/CuysVExcA+1JSDr18wSyp/SlPRlS+oRcA/oAMgdY3eoIoaXaTxi3cmVefw/yee0hm1Axl6X6TFVFkkKzgP9aHffV0RnLDSmHTsb8ReoDKfkFSC/0iBVd3Y5IpelPjUlG9XNgai8aCtrfPqQMU4C63B5U5b9xcMeC8KnPORh6fDDTCSebxI4D2w+Hk+8pLIYOFdefsFIBf8awvGg5tF8YzRuakdKMhKETTJKDRYmxJdAQEtPDMyDgGKN0GJSGpSXhfe+9gtdd8DFkIHGluISK2BOd9tUrm3ZuYcddtzL2bUpGWizTanRnShOQWgWdVjuKsY12i0usHlhIdNu+6yCk09F7BtvmaeaHhK7Xn4izdJ1n2+Pvyy1/egzLX7sRmRlENXB5h1XNpzGw0jF61rm4LXOw0oKzZSGKAnrYRpgboeOVmD+yGCH/4tbA7fuQg0vophlog2BMArcqTn76mzWt/i6nppoM7sXAmN5QpTXiP3VgCkz5XQuV6EC0thXTLF7K5sZrt2EVI9P+Pdd7a2pvi4ZOxYYU1Z7cyVQLIbgg3OoX1dP1ugBf+eHndCIJHdapYY9OPwO5EpDaam2Ny0x1/1rfN2UONrXqS4oJSF8hyLRqTvqKpIz2qmQQlL6/F6l6/f62xUij3F/ogmGmgc99ueG662aRUZegXzPFljFGCaueU+7uZPvhqguryU+EYlMcMQAPGweOj3604QU/dzNbd3hGA2Vm85DNmwZs3mQZzloG846ZGctoNMQ2LpXZ0ftvaSXIoYMTdt+8zPVfO6S3fv0ANAYZDERD7WiZTFcE/OKqnvDYu7Jj6zz7VlfBNKXNwFabj7TyruuzQH0og4hagywdWGJyaFnFmv7E0R4j0KA02zdhRw1+te0RcCNop+jsgC3PeDjLv/KXMDdKdN9QqWRSeb7aYo45nNmnPBh8wBtTRneqUTnItg3Ipjn0liUYuGpBQkokTtADC7BvEd02h7S+wjrWBFlZMV6p0KR2TE54/1RJJEX9LMKaJ2OqGiZbMKn0PxctA6dpzk01AcgemVp7Gd6JeiVTJjpGq9tXEi9F4hJHIwccjmt1URftRDeFET5J7GBKr9f3iLIGKqp9eorlVyFZSTXzzM5N/SA0qKQJX+3zr9O+9+l07iu6euYhRcabk0BuV4NUQU9/4tfBH7ROHgn5z0lAo1ORRfjYJ+fQVcGNBO8pZAiRPmPjA2c+wGAwdBpwOXFlwqBIqTSuv2WB1f2eW7wKY6JlbZhEtkxIC+hqyLoYxElCiCSCYwMwc8P49+e1YLXdmQqqHkzgQU8/HZ9si7RaWEMyRSnPsUavwSl+UHWiqSoWWN1zCL+8Gsd2IdQuUmnkFBhs31hGfCKmOEKJEbousOlJZ3HHq95He8tuZNj0Q3VN4J11sLyKPf/BmB0bCKttdPkplnEaZdQbZpCtm+DG26tRdHW4GIMsrBJ2LyAn7iwOT1MeiDLtJl3P+KfOL5OcgkSmAVOmtBD95qmqUIgHV+iPv5hp+v2ztSu8TO/EKCTNaty+1ie3z0fae2oXWyItFA8JiO4GrF5lRudxvV/Vb8iiJBxg2tt52iJ6ajNd+SqNitN4tD/btUzDi8dv7/OXxvsFN64R/4L6G9ZuBa3tvzRbf0klxS79vVSOS1Lss/rdjn0SKOCf1vbtsSVYBT522UyRwdbJvay08mDnLWc8sGE1la3V/sjKHTriD7feuIBoS9MY7IxgZwW7QbCbDG6zxW4ZYLcMsVtGuM1D7OYZzOZZ7JbZ+L1NQ+zmISYFX1zqUZlvJ3NJO2gIdyxy36fej+MffDwL49UIVlaVT8YA0ooOlTWnyZ3KxpR6F27bD+NJ5c9Rvz5xWO62bii/j5T1X8k2ddwy2jbHtmc8FJbbfqadZ/AEaBU5/DCap5+THHbNnY4cgiIDg+zYDD4UtmoNg4gITFq4cXdRv93JgysD1bWzXGGy6p2pw5VGRWpdQWYY1rcX7e3qe5BSxIj2pUQ2N7uzhZ+EyhpPp20N6y1OpWXPXyfnsNyTKxCMwj4sN/pVNupHjQittvpudgtpfWHZRGOmrKGr/1hqzKEHT81a326VKttK+cWmnog17YGWPkcLdbcaG0gmR2hl612X8loFW8/nFyrlXj/3r+b9GfSLg6SYIJqhcuMtA754hYGhR0OlCdU4ohJRwlg55ng47m6OlS6+UcsYT6YTQUfD/r2RzBEBSoMPQvBK6BTvpRQCwWv6fug/th2+6wg+xGlkv/Au+RlEIMk4Q3fHCic9+p784EufyFI7KVOJghDnUyGEqcpLMl6jPSmlPNtx0q6rtx3UOHoLUdWn3OkYG+zakrwzpLbqS249VrWD7U99MO6uh6PjyqdCkwvTwgKjJ5zJ/LHb4xowqUwza0YYwM7NNR1Ye3fghMEEkBv39u6OwvT70KzxyZrykJzeYrVW7q5mjcakJues2UWzhgBYxUePQ0xpGXJzrEk+PbV0pPYT7DEM0VpxWXkUxtUVgesMeoDPcOrbLzcA7ZC/81/vOlkSS8JGVBGvWk2Iq8m/SlXiVxTIO6Hj9KCh9gOqO5dWU8bQMjWDXmusIP3WGJUeQFlb3pd5vkyf6qFOFrliyOh/5U7chUihvuLKIQd3N7hBIsMmApAk3ry1HpkI9zlzyPxc0ElLRTaqKg5NdlooS4sDEdeIJj/AinHH2u0IOk1pTEyfkCVIpa8TE9S4OIwPi2P8gTH3e9bpPOf1T8XNWIL3qOmnNjY5Lql60HE6MWrZppZlJZLWN+dWrgOWbk0+AFVjVhiYqeF1mQOQu5GqdDdGkLbF7djExqc/HFY8ONsvR/GKbJxl5lkPif93X1KriNW6ZQmAHrU5rSfL2og8v0gggHHCdXfUdmcyzcyr5OMlYcXjN57wZsoXYGpT0BR3TksiKNus1jJTy1qyvuDqHdTSarF0kuU1hxoQ9YimMlJDXFdfyTT7+2TMS3sr8+JVG2zQyxE0vJHzz/curlLhy+M3+PcMbmie4E8xE5nEjb29L+za2Wy/Q1Iq/7g1GMYU9ReddmtW1WrB5RrSURwOa59YlGpgTL9JlrI+rKcgmSoZmNTTm3Ta9gCflglA+n520k1NS7S1UD5yyQBd8nR5wWRtF6tRdEPXcuaDZjXgUGkJFZe8n0bE3nfcBm65cYK24Lvk9mr6xFJAzjvtQl8LnaZEHeLMXZfHMOlgZsBxZx2lD/+Zs7jnuXdj0ipd14F1yX08/kZl+7VoBuDSaZcmCSE1MWGChlDe9z6t9F64eU8CEC0qedCae1sPjWVm5+bc/KmuHS+jkU0XYPtTHsiB13+YcOBgMl8FDrQMzjuHmbsfFYFAa7WmGZvK/V8Ac+S2RLJKz45Y0CRbUg/Wq968J767bD1FCtO8faoqdQrvqjwTQr2qrp969QC8icFd4QAqtdyiGC0VF/W1dnd5RiAyDZD3LU4cc/fse4mcu3osXi1B0QC6QYJ8AaeXd3dwj+U3g4rLf9riYfpC85XuXHOYs7otqExqqms1nKlsvaOnmsn7I/pA1jKKFp0agWgFXCQQJG0AKaSOKjEXg6r0xwSlEFQKb19q/ZpUttg96Bff+GZNkCcnIO1vF98OpvCzFzrDDTdZjjixZThvCD4Qghc0RGa4iXlgNDKcem9liS6NIPkmk4ZIXFkdtxxxVNCV5cCkHcjSQmB1dYyOU5+gaxfWV+48AlMGdNYio4ZNm0dsO2qeY+93JKc86kSOP+tonG1YXFmJAhpp0iQkgJrEAYCWUKYAJnQQXG9vrYDv0C7ahnTZCs8KbetZuuX26J4UTPT885OerdkqZmaemR2bMVMakunlL4gSxi2DI7aw5QfPZO8fvRPZthntJsjMgLkffxg2j6A1THnjiYiKRs6YAdyxO+hm5qLnWfBpEUC8n/ooOuK2RWRpAkMbuRE6hcT3YVYJdnRq2Um9vir2UXlHu04dfjo931LTn2dUZ1uVGr6Ze79m4o5OJVGRehluT+6ZggVEplesYRVz0Ab9EA43uYBnb97HRRoN0i66CHv++fiFi/iF+Z3uD/1ZMsHiCFXuUpn27+trvWmPQK05AtLvUJtCByL4kdFXBcl6+v4UnLJ5J9AzN8rMXs2a0t8W7734s7w8w5bbF5BQExNQbZIDRyF4vH3GBSyLy7MIwwjsaSaaUn4fYRBXW41CWgITWRsGqwGbtu7Z9H9BwGKYYbLasLRiWFgMHDrkObQfFg4Ky4uB1UUYryrjMbRtLPW8V4wz2EHDcLZhZvMMc9vmmd81x+bD55jdMYu4ES3CeBwIwYBtEtHJlefG579PDcE6Vu5YZmXPEp0YWiV5IPbvnOAV2boJd+R2tItLN73C8jduox23cdtwen3bEJgksoazjsEJh+Mbpz6RlkIaS4V0VGQ2YmsMYWFF/HW3Q2PpVBk7ByfswmhettYzF71YAiEBrfH0MKst3Tduw2sPivZryuOyF2kc4fjDIyAXSvhpL27rCW2q06BbTaoUlbzHrE8UeidgLp51QSthkFY7EDOkobUL03S+qcKpwgZETb0Tj2r+VoMNvfRQRTCzdPp3ZqCfm7yFPxuexw9Gg1BZawi68kb569Hxg2f4+zIh+Ea0KnN0zZIHXUMb1r40TWs3you9tqOPB3lIf4OR3sQzqwR1ataQZyVFVksKKiiB3TP6bFX25+Az5edTty1JwBY8IAt1VGzqm13crkOVdNQUlqBi6YKtKgwbF4iKSzBZzzgMieCDcWAzC9Ehif+pifATyUAukYEcSlP9bhaPoyNafU2AyQQ6Hx8/nvr5d47B7xOPtXgdaBQqmUGDoaFDaDF0xYAjOSpjGaOMxx0k6nIQsANXwM1cq3RQfAYV6DofhxTxlS4thyLVNCbRnm0xHpGkk6Abd9lkvGwPVklU6QrbURAvFtz0Il6+GabehbT5NyeAdLSrVkRmmcandA3BR6uJtVYLQevJw52SQkbia8VgdlCviFb1Gux66qRaj+Wl3uGiaysGWbMcd5N08i4zCB/oLuecgw/mGdsWuADhQgm9K/B5BL0Aw1P02eM3tEcMxT3CnyETVJy2FblnzbQO7clCUxum8ws0hRXUfOSaQ4jmCq/e9KSy9nnPTK3MNwipZ5VpDb+mxFMx/lSk3zdfbjPtzByknxB4jY8XuvqNS2EIBjFoML1VWmkrqt9dVXJFUZbGpNfY+0DoTBbkoHi8Cp6Ax+FxqXJpUyJw5TTPgZ3pzNlt2Fqbgr0HOjPjr/crThVMfM/jJx2t+kRbTmvGal5FenwrsfrJgGW7Mil8G18B0/kNEEzURyh6JwGZrlk/RYZVujbrCMEYrJisWJweD+djQXuwzqhHx0k5rv1pqDW/JPcLd6I+a2GfSb8QcIpaXHZZqqSzuteTq+oazsv0oahTSGggb4EoeaGACD0tul+OKmVFY6HdhZ5xXyYE3Jmyr41F5n0n7zODcEl3Oyes/DDP2H6o3hZkasl8+jhePDM8efLV9r32U2agnXiaoKUJrCzkNFRbTkOaioQKvUx71iUjkUF7uaoGsSppMY724+uqRJpeU5dGhKmq6KchGsvBrFir3tz9r6b1abFm3l9PCqTcr97y1D/Z2o97Kp26Jq88rUC8oiWokk+/KTqLlbSIZMQYjIvX6DAbpaPGWow18epMpTbLXojR4kvXrEfLp2hOAIHQC4AkpHFe4l9UBqtiBWPTchMTRUdqKqpvrv+yZVY2zqz8GK0TnDFV35+nJnXwaY/3ZqzJmCjyKWo209uGFUp1foObXh2qFXZss+t0ej5s/v1MtcZ3zakiSr0jqR845eG2Vvsq05it1vtHFVwWwPYBXKH4OUNKFRvlBfFRMaa+J4+ol/S15s+FVkUniHZAK+kKEi2eykfGOUd0nbzTDsKHw3UctvhoXrDxK5yntl4VNrUy6MJLUb0AM/dDrNq/580P/FjY0eyX+zMQYXPwdGpI+9IlBXdpDRJwLNqvN+751X02NbmPqmw8MkXCSDV+mRr7JURdezeinrtPhe6bfr6/ltsvNTBYm3WYqnWgKAP770mlFch8gvz/pMeoaFu5reiCTcpDmSInRfzBlsfNKpKgFh8MXvL3ozrEY+hCcaGMvAHJnAVTEkz+fbsQQbMu25kj1d9k1wCUTLEiQ0aw01jU52SYzENCsg3M9uoRJ9G8EL3A1vlxvQ95fV98kU0SfHc+RrjpBbpTOzJ6LwpRREJQ0Sju6ik5PjIaxEjFHraVKC3y7SVT1afeWlMrTDOK1xe2aqY0EjK1Nq1OIlXAB6accHKFENXWMjWTF60W4GaGmqfElFYxlpNH/JlJCULLqRUP3HRatSnrzxDsAVHeZZtwuf8IJ02ewP/e+LV/dTEIgFyYWgHBC/ozK29sv9TcYn/Xniob/IlMaDCsqMnMIltKv34rkKRKIJJ6euS+JOBQLzlMlZdKbyGe35zVmDDPNmsWnmohraYADSkgp6cDoZIc9xOC6eUsYYonINNtQi6ji0V2/Ls6r9GlyucTPjPJDJtGI1pgadKioilQTN+jloQWk8Bo2NAiLE4Ur3lNOTjbMDsYsYqyPA69kEey0KiqihRmhyMUy77O430PbGl5l9q+Fchgl2hNW6fT+DvY4QDBstJ2dAHMaIQDQjvJgR9ZCWivocgaEmtpBpYJ0C23GAE1Ae8cZhj3a/vVri7PJQesSLaliCy/ASYamLY+ti1B0VF0rKcN1cg5aP8GNH2DnbpySdWnGCldQkXUnebTTs3nq3lbSAO24t2lpaTPdhaJ9FBZjPW2YNF7dc33U8BrAphN+lwrkD2Xt7LWVq9ytKJBMRr4nGvCJ0EXJn/EL1//Ak46afzNgv9f4HtWi2ovjstCFt7OaaMD5k/dYe5BnBAIhzFRL1baPnNLlQBKiVgLo0z/JEum1U7RJU3lDdAv/ERIOnjKCR5qU4/k4phP7VA0/tnZwZZTV4slV972Y3tgrTqVCwiYHzc/htiIDaSFyKNG2XcIBnMz+M4JxqrIAAkjPvWPlu2HdbLrHhopleqqk7hJIKZDGWCk4aufXWR5JXDMmVsjMGcaBmaWpd3CtZ88xPwJs2w/eQMTDyqW1ue/KZaprVqCbbjlU3egC4EtZx5NmB8QPIj0z48kcbnX6EAUzwBTyl1VocUysY6Va/fSHlzB3O1IGA1Y/MINYlrVTfc+mrYxdF6KdiYxKMWrQmPxe5e444NXsuHM4xideBghVqYs3rqfhfd9kS0POYW5E3amvYZE/4Su02jOEreIdyhmzyH8Z28hnHlX2u0jxqueSeMI7/8Czc5NmFOPwg9cxoVUdRptiFWXTvFQpsZshQOilTFf2WKt6RSX6WCvT6EaCNTprb4J+VREJWjfDvQ87AocqjcF93ZlPRDWJ4qK9x6/PYjQkNxiG/0i6NX+q8x2z+eVo3f9axuC/8WtoRdeCBdejOoFuOFPcevD/0H/+vCP6h3mOr2bWWKHsWLCnLZiiKtpQ6VGrBJpoShWa+EyCChr1Ev1ikrqcrCWd+d5vql89TKjr8z0kypQTWkHQvpap4Q/fbnfawHqvr137S3fQ/DBMBoIX/iM8ivf37BKIw954Ayr3smGZk6uurKVX3z0frn5hiUe/Yw5sTJkxswhRmg17ukrbYZa1DT89jOu4P1/eSMP/dET0EY5dIeRQTsjX/vcAX7/By5hYWGVE886nAN7JvhVxY4cmpSOHcJKAO+G/N2z3i4f+cOPc8oz7s1g6wyhU6xxOBkiZoRKnDJkBWDvZ5mehwBtF7DDWS756b/k0xf8Nbue/lAZbtsiH3nKH3Llqz/CCc86GzM/pGt9PrklkYKZdAEzarjm/32Ir/7Mn7G8DM32jRy84nomw4Y73voJbv7p/8uCnWWwcQNLV9/O4jdup50ZIBtmCSFIUEScwTWWPf90Jbc/8fcYrwT08feiG1jCFTew+ojfoLt6D4NnPxxnDT5bhOn0rsY7K2CrA748B3ce94n2RCxZyzWvAMDMJZKkQJOscgsSXaP9mtKS0rNKqQhCZP+VttpX/HEP4kG6WOpLC9oqdEK0MxMvt0vD56zVj/vd7PEv45yDz+YFGy/nPLV8+UVw6TdjGfwLLcA3aQk6vQBjhE4Jf7L/Et4wdy0/K9fzHHeEOZqjFL9VW7UqjGNzHEzSUxudZrBmb/+pTc4yvT2IalcblXlrpunWq7RrPKBiHqpoKd11ijFYIfHaE49CvfmmAgrrZBuStbWmLKdeGDQjFryRv/p1OPpY5fprOy59825WBRjBVV8N/OTDbkJlIIOZDXSLlqf+5lDv/4hNLI7jG7YZOkZYZmcE4wJbDpvhms/tkd957KeY27EZPw6C83z2zV/jyo/cRGCIsbM8//2P0vljHe1YGUuAkZOAsrpvmbljN8nMXbaqt4YNMzN84V1f4VO/9zmaWcdkaR9qPbSGM37mEdzzKfdlYXUMKYjMaMQMTTSHtAOCDGhDiIs3RgPEqiyFoAOEZnaEAdq2TTsJlNH8kP1fvkmu/8OLkJnA3n/4Z/a+67Nw+43MPfXBtFfvBjuni399CV9+4yfjjr8Dt7LhrS9k55PPFJ0EwmiAv/o29v3z1UxQzHHbGL/53YRjRrhjdtK96ZPocAZO2EX7N5fBMdvgIScRJp2oiW+mkEhn9YErFU25N/rUYuum1cmv1K7BqGa2s07jXpr7zbp1KESqNGAM2hNbAtJTdntkWEO/X7AHzdMcPyUIQlK7OhQjnlvtQL+B1Wv9Mr57A5va3+blszfwF/Avlfz/7gRQcAEQLsLIwzgA/PbBD/o/m7lWn2Fv5jl2hzmFIwx+h3Y0QU0rVjXbEVdiHl8bMGi1PKSWPsZILOuWK536lJtAJTzok7P2PX16fK1689gnh0oDkPt5oZ5V1xXW9Mc8i1EWJoFT7mX4P381w689coV3X7TKSfd0LI+XuP1Gx3DzLMfdY47J8iFWVwPjLtCqwbgB4Gj9mNlZ4RPvu5VLXrfC7usFH4b84bO/wEOedBQP+/G78OE//wY7T97CA599CmGp5SOv3cNgyxwPfNoxuHmRznsNChuGc7zv97/ANf90Dct7xpjRjL7jx99GWFnisJOPYua4XdzxyW+I7BoyaDrCuKW9YYmDTzyUtn1G9ZE0M1z1pk+z/4s3yanPf0J8dwTP7PyQbcZitcG3HePgGRnLV3737Ww7/a7seORptKtj3MCxeu1uvvSUV+EPLbHjH36dxb/8Z1bf80WOfu+L2Pv6DzD51JVsff2viL/6gB586dvZ9uc/QnPPozBHbIU2rvZyBpY/fz2Lz34lMr8RBg20He0L/5LODVC3FWYOx7/1iyy/5iPYH30YzTknRcCtcsPVKYmTjduU1rLS8kFT4INCQP0m1+xeXZf6plgmSdXjFwAslZaSArmeCBQhTwruuF0uJQEvKcGkx0SikKdVletdw3VYvbHbqx2vZ4d/NS8bXQXAOeq4FP9vCf5/cwIoIXd+GgVfjJFHshfCH938Gf585xc4X2+R57lt5j4cJYQddDJCtcWWAj/5rEV5cuZrJ4TVpBM/UKi0ksxXyuitGvWEapN95AVoZfqhZaw4PRIMCQw02SeHIDkhSEUg6WWh+f8J2qsUNVmL2QZaOh7xIMeffmSOzUcFtuyEjTvneNVzlnjGbzsO7m5Y3D/Pc39vV5rNt6y0IgcnE41VnnLrzWM+997bsFs2YdxGrnjPPh75Iyfpj7/kQfKVS3ezutJx7vPP4OavHuSf/+hjPPqCE3nSj53CdRxipe0QLAbL/i8v6Y3/fKvI/EbUN9zy0Ztob1yQxTOD3v2Ew5F2P6c89/Hc72cfzXVv/Tz//Ky/AQkySVNzVJkzDTe89Ut84y0fZsOPnkPQFkLgjku+xswpyxFYGwx0KI6vXPgWvv6iN8mGB9yDsx54khoXF64u3XaQycIhNvzYY/Bfvo0N5z8QWW1pt8yy4QlnYkZzDB92b7q77JHhZ65Tv2nE7ClH4oYNeN+zQ4YG3ALNzz4R85xH0x1cEH3eqwnX3KEzF/1vmiO3M/7yzYx/6JWYQbVBunbAmXLo8FOU37IQSUxPzJnuPVNPH5FOU+nr6z6/WDXUaHI+KYJU4/LqNEnCHemVYtXapXQAhv52DEwM/Gtto1+BcJu/AauvZ+eh1/CSbTdGHo9aLiIg0vHvuDj+nZfM/SiJ4L4sQ3jdJcrfPuBV/vHN7fJcs1kewQmWsEM7dUF1kpYyu7RFKGdR06Ojapkyai17MafZxeVF7fF4E+Wo9A6zoXAGAqoWn2jHoWJ7hYTMZ3S/JIViET5d/lMpCrEwXhrw5tcOWV2dMCuGYx40YRvKG1+6yKYTLCfd2/OSH13WiVp51LM7urCCHQY2HTnEiEWtcGjScZ8f2sG9vv9oXvnMr3PHDZ6//tz5/MNfXsFbXvAFFnYri7cs8QfnfoCF2yId+FNvvpZPvvZLnP5jJ3O/Hz2ZJd+ysrrAE//f/bnrubv0bU97n9zvpWfLg37s3vy/s96gg+0bUCaoX9LhsJG5YYOdi4nMGIvipVNVkSBKoNk8i9m4MZ6Wdgiyic8+9c/5+kNPZbB5FuOEzz/vtf9fe+8dZ1ld3/8/35/PObdMn+0Lu8suvaiASABFEbuxBQzEltiVaGJiiSUxLKvG2BJjjd3YogG72MuCihRBkF6Wssv23enl3nvO+Xzevz8+55x7ZjD5xW8sIPezj3nMMHvnzt1hPu/6Kuz7ymU0H3wUR/7Ls3B1i888WZLSf8rBPGTLu5n68RZuPP11DD71YYycfjw7T34jsmwAaqPMfHmjYjqYUUhefDnZcx/Pqnc/H5IOXgKC1HqBaAj3nZ+jV9+Kaqx+xxxok84/X0gSCczNQDaB+rSrUJWLbISoZroY2/zy+5ygXIXKVg1rim1Wd+1UZPZFRiB+IQ8/709Lowvx2p3w++4Uv9prSq79QiY5RkC6eBknqBEvXpU7bMxt4He5m3D+PRw/91+8cnSyvPhHo2wS99+P9H+DAeC/DQSBJPYV0K+kH9InyDXZ39kR+yjWWrKlPtOah0yNGEPhJqvFHrGktFf0RH2xfq3MA0qXouKCV8REqtLVFBlfcpBQVQcgXPMwMKxe/O46rbsm6yIzyw1E3s3MzcF/vM2RtVJlKuLMd2WyZtozfVsHlg7z2id4laYB63nlyTfD/BRLHzTCeT8+hIaVoDOHZXA4oj7cILIgmnHNtXsYn00ki2OGDo4wQzWMNyw/vI8VxzRx8/O4TlCqSPGk6nGaMdo3wOS2GXCw/KHLmdcOnd1jNE9fGwRIqWFtjJLRSZPSCj3/twpAB59vKuKgBWHqUGty5KYnsuLYA7nh4xfhJmbZ991fsvLZD+PwdzybvgOWknZaiDF49SSZYfLiG9A7d7F60/OpHbGKbO0ofR94IbZRI5IYI0qnEZFcdwfJW78EA4PUgDTX8yugviBQrxP1D0BspdPox3fm1NYtph6gxkgKUUwMZKaAaWuhyUYBMwzcTpUqwm+hIEp3naG5Z3K53tNKoPAL13fVgWCg52r5cVn25xe6CASq4fKX2d9J3gLkrYGVgGy7M4r1LtC9/jaM+zdOH/sUf7F6jk8vyPiO/8OJ+D+eMhDkMwLOwovwHfDfST8hfyw36OuiwfgRrLW4VWmqxotkxqipbgtyb0rbXRVqxTcwuJkL6hUvwXEmV5HMK4AiCNAt3VVKlOCCfj//43IySTcwmJK3oJXHsjgo5DyQeCjh/T+ocenFRj77NwkOYe2xjj/915X0DQ7iXSJfee+8iqY8+e+XkyWj9I0aNEo18aFwj03E3i2ea75/N+N3TZCMO3nn477Gi3/0GB7/ynVc+bWdXPiG23nEKzdw+JOWMj7Tpt4YpL/WR2ZTZpIWxsRIDiG++9Kd2AOarDx+BXdfvBVmd8nSw0/TWqMhEOF8SrvEvLn8T1DvCa1N/i+2DWxswadgHUf89ak0RpdxzQe+AlmH49/3Ig5+waky5xKy2RlsLUZFcV6JI8vk+Zfqro/8hxz0009gts2w5y/ehtZiJR2AwSExri3NVz9e+//kVEne+nVMvaYxAbxkNDAVM9+BdB/R6U+Wwb94HNYljL/683TGJrEvfBjxmlH0pm34H14HtRibY2C6jlJdWbAulT38YqgssIGqsFoqq7lyj18xKPHVjVZlVVdy9jW/5ItWe8VUvwT8aKkUI4VEkssxYR7P3TbWW0F3ujux/n08LP4YL7IzfLQY7uG54P8t4//GA8DiGUFBLOJsvLzAfQvhW+0PZ38aXWNea5ebE1mnZCtIxQTmidhuua8VWyRf9E4mh0laSvBQyM22q1orBUjHL2zFChrw4j9SBfVQCRSmu2lYvFHQ/PKjeC+IVQ47ps2Wu8FlGS6tUbMNHv7HI8S1Op1M+eaHUjE+5YTH9mOiOj5Nmd3ZYWC1JU2Fgf4+vveJvWz+5y2wPCOywpPfeQLfe9ctfPJn02jcwO2f5wsv/ym8Cmoj/YCQ3D3DKf/0YB7+t8fSns+o99XZs32cOy7axuBBwwxIgzu/fzdgdcUp6+nsbgeLMx/8AEJ/maHe5/9uLWXCvWZgIupRHOqdbI79e2cYGBjAZ06pG1Y+7YGS0SG2hnigj3aalqhBC0RDA0i0jChxJFv3kN2+n/5zn0X/IWuQ/bPsefWnqd+5T/o2rAbaaGc+KH51qeBkcy1wHTrv+Tp7//WikC2GaiAdOk9+Ix06YPvA1fEzrUBACkkkLxRL9H6u7OAriqULZTS1XM35BehV1YUroQWXv9IKBORed3KfyyOUiD51lbLGd99rnv1zCcSMnVLT26zVbe5O8B/k+LmP8crRST4JbNSITf/74d7vPAAsCAaLA8FL3BdV3VeSD5u/MGP8Q7RaDmEdZMs0FY+VrLBcLvy2q+JJuSqJL6yacqRf7j2nFfFMVd9108kz/4JVYGXwF8r50Aq4Crko0IQlDzNaGQDSDQQ4vBfmnCdtB6H3oXqT975Quf3be2DIQNqBvkCg+LtjboFmH0zWOO01AzzvnUuYSBPaOI5/0mqWrFsql3zqJsb3zPDwl25g6KAaF8+2uPuySU58yWGsOXKQPXfM8LOP7GTk0AYnvnIDy44b1cwrkZjAge+rc+gZ67jtM7fw2Seez/TWGYZPPZYVf3Qwt3/+KjB1IlOjBjifBbEMLX4mXd5l2AikpD5sGHBtYaCm9biBSAMwzEzOYpYOMPfLHTCf0DxuLWmY8gQn4DRFM9WBekyn1hD6lpPdtF/mb5/EdGah3kKtJ/MKzKsmLdK8EhFriYHm40/Afv2dUG+q11hcs0brvPPJrrpWap/4G7WrV2IJycGvX5bbrQsLlblz9oJo4VaD3gMMtJC9t5DaXtWZq6wJ/cI9sVSGReLyi5+7uqiv4vsrrUCO0iTCyQSGW23N3+6mSNJ3c+Tsv/H6JVNlj38Bnk2/3nDv9xoAflUgCCxO/8nx7/Plgds4x+7jVdEGsyI7ECeD6iVViwafs4LOXfw+FgObUjUrh7UWsF7F54CfhTJfKtW877tMPi2GgFJm9QJfUEAwVXy5hfDqSxsrn/MInCoDVrHWYMwAXuv8+Wvr3PLEeSQGn9b48rvHkASedu5KfC0ibcGG4xt4L8SRZTbJ2HByxJEPG+WKr9bQPTXGJ2bY8NhBvvXWBD8zhzGW4x57ID/69HZMlvGwTUfwoKccTMt10DTD2Djs7/sjnvSxp8lVJ1zOT15/CWgfKx59MMNxH3FcDxnM1Bign0ZUz4GzjkILKPwy2EA4ylq4ZoxIhojqxI9vgTXj2OYoUp8VjMH7mB3fuY4tf/9FPfY7r2TpY48jm5vPq97wrHUjeCtgLfG65choP519u0E8kXpiEYUmRAFP4L1im5bxj/6UmW9cg1k5iPrCGt7jd+wBC+4b16Mje8JA1ijZ3Ax2pIl9x7PwjThcQOny+as2Kd1bvggksKifv+fbQg2+Rfjxco8fnMykMtlXqoSfgtxDjJc5UW61sd7uvXayT7M0ezNva24J67zNERc/8jee8X+nAaAaCEocwWOZAv/28U/x+YHb5bxouzxfNhibrdMUq0acLBAiCi1ClwUSKgGp7Px9DvX1lbI/p/JKnunLgaB2H19hFFaxh11kZmVmUHDR8/7ZeaHR77j6F47//KdBfKPONz7SZu0DUv7k5ZaIQK/95UUWTfp45l+twKHM0ybBMduZRaSWQ5ID0982+pGapd7o005zjid99Gi544tj/Oxjd3P5f+6BOVhx8ggHPKQfmKchgTvgJWDj43rMxNg4d1+2DTShtqyP7Z++ju8MfJmlhwwg/XDTxy7lzi/dTDIzh/T34b0jzascZ2B+aoZkLkOa/dz8j1+Wicu3qCaeG5/1Hhl81CnY0QHQDNtXY8CAjs1ADXwtKmvhGoiJG0A/iRfa7TmY2Yuf2KemM4mOTwht0XjpMoaXDrJLhpBaM8A/NFiXte/cQ/vHN8JoE7Ikl7vq4JMZwQj+0uvx0RBqIkRTaM3C4Qdgva8Q9UvIbkWMsmD9SMXTVLrT/epksESBVYd9uQhuuOiyECVGqdGnLp/oZxVV2CyvDIJjkNMttsaNoOP+Yvo65/LRvh8vyPgX/3Yy/u8lANwDR3AeVp7LNnAvaH2Mz8Q3mDdHe+RheojBHeBTHNZ4wUcVrkAVE62LcJ2FxZUUQ8AwTSmrgQVKwfnaTxYCj8PjTWVYmGedArJbrBK9UouVrVtg4xmDdHYLDz1njpsvU975+EmWnhiz6tAGUaODFYM2Y33rOROoiZibnKWvv82f/stKak1LzTTYetMMN31nH2N3eEzcYHa3Y/tPZ9l+87juun5K3NwsfatG6D9miL0/38unH/oTjn/O4ZzwvMPpP6hBkjm8jbh781Yu/oeLdfzSrax71vGc/I+n8b2X/oC7v3M7Qy84EvUZ2dwsrtlQ9Yq6PrHUMPi8gmjw01d8nm1fuELpH2TPf1wh0Zo+GT39WEaOOpBVTzqWG9/9bXTvXq55yYe13mww/tMtmOUj9B28IqziDESgYutIPMSsCO6wFTSffCw6Nonf2aY+NKg85mQ6t40zkdwIJsKljhTwxpAkGYOvfSJL//axOGtIVUk1kH9mnvVeTX6+RQa/+0bq65eTpZ6OQqYeYw3SrJXc/VJ3r6uLL1Q9K7Q7WF4wEMx1IO7BJOtedFkwBCxZecVEv7rbD0FAs3w2YHGyX63eGNV0m7+TWnYen6l/Grdonfc7PBG/45NX6lmFbLR5o/pHvP4DvCweZ2N0sCzLDtZMBzySiSkt60uvdKnoE1elg6vdfr76y9eA3f2+r4CzfJcaXKAGWYgH6OIG8pYg5yMkDlYeIBxxvDJ61Ky+4p8b7Nxq5Rsf6OeazQ1uucziWh0V1w6vJRrA1GL8eIdjn1RjcKiPmVZK3PTMjmV883V3KX01TnrhenTe8J9n3g7aou8QePCLD+TEFx3KsgOXcv3XdnHJh7dz2Xt36/onbaBxCGSJUmtYbv78HYxfOs6Rr3o4x7/pEfT19/HoTz6BWscyedcscb2fw15xkj7kZY9m13du4qd/+V36lg1jcOqDQTPLTlzL7N5xlj/yWJY/aB19hy/HrBmhnguQdGZa3Lp1irmrdzOXtbBNy5q/fjR9a0fwrQ4g4SLPTKPpDG5mnqVnnsLAmaeU/6cM0N4+wc3HvJqZdgajw/SfdEhuhGrUeHD9dUkH+/KLHCS+NI5QF8FMBIP9ZEN9JKkDLBW/GRVdWAV0veQokXslmtwvklusVAaLSD2VYR8Lg0MRBLLwvuT7Ow1ZPxOwqtLGy5Yo9lt8qq3svRwdvZlX18dBhbMuML/tUv9/SMy/31NIkQHMX8hB8Q7ZFDXtczkCOmtJFCKP4mPBR+AMeAsuF8NwUjjsBpagE4NTG9RtxOTvJVfYMThszgK0FYZgwcyLSiahL4lEXdmvgiHo1GIiYXI2Q/oM4vqI4ybWxDLfqdGeiknamaaJByKMraM2aP43RmvYgYjUgVpLu2O5/ao5mo06hz5oNSaOuPKHEwwu7WPpEUbsgCVByFIYigfozBh23NrS5SeMMp9meG+oxTWySWXrtftZ8cgDcSlopkitRs3WyaYySWYdaX+E62+oSQTbdthGHV8LP5cUITMWjWrUqRGDJN6RJZ7MB6q56evDTrfRqYxEvc43I+Llw5BmoAbnIYvrTF9xG9M3bWf5Y4+lb/USkjTrwqxN8D3Y+8PrSNoJfYceSPO4NaRpIFoUCte+AszzCklkSTZfR7Z/nr4nPAgdapKmrksGM6VHhJYUWRVdaF9XQe35RYo+Kvfs76uZ39GVuHJS1XsPFz/rfqw5N19VQ9a/28T+JoPucxcx4l/L22o/75b7v5+Lf68JAL8qELQ/Zp8aZ/IOs16O6ByKc8Oq6jA+gswqPhKcAWfyyy0S7LWluPQ2t9sOASDYcNsFUlqeqnxWIZxZyG3lb4X4h9iSGlw8R+YNzgipMyBxrgsYiUQR1hoNIJuopCqHfYDFZzHex2gu+5UZi4lihBpZGl57XGsEvb/USZrllYcRnLPYWlPFRswn5FazucCpjVEb0Wo7hChPSiFg2SgWjCVzouoFZ2y+fy1AFuHn4DXX2VDBihFMCJYOIdMgEGIii0QRCaLOgaYeMV3pNacGV68HcVTfQTKtJMwQqBOBLKrlCEuPS5JCsUc9Qpabyxe8D1ck2FqU4/Y96nwFKp4zPsMMoKvLq5LHgK6NUxe2K/e46NoV6VioE5epqFeVcq2XU0crAz/Nur0+mUCMSgvPjTb2t7lJtX4T//ZP70U2+bLP579n6d3vAgCAbsRwIyIX4MavZHjwajlXGvaV9hiRubWaOlHrBbwVskoVkJmiArB5NWAqbxIqArH5pQsCmV2BTlNeeC0CRC7U6QohUemKcfpCTZiINLO4XHknGLrb3IbcohqVFzRo/YWAJBJjbA0lxklE5m0IJkR4iRCJUJ+/XjE4VQmechFerWb582EiROKCGkbmhNQpanMRUJX832m7UucSIeHfIE6Nis19p4ufR4FmC2BcKfQLvCkUjXPDEzE4DQFAIlMqEhUmqN6FWYm3kj9/AHYVlZoD0syRecUbCd59ob3TgipNjo7FB4CRM8HmnMyjkcEbG/wQrKDWFLLxqhU5P80BJloR7ixVUHy3xA+qPeYewJ6SI+5Ew2CvavdUDAND9lcHpDnyL1Ind5tYrzPohP8WK8wr2SS3gkohxnlvuXP3qgDwq6qB1qd5bJzIe+zB9qi5I8nSfo/PxGSR4CLBmZAhnAhOuheyuAAOQ1Zk+zIQFBc/ZNzwix3kt1TzKkAKAc7CYCQ8DikCQUxUC5nb59+nq/wbLh658EfxS10Ep7QTIVILFYBGtJ1BbUS9HkuKkCRGjdSxxJhYxKF0OgYnoi5XOhbpti1OLc5GWBuCUEYIQlReSxHAiovtUHWZC7+4+c/E1gJkOJcSEy2ewztqphZUidpp0NiLYlJT09R1EOdzH8f8Z9qVf8UhuT8dpLnijctnBS0TKqPI+y46PPf/cwHvIS62of0AjHN4a+kAaStFmnGYBXXSEAS8UlHz1pK9R6WXL1R7K/1/F9ATpvfqVQqST47PV3UgLueQ5ys9KbT8MtBUIGi4Oq61Nb3FTar1f8/7a/+OFkCe381k/z4fAEpFovOwsols/2UMDd8s74yG7Es6Rxpm1mmKU5sZIbOhHcjyVqC49F7yshVLtqAFsOVlDhfd5B9Xy/+ofJwWajpqylbBiUUw7L1jkM7cEErGfJbgVDGmXrrwCDGYUIWIRjiXEQ3ByME10DpKA6RBPa6zd7ItX/yLO1l5bJNTNh2s/aaPW781L1e8dxenvOEA1p86ymzqtMjWlJnekhjL3GRGe2uLWtQk86Fcj0zcFSbFBMSjRxwGTKTNg0aQ/gjnwUZ13O428zvngvyWIC7zRGIYPWwtW953Ce3BOge8Oph1bN/0Tea37NED3n4mtVXDkDrEhOrKZ57IA8bQytmTXhBnRNUr3hjUwa4XfIS002bpJ16KHWgE/fBcAMZ5ROs1Zt/xTTpb91B/w9OIopjOqz4HR68ge+PTiS+8Cn/YgZgjVqHtNGcDmhzkqV0Jbq2YpuZ4f+nSdkvUXm7LJWV14LrkHa1cePHB4lwcaJJP+mt4dmG5xorudj/kgOyv2NS4GdSwEe5NWf/3ugX4tbcF52PlZKZBX9r5L//D+Ofyr8sm5cCxo0k0CjW33kNTyFccgHxFHnqRDXiB9CMo5RZy32FDYMIGQU2pLNwlEhnimvL+F1u2Xuqh2YH2NAzGSC1C543gUvAT+TjLQGRgOuWwMwZ50ZdXMdtKadRqdCY9P/rUPpYcmnDnpWOkugQxSBvHdV/fxZ3f3ccjzjucAdsP3om3sQqetne0VEm9I6rV2f3du7j4Od+A/lGhMYBpGPWz89CZJuhl5wgrVaj1QTrIad98JssffRDtmTZRo5+b/uUStnzgB0gf6GyGLBlFZ1NO/ukbGLtzH/vOv5S+sx/EwHCDrR/4Jnbdag5ZNoBzWfAYECVtpdz+7I+Tbp8MLYHNhPkp+t/x5/Q9+SQxLsPaSGtAcv123GyHet2isdBpexEj6r1KFkWYfVMkH74Iv3ccee2TcZ2M5PM/QB5/HPFNJ5P+2Udgw0r4z5fAMauDPmBVtTl02VJqVgabEVHVeyD9ZLGRZiH/VaD6CjHOipS0T7VgtTq5Lor9da6Npufxkdo7EDRw8yVjE/faE3EvP1LVIDjbn7//G/6SkRvlQ0vH7ZPHjsfNrpSgtFEqOBW8fR8GZPlKsKAYUhX9pNC+LwhDOTZeuhRjL1oR/OxSh1MvnPR0x/oHZkik+E6Nn38vpt2J+aM/76MxIHRakbgsDQ5CRvHZAGtOGMB7o05TMpsxsz/hh6+bkoe9vsnAihF8rQ+XCfvvnuL2b98Fq2r84C038f2skE30Qsdw7BvWsu4xqzRLHd47ho8a5ZjXnE5tsJ+7Nu9i4ur9svKph2vfgTV8O8WYCFGDjSxRvZ/MW/rWDpI5hxho+YTRJ64X+7mI2oPXM/qMU9j5ph9Sf9ByktFBRh61nrELL2XukluZv2sffnqS5Wc8SWR/qrrUlCvSWJHOlnGSvWPYIw/Ej0+jN92J3TtNbfsY6cw8EkfSSDOwVmnUad+2l/rqYfxoP+pVvPNkdYv/4s9wd9xK9JdnEB+0guSmHcjSBoKnvmEF0b+/gPm//CS8+LPIRa/BxDZk6AD+ZYHRTEn0KVXAK0AfKcCl0m0FKNV5SrUeDYM+zTRfi4jKrCq/jGJ/m7uRAf983l27gg+osBFzbyz573MBoMo43LyRaNlT2IHVp8x+3G8cvphz6ydGdv+hJJoGKzPNm7dugDcVIHDVHkO6FuI5JLiS4/NKoBAMsTmAKMcOiCfNHI/7mykMsxgMadLk+hPqJGnGU95hdWlfJI5REjJSCsitAeq0OmnefDmmxhLMMrjy83Nk7YiZi+a44IxrWXJEg86eNs0Nwo6f7aG2aoRkLCFeKqQ3zXHgi5exAo8TxaUdljx4lDUPXsMATT5/43eZ8C2O+/tTGD5yNZlTGjYmIoK8SUpQ5lxCkqZgBe9SWfLQNUQDw9QPXceap5/Cnjd8jei4Y9j6vV8wds6/w/AG7n7VN/CtGYiWsOeN36B15U6O+cqLSFud4O4jglGDHHUgq37yRub//XtM/NWdZFv3s+/E8/DjYxAFD0Wa/SL1PvY++E068IY/YeQtT6M1N4/GEUzM0f7g95GRAdGXPpwWEK0ZVYZGkFYEjZjGX5yEzxIya5CpWRjuQ60tXc/1V8F5q5p+JcovlP2lcGeBHHNFL5Q/Lis+Z9DYe7kTq1dHolPZZzl+7hW8bGQi7/Udm/D3hbt1nwgAxTk91ycEkOf5TZNf5tKBn7sPHTQbbbj9KFIfq5E0t0kplIPKsXAoxX3BGCzhwqbE/VcBQl2eXM6SE9slB+WQ1VYrMOzi2JDuN6SdJsZMccXX9tE3GmnkG6ixJD7DJR2WPyBidI0Tkw/vLBH7dk3jW+Msf0g/O37eYmCV4qIm1/3Lfg7/24PwWcL+q2D9c1dz+we3s+G5a7nu736Ob6IJDlXFiCVrp0yZWWanZhm7dVxpKJc883OhtDUNiBuYZg1tpzp87FKOff/jyVKHmBivwQSMOY8ZXsbk56/hyv+8GD87A1PT1I47lpWvexrxslXs/dSVJEmNZS84lZpLsIcuYc5luYKTl9QLPp2BrA8L1CIDPoaVS2i85DRkYoZschJxHZIf34DaDv1/dpL0n7BOTb68jWo1Ou/+Pu76ncjx64Ji1IWX43ZOQ9yP2zHF3Av+Q2TPXpgeV793DHlLnXjzm3AHLEE7WYVMUvD8q1z9qrNPAebR3Gm5i/lXVxHzyIIJR8Hckxuiml7tWirp3/HB2gfKvf59IOvfZwMABH3CfGUYyZl87/ZL3SkH3az/fuhUdMaWB4mbG1UvHTXeF3JQJtcO6DIEC9Rg4ZgTNBt9xU045xGo6zoIa8EdKLT5c+ca4zG1mKxtyNSQzsd841kz+S9gG6QPRizMxZz5hT4OPFR0pqWgjjYdbv3eHPEwPP0DB/OBU69ixQnLedynj+R7L7iDI166iu+feZuuf+pBzN4+j8QZ3qWifo6oJlgEJ10FA2qWfTuntb19P1G/YkaC36CJBhGJSSbbzF+1g/q6Jmkco0kaal4JaEtjBZ2ZpPaQ5Sx54RPY91cXQCdl9KSjGTzpGAaImLrwGpKpPg583VPowzBPIkkyozYnUqWqqtKGVibujt2wfx5MHbN+OQOnH43etJfozBNI0jbJsa9CXMqSTz4bqdel056H/iGSS2+m/e7vwMggGln0gkvJ3vwJVUZhyQqo18V//XKoORiKkJUr4bAN+HrcVY/ylctfogCpsPcW03qFhfZNFdSfEzTNndBbOH5hav52dwPD/rm8uXbVb0qcoxcAfr1AEAaEp7AH8WfOfSE9b+3maOOuEw371mpqk8Au7DICfb5M6sKEqxbevioEIhVG4AKjkMJau6IirILHsXc8pT3hGF0X85BXjwT0WybEVrj+h8q+6+sMjvZhSVBJAU8Hz+rjDX1LRulf3g8Mk6T9zN0JT/3EEVxzwS7aN3VY8f4hrtl4K0uOWEpNU8DS11cjrnAXvA8V59ht+/D79nDAGQ/mjz58JtY70BjsELef/0uufsYN9K0ZLE1FCh6sipBqhrZniJYdyOiJR7M/HsL3NZj82A/Y+5ObkYEhWtunIBPuevnHiKSDiSKWvuYJsGpYvMuNK/oG0K372XHc66HRD/39RLMdJl72OdKf3q6rfrlRooOXos4jzmt7ak5YIkgcw74J5l/yKXRmBoYGILXIIx6I+YcXoEcchL/gSvT716r97DnCaUfjI4sZ6ccALnOQpYjmyqAVL0Ptusn8arRfjg0oLr3kenzeaSj9a3jZifFX25qOpedz0vw5PLss+bN77z7tDzQAFAPCjRsx5wHyZ3re3i+nV674WfTRgePsqq1HkGimUVdqrDIJqDgElZ4BFC1BtQKQBX4BDsUJqioSpOcKtKDjrmtTdKzF+mfUecrrY8bxpHiaZNx9S8reyy2mFjR4FMVYS5rAQ85ZxvR+4ZffuB2xyvbN05z/+Bt5xleO4ao37WD40cPIaIfpy3bLMc87lNbulhL10xiq5apG3ZYEPJPX7kdsg/4TDiJyiptL6LiOSL/S2jmmqhHRyoFg/VTxB3R4nM8wo0PMf3crN333PTDvqDUGGL9oC+3PXQZLRiHuA+OY+szFwZK4b4iRlz5KmmsE9V6NAfEWlo1q/ayT8TfvkPTrl8CAYeC8JzPxmH9l/G3fZPDDf45ERtUFRKURIMtI+xvo8mHMQ9ahW8fQbVM0/mgD9jEPlARLsmNc9Rs/wE9OY5YNUWt30FYH5xxEUSHjlTfzVesnLSS/SpUf0WBAUsCAtbj4+d5Ss5y/X8eZ22zsLvOpZp3X8u7Gv9xXS/4/qAAAsGkTfhOgm4nkdC68bXP28FXXyKcOnzMPvfEBkvqaNyRekCr1VysuwdXs7rtVQS6TVbSPTjOcmOBcW5qEOFSCd991FxqgzYoTlGlvaM8ozgozNmN6XwJmniSuMU+K1+Bj3WxYLn7XOFe8cz/ZxBz09zOwapgNf76EC9+4lZlb4UmfPVRu/eQ2RTxrHjPCdf/WguYgts/gyPLXUagVpey7Ygx1A9z6L9ey9QO/RLMOmrSDTJYZgsFV9K0aoYZnvpBK94Fwkwn4ltL/iA2se/mp3Prs/4TEs+HDzyB5y5Nwt4yz7TmfwNuMFf/1lwwfthIkpXnAID5JMCaYl2qnjazuZ+lbz6bz8c2MfeXbuKkp+OOTqJ92qHQuvAbZ8kTMwAjOzWGNgDq89/hGTOMTz8EP9NN56jtQn0Anw7ZnIB5A1g2HSdzlW7AvfBxWlaTZCBX+fBsVy0ILYi1nAFK16AqBQkx1yl+l9mYhdhhDJr+wNXe936dx8mze2fw+G9VwHnpfLPkXH8MfyJHTQ0tw2Ols+cSfpY9q35l8+MjLXdycgKymqr7rkRsursvhXcWWP/fRVV8qCgc9gbzIzj/uIg0cndTR14RbL25yxw/6aBzkWfeYGWZ0DrUeYwV8jWTegG2RNefpkKAmFxkho1YXBlYOcuJrDkJUOejhNdYeO8LYV+c59aOH0Kh5bvvAjCw/8xCaBzV0ds801IWoVigalSoH2NmOjB42LCuftFZWHDko/Wsa0r9hQAaOXM7QA1YTNWKwhnh5P+LSoLFYDDpFqQ3WIOlgDqjRf9JqbF9E56qtuGt3sWz9gcz9Ygt+ehr2zOB+dD1Dhx5A/0HDSBQoPMF12INvQ9YiAbxLAMFIhMXReOPjWfLVlzB86BJCN1MnMgSZFotGaVuj9aNaG+5TcQZEceJxsUFtih63Dlm6Aq7YhhmfwcVW9L8uwXx6M5JVpH0W+PDldKDCvq74sMLhrzrxaOA2YZxkXG5r2bX+FzqaPoJ/bn4/L/kDUPIP4ET8AZ0cM2CM0Pkb9JxtX3O3rbnCvNMca2X/KlJJvS2loURyDQC/ACAUPnZhTmCkFBQtNQdzOfHMC7V+x/69yoXnrcLPKMe9usPytcp8O6Mx4KhRI+40yGaFaKBN1AwW3YJDImEuhSOeW+foc4bVtOpy5afmaM3CYY8Unvq9dax+6AAXPP5GTNPz4PM2AEI6OYvYFt5meKLcXNTS12wSE3P6+x6Bp0ESUIsqxKRYcTS59FmfkPlbdujQQcP02QHSAUO7naAmmINsf/9VuHabma9cxVXfuB60H71qO7PXbadvzQhj7/4JjeMPIt4wyti7f8LAacew7MkPIk1myAo5NdXQy7dSslvvRvdPQdTARjGGlPiRhxPTpJ22UNchOJgGifiA2AHpJIEPEDVB50l9ilBHWolGR6zFPepk3Fd+gfvWdchzHop84VL8V69AbjgcPfJAmEsqkNLuOlC6wz5ZkPGddPX5MtBY1Yzh9Qpb8/vcBRxvX8SfN6b/EEr+P+gAkGMGfAkcepr/lxt+ILevuN79Ry01w9vXSqKpRlIIRBaZf8FAOB8IGglbgMqgUMRIIR0ukbL9euWCV4yy65IGK57Q4rS/Fcgs7ZmU67+VMDQY0b61wfzeQfpX9DM0muDSNkYDuNwjmKZg4oTZPV4lciTOS9KfsPQBhguffQfjl8xxxLlLyTptbv/WXTJ166RGA+HryALyLY4ibv3kDqa37Mf7JGga2giRBpKrASdJyv6rd8FATW750M9125J+6gc1OfC5R+PSjEZc1/0/2SpOlOa6JdQPWc7M9/dgzn4g8UlrufXs/8CPOV318acw+pDV/PKiPbL1xV8jfVeb0acdgYsM5CtUl0TozXcz+YBXgLGQCW6+g8Mg2yZIZvfgdo2p7t8D/X34zOW1VeAUqOS8gcCMKJG6Rh11K2QvfyStb16l6dsvoEZL/K078Q84lGj1CJqk3RZAu2KeXdkurZT7EuC8hSqvC5Beu02MXmFjP+ffzrui1+O5V1B3ewHg1wQOhbmA++oVF3H6ipvsf67PoiPvOIhEvUQ4UOMqvoKFS2xeEYjJs73vwoM1lN3GGDozhi88fw17r6yz4vSdPOcTMwwMRLScp2YjfvSXit87CZJBNMLhL7IsWWKZbBm8ZDlq0aDOYKxgRPCzhiwNPMJrv7CLHV+b1A1vOIAHvmwdX37A5fj9k4Bw0IsPYWh5jXYrA6NYq2z5zJ2Mb96i1OeDOWPUD6YRfrOz+bDfGh6F+iC7P3sdTM4x8LgNrH7BMUiq+CzhqA8+WpP2I9F1S2HeydXr3020dz+7nv8JTa4e58B3ncGapxyMIBzx8afpzX/xVdn5nM9o+tVnM/K0Y6GdopFh6HnH4/ceATFkLoXU0zhyGTFK+7qdOnnmh6CewMwc5vT1ZEN1yLJ8RZtvXtQh09PqZ1uBuiUeicB1ZvGnHY684hHo2y4gef4HlayOvO4M/Gg/MtVCrale/hz6W/GQW8DvD4FBvSAxzt5qY/8L31Hf/mve0fzoH1K//yvvCn/gZ/NmotNPJ/vBtaxcuzv+vF1rT7/lYJO0LZE6yHICUGASWpzGeLU4CdTh4uNAIMr58T6iHkfcedkwl32hyUPP3c3gsoi0FSOmhq03uPYzDfZfl0ETRo6KOPLMJiJC4n0pNIIGtqCJIjqTMd9+fpsVD4k5+dx+mZ9T7rxwVpf+8RL6Bvu442OzzN45Q329Yd2fHkhzsI5zRaCKmb3Dk80W62+LmBoZQuIcqVPERsQ2xpgaagxJkkB/ROPQYawGi3WpRTig44Vkb0tuf8lXGTn1MMTWVJtN1r7sZNKkReY9cWOQsW/ext5v3UD/Ox9HX1zDeMEZg43rmJwF2Sk9XlJRrHa2zzDxmi+iTogOXEHjnJOJjlyGb2fBD5LgdpxqBK/6Am68hfnAnxEP19Es1xRQgzcRfOSH6LdvgIPXoOc+FTPQRBJFJWi5q5ec1SeByFOw+rIcyJEj/XKtvkyuMTV/k9urfekzeUPzR6XPHn8Y/f79MgAAnH8+9uyzcWcptXN/WPtEY5V99s3rJW01xfgUcSZQhl0u0uE0QsWSaeDoF+xBJ1GpG5CpxdTCj6/tIzodi1hTCos0anUES4ILclpJvaIlYHK9gIJ9GFiM1hrQiI4TUgxRvU6aCN5HNBr9WGIcQjv1qDeI5MpFGKJ6jKEWglmug1DQgpUYQ2Aw+lILwQRka8cF5VWJ0NyNJUPoIELdEhETUVeAdicNEuoSLo2tN2ijpKlDXG7oiskNXLowa6eEn42JSESlY2M1CA0siiNN0px8VbgUCg5EahGguNSF9V5oxVRVxWOg3syHshF0UkgJHgAFSEO7OvzBiUeU4vJnEmy2jSBKZq60NXeru01Hs6fymsbN91b6bi8A/D8e3Ygxm/AqcOVF8b/290ev3HKocVPDiiQiGZZMolw6LK8A1JZCHV4Ddbj4e09E4gMdN6gU57RisaAW53M9AQ0aAZg4XP5SfiynGqvpXpT8+crnchax9QBDdoIQREDU5EpAEtR8tFAFwuK9yaXPpOD/B5ERTK4QFHTyJB8gemvzdWcQB/FeCgETUR+4/CK5wIgxudN1wPyrDwI4ztgSS+G1S7LSPMiEmYpBXcGozWE5LmgDaGwrjkwVgd4g0S5q8n9foPrmxB4RnAa1Ji9BHwHT9dfLtfyDeIfkQUCUTEUd0Ml/+zs4+UUU63b3M12XPIMX9N19f7n896sAAKXGgMgm/E8ujv4qtvKefYdHMrHcOE3EZGLLCiDD4iUiyy+75m2Cp2gNisd0s3BVfKNQ6illxiRCKzoESqgyVA1OBK95kDBBvyBIhkeoqZMi4C2xqWOo5dkdXJJLeolFsEithlLPOSvhQhgshhoKkkCuXmQxxApCmmY5WzIEgiyOEGMQb0RVysrHGRs8Q8h1/cLzq/eKc65QFBJqsQblJcnl1nKHRy8Y06SDI+u0UVGyWp8qEca1MM4VIjzqu1afXUNWpUvx1m6AAZG8clFxIsFTrnDoycv7TIJyT27RpUFhRNknXq60sR9LP8vzd7yYDRvaf6jDvvvVEPB/HA4qbIbo4adl7//2T+zO4RvdZzlCmvtXSSqJWnL6T9gGFKKTed+ecwbCpa2sDwtn4orlWOF26nJzsZJJWEqMu9IsVr0B4+mMwfxsvoM2BisRSZrQUTA2pm6FmjFhsm7AjEaBC6CKRtDZmTB3xyyJVUQiLDH1lf0k+zuQOhIcqfogf6Vga4baA1cgsQ2oOGNI98yCM0RRE+/JZbnzS2csIrlKVu6fST1SRvsBxRiLG+9IMjmR62MarFpss046WCf9r0tojfbhnv5AxKfoezcLU5lGL3soMhKhmS9TUjmYLcA8uZOv5nJhFfceLSf+kqN+Khh/qWr+OSAViFXZLcrlNtbJ5B28qf463gRsVPO7luXuVQC/r2ogIAezL15pTx9tmy+219eX7F4dpZlTm+WlfyYh07s8i4d2INcDzKsALzbP7DYXGukqDQtWVSxOrahEoZLQXG5MTV6iGzJnqDctP/3LiJs+Nossa6CuhkQZUV8H32qJmw8wW2KLpn00V/Xzxz8+Cj/iSNoQ9Te59aM7ufFlV+d02z6oD7P6RYew9ytbcdv3QbsFtl+Ia2BbWl9V4/ifPIPaygFIFNvo59ozLmTs+3dhlgyJNGvh0k1OgGtD3sfjEyCFRGmecJiu//YLcD6j2WjKnS/9FlNfuhITtWE+hSUrwTUY+dpzmHrxx3HbJqlfdy614Tqzh74JJNIl178WP1QjSzW3yst1AfNKP3f4zisVQ6npoLLIRVbyKeGi8j8Lb5oERx7uNIarjFHf+Tte33hXZdKv97d7EN1fA4CcTrZ5M9HpD3GbP3u1efTyrclXVnldv/2AOMFrpJrlnvGFbaaUtOEMl/++dXve0McHslGhPhRs4rv2ZardSqIgixerrxTD8IMTDjxDsX2euGnp7DNs35zKwJo+lp4QSSdJNKy2GtK3oo6JfO5S7cnwqFHAccDLjsJ3Guz+rzGaGwbQ2TGGnnYga55zHDXXJO5vctNbfkRn2/6gNqwuZHAShk9cjTMGJxkzP9mH1CMap6xF3Tzh+kWoyxAxWN/U5jEHYiXAiDt4bRy3VKY/1UIedgDmqFWkn7gBTjuQdPUI8bMfjD/3q8S/3E20Zx7d16L5lidR7xtgJm3jJVjD5mm8JPAU5L3CE0JLF/mKX19V+LNwBvGmC+11ILF6ttjIX6kdouRFvL7x2dJ0c9P97/LfrwMAwOlFEDg+veYjN9cftWZb5+trVR9w1wG1RNFI1XVL/6ItkIpgLC4PAsVKWSrSI6biu5vzDEo/Q0o0IngwlixVDn1xxMEvrqEIgzTZfXmd7RdOseoRKzj1fUsYZ14yICKiSYMsbYlzsYoJLa01FjLLyuccLlPf2YOMdBg4rg/mU80m5mnfvpfMxdi+Om4eiPvzzUOAAqdpixV/fxQHcBJTt03odcd/hL5TD5H1X/pzMjpA8BKqIRrl/4oEgj8BSoeU+tOORN5giR7zQAafezL7P/Az4icdRuf93yF561dgeDVzf/dNdGwa6hHtf76YfTdNYD55JrbVRmzo6xEJnp4LyraKq283RBSe0r9C+KNwQg5Kvdxci/WadArbeTqvHfzh/WnY1wsA/0MQOF+xZ0vnzn+7vf8xG3alX17j/EPvOrCZZEYj9S73Hsylw0qvgBz6iu+SinD5mi/nFFAxL81JRL7yOS3ERkVRZzFzg0QqpKrM9gsTt09A0kKNI+3E2PkBOmSk3uOsIjYji8MgsAnUbA1kGN2ZsveLt9F/Yj+61KHW0LpuP3fethv1MUQxzPdRW7EEWxU/UUM6l0AzZeaKXdBpkd2+R+9+zn+BCaIBIgYT10TamS792xOJjl9F5kPV472SzaZqhkel8/6rST54JQhEc/PYYw6APz0JGVpO8t1bYMATPflYZNbD8UvDvsBQejHes1OtBgOh9Pyg4hmZq/2qSon2Uy9g1ckN9Vhvcru12TqDvxm+rHf5ewGgPGcL7vzzsWcfMrfn7br0CQf9fPpLB0jrsdtW9yVYjfCu6yy8QFuwChWmuwYTCyWiUEop+kAhcnRNagXnHfWG4fqPJvzy7fuJlsR4b8G38HNzsMTrnV/cxY4fzCGxQbN5QTsYZ7RvXT8P+PLhRDa0AXgPfTH7LtvH7K0zrDv3aNKGQ2ccq15+Kke++cEytXsKHYi549nfZ/6GWZypzNvzAWZmlPYNe0GUzu4xOndOQG0ETC38wFKBGSf1cx6s/SYYdXiRUs1HM4Mctwr7wGVk79iNyRJGn/UI7LNOJSFj9xHnwvphGh9+Lv10pA2auQ6UTs2Sy4xXUj9SsYLThQKegdkj5TzAe9QFnX9jybi2UfO3JnfoyMxTeOGyG3uXvxcA7hkEzsZtVMzrZGzmND3oqc+94u7Pr3buT3YeMJi4WKKgOW8qG4IuJbhoASgCgpqKvXiuLwDl16KSy1d7vAZXKVMzRKMdassGEQxWhKktMfiEgfVKbZknm1N86lSiOtqJsaMRJkhfkOFxmkGSiqz0xMuU2e/tZujIFcrIAGNf2iHXXLEfp7O4yQla109hlw7RaXeIRuoBDovijZKQ0rplEqTJig/9MY0TV4pNhFoUE8c17njhj2lddje1ZXWULK8gDBYliyy+JZhT1zP4vOOYePvXcWKZ/+bV+G3jdJIUZuZhl5J8+IeoxKhR9MmHIyv6lLSwYi+CbEXVp+L6Fz4IIi9lYMiFPcTn7YFoxtXNmru9fSMrJ5/EM1ffxcbNvcvfCwC/+mwS/EbFvEm2ti9W/vTffy6fXi7Tz9q9aiDJanFeCUhFTEwW9PTkasSBFmu7jxFZMCMgOF+Fjyw6n3hZ8VzhUc+tUcfQsDWkNchXHz1N1umw9mUDNC0MnzJCdFANTQ3GRWTegXGhx8XjLZDOUXtQk5UvW8/2N21h2eMPElOLVYZgZvcUbut++h53AH2HLZV4LlPfp+J8BlhVFYgsbqpN+7b9yNplrHzsUdj+mDaOeo4hyCb2o3Ye0wSDw+VsG288WeqEkRj/vh8w/aELwQqknok3X4S//DawwJII2TFDcs6XSegHEuqXnYNd1V/KtxWsTUqDMCk1PnLJ30LpN//B5mWVCx8KmvHLvpq7a/6XrJ17Ik9fvYvz1XJ27/L3AsD/IgicB15O9s9+35VmfClzf7V39UiSxWJxXgKNuGJMWVxu9RVNAVMy3HxpThsqBhEtVYlCOBAiDWi6VpIiAwnbLvTM/Nwz8qx+9lw2zf73T/PgLw2z5iBhrpPiBzyCgbbHa0pGlMuCCbHrMPrElWw/bw8zN0/j28qyP1tFvMGz9axtLHnjSSRbJpl82eUy88M9DD59DaYddvASR/it4yTbxtGhAe58+UVEqGY+FQyoJqS378QO11QbQUwkuG8rKUonayFz+9H1/egD18Anr4emo/nRR8Puh+G2jNH+h++hSxoMfOwMzKAJysSHDuGdC6jKvJ4qqyXIA4PpCnmWvG4P2DLzewEcmb+mv6bbZ3/KA6bP4PQD9+eX3/V+w3sB4H8VBM5TZOM/qvnrB7u/fte1Zm5wz9Tr0mUjiWvWjDpnCpkwXWA64sKWoJwVFFVAZUugueddEKTBYyWwDR1ZCjJgmdjR5rq3KFgjRzxvGWOXOB2zKbYWo4CJhLHvzYgYr0MnjeANCBmZS4CaRjNWGDNgBskkAusk2zPN6NPXwHAfe57xE9Jd8/SfMoQe1U+SZRoXRhre09k9hQxYsU3D/HdvVhVBTE0lzUSZRec7KmuG8PUIk2QBmFSAcwZryPwMnHEifa94HHOf2Uh29xjxugGiBx5C54aLYU4g8WjqsY85DmUWdYrJvGi+iy/wPQHgY/I5oM/Rfyww9cB7cAYvYDKf+V/213T75I84Zu+fcOpRM6iaP1Q2Xy8A/JaO5CvmY47Bnv2g9PVvvbbW6peJ89KlS9KkGSuZE5UCvx7l/X2e5cV1hUSIgrJQIVEneeAIWjcUWCzvDbV+I3N7Pb94vtf56zOW/tkghz66zt7vWlHfpy5WUhLqjUj2fEnZ8ZExjr20wZI/agQkgEuhv8bUVzK94XM7MYfWpf+EQfbNzuOzDsPrRln1oiPY/fa9DP7FwRz7qRNJaNFppaiNwEZYE7HscRsYvvkAzYwlMpaIwC9I6pEml+7gtkd9jtrBK1k6PEKLhHkcLvGIc7hL7kL7mujXt9D+wV50tEH2/kvwDz8K91Bove372AcdgKow9+oLSR60AjlyCVGnjYssBcintPUWk6v55J9RjyoS0Iz5511AB5pUMn/9QM3vnPweJ+08k+OOm2OjmtwJsHd6AeDXDwIoPqwJk03/eF1d+vzYRrdsJG01m0ZdJl6D2Qam+MV1pbhoEJp1gRuQDwVzG9zuOisny/Y1hf0/i7niVY7pyxP6T4IHvLNGixmyVoZYZP6WadoPCBLj89scLB2gOdQgzg05xXhIUgYe4jjouH6GHr4CO6ogEekU3Pn6a4ky6D9NmP3qbWx9Z8zalx6Gb0Q4IyT7Zpm9fCcSRfgsxaHYuIGxNVyakMWe1s93I3EdfI3Z795ONjlN8uAV6MEj2Cxj/rzv48dB4g5+dBJaYJ7zMPSYVbSf/3l0zy7qH/pTov6Y6cd9EPfczxF95pno4Uugk+KNCdDmEhPsc1RgMTwNGH9ylWd1Qf5dEs30hkZNd4//gBP2dC//pt7l7wWA/1MUQM8ug0DnvH+4Lppv2Mm3d7AZzTo4H5T5c4WfheIiBT9fcgdiX/5idx+niFV+8Y8Nbn3/kDKVMvL4lAd+NKJ2QEKKobmug2bKzW+c4JZzW2EFNtNH44+G6F9noJMRN+vhmdMZ2usT2fCklSgRO748pkjE1Od3MDWHrHnnAzn0Yyu58Yk/4e7XXs7EDyc44gsPlmikqVO3THDHn3wv/4enQCN/A5gFWkANmsPMf+02bvvytcAsjY+eyZLDTkBcQnPTaTSoMfxHB2oyNsveR3wOWbKM9ku/j79kC+Z5j0CevAGJhPobHk3nn39C+vAvop//Y3jUAdDOwCxeAZruprL8dDDqRMA4Sf2tzbrfM/41feTdz2TdQ1u9y98LAL/ZIABu42aiTQ/M3vGaGyNT9/v/2S1Zmvq+psGHdgB1pS+h5nBh8uCglSFg8aSFK5WNYMkJKc0DHOs2zXHIORYfGXw7UY2MHHJOXV2nxdQvDcYOIOrELLGsP6dBPNAmmYOYOLD4YsFIRpY5jBodPXyIxqENBh/az8oXb9ChY4ZFaoYHbX683vXK6+l/9DJkBNJsntqhA6z54EMRCQIhxsQ5wCcXH7W5Pbozoe/G4ZMMOXUVxrdR9QyfeYRSsCDHZkA6sMTAcqX2qocTv+0xGJ/gO1B/6xMww310vnMnHNOPZElJ4c+tfvP5f57tVUXUhADowqDVJJL5m03d7R77HM/6+XORs13v8v86v9q982v9vDZuxm46nexvrov+IR7mLenI0jTpq5nMGdFcO6Dg9LvcalwrlOLC3rtLGw4UYWqWuTFL39IYl0S5FkAUIMfGYKKIDIOljiHKBW0EnwT3H28snUlLtsth10WY/hribBDtGM+IljQDFbnjQQ22UQcMGUqWCs4LPoqp2QZC6MVdjndw+Ws1pZhIV1cjBLUMn4CKpUDiORuRdJTkjglkwwjEBmlEGKdopngxiBE0iunMzqIDTaQjwf48DPlFMeUWIFx8Cfh+l7dSiWR6U1zzO6cv4FlHno1XYeN5wqZNvcvfCwC/vZ/ZaZuxF58u2Tk3xhv7+v15bumytNVomsyplNoB+SX3RKWGAIUOQMllj3MefRDwUGvwSQ2sBYkpNAW8CupyNaKKeo8Xi9ggLQYxaiOMjchScD4Ylygm+P+lISCFib2g3uTKyCYPTuF1BGigKVWKtNQmyD8v+Wst7NXz1118r1w8NWgWGMFbg898idwLd9t0PTkVnAmsPTWRlmogBD2C4te0oDDjQjtlMpPpbbbmd019W58mfwLHpJzXu/y/7rG9H8Gvf7Z+Cj1LsZ9e4TYf+5III61Ha1zPssgYX3LWJV//Fcw/U+EBFIIWXYuycCklGGsUEuXSBRiFZBjUfNRIcNeVgi8vIWt7wae+fL7weYN35F9j8vVG/vWYHHVXfJy/HiNgDRgTZMdteK9G8Ca8BqyUr0Mx+fej3H54Cfh8TYv1R/GuEjg0PNZoQYxaAPcVka44QOnTJyAqmd4hNbdz/HucmD2doeM6cJ6w6fTe5f81j+n9CP6fjl4A/rTNRB86Ot00O63v1Ol9NZOkGblDT5AUz98kGJJo1YBENCcUudJ0JEiH5KxB8SWwqCTriJamJVpBF4THJAGWbPPnrZidL/66qkCu5tZiJYAp/z6lF0Lug+BFSwt1X7xOKNF65R/xFR8FRQuugVQQk8WaT4KsefhcId7n81gSXleuAgi+kPHF6V3U/O6Jn/JH+87kwIfMs3Gj9Hr+XgvwewgDyFlgLhBxz745+nB9iXmJH1iapFEc+Vzwo2gJgq5glLcAoRWgZBnavF2w5d9TlRbLBUa6fxflxZstZcjIvx6Nc6mxUO4XMmTVmUP18SWvQU3OerSVGUX+uaINweSvJVcjRv7bN1+pcHw+0CsVkSoIyoIoVVYm+fqUvEIQzSHAajAiTu8idttnf6FrssfygIeO5yCf3uXvVQC/n+3ABeA3qprPHZW9dH7CfYb2RM16spBlQ9bqZteiIiisyfyCDFw1p9OqJZkWWT3PgtL9u+IaKUU1kXW/tvK8YRPhK96Ila8r/jv30SqrE+lWIAsqD+k+RzXzL3h8yPqquVdvxZWz8u/U3GYxz/K5pFpp4wW5a4cHq063dWK3Y2yLrsyeygMeOs7559ve5e8FgN97ENgEuvFcNUcc/g/Pmx53F6Tt/TWrrgwCxRvle59/XFwUv0C8TqVa3heWNVXnyuBpWJbueWtBESQ0BXF5G7LY7L4SQIoLXXgkSghGXf/DRY6Zsuj7aSVYaTcYVMX6ugFukSd3kAotJyI5qb/ET+YQvwDHjHHsaMdux/R27Z99Msc/dAfnn285++wevLcXAO4dQQBgE5t07JBTnjW9p3Vh0hqrxZAtvPxFNi4IQ9UM7Bf09r60LXPlx1RmCuTPQXnxtVsF4MKiToIBqS5yv9TqfKKULfUhYFTmBSx6XWUwKYLEgoBQwHW1eoEFXHdCoF2lzjLQqJNqZYIUDULu4hHjze525LdO7tdG68mc+sRbepe/NwO4V56Nitkk+KfuWzrYmZnc3Le8/4RabUmaILaYB0BMEAgNYBkKjIAE7XskCgYi+cov9OS20vMXa8AoX8/ZUv+/6N+LuYESl72/ls8ZdT9Xriq7ZiGqtmteUvbr3b8vtxlarBC7fx8g0KaY4edQaPnVgp7VXh+6tUCuQKweiIyaiRS/ZTZ1rv14Tnvyj9m8OeL003uU3l4FcO87BZX468vHZrQ2dMbUxNxdrWQqtoLrZvAMr1mewV3OFXA5082jmpX9vmq3Xai2DyGDB/V/n78PlUKWzxeKjOoK47tyZlBk/gVbCkKVQYlgrP7d4sqku8XwZenf3S5QKCFqsUkosr1f8JzdWUfXlr2oLFCPxqIy01G9a9q6bO65vcvfqwDuM+csxV4guEfd3v+gTtT64cjI8NJ637DreGsKMJDPMzEaNgRoFyTkCWYjSHfi353MR4s+DtLi5XZBQ4VALj9efr9K1veaf16KTUCR+avmJqZSBVQqgDzL64IKwZaVgl+U0f0CzYT8Vy7ffnT1O4tdoMlXjxbpZJlunam5yflX8Iinv693+XsVwH3mXCC40zYT/eiQuWulU/vTvXPTSSeZI3gMu+7grTq9L/f/ioojN7Mrq4bq8K2awVG3cCgnbkFloeXXV+YJ4vIpg6tsByqzCVzOWahkal00uKwM9BYO/hbONbqPCWfh1kPLwWOQR8tQUUyWZOyerrnpiXf1Ln+vArjPntOU6GIhO2Fb3wvNqP/Yimhpgm1ETm3eSwfjzmqvX/TkJfQ278m1rAQq1YBGZYYPUNzKmy76b2zQ3yszfeUxYirfW/JM3/28z70HvUj+uvPXt2BWYBZ4A5ZMSFmMfpRKMJDC5y8MCAMaMLP75mvJzv1f1JOfcxb+fAtn+8qX9c5v8PSgwL/Fs3VTQAteelx61bKXRiPtgeRhQ9JIFWO0XIItHoQVcVkoH1OoCEtXJLMwJgkPXwTE0VwaC6guyUt2olSgyJX8HRB9slBmjy51ecFzFJ+TipsnXaivlnv/ipJv4c1WzT1aqQ+sODM+V8t27b9al9afzsjRKRftg9Mv7l3+XgVwHz0VtOCR22ufGV3WfM4ylqZtg6XM0lEFBViZ7IvtIvByE9Aw/S+qgqIyKJCBUdnTF5sEKkak3Qoi7vb6mmfvwrm4qEyKPl9Nt2KoMBkRU35tmPxLiRD0yoKs303fpqKHIN3+3ytEkZfJ2cjdvf8OL/oIjn/eDnSjQXrknt/m6ekB/PZDrF6gKBvVrIwP+csdY3c8SJdMPWgJw2mCswuy6+L3WhRpvsy0XYfcqj5mEcpNt88uJbUkn65XDTf9gvhfbv2lO6grzXWqRpzl95Iy6xepuSQ6qZYVDJUgEN4qUt/k7YEHiSI1c7O4nXvaXtwzOf7FO9DzLdLb9fcCwB9GEPAo5mK5cfaYnQPP2Ds1c2ltMBqoR32aaSYiklNrCumrkgbf3cOXTkNZvsuvGGRKsVLL8qyeP03uQEzFYBPjUU2BmMJhZ0FQ+dUOW92+Xbrq/KW/YSnhtYgfUOD7FcSYUt9fSmNPBSNImngdm4y13fprTnr5FWzeGCFn94Z+v4PT2wL8DoPAWYq94YDZm+JW9LLtyaRNs7YLSTDLL3G+75fubr5EEkq+15diGt9FFy7eEFQ5BwU8WHO4cQgKxWYgo4vsK7AHOQKvuomQKgzY5SDhxdBm7W4j6G4oyteobhEOILw+IcuYGIuz8cmP+pNe/iE2b4w4fVPv8vdmAH+wM4EIIVu3rf7uxhLzt2vtik4mJi52/t1evMsQ7Pb+skBNKEzxC+GQ6lzAlrOEEkko0YLPV7cLXm3OBDQVVqIpn6+7sZByI6AsFAHx5fvqtL9oMQJ+QIWKrTeoFWfGJuJs19hl/vgDToMbMjjvfmnT3asA7j/HcT72pLVPfd30WHLFbjdWt6KZw2k3Oy9C35VMwoVsui5Dr4Leq6AEQ+WwCPef7/gXYgTS3HgjYARgMQKxQuJZUBHk6MNKhl9YFRQIv4Wfgwy1qmZ22rg9+2d9n3k+cnbCBTdK7/L3KoD7QxVgEPxhdw4cNdGcv3TtwPDAYG3Y+6DxFXQDFmD2owX7f8oJfsD2e82zvVTRgAsxAbCwOtAye1c1C01l+1CtAAJ3oasD8Kt4Ar9iBrBoEKjlHEIgSZ3fOx676bkXctxrPtEr/XsVwP1tKGhv2zB7Uy2rvWRnNmd91tbgHVBh/VXw8pTaAu4eWZ9F2T9/TE7wV0WKTJ3lZp75Y7WqIZCWMwG9RwWQ4/yrlOIFugWLXrN2mYeUaMVipuBQ0UznJmM/OfW53uXvBYD7axBwbCbataZ9fjojn99mp2uRZlmX07+IAHQPWK5WLmlRkmfdS1sM84rnqgzyqAwFkSrf33UHgQvgvNW2QBfQmqk8Nqf34nO68gLKckFusuplZizWvfu3aaP/b9i40fDI83rrvl4AuB+ei/CqmAPi4VdOTHS2783mYot3XtL8ImZln84idqAW7D1dzNwrNgBpfqGzoNKnOX9Aupz+LhMwcAcCvyCtKBaF7+fL15LlM4KicghfV/Ia1C2sDKrzBM3AeJV0TpnYLxh7Dkf/9RjHHNPr+3+PpwcF/n2ei1GOwew9aW5m6G/iWyZt8swhG6kxIooEnG3VSqxqiiu50GYFilvu7Au8rgSlrSobr1QgpjuVLzECeU4IgqRSAo20iuitOht10bw5FZhFsl+6QIJMxTuZ2Vfzk7PvdQ84931s3hjx5L/qZf/eEPB+fjYTcTrZwFb7noGV0Ss26EiaSWwNEb4g8OQrwoLMU6z3gpiIQDG0K9d+VUJQtFBwVKqioItEQAt4sFhU464XwaIBpCuszwpqr0genHLRD+kWmaqCGut1dsLqrj13uBWHHs+yu+d6K79eC9A7AI/EoZgV2dC50+PZneM6H0XivSvWdJK/5b17V2C0mBcskgOTewqAlAO4CgW42050+/4FohxkC76OyvcUKVwPHCIO0fA5WVD2e9QHEJMk88j0fkH4W5a/aKa38rt3nB4U+N5RhymKueOQiakldzdfsyfrfGlImipG8p29duG9kIN+yC9/UchZCp2+MC/ownZ9/riSvVe4GENlfJdX4mUm77YcXdOPouQvfAGkzP4qwa47mJfkct7F9xOccftjPz/7OXf0ey7s4fx7FUDv3DMIOBQ7sbb15XRKv77LzsURzikZqiET+2JVJwvhvn6BUEd3Mk9lELcYDKSaD++KTYH4hWvHUqXYQQEZzjcF1c1DuWUoNw5Z5XukeKNeWvut37tnT9bX/3chKtzQy/y9ANA7v+KogozUG6+ZmuzMTLuWEXFa7vtzwo8n62L6tcADZJXV3aKpvHRxA4WseJjg+4pCr8vhCRV58QUqwjlGQLutw2JUYMk5wOE14A0km1ed22dcKv/I+rfugrN6FN9eAOid/6YK8Chmx4qZ2yThnftsy6rPnC/EQhfAae+Z1Yts7Es/goq4qCz8mjKYaFUENKs8V746rMwPKEFGbtFrWAwOyqsGK45kIvaTM1f6+Qf+B7rRwAW9y98LAL3zPxyPYtbEo++eHfe3Tmg7FnEu7OXTHNHnShy+z1sAXygOk2lXY9B1B4YlDqBoG/LWYnGmL6uNrNQmrCoaQ5qjBos2IgQKkWIwWLQUIOm86NQ+T63+eh7y0jQM/nrSXr0A0Dv/80DwAuTGlftmrTN/N9ZJJMvSXDAzz/Bage1WEIM+SILLAuqudGXGu5ncAS6f4YX/9mWLkJWVwYLgsKjigASVtKD0dmXJizfxjmQs0unWx92hH/whepbl7At6g79eAOid/99zdlgLzq5Jvp7M8aMJk8SR8VlwE+pqBnT78CJT5/29Fv9deP51h3yLXYG6Wv8LLcx+ldZA15koK9GBkOAlRSVBSXJfA1WyKavje2dc/9A/hcHf0b3Mfy88vTXgvbgWUKBuzFum57LTh5qpMaZE+XXXb/muL7DxsgDaUbNQi1+Kr8u/hlyQ2xDAQmq7qL6KFFgAExbP43OQj8lXg+FjpVj5aTefSM3BZE199p8c9sGt6FkW2dTL/r0KoHd+jVbAoZjp1Z3NWYuvT1kXGdFMcfccBopflLGzLqFHC/ced483tKIctAgwRMkyzCjXgOrKVqRUFCrnCgVwCJVkMtL9+2ddY/hfetm/FwB65/9wFKjH8XkzMy7peGcQr+VEX7uknQWT+QXCHl06b7XsX4AFwC9g/XXZfln5PYqAgFSxAw4kHySWn1OHjhnfTj7O2g/fxgW9tV+vBeid/9cqwKOYKZm/pm9H/I3ZoezpI5jEeR+FiyrlA8P0MEcA5qi+wjug/LzY/LIXwUW6KsEVs04WtA/SVSCufB+0eK6iHQAkUpKpyO8fm9ah5f/Wy/69CqB3/q/ngnAjG17fNTubZal3RsVrKNezRXTgbmvgy/K/8nmtWpG7LuJvUSWgVW0A7rkNCOCfbBE+IAPJnPr9xqX+M6z+1F090E8vAPTO//XkG4GJtdll7bZeOGezyIi6hRP6vHyvKgDTJQSRbw+0FOqoaPsVX6d+4UXXherDlLOALIwn8pJfCGtJxCudmUjH9s/R7HtPKCV62b8XAHrnN9IMKGBE3zcz6zRzziyQ5pKKxXYhH14M9yrDwO58QHMDjwqzUNw95MWraL+F70PfL1oZEopzyLjB+S+z9su3oRull/17AaB3fjOzAIciD1jlfpK29NqWdRHGO69VyG8Vk1/N/NW/q1YLukC1554Xv3jcIp3/XOqr2BBIziEga1udmvIS9X0IEC64sac10QsAvfMbOxdhrxJSI3x0xjm8elVxWur/SQD0eF2o6YcutPnuZv3874sAoZWtgFRsyTXrSpLJonlAsSa0OGTS+iS5JDvom5ei0EP99QJA7/wmTxANkb4o+3RnzN/V9j5WvPpi5beA1lsp50UXZP9QDRQyXQVGoDsjUMl3/VU3oaou4T18BjyadsTP7ke8vDeIfJzV+73qBYDe+Q23AcpF2LHlzKjyuXlxouJdN5sXSsC+K/wpi+G83Z7ea64kpLpA/beqMxBwANkiHkBQJyqn/4JXnbQ6NXuzM4dcGFZ/PcZfLwD0zm+jCvAADdynWuM6n6Y+VuO9akX+S7oXXKuXHb+g10eqRKFCwLMy6Msvvl9MOZZuu6CagToP04I1n2bDp9pcdJrtMf56AaB3fjtVgEcxM2u5zWf6rbZVA3jFawgCuvCCV0RBFlQI1YqgauBZioS5LlVYqxuFqvFITvpx05GfmBz30fBnwqzi4l727wWA3vmthgHARub9nTnUO4yiwgK3n8XCob7U/l9g6kF3S9AVAdFyLuArvT+ViiJsBlLEeKcyYTR1X2Ttxds5/yzLJnoBoBcAeue3eP0dGzGvW539JJ33l7WNt2LU+UVOQYUYCBW5sMIMxGvV+KOy3luA9NMKhiDrXvzSwBR8Om91aiKNqH0IgLMu6JX+98Vs0jv3saNYBFfbXjvLjuj5w1ZSFbFdjf8IcrPPQA/O7cE16hqMis0pwhXT0dwi3Bc+AxWcf3hsxQJcYqd+T6x7Jr7q1995RmF42vuf06sAeud3UQUo5pQDk68k4+5nbTRW0cyrX4Tm6yoE+0WW43n2V8Vp1TewQA8WlYTgc5JQdUioSDYnTI877xtvA0rOQu/0KoDe+R1WAdHO6BG2phcNNm2GFZM790hhBU7uCERu861iyqwPVnM3H/FlBSCl9TfY4BEgwe2nSO+iUeZlR83taX1OD7r7Ob3s36sAeuf3UQWcj80OyH6sHc5vxT4GMg9dcE+Z+V0JB17gGaBePF5UFvb/WiEKLRAL0QxQr27S+rHpcc0G/77CSe6dXgDond/pOSsQ8m3mXtUZ1x2J11hEvYpqYc5JpS3wBTJQPb7CELxH27BA3jtX+tEsMP58x/tsnyWtvYJDbtzGBb3s3wsAvfP7qgKUCzCtg9ipczx/ft4Z51DEqy9IO0UgKARBtQLx1QoJqGr7XZH87uIEMoz6VNlb81PJ+/36bZ9jMxFn08P89wJA7/zeztk4NhO5Q9z3mZdz58XV1OFF0Orgr2oUWjL+CuqwViTG6LoEYXwZGERIHLsbft/sJbrutFdzPpZH9i5/LwD0zu//BKKQzdZlb9a9/v0tcTXv1AegjlcpWX5uoa+g5t4C0mUQCpXHhJ4fUU2939Vw+2evacwtPwu5IOGGXE2sd+7jRWTv/GGcMIwzCC7abt5In7y5FkUa12zisbGqyaf53Z0/anNpcVt+ebHrVwwikSNL8LIvduPZt3V6zZ9z9M1jval/rwLonXvjPCC3FcvW+Lf4ef2z9lw62SGti3cq1meI11IQpKIU5EtjUYfiNeAMsgw/Hvv2rtiNJf+qP3viU3qXv1cB9M59oxoISMGbakekw+48K3JWNBpZ4yPERBnWesWiaiRgBUQRg3pEnYs1SvDzLfxceqlJBt/sNox9u3Qk6ZX9vdM795EgkJ94a3yCbLP/brdGd8djNa13mlrPBrSeDmk9HdZ6NqK1ZFCjmT6NdjfnzI7Gt9kx8Cds3BgqxPNDlOj9UHsVQO/ct4KAyf8vh5J9fHTYTs6fLKIPUaPr8H7Uo2KMjCu6TaR+Y1Qb/GVn1b47KBL9+djeqq93eue+HggqFcH/4vHyaz2+d3qnd+4TgSBcbCViMxFKhGLLjzfnFMLeud+c/w9W4qN076mW2QAAAABJRU5ErkJggg==" alt="CFLYHL" /><span class="brand-text" style="display:inline!important;visibility:visible!important;font-size:19px;font-weight:800;white-space:nowrap;margin-left:8px;text-decoration:none!important;border-bottom:none!important">CFLYHL</span></a>
  <span class="tag" id="h-ver">-</span>
  <span class="tag" id="h-colo">-</span>
  <span class="tag" id="h-store">-</span>
  <div class="themes">
    <button type="button" class="theme-toggle" id="theme-toggle" title="切换深色/浅色" aria-label="切换主题">🌙</button>
  </div>
<script>
(function(){
  var btn=document.getElementById("theme-toggle");
  if(!btn)return;
  function cur(){ return document.documentElement.getAttribute("data-theme")==="dark"?"dark":"light"; }
  function sync(){ var t=cur(); btn.textContent=t==="dark"?"☀️":"🌙"; btn.title=t==="dark"?"切换浅色":"切换深色"; }
  function apply(t){
    document.documentElement.setAttribute("data-theme",t); if(t==="dark") document.documentElement.classList.add("dark-mode"); else document.documentElement.classList.remove("dark-mode");
    try{ localStorage.setItem("pth",t); }catch(e){}
    if(typeof setTheme==="function"){ try{ setTheme(t); }catch(e){} }
    sync();
  }
  btn.addEventListener("click",function(e){ e.preventDefault(); e.stopPropagation(); apply(cur()==="dark"?"light":"dark"); });
  sync();
  setTimeout(sync,800);
})();
</script>
</header>
<main>

  <div id="cf-usage-box" aria-live="polite">
    <h2>Workers/Pages 请求使用情况 <span class="badge" id="cf-usage-src">加载中</span></h2>
    <div id="cf-usage-body">
      <div class="uempty">正在获取今日请求量…</div>
    </div>
<script>
(function(){
  var box = document.getElementById("cf-usage-body");
  var src = document.getElementById("cf-usage-src");
  if(!box) return;
  var timer = null;
  var lastTotal = 0;

  function esc(s){
    return String(s==null?"":s).replace(/[&<>"']/g,function(c){
      return ({"&":"&amp;","<":"&lt;",">":"&gt;","\\"":"&quot;","'":"&#39;"})[c];
    });
  }

  function msToReset(){
    // 北京时间次日 8:00 = UTC 次日 00:00
    var now = new Date();
    var reset = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate() + 1, 0, 0, 0));
    return Math.max(0, reset - now);
  }

  function fmtRemain(ms){
    var s = Math.floor(ms / 1000);
    var h = Math.floor(s / 3600);
    var m = Math.floor((s % 3600) / 60);
    var sec = s % 60;
    return '<span class="unum">' + pad2(h) + '</span><span class="uunit">小时</span>'
         + '<span class="unum">' + pad2(m) + '</span><span class="uunit">分</span>'
         + '<span class="unum">' + pad2(sec) + '</span><span class="uunit">秒</span>';
  }

  function pad2(n){ return n < 10 ? "0" + n : "" + n; }
  function fmtPartsHtml(y, mo, d, h, mi, s){
    return '<span class="unum">' + y + '</span><span class="uunit">年</span>'
         + '<span class="unum">' + pad2(mo) + '</span><span class="uunit">月</span>'
         + '<span class="unum">' + pad2(d) + '</span><span class="uunit">日</span> '
         + '<span class="unum">' + pad2(h) + '</span><span class="uunit">时</span>'
         + '<span class="unum">' + pad2(mi) + '</span><span class="uunit">分</span>'
         + '<span class="unum">' + pad2(s) + '</span><span class="uunit">秒</span>';
  }
  function fmtUTC(){
    var n = new Date();
    return fmtPartsHtml(n.getUTCFullYear(), n.getUTCMonth()+1, n.getUTCDate(), n.getUTCHours(), n.getUTCMinutes(), n.getUTCSeconds());
  }
  function fmtBeijing(){
    var n = new Date();
    var bj = new Date(n.getTime() + 8 * 3600 * 1000);
    return fmtPartsHtml(bj.getUTCFullYear(), bj.getUTCMonth()+1, bj.getUTCDate(), bj.getUTCHours(), bj.getUTCMinutes(), bj.getUTCSeconds());
  }
  function fmtNewYork(){
    try {
      var fmt = new Intl.DateTimeFormat('en-US', {
        timeZone: 'America/New_York',
        year: 'numeric', month: '2-digit', day: '2-digit',
        hour: '2-digit', minute: '2-digit', second: '2-digit',
        hour12: false
      });
      var parts = fmt.formatToParts(new Date());
      var map = {};
      for (var i = 0; i < parts.length; i++) map[parts[i].type] = parts[i].value;
      return fmtPartsHtml(+map.year, +map.month, +map.day, +map.hour % 24, +map.minute, +map.second);
    } catch (e) {
      var n = new Date();
      var ny = new Date(n.getTime() - 5 * 3600 * 1000);
      return fmtPartsHtml(ny.getUTCFullYear(), ny.getUTCMonth()+1, ny.getUTCDate(), ny.getUTCHours(), ny.getUTCMinutes(), ny.getUTCSeconds());
    }
  }
  function fmtFromTz(tz, fallbackOffsetHours){
    try {
      var fmt = new Intl.DateTimeFormat('en-US', {
        timeZone: tz,
        year: 'numeric', month: '2-digit', day: '2-digit',
        hour: '2-digit', minute: '2-digit', second: '2-digit',
        hour12: false
      });
      var parts = fmt.formatToParts(new Date());
      var map = {};
      for (var i = 0; i < parts.length; i++) map[parts[i].type] = parts[i].value;
      return fmtPartsHtml(+map.year, +map.month, +map.day, +map.hour % 24, +map.minute, +map.second);
    } catch (e) {
      var n = new Date();
      var t = new Date(n.getTime() + fallbackOffsetHours * 3600 * 1000);
      return fmtPartsHtml(t.getUTCFullYear(), t.getUTCMonth()+1, t.getUTCDate(), t.getUTCHours(), t.getUTCMinutes(), t.getUTCSeconds());
    }
  }
  function fmtLosAngeles(){ return fmtFromTz('America/Los_Angeles', -8); }
  function fmtSydney(){ return fmtFromTz('Australia/Sydney', 10); }
  function fmtKiribati(){ return fmtFromTz('Pacific/Kiritimati', 14); }
  function fmtTokyo(){ return fmtFromTz('Asia/Tokyo', 9); }
  var __srvBase = null, __srvLocal = null, __srvSample = "";
  function tickServerTime(){
    var el = document.getElementById("d-time");
    if(!el) return;
    var t = (el.textContent || "").trim();
    if(__srvBase == null){
      if(!t || t === "-") return;
      var m = t.match(/(\\d{4})\\D+(\\d{1,2})\\D+(\\d{1,2})\\D+(\\d{1,2})\\D+(\\d{1,2})\\D+(\\d{1,2})/);
      if(!m) return;
      var d = new Date(+m[1], +m[2]-1, +m[3], +m[4], +m[5], +m[6]);
      if(isNaN(d.getTime())) return;
      __srvBase = d.getTime();
      __srvLocal = Date.now();
      __srvSample = t;
      return;
    }
    var now = new Date(__srvBase + (Date.now() - __srvLocal));
    var y = now.getFullYear(), mo = pad2(now.getMonth()+1), day = pad2(now.getDate());
    var h = pad2(now.getHours()), mi = pad2(now.getMinutes()), sec = pad2(now.getSeconds());
    if(/年/.test(__srvSample))
      el.textContent = y + "年" + mo + "月" + day + "日 " + h + ":" + mi + ":" + sec;
    else if(/\\//.test(__srvSample))
      el.textContent = y + "/" + mo + "/" + day + " " + h + ":" + mi + ":" + sec;
    else
      el.textContent = y + "-" + mo + "-" + day + " " + h + ":" + mi + ":" + sec;
  }

  function getTzOffsetHours(tz){
    try {
      var d = new Date();
      var a = new Date(d.toLocaleString('en-US', { timeZone: 'UTC' }));
      var b = new Date(d.toLocaleString('en-US', { timeZone: tz }));
      return Math.round((b - a) / 3600000);
    } catch (e) { return null; }
  }
  function fmtOffPair(a, b, cur){
    function one(v){
      var s = (v > 0 ? '+' : '') + v;
      var on = (cur !== null && cur === v);
      return '<span class="' + (on ? 'tz-on' : 'tz-off') + '">' + s + '</span>';
    }
    return 'UTC' + one(a) + '/' + one(b);
  }
  function relToBeijing(off){
    if(off === null || off === undefined) return '--';
    var d = off - 8;
    if(d === 0) return '同时';
    if(d < 0) return '慢' + (-d);
    return '快' + d;
  }
  function setRel(id, off){
    var el = document.getElementById(id);
    if(el) el.textContent = relToBeijing(off);
  }
  function updateTzOffsets(){
    var la = getTzOffsetHours('America/Los_Angeles');
    var ny = getTzOffsetHours('America/New_York');
    var sy = getTzOffsetHours('Australia/Sydney');
    var el;
    el = document.getElementById('cf-la-off');
    if(el) el.innerHTML = fmtOffPair(-8, -7, la);
    el = document.getElementById('cf-ny-off');
    if(el) el.innerHTML = fmtOffPair(-5, -4, ny);
    el = document.getElementById('cf-sy-off');
    if(el) el.innerHTML = fmtOffPair(10, 11, sy);
    setRel('cf-la-rel', la);
    setRel('cf-ny-rel', ny);
    setRel('cf-utc-rel', 0);
    setRel('cf-bj-rel', 8);
    setRel('cf-tk-rel', 9);
    setRel('cf-sy-rel', sy);
    setRel('cf-ki-rel', 14);
  }
  function tick(){
    var el = document.getElementById("cf-reset-live");
    if(el) el.innerHTML = fmtRemain(msToReset());
    var laEl = document.getElementById("cf-la-live");
    if(laEl) laEl.innerHTML = fmtLosAngeles();
    var nyEl = document.getElementById("cf-ny-live");
    if(nyEl) nyEl.innerHTML = fmtNewYork();
    var utcEl = document.getElementById("cf-utc-live");
    if(utcEl) utcEl.innerHTML = fmtUTC();
    var bjEl = document.getElementById("cf-bj-live");
    if(bjEl) bjEl.innerHTML = fmtBeijing();
    var tkEl = document.getElementById("cf-tk-live");
    if(tkEl) tkEl.innerHTML = fmtTokyo();
    var syEl = document.getElementById("cf-sy-live");
    if(syEl) syEl.innerHTML = fmtSydney();
    var kiEl = document.getElementById("cf-ki-live");
    if(kiEl) kiEl.innerHTML = fmtKiribati();
    updateTzOffsets();
    tickServerTime();
  }

  function startLive(){
    if(timer) clearInterval(timer);
    tick();
    timer = setInterval(tick, 1000);
  }

  function render(d){
    if(!d || !d.success){
      src.textContent = "未配置";
      box.innerHTML = '<div class="uerr">' + esc((d && d.msg) || "尚未配置 Cloudflare 凭证") +
        '</div><a class="usetup" href="/usage">去设置凭证（一次即可） →</a>';
      return;
    }
    var pct = d.percent || 0;
    var color = pct >= 90 ? "var(--bad)" : pct >= 70 ? "#d97706" : "var(--ok)";
    lastTotal = d.total || 0;
    src.textContent = (d.credSource === "kv" ? "已保存" : d.credSource === "env" ? "环境变量" : "自动");
    box.innerHTML =
      '<div class="ulabel"><span><b>' + (d.total||0).toLocaleString() + '</b> <span style="color:var(--mut)">(' + pct + '%)</span></span>' +
      '<span style="color:var(--mut)">配额 ' + (d.max||100000).toLocaleString() + '</span></div>' +
      '<div class="ubar"><i style="width:' + pct + '%;background:' + color + '"></i></div>' +
      '<div class="ugrid">' +
        '<div class="ustat"><div class="k">Workers 请求</div><div class="v">' + (d.workers||0).toLocaleString() + '</div></div>' +
        '<div class="ustat"><div class="k">Pages 请求</div><div class="v">' + (d.pages||0).toLocaleString() + '</div></div>' +
        '<div class="ustat"><div class="k">剩余额度</div><div class="v" style="color:' + color + '">' + (d.remaining!=null?d.remaining:(d.max-(d.total||0))).toLocaleString() + '</div></div>' +
      '</div>' +
      '<div class="ureset">ℹ️ <b>每日请求数重置清零</b><br>' +
        '<div class="tz-grid">' +
        '<span class="tz-line"><span class="tz-label">洛城时间 (<span id="cf-la-off">UTC-8/-7</span>)(<span id="cf-la-rel">--</span>)</span><span class="tz-time"><span id="cf-la-live">--</span>。</span></span>' +
        '<span class="tz-line"><span class="tz-label">纽约时间 (<span id="cf-ny-off">UTC-5/-4</span>)(<span id="cf-ny-rel">--</span>)</span><span class="tz-time"><span id="cf-ny-live">--</span>。</span></span>' +
        '<span class="tz-line"><span class="tz-label">标准时间 (<span id="cf-utc-off">UTC+0</span>)(<span id="cf-utc-rel">--</span>)</span><span class="tz-time"><span id="cf-utc-live">--</span>。</span></span>' +
        '<span class="tz-line"><span class="tz-label">北京时间 (<span id="cf-bj-off">UTC+8</span>)(<span id="cf-bj-rel">--</span>)</span><span class="tz-time"><span id="cf-bj-live">--</span>。</span></span>' +
        '<span class="tz-line"><span class="tz-label">东京时间 (<span id="cf-tk-off">UTC+9</span>)(<span id="cf-tk-rel">--</span>)</span><span class="tz-time"><span id="cf-tk-live">--</span>。</span></span>' +
        '<span class="tz-line"><span class="tz-label">悉尼时间 (<span id="cf-sy-off">UTC+10/+11</span>)(<span id="cf-sy-rel">--</span>)</span><span class="tz-time"><span id="cf-sy-live">--</span>。</span></span>' +
        '<span class="tz-line"><span class="tz-label">最早时间 (<span id="cf-ki-off">UTC+14</span>)(<span id="cf-ki-rel">--</span>)</span><span class="tz-time"><span id="cf-ki-live">--</span>。</span></span>' +
        '</div>' +
        '<span class="tz-line tz-reset-line"><span class="tz-reset-head">北京时间 (UTC+8) <b>8:00</b> 重置，</span><span class="tz-reset-tail"><span class="tz-reset-label">距离重置还有</span><span id="cf-reset-live">--</span>。</span></span>' +
        '今日使用情况总计： <b class="unum">' + (d.total||0).toLocaleString() + '</b>' +
        ' · <a class="usetup" href="/usage" style="margin:0">详情/更新凭证</a></div>';
    startLive();
  }

  fetch("/usage?format=json", {credentials:"same-origin"})
    .then(function(r){ return r.json(); })
    .then(render)
    .catch(function(e){
      src.textContent = "失败";
      box.innerHTML = '<div class="uerr">获取失败：' + esc(e && e.message || e) +
        '</div><a class="usetup" href="/usage">打开使用量页面 →</a>';
    });
})();
</script>

  </div>

  
  
  
  <!-- 网络信息模块 -->
			<div id="net-info-box" class="module network-detail-collapsed">
				<div class="module-title" onclick="toggleNetworkModule(this)">
					🌍 当前网络信息
					<svg class="collapse-icon" viewBox="0 0 24 24" style="transform: rotate(90deg);">
						<path d="M7 10l5 5 5-5z" />
					</svg>
				</div>
				<div class="module-content">
					<div class="network-cards-container">
						<div class="network-card">
							<div class="network-card-title">
								<span class="status-indicator" id="status-ipip"></span>
								<div class="title-text">
									<div class="title-main">国内测试</div>
									<div class="title-subtitle">CN-Test</div>
								</div>
							</div>
							<div class="network-info-content">
								<span id="ipip-ip" class="ip-text">-</span>
								<div class="location-text">
									<span id="ipip-country" class="country-text">-</span>
								</div>
								<div class="network-tip">· 您访问国内站点所使用的IP</div>
							</div>
						</div>

						<div class="network-card">
							<div class="network-card-title">
								<span class="status-indicator" id="status-overseas"></span>
								<div class="title-text">
									<div class="title-main">国外测试</div>
									<div class="title-subtitle">漏网之鱼</div>
								</div>
							</div>
							<div class="network-info-content">
								<span id="overseas-ip" class="ip-text">-</span>
								<div class="location-text">
									<span id="overseas-country" class="country-text">-</span>
								</div>
								<div class="network-tip">· 您访问没有被封的国外站点所使用的IP</div>
							</div>
						</div>

						<div class="network-card">
							<div class="network-card-title">
								<span class="status-indicator" id="status-cf"></span>
								<div class="title-text">
									<div class="title-main">CloudFlare</div>
									<div class="title-subtitle" id="cf-subtitle">ProxyIP</div>
								</div>
							</div>
							<div class="network-info-content">
								<span id="cf-ip" class="ip-text">-</span>
								<div class="location-text">
									<span id="cf-country" class="country-text">-</span>
								</div>
								<div class="network-tip">· 您访问CFCDN站点所使用的落地IP</div>
							</div>
						</div>

						<div class="network-card">
							<div class="network-card-title">
								<span class="status-indicator" id="status-twitter"></span>
								<div class="title-text">
									<div class="title-main">墙外测试</div>
									<div class="title-subtitle">!CN-Test</div>
								</div>
							</div>
							<div class="network-info-content">
								<span id="twitter-ip" class="ip-text">-</span>
								<div class="location-text">
									<span id="twitter-country" class="country-text">-</span>
								</div>
								<div id="twitter-tip" class="network-tip">· 您访问墙外站点所使用的IP</div>
							</div>
						</div>
					</div>
					<div class="module-content" style="display: none;" id="network-module-content">
						<!-- 延迟测试卡片 -->
						<div class="latency-cards" id="latency-cards">
							<!-- 卡片将通过JavaScript动态生成 -->
						</div>
					</div>
				</div>
			</div>

			
<script>
(function(){
  var latencySites = [
			{
				name: '字节抖音',
				region: '国内',
				icon: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="#1677FF" d="m19.9 1.5 4.1 1v19l-4.1 1zM6.5 10.9l4.1 1v9l-4 1.1zM0 2.6l4.1 1v16.8l-4.1 1zm17.5 5.6v11.1l-4.2-1v-9z"></path></svg>',
				url: 'https://lf3-zlink-tos.ugurl.cn/obj/zebra-public/resource_lmmizj_1632398893.png'
			},
			{
				name: 'Bilibili',
				region: '国内',
				icon: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="#FB7299" d="M17.813 4.653h.854q2.266.08 3.773 1.574Q23.946 7.72 24 9.987v7.36q-.054 2.266-1.56 3.773c-1.506 1.507-2.262 1.524-3.773 1.56H5.333q-2.266-.054-3.773-1.56C.053 19.614.036 18.858 0 17.347v-7.36q.054-2.267 1.56-3.76t3.773-1.574h.774l-1.174-1.12a1.23 1.23 0 0 1-.373-.906q0-.534.373-.907l.027-.027q.4-.373.92-.373t.92.373L9.653 4.44q.107.106.187.213h4.267a.8.8 0 0 1 .16-.213l2.853-2.747q.4-.373.92-.373c.347 0 .662.151.929.4s.391.551.391.907q0 .532-.373.906zM5.333 7.24q-1.12.027-1.88.773q-.76.748-.786 1.894v7.52q.026 1.146.786 1.893t1.88.773h13.334q1.12-.026 1.88-.773t.786-1.893v-7.52q-.026-1.147-.786-1.894t-1.88-.773zM8 11.107q.56 0 .933.373q.375.374.4.96v1.173q-.025.586-.4.96q-.373.375-.933.374c-.56-.001-.684-.125-.933-.374q-.375-.373-.4-.96V12.44q0-.56.386-.947q.387-.386.947-.386m8 0q.56 0 .933.373q.375.374.4.96v1.173q-.025.586-.4.96q-.373.375-.933.374c-.56-.001-.684-.125-.933-.374q-.375-.373-.4-.96V12.44q.025-.586.4-.96q.373-.373.933-.373"></path></svg>',
				url: 'https://i0.hdslb.com/bfs/face/member/noface.jpg@24w_24h_1c'
			},
			{
				name: '腾讯微信',
				region: '国内',
				icon: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="#09B83E" d="M8.7 2.19C3.9 2.19 0 5.48 0 9.53c0 2.21 1.17 4.2 3 5.55a.6.6 0 0 1 .21.66l-.39 1.48q-.03.11-.04.22c0 .16.13.3.29.3a.3.3 0 0 0 .16-.06l1.9-1.11a.9.9 0 0 1 .72-.1 10 10 0 0 0 2.84.4q.41-.01.81-.05a5.85 5.85 0 0 1 1.93-6.45 8.3 8.3 0 0 1 5.86-1.83c-.58-3.59-4.2-6.35-8.6-6.35m-2.9 3.8c.64 0 1.16.53 1.16 1.18a1.17 1.17 0 0 1-1.16 1.18 1.17 1.17 0 0 1-1.17-1.18c0-.65.52-1.18 1.17-1.18m5.8 0c.65 0 1.17.53 1.17 1.18a1.17 1.17 0 0 1-1.16 1.18 1.17 1.17 0 0 1-1.16-1.18c0-.65.52-1.18 1.16-1.18m5.34 2.87a8 8 0 0 0-5.28 1.78 5.5 5.5 0 0 0-1.78 6.22c.94 2.46 3.66 4.23 6.88 4.23q1.25 0 2.36-.33a.7.7 0 0 1 .6.08l1.59.93.14.04c.13 0 .24-.1.24-.24q-.01-.09-.04-.18l-.33-1.23-.02-.16a.5.5 0 0 1 .2-.4 5.8 5.8 0 0 0 2.5-4.62c0-3.21-2.93-5.84-6.66-6.09zm-2.53 3.27c.53 0 .97.44.97.98a1 1 0 0 1-.97.99 1 1 0 0 1-.97-.99c0-.54.43-.98.97-.98zm4.84 0c.54 0 .97.44.97.98a1 1 0 0 1-.97.99 1 1 0 0 1-.97-.99c0-.54.44-.98.97-.98"></path></svg>',
				url: 'https://res.wx.qq.com/a/wx_fed/assets/res/NTI4MWU5.ico'
			},
			{
				name: '阿里淘宝',
				region: '国内',
				icon: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="#E16322" d="M21.31 9.9a3 3 0 1 1 0 1.92.96.96 0 0 1 0-1.92m2.39 3.05H13.3v-.96h4.14V9.76h-2.89v-.77h2.9v-.92h-2.52v.2H13.3v-2.9h1.64v.35l2.52-.3V4.6h1.85v.64c.93-.08 1.76-.13 2.21-.1 1.5.06 2.45.27 2.49 1.26.03 1-1.43 1.9-1.43 1.9l-.45-.43v.2h-2.8v.92h3.22v.77h-3.23v2.23h4.39zM21.53 7.3l-.02-.01s1.38-.76.35-1.27c-.87-.43-5.54.3-6.93.62v.66zM1.88 6.42a1 1 0 0 0 0-2 1 1 0 0 0-1 1 1 1 0 0 0 1 1m3.41-.86a7 7 0 0 0 .37-.72L4.2 4.42s-.6 1.93-1.65 2.83c0 0 1.02.6 1.01.58a10 10 0 0 0 .78-.88l.68-.3a9 9 0 0 1-1.14 1.69l.61.54s.42-.4.88-.9h.53v.9H3.86v.73H5.9v1.72h-.08c-.23-.01-.58-.05-.71-.27-.17-.26-.05-.75-.04-1.04h-1.4l-.06.02s-.52 2.32 1.5 2.27a5.3 5.3 0 0 0 3.46-.92l.2.76 1.17-.48-.79-1.92-.94.3.18.65a3 3 0 0 1-.82.42V9.6h2v-.72h-2v-.9h2v-.72H6.01c.26-.31.46-.6.51-.78l-.62-.17c2.67-.95 4.15-.79 4.13.77v4.12s.16 1.4-1.46 1.3l-.87-.18-.21.83s3.78 1.08 4.1-1.82-.09-4.76-.09-4.76-.34-2.68-6.2-1.02zm-5.23 6.6 1.58.98c1.1-2.38 1.03-2.06 1.3-2.92.29-.87.35-1.54-.13-2.02a10 10 0 0 0-1.6-1.36L.55 7.86l1.21.75s.82.42.43 1.2c-.36.73-2.13 2.34-2.13 2.34M20 19s-.02.53-.67.53c-.6 0-.64-.42-.64-.42q-.39.45-1.07.46c-.76 0-1.3-.51-1.3-1.3 0-.78.56-1.27 1.4-1.27.39 0 .73.15.93.4l.01-.2c0-.56-.3-.8-1-.8q-.51 0-1.02.13.16-.33.3-.45.18-.14.94-.14c1.27 0 1.74.42 1.74 1.42v1.2c0 .32.03.44.38.44m-1.33-.74c0-.48-.25-.75-.64-.75-.4 0-.66.28-.66.76 0 .47.27.76.65.76.39 0 .65-.27.65-.77m5.27-.5c0 1.15-.7 1.82-1.78 1.82-1.1 0-1.77-.67-1.77-1.82 0-1.16.68-1.83 1.77-1.83s1.78.67 1.78 1.83m-1.08 0q0-1.3-.7-1.3t-.69 1.3.7 1.3.69-1.3m-7.14-.05c0 1.17-.65 1.86-1.57 1.86q-.66-.01-1.05-.47s-.1.42-.66.42c-.69 0-.67-.52-.67-.52.4.02.38-.21.38-.43v-2.89c0-.36-.07-.48-.43-.49.02-.1.08-.53.68-.53.82 0 .76.91.76.91v.79q.34-.4 1-.4c.96 0 1.56.65 1.56 1.75m-1.09.08q-.01-1.35-.76-1.35c-.44 0-.74.4-.74 1.1v.36c0 .72.31 1.12.76 1.12q.73 0 .74-1.23m-3.24-.03c0 1.15-.7 1.82-1.78 1.82-1.1 0-1.78-.67-1.78-1.82 0-1.16.68-1.83 1.78-1.83s1.78.67 1.78 1.83m-1.09 0q0-1.3-.7-1.3-.69 0-.68 1.3t.69 1.3q.7 0 .7-1.3m-6-2.72q-.4.11-1.55.1-1.38-.02-1.85-.04c-.52 0-.73.13-.91.66q.45-.13 1.13-.11c.36 0 .42.04.42.3v2.9c0 .28.11.67.72.67.71 0 .84-.52.84-.52-.36 0-.43-.13-.43-.49v-2.56c0-.27.1-.28.47-.28h.26c.55 0 .7-.1.9-.63M7.46 19s-.02.52-.67.52c-.56 0-.64-.4-.64-.4q-.39.45-1.07.45c-.76 0-1.3-.52-1.3-1.3S4.33 17 5.17 17c.39 0 .73.14.93.4v-.2c0-.56-.3-.8-1-.8q-.5 0-1.01.13.15-.33.3-.46.17-.14.94-.14c1.26 0 1.74.43 1.74 1.43v1.2c0 .32.03.44.38.44m-1.33-.75c0-.48-.26-.74-.64-.74-.4 0-.67.28-.67.76 0 .46.28.76.66.76.39 0 .65-.28.65-.78"></path></svg>',
				url: 'https://img.alicdn.com/imgextra/i2/O1CN01qnQCrN1VkzAWiU4Hs_!!6000000002692-2-tps-33-33.png'
			},
			{
				name: 'GitHub',
				region: '国际',
				icon: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="#181717" d="M12 .3a12 12 0 0 0-3.8 23.38c.6.12.83-.26.83-.57L9 21.07c-3.34.72-4.04-1.61-4.04-1.61-.55-1.39-1.34-1.76-1.34-1.76-1.08-.74.09-.73.09-.73 1.2.09 1.84 1.24 1.84 1.24 1.07 1.83 2.8 1.3 3.49 1 .1-.78.42-1.31.76-1.61-2.66-.3-5.47-1.33-5.47-5.93 0-1.31.47-2.38 1.24-3.22-.14-.3-.54-1.52.1-3.18 0 0 1-.32 3.3 1.23a11.5 11.5 0 0 1 6 0c2.28-1.55 3.29-1.23 3.29-1.23.64 1.66.24 2.88.12 3.18a4.7 4.7 0 0 1 1.23 3.22c0 4.61-2.8 5.63-5.48 5.92.42.36.81 1.1.81 2.22l-.01 3.29c0 .31.2.69.82.57A12 12 0 0 0 12 .3"></path></svg>',
				url: 'https://github.github.io/janky/images/bg_hr.png'
			},
			{
				name: 'Telegram.DC5',
				region: '国际',
				icon: '<svg width="24px" height="24px" viewBox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><defs><linearGradient x1="50%" y1="0%" x2="50%" y2="100%" id="linearGradient-1"><stop stop-color="#38AEEB" offset="0%"></stop><stop stop-color="#279AD1" offset="100%"></stop></linearGradient></defs><g id="Artboard" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd"><circle id="Oval" fill="url(#linearGradient-1)" cx="8" cy="8" r="8"></circle><path d="M3.17026167,7.83635602 C5.78750201,6.74265999 7.53273882,6.02162863 8.40597211,5.67326193 C10.8992306,4.67860423 11.2454541,4.53439191 11.5831299,4.52864956 C11.6573986,4.52743168 11.8385417,4.55776042 11.9798438,4.67645833 C12.1211458,4.79515625 12.1635786,4.87206678 12.1755371,4.93908691 C12.1874957,5.00610705 12.1862759,5.21456762 12.1744385,5.3338623 C12.0393279,6.69547283 11.5259342,9.83829771 11.2285121,11.3633248 C11.1026617,12.008621 10.8548582,12.2249854 10.6149558,12.2461596 C10.0935924,12.2921758 9.69769267,11.9156852 9.19272668,11.5981993 C8.40255458,11.1013965 8.13911734,10.9180161 7.3721185,10.4332283 C6.48571864,9.87297217 6.85080034,9.6784879 7.35595703,9.17524981 C7.48815894,9.04355001 9.67825076,7.04590073 9.71077046,6.86250183 C9.7391276,6.70257812 9.7494847,6.68189389 9.67664063,6.60973958 C9.60379655,6.53758527 9.51674192,6.54658941 9.46083149,6.55876051 C9.38158015,6.57601267 8.17521836,7.33962686 5.84174612,8.84960308 C5.48344358,9.08558775 5.15890428,9.20056741 4.86812819,9.19454205 C4.54757089,9.18789957 3.93094724,9.02070014 3.47255094,8.87778221 C2.91030922,8.70248755 2.46345069,8.609808 2.50236203,8.31210343 C2.52262946,8.15704047 2.74526267,7.998458 3.17026167,7.83635602 Z" id="Path-3" fill="#FFFFFF"></path></g></svg>',
				url: 'https://flora.web.telegram.org/'
			},
			{
				name: 'X.com',
				region: '国际',
				icon: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="#1DA1F2" d="M23.643 4.937c-.835.37-1.732.62-2.675.733.962-.576 1.7-1.49 2.048-2.578-.9.534-1.897.922-2.958 1.13-.85-.904-2.06-1.47-3.4-1.47-2.572 0-4.658 2.086-4.658 4.66 0 .364.042.718.12 1.06-3.873-.195-7.304-2.05-9.602-4.868-.4.69-.63 1.49-.63 2.342 0 1.616.823 3.043 2.072 3.878-.764-.025-1.482-.234-2.11-.583v.06c0 2.257 1.605 4.14 3.737 4.568-.392.106-.803.162-1.227.162-.3 0-.593-.028-.877-.082.594 1.85 2.323 3.196 4.368 3.233-1.595 1.25-3.604 1.995-5.786 1.995-.376 0-.747-.022-1.112-.065 2.072 1.328 4.532 2.104 7.172 2.104 8.607 0 13.3-7.132 13.3-13.3 0-.202-.005-.403-.014-.602.913-.66 1.706-1.477 2.332-2.41z"></path></svg>',
				url: 'https://abs.twimg.com/favicons/twitter.3.ico'
			},
			{
				name: 'YouTube',
				region: '国际',
				icon: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="#FF0000" d="M23.5 6.19a3 3 0 0 0-2.12-2.14c-1.87-.5-9.38-.5-9.38-.5s-7.5 0-9.38.5A3 3 0 0 0 .5 6.19C0 8.07 0 12 0 12s0 3.93.5 5.81a3 3 0 0 0 2.12 2.14c1.87.5 9.38.5 9.38.5s7.5 0 9.38-.5a3 3 0 0 0 2.12-2.14C24 15.93 24 12 24 12s0-3.93-.5-5.81M9.55 15.57V8.43L15.82 12z"></path></svg>',
				url: 'https://www.youtube.com/favicon.ico'
			}
		];
function calculateAbuseScore(companyScore, asnScore, securityFlags = {}) {
			// 如果两个分数都无效，返回null
			if (!companyScore || companyScore === '未知') companyScore = 0;
			if (!asnScore || asnScore === '未知') asnScore = 0;

			const company = parseFloat(companyScore) || 0;
			const asn = parseFloat(asnScore) || 0;

			// 计算基础评分：(company + asn) / 2 * 5
			let baseScore = ((company + asn) / 2) * 5;

			// 计算安全风险附加分：每个安全风险项增加 15%
			let riskAddition = 0;
			const riskFlags = [
				securityFlags.is_crawler,   // 爬虫
				securityFlags.is_proxy,     // 代理服务器
				securityFlags.is_vpn,       // VPN
				securityFlags.is_tor,       // Tor 网络
				securityFlags.is_abuser     // 滥用 IP
			];

			// 统计为 true 的风险项数量
			const riskCount = riskFlags.filter(flag => flag === true).length;
			riskAddition = riskCount * 0.15; // 每个风险项增加 15%

			// 最终评分 = 基础评分 + 风险附加分
			let finalScore = baseScore + riskAddition;

			// 如果是虚假IP (蜜罐)，则风险值增加100%
			if (securityFlags.is_bogon === true) {
				finalScore += 1.0; // 增加100%
			}

			// 如果基础评分和风险附加分都是0且不是虚假IP，返回null
			if (baseScore === 0 && riskAddition === 0 && securityFlags.is_bogon !== true) return null;

			return finalScore;
		}
function getAbuseScoreBadgeClass(percentage) {
			if (percentage === null || percentage === undefined) return 'badge-info';

			if (percentage >= 100) return 'badge-critical';      // 危险红色 >= 100%
			if (percentage >= 20) return 'badge-high';           // 橘黄色 15-99.99%
			if (percentage >= 5) return 'badge-elevated';     // 黄色 5-14.99%
			if (percentage >= 0.25) return 'badge-low';          // 淡绿色 0.25-4.99%
			return 'badge-verylow';                              // 绿色 < 0.25%
		}
function formatAbuseScorePercentage(score) {
			if (score === null || score === undefined) return '未知';

			const percentage = score * 100;
			return percentage.toFixed(2) + '%';
		}
function formatIpType(type) {
			if (!type) return '<span class="ip-type-unknown">未知</span>';

			const typeMap = {
				'isp': { text: '住宅', class: 'ip-type-residential' },
				'hosting': { text: '机房', class: 'ip-type-hosting' },
				'business': { text: '商用', class: 'ip-type-business' }
			};

			const typeInfo = typeMap[type.toLowerCase()] || { text: type, class: 'ip-type-unknown' };
			return \`<span class="\${typeInfo.class}">\${typeInfo.text}</span>\`;
		}
function normalizeIpapiData(data) {
			if (!data || typeof data !== 'object') return data || {};

			// 幂等保护：已有 location 子对象说明是旧格式或 fallback 数据，无需二次处理
			if (data.location && typeof data.location === 'object') return data;

			// 复制原对象并保留扁平字段（cc/lat/lon/company_name/asn_num/asn_org 等仍可访问）
			const normalized = Object.assign({}, data);

			// 构造 location 子对象（新版缺少 country/state/city/timezone，缺省为 undefined）
			normalized.location = {
				country: data.country,
				country_code: data.cc,
				state: data.state,
				city: data.city,
				latitude: data.lat,
				longitude: data.lon,
				timezone: data.timezone
			};

			// 构造 company 子对象（新版仅有 company_name，无 type/abuser_score，缺省为 undefined）
			normalized.company = {
				name: data.company_name,
				type: data.company_type,
				abuser_score: data.company_abuser_score
			};

			// 构造 asn 子对象（新版仅有 asn_num/asn_org，无 type/abuser_score，缺省为 undefined）
			normalized.asn = {
				asn: data.asn_num,
				org: data.asn_org,
				type: data.asn_type,
				abuser_score: data.asn_abuser_score
			};

			return normalized;
		}
function showIpDetailModal(data) {
			// 首先移除旧的弹窗（如果存在）
			const existingModal = document.querySelector('.ip-detail-modal');
			if (existingModal) existingModal.remove();

			// 创建弹窗
			const modal = document.createElement('div');
			modal.className = 'ip-detail-modal';

			// 计算评分和等级
			const companyScore = data.company?.abuser_score;
			const asnScore = data.asn?.abuser_score;
			const securityFlags = {
				is_crawler: data.is_crawler,
				is_proxy: data.is_proxy,
				is_vpn: data.is_vpn,
				is_tor: data.is_tor,
				is_abuser: data.is_abuser,
				is_bogon: data.is_bogon
			};

			const combinedScore = calculateAbuseScore(companyScore, asnScore, securityFlags);
			let riskControlHTML = '未知';
			let riskLevel = '未知';
			let badgeClass = 'badge-info';

			if (combinedScore !== null) {
				const scorePercentage = combinedScore * 100;
				badgeClass = getAbuseScoreBadgeClass(scorePercentage);
				const formattedScore = formatAbuseScorePercentage(combinedScore);

				if (scorePercentage >= 100) riskLevel = '极度危险';
				else if (scorePercentage >= 20) riskLevel = '高风险';
				else if (scorePercentage >= 5) riskLevel = '轻微风险';
				else if (scorePercentage >= 0.25) riskLevel = '纯净';
				else riskLevel = '极度纯净';

				riskControlHTML = \`<span class="ip-detail-badge \${badgeClass}">\${formattedScore} \${riskLevel}</span>\`;
			}

			// 构建 HTML 结构
			modal.innerHTML = \`
				<div class="ip-detail-content">
					<div class="ip-detail-header">
						<h2 class="ip-detail-title">
							🔍 IP 详细信息
							<span class="ip-detail-source-tag">数据来源: ipapi.is</span>
						</h2>
						<button class="ip-detail-close" title="关闭">&times;</button>
					</div>
					<div class="ip-detail-body">
						<!-- 地图展示区 -->
						<div class="ip-detail-map-container">
							<div id="ip-detail-map"></div>
						</div>

						<!-- 数据网格区 -->
						<div class="ip-detail-grid-container">
							<!-- 左栏: 基本信息 (整合地理、运营商信息) -->
							<div class="ip-detail-left-col">
								<div class="ip-detail-card" style="height: 100%;">
									<div class="ip-detail-section-title">📍 基本信息</div>
									<div class="ip-detail-item" title="当前查询的公网 IP 地址，用于在互联网上唯一标识设备">
										<span class="ip-detail-label">IP 地址</span>
										<span class="ip-detail-value">\${data.ip || '未知'}</span>
									</div>
									<div class="ip-detail-item" title="IP 地址的物理位置，通过 IP 地址段分配数据库推算得出，包括国家/地区、州省和城市信息">
										<span class="ip-detail-label">地理位置</span>
										<span class="ip-detail-value">\${data.location?.country_code ? \`[\${data.location.country_code}]\` : ''}\${data.location?.country || ''} \${[data.location?.state, data.location?.city].filter(Boolean).join('/') || '未知'}</span>
									</div>
									<div class="ip-detail-item" title="该 IP 地址所在地区使用的标准时区，格式为洲/城市，如 Asia/Shanghai">
										<span class="ip-detail-label">时区</span>
										<span class="ip-detail-value">\${data.location?.timezone || '未知'}</span>
									</div>
									<div class="ip-detail-item" title="IP 的网络类型:【住宅】家庭宽带、【机房】数据中心或云服务器、【商用】企业专线。左侧为运营商分类，右侧为 ASN (自治系统)分类">
										<span class="ip-detail-label">运营商 / ASN 类型</span>
										<span class="ip-detail-value">\${formatIpType(data.company?.type)} / \${formatIpType(data.asn?.type)}</span>
									</div>
									<div class="ip-detail-item" title="综合滥用评分，基于运营商/ASN 历史记录和安全风险项计算。评分越低表示 IP 越纯净，越高表示被滥用可能性越大">
										<span class="ip-detail-label">风控评级</span>
										<span class="ip-detail-value">\${riskControlHTML}</span>
									</div>
								</div>
							</div>

							<!-- 右栏: 安全检测 -->
							<div class="ip-detail-right-col">
								<!-- 安全检测内容保持不变 -->
								<div class="ip-detail-card" style="height: 100%;">
									<div class="ip-detail-section-title">🛡️ 安全检测</div>
									<div class="ip-detail-security-grid">
										<div class="ip-detail-item" title="该 IP 是否属于数据中心(IDC)、云服务商或主机托管服务。数据中心 IP 常被用于服务器部署，部分网站可能限制此类 IP 访问">
											<span class="ip-detail-label">数据中心</span>
											<span class="ip-detail-value">\${data.is_datacenter ? '<span class="warning-text">🏢 是</span>' : '✅ 否'}</span>
										</div>
										<div class="ip-detail-item" title="该 IP 是否被识别为公开的代理服务器(如 HTTP/SOCKS 代理)。代理服务器可能被用于隐藏真实 IP，部分服务会限制代理访问">
											<span class="ip-detail-label">代理服务器</span>
											<span class="ip-detail-value">\${data.is_proxy ? '<span class="danger-text">⚠️ 是</span>' : '✅ 否'}</span>
										</div>
										<div class="ip-detail-item" title="该 IP 是否属于已知的 VPN (虚拟私人网络)服务提供商。VPN 用于加密网络流量和隐藏真实位置，部分网站会限制 VPN 访问">
											<span class="ip-detail-label">VPN 连线</span>
											<span class="ip-detail-value">\${data.is_vpn ? '<span class="danger-text">⚠️ 是</span>' : '✅ 否'}</span>
										</div>
										<div class="ip-detail-item" title="该 IP 是否属于 Tor (洋葱路由)匿名网络的出口节点。Tor 提供高度匿名性，但也常被用于非法活动，因此大多数网站会限制或禁止 Tor 访问">
											<span class="ip-detail-label">Tor 网络</span>
											<span class="ip-detail-value">\${data.is_tor ? '<span class="danger-text">⚠️ 是</span>' : '✅ 否'}</span>
										</div>
										<div class="ip-detail-item" title="该 IP 是否被识别为网络爬虫(搜索引擎蜘蛛、数据采集机器人等)。爬虫可能对网站造成额外负担，部分网站会限制或特殊处理爬虫流量">
											<span class="ip-detail-label">网络爬虫</span>
											<span class="ip-detail-value">\${data.is_crawler ? '<span class="danger-text">🤖 是</span>' : '✅ 否'}</span>
										</div>
										<div class="ip-detail-item" title="该 IP 是否来自移动网络运营商(如 4G/5G 网络)。移动网络 IP 通常动态分配且更换频繁，属于住宅类 IP">
											<span class="ip-detail-label">移动网络</span>
											<span class="ip-detail-value">\${data.is_mobile ? '<span class="success-text">📱 是</span>' : '否'}</span>
										</div>
										<div class="ip-detail-item" title="该 IP 是否来自卫星互联网服务(如 Starlink、OneWeb 等)。卫星网络通常用于偏远地区或移动场景的互联网接入，延迟较高">
											<span class="ip-detail-label">卫星网络</span>
											<span class="ip-detail-value">\${data.is_satellite ? '<span class="success-text">🛰️ 是</span>' : '否'}</span>
										</div>
										<div class="ip-detail-item" title="该 IP 是否存在已知的滥用记录(如垃圾邮件、DDoS 攻击、恶意扫描等)。滥用 IP 通常会被安全系统拦截或限制访问">
											<span class="ip-detail-label">已知滥用</span>
											<span class="ip-detail-value">\${data.is_abuser ? '<span class="danger-text">⚠️ 是</span>' : '✅ 否'}</span>
										</div>
										<div class="ip-detail-item" title="该 IP 是否为虚假 IP (Bogon IP)，即保留地址、私有地址或未分配的地址段。此类 IP 不应出现在公网上，可能表示异常流量或蜜罐">
											<span class="ip-detail-label">虚假 IP</span>
											<span class="ip-detail-value">\${data.is_bogon ? '<span class="danger-text">⚠️ 是</span>' : '✅ 否'}</span>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			\`;

			document.body.appendChild(modal);

			// 初始化弹窗内的地图
			if (data.location?.latitude && data.location?.longitude) {
				const lat = parseFloat(data.location.latitude);
				const lng = parseFloat(data.location.longitude);

				// 给 DOM 渲染留出一点点时间
				setTimeout(() => {
					// Leaflet 异步到达：极端情况下（镜像全挂）这里它还没加载好，跳过地图渲染即可，
					// 不能让这个定时器里抛 ReferenceError 污染全局。
					if (typeof L === 'undefined') return;
					const detailMap = L.map('ip-detail-map', {
						zoomControl: false,
						attributionControl: false
					}).setView([lat + 5, lng], 4); // 向上偏移中心点，使标记在视野内偏下

					L.tileLayer('https://webrd0{s}.is.autonavi.com/appmaptile?lang=zh_cn&size=1&scale=1&style=8&x={x}&y={y}&z={z}', {
						subdomains: '1234',
						minZoom: 1,
						maxZoom: 18
					}).addTo(detailMap);

					const popupHTML = \`
						<div class="ip-detail-popup-content">
							<div class="ip-detail-popup-city">
								\${data.location?.city || data.location?.country || '位置'}
							</div>
							<div class="ip-detail-popup-item">
								<span class="ip-detail-popup-label">国家:</span>
								<span class="ip-detail-popup-value">[\${data.location?.country_code || '-'}]\${data.location?.country || '未知'}</span>
							</div>
							<div class="ip-detail-popup-item">
								<span class="ip-detail-popup-label">落地IP:</span>
								<span class="ip-detail-popup-value">\${data.ip}</span>
							</div>
							<div class="ip-detail-popup-item">
								<span class="ip-detail-popup-label">ASN:</span>
								<span class="ip-detail-popup-value">\${data.asn?.asn || ''}</span>
							</div>
							<div class="ip-detail-popup-item">
								<span class="ip-detail-popup-label">运营商:</span>
								<span class="ip-detail-popup-value">\${data.company?.name || '未知'}</span>
							</div>
						</div>
					\`;

					L.marker([lat, lng])
						.addTo(detailMap)
						.bindPopup(popupHTML, { closeButton: false, offset: [0, -32] })
						.openPopup();

					// 偶尔地图布局会出问题，强制刷新
					detailMap.invalidateSize();
				}, 400);
			} else {
				// 如果没有经纬度，隐藏地图容器
				const mapContainer = modal.querySelector('.ip-detail-map-container');
				if (mapContainer) mapContainer.style.display = 'none';
			}

			// 关闭逻辑
			const closeBtn = modal.querySelector('.ip-detail-close');
			const closeFunc = () => {
				modal.style.opacity = '0';
				modal.querySelector('.ip-detail-content').style.transform = 'translateY(20px)';
				setTimeout(() => modal.remove(), 300);
			};

			closeBtn.onclick = closeFunc;
			modal.onclick = (e) => { if (e.target === modal) closeFunc(); };

			// ESC 键关闭
			const escHandler = (e) => {
				if (e.key === 'Escape') {
					closeFunc();
					document.removeEventListener('keydown', escHandler);
				}
			};
			document.addEventListener('keydown', escHandler);
		}

  function ensureLeaflet(cb){
    if(typeof L!=="undefined"){ cb(); return; }
    if(window.__leafletLoading){ window.__leafletLoading.push(cb); return; }
    window.__leafletLoading=[cb];
    var css=document.createElement("link"); css.rel="stylesheet";
    css.href="https://cdn.jsdelivr.net/npm/leaflet@1.9.4/dist/leaflet.css";
    document.head.appendChild(css);
    var js=document.createElement("script");
    js.src="https://cdn.jsdelivr.net/npm/leaflet@1.9.4/dist/leaflet.js";
    js.onload=function(){ var q=window.__leafletLoading||[]; window.__leafletLoading=null; q.forEach(function(fn){try{fn()}catch(e){}}); };
    document.head.appendChild(js);
  }
  var _showIpDetailModal = showIpDetailModal;
  window.showIpDetailModal = function(data){
    var need = data && data.location && data.location.latitude && data.location.longitude;
    if(need && typeof L==="undefined") ensureLeaflet(function(){ _showIpDetailModal(data); });
    else _showIpDetailModal(data);
  };
  window.fetchAndShowIpDetail = async function(ip, targetElement){
    var cleanIp = String(ip || "").trim();
    if(cleanIp.indexOf("*")>=0 && targetElement && targetElement.dataset && targetElement.dataset.rawValue){
      cleanIp = String(targetElement.dataset.rawValue || "").trim();
    }
    if(!cleanIp || cleanIp==="未知") return;
    if(targetElement){
      if(targetElement.classList.contains("is-loading")) return;
      targetElement.classList.add("is-loading");
      targetElement.setAttribute("aria-busy","true");
    }
    try{
      var controller = new AbortController();
      var timeoutId = setTimeout(function(){ controller.abort(); }, 5000);
      var response, fromPrimary=false;
      try{
        response = await fetch("https://api.090227.xyz/api/ipapi?ip="+encodeURIComponent(cleanIp));
        clearTimeout(timeoutId);
        if(!response.ok) throw new Error("Primary API failed");
        fromPrimary = true;
      }catch(e){
        response = await fetch("https://api.ipapi.is/?q="+encodeURIComponent(cleanIp), {signal:controller.signal});
        if(!response.ok) throw new Error("Fallback API failed");
      }
      var data = await response.json();
      showIpDetailModal(fromPrimary ? normalizeIpapiData(data) : data);
    }catch(error){
      alert("❌ 查询IP详细信息失败");
      console.error(error);
    }finally{
      if(targetElement){
        targetElement.classList.remove("is-loading");
        targetElement.removeAttribute("aria-busy");
      }
    }
  };
  window.showIpDetail = window.fetchAndShowIpDetail;

  function setStatus(id, status){
    var indicator = document.getElementById(id);
    if(indicator) indicator.className = "status-indicator status-"+status;
  }
  function setIpClickable(id, ip){
    var el = document.getElementById(id);
    if(!el) return;
    el.textContent = ip || "-";
    el.dataset.rawValue = ip || "";
    if(ip && ip!=="-" && ip!=="加载失败" && ip!=="未知"){
      el.className = "ip-text clickable";
      el.onclick = function(){ fetchAndShowIpDetail(ip, el); };
    } else {
      el.className = "ip-text";
      el.onclick = null;
    }
  }
  function setLoc(id, text){
    var el = document.getElementById(id);
    if(el) el.textContent = text || "-";
  }
  function parseTrace(text){
    var ip="", loc="", colo="";
    String(text||"").split("\\n").forEach(function(line){
      var i=line.indexOf("="); if(i<0)return;
      var k=line.slice(0,i).trim(), v=line.slice(i+1).trim();
      if(k==="ip") ip=v; if(k==="loc") loc=v; if(k==="colo") colo=v;
    });
    return {ip:ip, loc:loc, colo:colo};
  }
  function raceTrace(urls, ms){
    ms=ms||6000;
    return new Promise(function(resolve, reject){
      var done=false, left=urls.length, lastErr=null;
      if(!left){reject(new Error("empty"));return;}
      urls.forEach(function(url){
        var c=typeof AbortController!=="undefined"?new AbortController():null;
        var t=setTimeout(function(){try{c&&c.abort()}catch(e){}}, ms);
        fetch(url,{cache:"no-store",mode:"cors",signal:c&&c.signal})
          .then(function(r){if(!r.ok)throw new Error("http");return r.text()})
          .then(function(tx){
            clearTimeout(t); if(done)return;
            var p=parseTrace(tx);
            if(p.ip){done=true;resolve(p)} else {lastErr=new Error("noip"); if(--left<=0&&!done)reject(lastErr)}
          }).catch(function(e){clearTimeout(t);lastErr=e; if(--left<=0&&!done)reject(lastErr||e)});
      });
    });
  }

  setStatus("status-ipip","loading");
  raceTrace(["https://api.cloudflare-cn.com/cdn-cgi/trace","https://www.cf-ns.com/cdn-cgi/trace","https://www.cf-ns.net/cdn-cgi/trace","https://www.cf-ns.tech/cdn-cgi/trace"])
    .then(function(p){ setStatus("status-ipip","success"); setIpClickable("ipip-ip", p.ip); setLoc("ipip-country",[p.loc,p.colo].filter(Boolean).join(" · ")||"-"); })
    .catch(function(){ setStatus("status-ipip","error"); setIpClickable("ipip-ip","加载失败"); setLoc("ipip-country","-"); });

  setStatus("status-overseas","loading");
  fetch("https://api.cmliussss.net/api/ipinfo?_t="+Date.now(),{cache:"no-store"})
    .then(function(r){if(!r.ok)throw new Error("http");return r.json()})
    .then(function(d){
      if(!d.ip) throw new Error("noip");
      setStatus("status-overseas","success"); setIpClickable("overseas-ip", d.ip);
      setLoc("overseas-country", [d.country_code||"", d.asn||"", d.as_name||""].filter(Boolean).join(" ").trim()||"-");
    }).catch(function(){
      return fetch("https://api.ipify.org?format=json",{cache:"no-store"}).then(function(r){return r.json()}).then(function(d){
        setStatus("status-overseas","success"); setIpClickable("overseas-ip", d.ip); setLoc("overseas-country","-");
      });
    }).catch(function(){ setStatus("status-overseas","error"); setIpClickable("overseas-ip","加载失败"); setLoc("overseas-country","-"); });

  setStatus("status-cf","loading");
  var ts=Date.now();
  Promise.allSettled([
    fetch("https://ipv4.090227.xyz/?_t="+ts,{cache:"no-store"}).then(function(r){return r.json()}),
    fetch("https://ipv6.090227.xyz/?_t="+ts,{cache:"no-store"}).then(function(r){return r.json()})
  ]).then(function(results){
    var entry=null;
    results.forEach(function(res){ if(res.status==="fulfilled"&&res.value&&res.value.ip&&!entry) entry=res.value; });
    if(!entry) throw new Error("none");
    setStatus("status-cf","success"); setIpClickable("cf-ip", entry.ip);
    setLoc("cf-country", [entry.country||entry.country_code||"", entry.city||"", entry.colo||""].filter(Boolean).join(" · ")||"-");
  }).catch(function(){
    return raceTrace(["https://cloudflare.com/cdn-cgi/trace","https://1.1.1.1/cdn-cgi/trace"]).then(function(p){
      setStatus("status-cf","success"); setIpClickable("cf-ip", p.ip); setLoc("cf-country",[p.loc,p.colo].filter(Boolean).join(" · ")||"-");
    });
  }).catch(function(){ setStatus("status-cf","error"); setIpClickable("cf-ip","加载失败"); setLoc("cf-country","-"); });

  var twitterEntries=[], twitterActiveIndex=0;
  function getBrandClass(name){
    name=String(name||"");
    if(name.indexOf("Google")>=0||name.indexOf("谷歌")>=0) return "tw-subtitle-google";
    if(name.indexOf("X.com")>=0||name.indexOf("推特")>=0) return "tw-subtitle-twitter";
    return "";
  }
  function createJsonpRequest(url, callbackParam, timeoutMs){
    timeoutMs=timeoutMs||8000;
    return new Promise(function(resolve, reject){
      var cbName="__jp_"+Date.now()+"_"+Math.floor(Math.random()*1e6);
      var settled=false, script=document.createElement("script");
      var timer=setTimeout(function(){ if(settled)return; settled=true; try{delete window[cbName]}catch(e){} if(script.parentNode)script.parentNode.removeChild(script); reject(new Error("timeout")); }, timeoutMs);
      window[cbName]=function(payload){ if(settled)return; settled=true; clearTimeout(timer); try{delete window[cbName]}catch(e){} if(script.parentNode)script.parentNode.removeChild(script); resolve(payload); };
      script.onerror=function(){ if(settled)return; settled=true; clearTimeout(timer); try{delete window[cbName]}catch(e){} if(script.parentNode)script.parentNode.removeChild(script); reject(new Error("err")); };
      script.src=url+(url.indexOf("?")>=0?"&":"?")+callbackParam+"="+cbName;
      document.head.appendChild(script);
    });
  }
  function formatIpInfoLocation(info){
    var countryCode=String((info&&info.country_code)||"未知").trim()||"未知";
    var rawAsn=info&&info.asn;
    var asnText=(rawAsn===undefined||rawAsn===null)?"":(/^\\d+$/.test(String(rawAsn).trim())?("AS"+String(rawAsn).trim()):String(rawAsn).trim());
    var asnName=String((info&&(info.as_name||info.asn_organization||info.organization||info.isp))||"").trim();
    return (countryCode+" "+asnText+" "+asnName).trim()||"未知";
  }
  async function fetchIpInfoByIp(ip){
    var requestIp=String(ip||"").trim();
    if(!requestIp) throw new Error("missing ip");
    var response=await fetch("https://api.090227.xyz/api/ipsb?ip="+encodeURIComponent(requestIp),{cache:"no-store"});
    if(!response.ok) throw new Error("HTTP "+response.status);
    return response.json();
  }
  function renderTwitterSubtitle(){
    var statusElement=document.querySelector("#status-twitter");
    var titleElement=statusElement?statusElement.parentElement:null;
    if(!titleElement) return;
    var prev=document.getElementById("status-twitter");
    var prevStatus=prev?((prev.className.match(/status-(?!indicator)(\\w+)/)||[])[1]||""):"";
    if(!twitterEntries.length){
      titleElement.innerHTML='<span class="status-indicator" id="status-twitter"></span><div class="title-text"><div class="title-main">墙外测试</div><div class="title-subtitle">!CN-Test</div></div>';
      if(prevStatus) setStatus("status-twitter", prevStatus); return;
    }
    if(twitterEntries.length===1){
      var bc=getBrandClass(twitterEntries[0].providerName);
      titleElement.innerHTML='<span class="status-indicator" id="status-twitter"></span><div class="title-text"><div class="title-main">墙外测试</div><div class="title-subtitle"><span class="'+bc+'">'+twitterEntries[0].providerName+'</span></div></div>';
      if(prevStatus) setStatus("status-twitter", prevStatus); return;
    }
    twitterActiveIndex=Math.min(Math.max(twitterActiveIndex,0), twitterEntries.length-1);
    var onSwitch=function(event){
      event.preventDefault(); event.stopPropagation();
      var targetIndex=Number(event.currentTarget.getAttribute("data-tw-target-index"));
      if(!Number.isInteger(targetIndex)||targetIndex<0||targetIndex>=twitterEntries.length||targetIndex===twitterActiveIndex) return;
      twitterActiveIndex=targetIndex; renderTwitterActiveEntry();
    };
    var subtitleHtml=twitterEntries.map(function(entry,index){
      var bc=getBrandClass(entry.providerName);
      if(index===twitterActiveIndex) return '<span class="'+bc+'">'+entry.providerName+'</span>';
      return '<span class="'+bc+' cf-subtitle-switch" data-tw-target-index="'+index+'" role="button" tabindex="0">'+entry.providerName+'</span>';
    }).join('<span class="cf-subtitle-sep"> / </span>');
    titleElement.innerHTML='<span class="status-indicator" id="status-twitter"></span><div class="title-text"><div class="title-main">墙外测试</div><div class="title-subtitle">'+subtitleHtml+'</div></div>';
    if(prevStatus) setStatus("status-twitter", prevStatus);
    titleElement.querySelectorAll(".cf-subtitle-switch").forEach(function(el){
      el.title="点击切换来源";
      el.addEventListener("click", onSwitch);
    });
  }
  function renderTwitterActiveEntry(){
    if(!twitterEntries.length) return;
    twitterActiveIndex=Math.min(Math.max(twitterActiveIndex,0), twitterEntries.length-1);
    var active=twitterEntries[twitterActiveIndex];
    setIpClickable("twitter-ip", active.ip);
    setLoc("twitter-country", active.loc||"未知");
    var tip=document.getElementById("twitter-tip");
    if(tip) tip.textContent="· 您访问 "+active.providerName+" 所使用的IP";
    renderTwitterSubtitle();
  }
  (async function(){
    setStatus("status-twitter","loading");
    var isInvalid=function(ip){ var c=String(ip||"").trim(); return !c||c==="0.0.0.0"; };
    try{
      var tasks=[
        createJsonpRequest("https://jsonp-ip.appspot.com/?_t="+Date.now(),"callback",8000).then(function(p){
          var ip=String((p&&p.ip)||"").trim(); if(isInvalid(ip)) throw new Error("bad"); return {providerName:"谷歌(Google)", requestIp:ip};
        }),
        fetch("https://help.x.com/cdn-cgi/trace?_t="+Date.now(),{cache:"no-store"}).then(function(r){ if(!r.ok) throw new Error("http"); return r.text(); }).then(function(text){
          var line=text.split("\\n").find(function(l){return l.indexOf("ip=")===0});
          var ip=String(line?line.slice(3):"").trim(); if(isInvalid(ip)) throw new Error("bad"); return {providerName:"推特(X.com)", requestIp:ip};
        })
      ];
      var results=await Promise.allSettled(tasks);
      var ok=[];
      results.forEach(function(s){ if(s.status==="fulfilled"&&s.value) ok.push(s.value); });
      if(!ok.length) throw new Error("all failed");
      twitterEntries=await Promise.all(ok.map(async function(item){
        try{ var info=await fetchIpInfoByIp(item.requestIp); return {providerName:item.providerName, ip:String((info&&info.ip)||item.requestIp).trim(), loc:formatIpInfoLocation(info)}; }
        catch(e){ return {providerName:item.providerName, ip:item.requestIp, loc:"未知"}; }
      }));
      setStatus("status-twitter","success");
      renderTwitterActiveEntry();
    }catch(e){
      setStatus("status-twitter","error"); setIpClickable("twitter-ip","加载失败"); setLoc("twitter-country","-");
      var tip=document.getElementById("twitter-tip"); if(tip) tip.textContent="· 您访问墙外站点所使用的IP";
    }
  })();

  var latencyTestConfig={count:16}, latencyFetchTimeoutMs=8000;
  var latencyTestActive=false, latencyTestSessionId=0, latencyTestStarted=false;
  var latencySiteIntervals={}, latencySiteUpdateInProgress={}, latencySiteLatencies={};
  var latencyFetchControllers=new Set(), latencyUIState={};
  function getLatencyColor(latency){
    if(latency===-1) return "var(--destructive)";
    if(latency<=49) return "var(--latency-49)";
    if(latency<=149) return "var(--latency-149)";
    if(latency<=299) return "var(--latency-299)";
    if(latency<=999) return "var(--latency-999)";
    return "var(--latency-1000)";
  }
  function generateLatencyCards(){
    var container=document.getElementById("latency-cards"); if(!container) return;
    container.innerHTML="";
    latencySites.slice().sort(function(a,b){return (a.region==="国内"?0:1)-(b.region==="国内"?0:1)}).forEach(function(site){
      var siteName=site.name.toLowerCase().replace(/\\s+/g,"-");
      var card=document.createElement("div"); card.className="latency-card";
      card.innerHTML='<div class="latency-card-header"><div class="latency-card-info"><div class="latency-card-icon-wrapper" data-site="'+siteName+'">'+site.icon+'</div><div class="latency-card-text"><span class="latency-card-name">'+site.name+'</span><span class="latency-card-region" data-region="'+site.region+'">'+site.region+'</span></div></div><div class="latency-status" id="latency-'+siteName+'">...<span class="unit">ms</span></div></div><div class="latency-graph-container"><svg class="latency-ecg" viewBox="0 0 400 60" preserveAspectRatio="none"><path class="ecg-path-bg" d="M0,30 L400,30"></path><path class="ecg-path" id="path-'+siteName+'" d="M0,30 L400,30"></path><circle class="ecg-cursor" id="cursor-'+siteName+'" r="3" cx="0" cy="30" style="display:none"></circle></svg></div>';
      container.appendChild(card);
    });
  }
  function initLatencyDataStorage(){
    if(Object.keys(latencySiteLatencies).length>0) return;
    latencySites.forEach(function(site){ latencySiteLatencies[site.name.toLowerCase().replace(/\\s+/g,"-")]=[]; });
  }
  async function testLatency(site){
    var start=Date.now(), controller=new AbortController();
    var timeoutId=setTimeout(function(){controller.abort()}, latencyFetchTimeoutMs);
    latencyFetchControllers.add(controller);
    try{ await fetch(site.url+"?t="+Date.now(),{method:"HEAD",cache:"no-cache",mode:"no-cors",referrerPolicy:"no-referrer",signal:controller.signal}); return Date.now()-start; }
    catch(e){ return -1; }
    finally{ clearTimeout(timeoutId); latencyFetchControllers.delete(controller); }
  }
  function updateLatencyDisplay(siteName, latencies){
    var valueElement=document.getElementById("latency-"+siteName);
    var pathElement=document.getElementById("path-"+siteName);
    var cursorElement=document.getElementById("cursor-"+siteName);
    if(!valueElement||!pathElement) return;
    var lastLatency=latencies[latencies.length-1];
    var valid=latencies.filter(function(l){return l!==-1});
    var avg=-1;
    if(valid.length>0){
      if(valid.length>5){ var s=valid.slice().sort(function(a,b){return a-b}); var t=s.slice(1,-1); avg=t.reduce(function(a,b){return a+b},0)/t.length; }
      else avg=valid.reduce(function(a,b){return a+b},0)/valid.length;
    }
    var target=Math.round(avg);
    if(valid.length===0){
      if(lastLatency===-1){ valueElement.innerHTML="TIMEOUT"; valueElement.style.color="var(--latency-999)"; }
      else { valueElement.innerHTML='...<span class="unit">ms</span>'; valueElement.style.color="#f6821f"; }
    } else {
      var st=latencyUIState[siteName]||{current:target,timer:null}; latencyUIState[siteName]=st;
      valueElement.style.color=getLatencyColor(target);
      if(Math.abs(st.current-target)<2){ st.current=target; valueElement.innerHTML=target+'<span class="unit">ms</span>'; }
      else {
        if(st.timer) clearInterval(st.timer);
        st.timer=setInterval(function(){
          if(st.current<target) st.current+=Math.ceil((target-st.current)/5);
          else if(st.current>target) st.current-=Math.ceil((st.current-target)/5);
          valueElement.innerHTML=st.current+'<span class="unit">ms</span>';
          if(st.current===target){ clearInterval(st.timer); st.timer=null; }
        },30);
      }
    }
    var points=[], data=latencies.slice(-latencyTestConfig.count), maxShow=latencyTestConfig.count;
    for(var i=0;i<data.length;i++){
      var x=(i/(maxShow-1||1))*400, v=data[i], y=v===-1?55:Math.max(4,Math.min(56,56-(Math.min(v,1000)/1000)*52));
      points.push(x+","+y);
    }
    pathElement.setAttribute("d", points.length?("M"+points.join(" L")):"M0,30 L400,30");
    pathElement.style.stroke=valid.length?getLatencyColor(target):"#94a3b8";
    if(cursorElement&&points.length){ var last=points[points.length-1].split(","); cursorElement.style.display="block"; cursorElement.setAttribute("cx",last[0]); cursorElement.setAttribute("cy",last[1]); cursorElement.setAttribute("fill", valid.length?getLatencyColor(target):"#94a3b8"); }
  }
  async function startSingleSiteLatencyLoop(site, sessionId){
    var siteName=site.name.toLowerCase().replace(/\\s+/g,"-");
    while(latencyTestActive&&sessionId===latencyTestSessionId&&latencySiteLatencies[siteName].length<latencyTestConfig.count){
      var latency=await testLatency(site);
      if(!latencyTestActive||sessionId!==latencyTestSessionId) return;
      latencySiteLatencies[siteName].push(latency); updateLatencyDisplay(siteName, latencySiteLatencies[siteName]);
      await new Promise(function(r){setTimeout(r,0)});
    }
    if(!latencyTestActive||sessionId!==latencyTestSessionId) return;
    if(latencySiteIntervals[siteName]){ clearInterval(latencySiteIntervals[siteName]); delete latencySiteIntervals[siteName]; }
    latencySiteIntervals[siteName]=setInterval(async function(){
      if(!latencyTestActive||sessionId!==latencyTestSessionId||latencySiteUpdateInProgress[siteName]) return;
      latencySiteUpdateInProgress[siteName]=true;
      try{
        var latency=await testLatency(site);
        if(!latencyTestActive||sessionId!==latencyTestSessionId) return;
        latencySiteLatencies[siteName].push(latency);
        if(latencySiteLatencies[siteName].length>latencyTestConfig.count) latencySiteLatencies[siteName].shift();
        updateLatencyDisplay(siteName, latencySiteLatencies[siteName]);
      } finally { latencySiteUpdateInProgress[siteName]=false; }
    }, 618*3);
  }
  function startLatencyTest(){
    if(latencyTestActive) return;
    latencyTestActive=true; var sid=++latencyTestSessionId;
    Object.keys(latencySiteIntervals).forEach(function(k){clearInterval(latencySiteIntervals[k])});
    latencySiteIntervals={}; latencySiteUpdateInProgress={};
    if(!latencyTestStarted){ generateLatencyCards(); latencyTestStarted=true; }
    initLatencyDataStorage();
    latencySites.forEach(function(site){ startSingleSiteLatencyLoop(site, sid); });
  }
  function stopLatencyTest(){
    latencyTestActive=false; latencyTestSessionId+=1;
    Object.keys(latencySiteIntervals).forEach(function(k){clearInterval(latencySiteIntervals[k])});
    latencySiteIntervals={}; latencySiteUpdateInProgress={};
    latencyFetchControllers.forEach(function(c){try{c.abort()}catch(e){}}); latencyFetchControllers.clear();
    Object.keys(latencyUIState).forEach(function(k){ var st=latencyUIState[k]; if(st&&st.timer){clearInterval(st.timer);st.timer=null} });
  }
  function animateSectionHeight(content, expand){
    if(!content) return;
    content.style.transition="height .28s ease";
    content.style.display="block"; content.style.overflow="hidden";
    var startHeight=content.getBoundingClientRect().height;
    content.style.height=startHeight+"px"; content.getBoundingClientRect();
    var targetHeight=expand?content.scrollHeight:0;
    if(Math.abs(targetHeight-startHeight)<1){
      if(expand){ content.style.height="auto"; content.style.overflow="visible"; }
      else { content.style.display="none"; content.style.height="0px"; content.style.overflow="hidden"; }
      return;
    }
    content.style.height=targetHeight+"px";
    var onEnd=function(e){
      if(e.propertyName!=="height") return;
      content.removeEventListener("transitionend", onEnd);
      if(expand){ content.style.height="auto"; content.style.overflow="visible"; }
      else { content.style.display="none"; content.style.height="0px"; content.style.overflow="hidden"; }
    };
    content.addEventListener("transitionend", onEnd);
  }
  window.toggleNetworkModule = function(titleEl){
    var module = titleEl ? titleEl.parentElement : document.getElementById("net-info-box");
    var content = document.getElementById("network-module-content");
    var icon = titleEl ? titleEl.querySelector(".collapse-icon") : (module && module.querySelector(".collapse-icon"));
    if(!content) return;
    var isHidden = content.style.display==="none" || getComputedStyle(content).display==="none";
    if(isHidden){
      if(module){ module.classList.remove("network-detail-collapsed"); module.classList.add("is-expanded"); }
      if(icon) icon.style.transform="rotate(0deg)";
      animateSectionHeight(content, true);
      startLatencyTest();
    } else {
      if(module){ module.classList.add("network-detail-collapsed"); module.classList.remove("is-expanded"); }
      if(icon) icon.style.transform="rotate(90deg)";
      stopLatencyTest();
      animateSectionHeight(content, false);
    }
  };
})();
</script>

  <div class="tabs">
    <button class="tab" data-t="t-nodes">节点列表</button>
    <button class="tab" data-t="t-pool">自定义优选IP</button>
    <button class="tab" data-t="t-rp">自定义 Proxy IP</button>
    <button class="tab" data-t="t-exit">自定义出站 IP</button>
    <button class="tab on" data-t="t-settings">设置</button>
    <button class="tab" data-t="t-logs">操作日志</button>
    <button class="tab" data-t="t-about">关于</button>
  </div>

  <section class="panel" id="t-nodes">
    <div class="box">
      <div class="row">
        <button id="b-prev">上一批</button>
        <button id="b-next">下一批</button>
        <span class="tag" id="npage">-</span>
        <span class="tag" id="nhint">-</span>
      </div>
      <div class="wrap"><table>
        <thead><tr><th>#</th><th>名称</th><th>地址</th><th>传输</th></tr></thead>
        <tbody id="nb"><tr><td colspan="4" class="empty">加载中</td></tr></tbody>
      </table></div>
    </div>
  </section>

  <section class="panel" id="t-rp">
    <div class="box"><h2>自定义 Proxy IP</h2>
      <label class="hint" for="rp-text">填写 Proxy IP 或域名；多个地址用 / 或换行分隔。</label>
      <textarea class="ta compact" id="rp-text" spellcheck="false" maxlength="16000" placeholder="109.168.1.1,443 #JP/109.168.2.2,8443 #US"></textarea>
      <div class="hint" id="rp-stat" role="status" aria-live="polite">加载中…</div>
    </div>
    <div class="box"><h2>格式与回落</h2>
      <div class="hint">
        例如 <code>109.168.1.1,443 #JP/109.168.2.2,8443 #US</code>；也支持 <code>[2001:db8::1],443 #JP</code>。<br>
        兼容 CFNext 写法：<code>133.117.72.192:443#JP</code>、<code>JP.133.117.72.192:443</code>、<code>Proxy-JP.example.com:443</code>；未写端口时为 443，无地区标签时作为通用候选。<br>
        按节点地区先选同国地址，再选通用地址；没有候选时使用列表首条。只填一条时，所有地区均可使用它。每次按顺序尝试最多三条；旧链接无地区标记时按 Worker 机房匹配。<br>
        <span id="rp-client-note">v2rayN 等客户端使用 <code>/rp/JP</code>、<code>/rp/US</code> 路径保留地区设置。修改后请更新客户端列表并重连。</span><br>
        留空保存沿用原有策略（含部署变量设置）。自定义 Proxy IP 仅用于 Cloudflare 目标的 TLS 转发；其他目标沿用原有出站。候选需完成 TLS 首响应，连接失败、握手错误或超时会尝试下一条，全部失败后恢复原有出站。<br>
        Proxy IP 需能按 TLS 域名转发，出站可能使用该服务器的 IPv4 或 IPv6，查 IP 结果未必等于填写的接入地址；需要通用固定出口时使用「自定义出站 IP」。<br>
        明文业务沿用原有直连策略；合规模式仅直连。最多 100 条 / 16000 字符；无效内容会被拒绝并保留旧设置。
      </div>
      <div class="warn" id="rp-warn">加载中…</div>
    </div>
  </section>

  <section class="panel" id="t-exit">
    <div class="box"><h2>自定义出站 IP</h2>
      <label for="eg-url">出站地址</label>
      <input class="field" type="text" id="eg-url" autocomplete="off" spellcheck="false" maxlength="4096" placeholder="socks5://user:pass@host:1080" disabled>
      <label for="eg-mode">出站方式</label>
      <select class="field" id="eg-mode" disabled>
        <option value="auto">默认模式（失败回退直连）</option>
        <option value="only">仅走出口（only）</option>
      </select>
      <div class="hint" id="eg-stat" role="status" aria-live="polite">加载中…</div>
    </div>
    <div class="box"><h2>支持格式与生效方式</h2><div class="hint">
      支持 <code>socks5://user:pass@host:1080</code>、<code>http://user:pass@host:8080</code>、<code>https://user:pass@host:443</code>、<code>ss://</code> 链接及 <code>host:port</code>。<br>
      未写协议时按 SOCKS5，未写端口时使用 1080；HTTP / HTTPS 默认端口分别为 80 / 443。用户名和密码可选，特殊字符使用 URL 编码。<br>
      SS 支持 SIP002 用户信息编码和完整 Base64 链接；加密支持 <code>aes-128-gcm</code> / <code>aes-256-gcm</code> / <code>chacha20-ietf-poly1305</code>，不支持插件或 SS2022。<br>
      此项控制 Worker 的真实转发出口，不会作为节点字段写进&#35746;&#38405;；配置后优先于地区 Proxy IP，TCP 和 DNS 转发均使用该出口。<br>
      验证出口 IP 时请选择「仅走出口（only）」；默认模式在出站连接或握手失败时回退直连。已经建立的业务连接中断后关闭连接，不重放业务数据。<br>
      留空保存可关闭该配置，恢复原有策略；修改后重新连接即可。使用右下角的全局按钮保存。
    </div></div>
  </section>

  <section class="panel on" id="t-settings">
    <div class="box">
      <h2>面板登录密码</h2>
      <div class="hint" id="panel-pass-stat">正在读取…</div>
      <label for="panel-pass-old">当前密码（已设置时必须填写才能修改或清除）</label>
      <input class="field" type="password" id="panel-pass-old" autocomplete="current-password" placeholder="首次设置可留空">
      <label for="panel-pass-new" style="margin-top:10px;display:block">新密码</label>
      <input class="field" type="password" id="panel-pass-new" autocomplete="new-password" placeholder="至少 4 位">
      <label for="panel-pass-new2" style="margin-top:10px;display:block">确认新密码</label>
      <input class="field" type="password" id="panel-pass-new2" autocomplete="new-password" placeholder="再输入一次">
      <div class="row" style="margin-top:12px;gap:8px;flex-wrap:wrap">
        <button type="button" class="pri" id="panel-pass-save">保存</button>
        <button type="button" id="panel-pass-clear">清除</button>
      </div>
      <div class="hint">密码写入 KV（需绑定 K）。设置后访问面板需先登录；订阅链接与 /usage 不受影响。</div>
    </div>
    <div class="box">
      <h2>会话</h2>
      <div class="row" style="margin-top:8px;gap:8px;flex-wrap:wrap">
        <button type="button" id="panel-logout">退出登录</button>
      </div>
      <div class="hint">清除本机会话 Cookie，需重新输入密码进入面板。</div>
    </div>
  </section>

  <section class="panel" id="t-logs" style="display:none">
    <div class="box" style="padding:20px">
      <h2 style="margin:0 0 12px;font-size:18px;font-weight:700">操作日志</h2>
      <div class="row" style="margin-bottom:10px;gap:8px;flex-wrap:wrap">
        <button type="button" id="log-refresh">刷新</button>
        <button type="button" id="log-clear">清空</button>
        <span class="hint" id="log-stat" role="status">记录登录 / 退出 / 修改密码 / 保存等操作</span>
      </div>
      <div class="wrap">
        <table>
          <thead><tr><th>时间</th><th>类型</th><th>详情</th><th>IP / 地区</th><th>UA</th><th>ASN</th><th>URL</th></tr></thead>
          <tbody id="log-body"><tr><td colspan="7" class="empty">暂无记录</td></tr></tbody>
        </table>
      </div>
      <div class="hint">已绑定 K 时写入 KV（全端可见）；未绑定 K 时使用本机浏览器 localStorage。记录登录 / 退出 / 修改密码等操作。</div>
    </div>
  </section>

  <section class="panel" id="t-about" style="display:none">
    <div class="box" style="padding:20px">
      <h2 style="margin:0 0 12px;font-size:18px;font-weight:700">CFLYHL · 版本 2.1.7</h2>
      <div class="hint" style="font-size:14px;line-height:1.7;color:var(--tx)">CFLYHL · 版本 2.1.7林呓互联</div>
    </div>
  </section>

  <section class="panel" id="t-pool">
    <div class="box"><h2>自定义优选 IP</h2>
      <div style="margin-bottom:10px"><textarea class="ta" id="p-text" spellcheck="false" placeholder="支持 IP:端口#备注、IP,端口#备注、纯 IP 或 http(s) 文本列表地址"></textarea></div>
      <div class="row">
        <button id="b-reload">重新读取</button>
        <button id="b-clear">清空输入</button>
        <button id="b-export">导出当前下发</button>
      </div>
      <div class="hint" id="p-stat">-</div>
    </div>
    <div class="box"><h2>格式与生效方式</h2>
      <div class="hint">
        支持 <code>1.1.1.1:443#US</code>、<code>1.1.1.1,443#US</code>、<code>1.1.1.1，443#US</code>、<code>1.1.1.1</code> 与 <code>[IPv6]:443#备注</code>；未写端口默认 443。每行一条，也可用英文或中文逗号分隔多个地址。<br>
        CSV 风格的 <code>IP,端口,备注</code> 也可直接粘贴，表头及无法解析的行会跳过。<br>
        可直接填多个 <code>http(s)</code> 文本地址，支持换行、空格、逗号或分号分隔，也可与手填节点混排。保存时由服务端取回内容再解析；地址只用来取一次，不会被存下来。<br>
        端口决定传输方式：80 / 8080 / 8880 / 2052 / 2082 / 2086 / 2095 走明文，其余走 TLS。<br>
        <code>#</code> 后面是节点名，建议用「地区码 + 序号」（us1、hk2、jp3），面板按此前缀统计地区。<br>
        同一地址同一端口只保留第一条；解析不了的行在保存时直接跳过。<br>
        上限 <span id="p-limit">-</span>。保存后立刻替换下发内容，不需要重新部署；清空输入后保存可恢复代码自带的那份。
      </div>
    </div>
    <div class="box"><h2>持久性</h2>
      <div class="warn" id="p-warn">-</div>
    </div>
  </section>

  <div class="foot" id="foot"></div>
</main>
<div class="global-actions" aria-label="全局设置操作">
  <div class="global-status" id="g-stat" role="status" aria-live="polite"></div>
  <div class="global-buttons">
    <button type="button" id="g-reset" title="直接清空绑定 K 中的全部数据并恢复默认">默认</button>
    <button class="pri" id="g-save">保存</button>
  </div>
</div>
<script>
(function(){
  var base = document.body.getAttribute('data-base') || location.pathname.replace(/\\/$/, '');
  var H = { 'Content-Type': 'application/json', 'X-Req': '1' };
  var PAGE = 40, FROM = 0, LAST = null;
  var SAVED_POOL = null, SAVED_RP = null, SAVED_EXIT = null, SAVED_UUID = null, exitBusy = false, globalBusy = false;

  function $(id){ return document.getElementById(id); }
  function txt(id, v){ var e = $(id); if (e) e.textContent = (v === undefined || v === null) ? '-' : String(v); }
  function api(sub, opt){
    return fetch(base + '/api/' + sub, opt || {}).then(function(r){
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return r.json();
    });
  }

})();
</script>
<script id="shell-api-fix">
(function(){
  function $(id){ return document.getElementById(id); }
  // 面板在站点根路径：API 固定走 /api/*
  var base = '';
  try {
    var db = document.body && document.body.getAttribute('data-base');
    if (db) base = String(db).replace(/\/$/, '');
  } catch (e) {}
  function apiUrl(name){
    return (base || '') + '/api/' + name;
  }
  function api(name, opt){
    opt = opt || {};
    opt.credentials = 'same-origin';
    if (!opt.headers) opt.headers = { 'Content-Type': 'application/json' };
    return fetch(apiUrl(name), opt).then(function(r){
      return r.text().then(function(txt){
        var d = null;
        try { d = txt ? JSON.parse(txt) : {}; } catch (e) {
          var err = new Error('非 JSON 响应 HTTP ' + r.status);
          err.status = r.status;
          throw err;
        }
        if (!r.ok) {
          var err2 = new Error((d && (d.error || d.msg)) || ('HTTP ' + r.status));
          err2.status = r.status; err2.data = d;
          throw err2;
        }
        return d;
      });
    });
  }
  var H = {'Content-Type':'application/json'};
  var LOG_LS_KEY = 'cfapex_op_logs_local';
  function readLocalLogs(){
    try { var a = JSON.parse(localStorage.getItem(LOG_LS_KEY) || '[]'); return Array.isArray(a) ? a : []; } catch(e){ return []; }
  }
  function writeLocalLogs(arr){
    try { localStorage.setItem(LOG_LS_KEY, JSON.stringify((arr||[]).slice(0,300))); } catch(e){}
  }
  function pushLocalLog(type, detail){
    var arr = readLocalLogs();
    arr.unshift({ t: Date.now(), type: type||'操作', detail: detail||'', IP:'', CC:'', ASN:'', URL: location.href, UA: navigator.userAgent||'' });
    writeLocalLogs(arr);
    return arr;
  }

  function showTab(id){
    try {
      if (!id) return;
      document.querySelectorAll('.tab').forEach(function(x){ x.classList.remove('on'); });
      document.querySelectorAll('section.panel, .panel').forEach(function(x){
        x.classList.remove('on');
        x.style.cssText = (x.style.cssText||'').replace(/display\s*:[^;]+;?/gi,'') + ';display:none !important;';
      });
      var btn = document.querySelector('.tab[data-t="'+id+'"]');
      var panel = document.getElementById(id);
      if (btn) btn.classList.add('on');
      if (panel) {
        panel.classList.add('on');
        panel.style.cssText = (panel.style.cssText||'').replace(/display\s*:[^;]+;?/gi,'') + ';display:block !important;visibility:visible !important;opacity:1 !important;';
        // 确保内部内容可见
        panel.querySelectorAll('.box, .hint, h2, table, .row').forEach(function(el){
          el.style.visibility = 'visible';
          el.style.opacity = '1';
        });
      } else {
        console.warn('panel not found', id);
      }
      if (id === 't-logs') loadLogs();
      if (id === 't-settings') loadPass(false);
    } catch (e) { console.error('showTab', e); }
  }

  function bindTabs(){
    document.querySelectorAll('.tab').forEach(function(b){
      var n = b.cloneNode(true);
      b.parentNode.replaceChild(n, b);
      n.onclick = function(ev){
        if (ev) { ev.preventDefault(); ev.stopPropagation(); }
        var id = n.getAttribute('data-t');
        if (id) showTab(id);
        return false;
      };
    });
    if (!document._tabDeleg){
      document._tabDeleg = true;
      document.addEventListener('click', function(ev){
        var t = ev.target;
        if (!t) return;
        var btn = t.closest ? t.closest('.tab') : null;
        if (!btn) return;
        var id = btn.getAttribute('data-t');
        if (!id) return;
        ev.preventDefault();
        ev.stopPropagation();
        showTab(id);
      }, true);
    }
  }

  function setSt(s){
    var st = document.getElementById('panel-pass-stat');
    if (st) st.textContent = s || '';
  }

  var _passLoading = false;
  var _passLoaded = false;
  function loadPass(force){
    if (_passLoading) return;
    if (_passLoaded && !force) return;
    _passLoading = true;
    setSt('正在读取…');
    var ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
    var timer = setTimeout(function(){
      try { if (ctrl) ctrl.abort(); } catch(e){}
      if (_passLoading) {
        _passLoading = false;
        setSt('读取超时（接口无响应）。请检查 Worker 是否部署成功，或稍后重试');
      }
    }, 4000);
    var url = '/api/panel-pass';
    fetch(url, {
      method: 'GET',
      credentials: 'same-origin',
      cache: 'no-store',
      signal: ctrl ? ctrl.signal : undefined,
      headers: { 'Accept': 'application/json', 'X-Req': '1' }
    }).then(function(r){
      return r.text().then(function(t){ return { ok: r.ok, status: r.status, t: t }; });
    }).then(function(res){
      clearTimeout(timer);
      _passLoading = false;
      var d = null;
      try { d = res.t ? JSON.parse(res.t) : {}; } catch (e) {
        setSt('读取失败：HTTP ' + res.status + '（返回了网页而非接口，路径可能不对）');
        return;
      }
      if (!res.ok) {
        setSt('读取失败：' + ((d && (d.error || d.msg)) || ('HTTP ' + res.status)));
        return;
      }
      _passLoaded = true;
      if (d.storage === 'none') setSt('未绑定 K，无法写入 KV');
      else if (d.set) setSt('已设置面板登录密码（KV）');
      else setSt('未设置面板登录密码');
    }).catch(function(e){
      clearTimeout(timer);
      _passLoading = false;
      if (e && e.name === 'AbortError') {
        setSt('读取超时（接口无响应）。请检查 Worker 是否部署成功');
        return;
      }
      setSt('读取失败：' + (e && e.message ? e.message : String(e)));
    });
  }

  function bindPass(){
    var save=$('panel-pass-save'), clear=$('panel-pass-clear');
    if (save){
      var s2 = save.cloneNode(true);
      save.parentNode.replaceChild(s2, save);
      s2.addEventListener('click', function(ev){
        ev.preventDefault();
        var o=($('panel-pass-old')&&$('panel-pass-old').value)||'';
        var n=($('panel-pass-new')&&$('panel-pass-new').value)||'';
        var n2=($('panel-pass-new2')&&$('panel-pass-new2').value)||'';
        if (n.length<4){ setSt('新密码至少 4 位'); return; }
        if (n!==n2){ setSt('两次新密码不一致'); return; }
        setSt('保存中…');
        api('panel-pass',{method:'POST',headers:H,body:JSON.stringify({password:n,oldPassword:o})}).then(function(d){
          if(!d||!d.ok){
            var e=(d&&d.error)||'失败';
            if(e==='bad_old') e='当前密码错误';
            if(e==='no_kv') e='未绑定 K';
            setSt('保存失败：'+e); return;
          }
          setSt('密码已保存到 KV');
          try{ pushLocalLog('修改密码','保存/更新面板登录密码'); }catch(e){}
          if($('panel-pass-old')) $('panel-pass-old').value='';
          if($('panel-pass-new')) $('panel-pass-new').value='';
          if($('panel-pass-new2')) $('panel-pass-new2').value='';
        }).catch(function(e){ setSt('保存失败：'+e.message); });
      });
    }
    if (clear){
      var c2 = clear.cloneNode(true);
      clear.parentNode.replaceChild(c2, clear);
      c2.addEventListener('click', function(ev){
        ev.preventDefault();
        var o=($('panel-pass-old')&&$('panel-pass-old').value)||'';
        api('panel-pass',{method:'POST',headers:H,body:JSON.stringify({action:'clear',oldPassword:o})}).then(function(d){
          if(!d||!d.ok){ setSt('清除失败：'+((d&&d.error)||'')); return; }
          setSt('已清除面板登录密码');
          try{ pushLocalLog('修改密码','清除面板登录密码'); }catch(e){}
        });
      });
    }
  }

  function paint(arr, storage){
    var ls=$('log-stat'), lb=$('log-body');
    var label = storage==='kv' ? 'KV' : (storage==='local' ? '本机' : '无');
    if (ls) ls.textContent='共 '+(arr||[]).length+' 条 · '+label;
    if (!lb) return;
    while (lb.firstChild) lb.removeChild(lb.firstChild);
    if (!arr || !arr.length){
      lb.innerHTML='<tr><td colspan="7" class="empty">暂无记录</td></tr>';
      return;
    }
    arr.forEach(function(item){
      var tr=document.createElement('tr');
      function c(v){ var td=document.createElement('td'); td.textContent=v||''; return td; }
      var t = item.t ? new Date(item.t).toLocaleString('zh-CN',{hour12:false}) : '';
      tr.appendChild(c(t));
      tr.appendChild(c(item.type));
      tr.appendChild(c(item.detail));
      tr.appendChild(c((item.IP||'')+(item.CC?(' '+item.CC):'')));
      tr.appendChild(c(item.UA));
      tr.appendChild(c(item.ASN));
      tr.appendChild(c(item.URL));
      lb.appendChild(tr);
    });
  }
  function loadLogs(){
    var ls=$('log-stat'); if(ls) ls.textContent='加载中…';
    api('logs').then(function(d){
      var server = (d&&d.logs)||[];
      if (d && d.storage === 'kv') {
        if (!server.length) {
          var local = readLocalLogs();
          if (local.length) { paint(local, 'local'); return; }
        }
        paint(server, 'kv');
        return;
      }
      var local = readLocalLogs();
      paint(local, 'local');
    }).catch(function(e){
      var local = readLocalLogs();
      paint(local, 'local');
      if (ls && !local.length) ls.textContent='读取失败：'+(e&&e.message||e)+'（已回退本机）';
    });
  }
  function bindLogs(){
    var lr=$('log-refresh'), lc=$('log-clear');
    if (lr){
      var a=lr.cloneNode(true); lr.parentNode.replaceChild(a,lr);
      a.addEventListener('click', function(ev){ ev.preventDefault(); loadLogs(); });
    }
    if (lc){
      var b=lc.cloneNode(true); lc.parentNode.replaceChild(b,lc);
      b.addEventListener('click', function(ev){
        ev.preventDefault();
        writeLocalLogs([]);
        api('logs',{method:'POST',headers:H,body:JSON.stringify({action:'clear'})})
          .then(loadLogs)
          .catch(function(){ paint([], 'local'); });
      });
    }
  }

  function setGlobalStat(msg){
    var gs = $('g-stat');
    if (gs) gs.textContent = msg || '';
  }

  function doKvReset(){
    if (!confirm('确定清空绑定 K 中的全部数据并恢复默认？此操作不可撤销。')) return;
    setGlobalStat('正在清空 KV…');
    var url = apiUrl('kv-reset');
    fetch(url, {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json', 'X-Req': '1' },
      body: JSON.stringify({ action: 'clear_all' })
    }).then(function(r){
      return r.json().then(function(d){ return { status: r.status, d: d }; });
    }).then(function(res){
      var d = res.d || {};
      if (!d.ok) {
        var msg = d.msg || d.error || ('HTTP ' + res.status);
        setGlobalStat('清空失败：' + msg);
        alert('清空 KV 失败：' + msg);
        return;
      }
      writeLocalLogs([]);
      try{ pushLocalLog('重置','清空 KV 全部内容'); }catch(e){}
      setGlobalStat('已清空 KV（处理 ' + (d.deleted||0) + ' 项）');
      alert('已清空 KV（处理 ' + (d.deleted||0) + ' 项）');
      loadPass();
      try{ loadLogs(); }catch(e){}
    }).catch(function(e){
      setGlobalStat('清空失败：' + (e && e.message || e));
      alert('清空 KV 失败：' + (e && e.message || e));
    });
  }

  function bindGlobal(){
    var gr = document.getElementById('g-reset');
    var gs = document.getElementById('g-save');
    if (gr){
      // 覆盖任何旧监听
      var n = gr.cloneNode(true);
      gr.parentNode.replaceChild(n, gr);
      n.id = 'g-reset';
      n.onclick = function(ev){ if(ev){ev.preventDefault();ev.stopPropagation();} doKvReset(); return false; };
    }
    if (gs){
      var n2 = gs.cloneNode(true);
      gs.parentNode.replaceChild(n2, gs);
      n2.id = 'g-save';
      n2.onclick = function(ev){
        if(ev){ev.preventDefault();ev.stopPropagation();}
        setGlobalStat('当前精简版无节点下发项可保存');
        return false;
      };
    }
  }

  var _inited = false;
  function init(){
    if (_inited) {
      // 仅重新绑定一次全局按钮，不再重复 loadPass
      try { bindGlobal(); } catch(e){}
      return;
    }
    _inited = true;
    try { window.doKvReset = doKvReset; } catch(e){}
    try { bindTabs(); } catch(e){ console.error(e); }
    try { bindPass(); } catch(e){ console.error(e); }
    try { bindLogs(); } catch(e){ console.error(e); }
    try { bindGlobal(); } catch(e){ console.error(e); }
    var lo = document.getElementById('panel-logout');
    if (lo && !lo._bound){
      lo._bound = true;
      lo.addEventListener('click', function(ev){
        ev.preventDefault();
        try{ pushLocalLog('退出','退出登录'); }catch(e){}
        location.href = '/logout';
      });
    }
    showTab('t-settings');
    try { loadPass(true); } catch(e){ setSt('读取异常：'+(e&&e.message||e)); }
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
  setTimeout(function(){ try { bindGlobal(); } catch(e){} }, 800);
})();
</script>
`;

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const path = url.pathname.replace(/\/+$/, "") || "/";
    try {
      if (path === "/usage" || path === "/cf-usage" || path.endsWith("/usage") || path.endsWith("/cf-usage") || path.endsWith("/admin/getCloudflareUsage")) {
        return await handleUsageRoute(request, env, url, path);
      }
      if (path === "/api/logs" || path.endsWith("/api/logs")) return handleLogs(request, env);
      if (path === "/api/panel-pass" || path.endsWith("/api/panel-pass")) return handlePanelPass(request, env);
      if (path === "/api/kv-reset" || path.endsWith("/api/kv-reset")) return handleKvReset(request, env);
      if (path === "/login" || path.endsWith("/login")) return handleLogin(request, env, path);
      if (path === "/logout" || path.endsWith("/logout")) {
        await appendOpLog(request, env, "退出", "退出登录");
        return new Response(null, { status: 302, headers: { Location: "/login", "Set-Cookie": cookie("", 0) } });
      }
      if (path === "/api/ping" || path.endsWith("/api/ping")) {
        return json({ ok: true, time: Date.now() });
      }

      const pass = await getPass(env);
      if (pass) {
        const ok = await isAuthed(request, pass);
        if (!ok) {
          const ua = (request.headers.get("User-Agent") || "").toLowerCase();
          if (/mozilla|chrome|safari|firefox|edg/i.test(ua)) {
            return new Response(loginPage("请登录后继续", "/login"), {
              status: 401,
              headers: { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store" }
            });
          }
        }
      }

      return new Response(PANEL_HTML, {
        headers: { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store" }
      });
    } catch (e) {
      return json({ ok: false, error: String(e && e.message || e) }, 500);
    }
  }
};

function json(obj, status = 200) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: { "Content-Type": "application/json; charset=utf-8" }
  });
}
async function getPass(env) {
  try { return (env && env.K && (await env.K.get(PASS_KEY))) || ""; } catch { return ""; }
}
async function hashPass(p) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode("cfapex:" + String(p)));
  return [...new Uint8Array(buf)].map(b => b.toString(16).padStart(2, "0")).join("");
}
function readSid(req) {
  const m = (req.headers.get("Cookie") || "").match(/(?:^|;\s*)cfapex_sid=([^;]*)/);
  return m ? decodeURIComponent(m[1].trim()) : "";
}
async function isAuthed(req, pass) {
  if (!pass) return true;
  const sid = readSid(req);
  return !!(sid && sid === await hashPass(pass));
}
function cookie(sid, maxAge = 604800) {
  return `cfapex_sid=${encodeURIComponent(sid)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAge}`;
}


async function appendOpLog(request, env, type, detail) {
  try {
    const kv = env && env.K;
    if (!kv || typeof kv.get !== "function") return;
    let arr = [];
    try { arr = JSON.parse(await kv.get(LOG_KEY) || "[]"); } catch { arr = []; }
    if (!Array.isArray(arr)) arr = [];
    arr.unshift({
      t: Date.now(), type: type || "操作", detail: detail || "",
      IP: request.headers.get("CF-Connecting-IP") || "",
      CC: request.cf ? `${request.cf.country || ""} ${request.cf.city || ""}`.trim() : "",
      ASN: request.cf ? `AS${request.cf.asn || ""} ${request.cf.asOrganization || ""}`.trim() : "",
      URL: request.url, UA: request.headers.get("User-Agent") || ""
    });
    while (arr.length > 300) arr.pop();
    await kv.put(LOG_KEY, JSON.stringify(arr));
  } catch (e) { console.error("appendOpLog", e); }
}

async function handleKvReset(request, env) {
  if (request.method !== "POST" && request.method !== "GET") return json({ ok: false, error: "method" }, 405);
  const pass = await getPass(env);
  if (pass && !(await isAuthed(request, pass))) return json({ ok: false, error: "unauthorized" }, 401);
  const kv = env && (env.K || env.KV || env.KV_NAMESPACE);
  if (!kv || typeof kv.delete !== "function") {
    return json({ ok: false, error: "no_kv", msg: "未绑定 KV（需绑定变量名 K）" }, 400);
  }
  let deleted = 0;
  const errors = [];
  // 1) 先删已知键
  const known = [
    LOG_KEY, PASS_KEY, CFAPEX_USAGE_CREDS_KEY,
    "cfapex_op_logs", "cfapex_panel_pass", "cfapex_usage_creds",
    "panel_pass", "op_logs", "usage_creds",
    "uuid", "pool", "rp", "exit", "proxy_ip", "nodes", "config"
  ];
  for (const key of known) {
    try {
      await kv.delete(key);
      deleted++;
    } catch (e) {
      errors.push(String(key) + ":" + (e && e.message || e));
    }
  }
  // 2) list 扫全库再删
  if (typeof kv.list === "function") {
    let cursor;
    try {
      do {
        const res = await kv.list(cursor ? { cursor, limit: 1000 } : { limit: 1000 });
        const keys = (res && res.keys) || [];
        for (const k of keys) {
          try {
            await kv.delete(k.name);
            deleted++;
          } catch (e) {
            errors.push(String(k.name) + ":" + (e && e.message || e));
          }
        }
        cursor = res && !res.list_complete ? res.cursor : null;
      } while (cursor);
    } catch (e) {
      errors.push("list:" + String(e && e.message || e));
    }
  }
  return json({ ok: true, deleted, errors: errors.length ? errors.slice(0, 20) : undefined });
}

async function handleLogs(request, env) {
  const kv = env && env.K;
  const pass = await getPass(env);
  if (pass && !(await isAuthed(request, pass))) return json({ ok: false, error: "unauthorized" }, 401);
  if (request.method === "GET") {
    let arr = [];
    if (kv) { try { arr = JSON.parse(await kv.get(LOG_KEY) || "[]"); } catch { arr = []; } }
    return json({ ok: true, logs: Array.isArray(arr) ? arr : [], storage: kv ? "kv" : "none" });
  }
  if (request.method === "POST") {
    let body = {}; try { body = await request.json(); } catch { return json({ ok: false, error: "bad_body" }, 400); }
    if (body.action === "clear") {
      if (kv) await kv.put(LOG_KEY, "[]");
      return json({ ok: true, logs: [] });
    }
    let arr = [];
    if (kv) { try { arr = JSON.parse(await kv.get(LOG_KEY) || "[]"); } catch { arr = []; } }
    if (!Array.isArray(arr)) arr = [];
    arr.unshift({
      t: Date.now(), type: body.type || "操作", detail: body.detail || "",
      IP: request.headers.get("CF-Connecting-IP") || "",
      CC: request.cf ? `${request.cf.country || ""} ${request.cf.city || ""}`.trim() : "",
      ASN: request.cf ? `AS${request.cf.asn || ""} ${request.cf.asOrganization || ""}`.trim() : "",
      URL: body.URL || request.url, UA: body.UA || request.headers.get("User-Agent") || ""
    });
    while (arr.length > 300) arr.pop();
    if (kv) await kv.put(LOG_KEY, JSON.stringify(arr));
    return json({ ok: true, storage: kv ? "kv" : "none" });
  }
  return json({ ok: false }, 405);
}

async function handlePanelPass(request, env) {
  const kv = env && (env.K || env.KV || env.KV_NAMESPACE);
  if (request.method === "GET") {
    let set = false;
    let storage = "none";
    try {
      if (kv && typeof kv.get === "function") {
        storage = "kv";
        const pass = await Promise.race([
          kv.get(PASS_KEY),
          new Promise(function(resolve){ setTimeout(function(){ resolve(null); }, 2500); })
        ]);
        set = !!pass;
      }
    } catch (e) {
      storage = kv ? "kv" : "none";
      set = false;
    }
    return json({ ok: true, set: set, storage: storage });
  }
  if (request.method === "POST") {
    if (!kv) return json({ ok: false, error: "no_kv" });
    const pass = await getPass(env);
    let body = {}; try { body = await request.json(); } catch { return json({ ok: false, error: "bad_body" }, 400); }
    if (body.action === "clear") {
      if (pass && String(body.oldPassword || "") !== pass) return json({ ok: false, error: "bad_old" }, 403);
      await kv.delete(PASS_KEY);
      await appendOpLog(request, env, "修改密码", "清除面板登录密码");
      return new Response(JSON.stringify({ ok: true, set: false }), {
        headers: { "Content-Type": "application/json; charset=utf-8", "Set-Cookie": cookie("", 0) }
      });
    }
    const np = String(body.password || "").trim();
    if (np.length < 4) return json({ ok: false, error: "too_short" }, 400);
    if (pass && String(body.oldPassword || "") !== pass) return json({ ok: false, error: "bad_old" }, 403);
    await kv.put(PASS_KEY, np);
    await appendOpLog(request, env, "修改密码", pass ? "更新面板登录密码" : "首次设置面板登录密码");
    return new Response(JSON.stringify({ ok: true, set: true }), {
      headers: { "Content-Type": "application/json; charset=utf-8", "Set-Cookie": cookie(await hashPass(np)) }
    });
  }
  return json({ ok: false }, 405);
}

async function handleLogin(request, env, path) {
  if (request.method === "GET") {
    return new Response(loginPage("", path), { headers: { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store" } });
  }
  let pw = "";
  try {
    const ct = (request.headers.get("Content-Type") || "").toLowerCase();
    if (ct.includes("json")) { const b = await request.json(); pw = b.password || ""; }
    else { const fd = await request.formData(); pw = fd.get("password") || ""; }
  } catch {}
  const real = await getPass(env);
  if (!real) return new Response(loginPage("尚未设置密码", path), { headers: { "Content-Type": "text/html; charset=utf-8" } });
  if (String(pw) !== real) {
    await appendOpLog(request, env, "登录", "登录失败：密码错误");
    return new Response(loginPage("密码错误", path), { status: 401, headers: { "Content-Type": "text/html; charset=utf-8" } });
  }
  await appendOpLog(request, env, "登录", "登录成功");
  return new Response(null, { status: 302, headers: { Location: "/", "Set-Cookie": cookie(await hashPass(real)) } });
}

async function handleUsageRoute(request, env, url, path) {
  let notice = null;
  let saved = await loadUsageCreds(env);
  if (request.method === "POST" && (path === "/usage" || path.endsWith("/usage"))) {
    const form = await request.formData();
    const action = form.get("action") || "save";
    if (action === "clear") {
      notice = await clearUsageCreds(env);
      saved = await loadUsageCreds(env);
    } else {
      const next = {
        Email: form.get("Email") || "",
        GlobalAPIKey: form.get("GlobalAPIKey") || "",
        AccountID: form.get("AccountID") || "",
        APIToken: form.get("APIToken") || ""
      };
      if (!next.APIToken && saved.APIToken) next.APIToken = saved.APIToken;
      if (!next.GlobalAPIKey && saved.GlobalAPIKey) next.GlobalAPIKey = saved.GlobalAPIKey;
      if (!next.Email && saved.Email) next.Email = saved.Email;
      if (!next.AccountID && saved.AccountID) next.AccountID = saved.AccountID;
      notice = await saveUsageCreds(env, next);
      saved = await loadUsageCreds(env);
    }
  }
  const Email = url.searchParams.get("Email") || saved.Email || "";
  const GlobalAPIKey = url.searchParams.get("GlobalAPIKey") || saved.GlobalAPIKey || "";
  const AccountID = url.searchParams.get("AccountID") || saved.AccountID || "";
  const APIToken = url.searchParams.get("APIToken") || saved.APIToken || "";
  const wantsJson = url.searchParams.get("format") === "json" || path.endsWith("getCloudflareUsage") || (request.headers.get("Accept") || "").includes("application/json");
  const data = await getCloudflareUsage(Email, GlobalAPIKey, AccountID, APIToken);
  if (wantsJson) {
    return new Response(JSON.stringify({ ...data, credSource: saved.source }, null, 2), {
      headers: { "Content-Type": "application/json; charset=utf-8", "Access-Control-Allow-Origin": "*" }
    });
  }
  return new Response(renderUsagePage(data, url.searchParams, saved, notice), {
    headers: { "Content-Type": "text/html; charset=utf-8" }
  });
}
