/**
 * CFLYHL Lite — 无代理/订阅核心
 * 保留：用量统计、网络测试、操作日志、登录密码、关于
 */
const LOG_KEY = "cfapex_op_logs";
const PASS_KEY = "cfapex_panel_pass";
const COOKIE = "cfapex_sid";

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    let path = url.pathname.replace(/\/+$/, "") || "/";
    const kv = env && env.K;

    try {
      // usage page / API
      if (path === "/usage" || path.endsWith("/usage") || path.endsWith("/cf-usage") || path.endsWith("/admin/getCloudflareUsage")) {
        return handleUsage(request, env, url, path);
      }
      if (path === "/login" || path.endsWith("/login")) {
        return handleLogin(request, env, url, path);
      }
      if (path.endsWith("/api/panel-pass") || path === "/api/panel-pass") {
        return handlePanelPass(request, env);
      }
      if (path.endsWith("/api/logs") || path === "/api/logs") {
        return handleLogs(request, env);
      }
      if (path.endsWith("/api/net") || path === "/api/net") {
        return handleNet(request);
      }
      if (path.endsWith("/api/ping") || path === "/api/ping") {
        return json({ ok: true, time: Date.now() });
      }

      // gate panel
      const pass = kv ? (await kv.get(PASS_KEY)) || "" : "";
      if (pass) {
        const ok = await authed(request, pass);
        if (!ok) {
          const accept = (request.headers.get("Accept") || "").toLowerCase();
          const ua = (request.headers.get("User-Agent") || "").toLowerCase();
          const isBrowser = /mozilla|chrome|safari|firefox|edg/i.test(ua);
          if (isBrowser || accept.includes("text/html")) {
            return new Response(loginHtml("", "/login"), {
              status: 401,
              headers: { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store" }
            });
          }
        }
      }

      return new Response(panelHtml(), {
        headers: { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store" }
      });
    } catch (e) {
      return json({ ok: false, error: String(e && e.message || e) }, 500);
    }
  }
};

function json(obj, status = 200) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: { "Content-Type": "application/json; charset=utf-8" }
  });
}

async function hashPass(p) {
  const data = new TextEncoder().encode("cfapex:" + String(p));
  const buf = await crypto.subtle.digest("SHA-256", data);
  return [...new Uint8Array(buf)].map(b => b.toString(16).padStart(2, "0")).join("");
}

function readSid(req) {
  const c = req.headers.get("Cookie") || "";
  const m = c.match(/(?:^|;\s*)cfapex_sid=([^;]*)/);
  return m ? decodeURIComponent(m[1].trim()) : "";
}

async function authed(req, pass) {
  if (!pass) return true;
  const sid = readSid(req);
  if (!sid) return false;
  return sid === (await hashPass(pass));
}

function cookieHeader(sid, maxAge = 604800) {
  return `cfapex_sid=${encodeURIComponent(sid)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAge}`;
}

async function appendLog(env, entry) {
  const kv = env && env.K;
  if (!kv) return;
  let arr = [];
  try { arr = JSON.parse(await kv.get(LOG_KEY) || "[]"); } catch { arr = []; }
  if (!Array.isArray(arr)) arr = [];
  arr.unshift(entry);
  while (arr.length > 300) arr.pop();
  await kv.put(LOG_KEY, JSON.stringify(arr));
}

async function handleLogs(request, env) {
  const kv = env && env.K;
  const pass = kv ? (await kv.get(PASS_KEY)) || "" : "";
  if (pass && !(await authed(request, pass))) return json({ ok: false, error: "unauthorized" }, 401);

  if (request.method === "GET") {
    let arr = [];
    if (kv) {
      try { arr = JSON.parse(await kv.get(LOG_KEY) || "[]"); } catch { arr = []; }
    }
    if (!Array.isArray(arr)) arr = [];
    return json({ ok: true, logs: arr, storage: kv ? "kv" : "none" });
  }
  if (request.method === "POST") {
    let body = {};
    try { body = await request.json(); } catch { return json({ ok: false, error: "bad_body" }, 400); }
    if (body.action === "clear") {
      if (kv) await kv.put(LOG_KEY, "[]");
      return json({ ok: true, logs: [] });
    }
    const entry = {
      t: Date.now(),
      type: body.type || "操作",
      detail: body.detail || "",
      IP: request.headers.get("CF-Connecting-IP") || "",
      CC: request.cf ? `${request.cf.country || ""} ${request.cf.city || ""}`.trim() : "",
      ASN: request.cf ? (`AS${request.cf.asn || ""} ${request.cf.asOrganization || ""}`).trim() : "",
      URL: body.URL || request.url,
      UA: body.UA || request.headers.get("User-Agent") || ""
    };
    await appendLog(env, entry);
    return json({ ok: true, storage: kv ? "kv" : "none" });
  }
  return json({ ok: false, error: "method" }, 405);
}

async function handlePanelPass(request, env) {
  const kv = env && env.K;
  const pass = kv ? (await kv.get(PASS_KEY)) || "" : "";
  if (request.method === "GET") {
    return json({ ok: true, set: !!pass, storage: kv ? "kv" : "none" });
  }
  if (request.method === "POST") {
    if (!kv) return json({ ok: false, error: "no_kv" });
    let body = {};
    try { body = await request.json(); } catch { return json({ ok: false, error: "bad_body" }, 400); }
    if (body.action === "clear") {
      if (pass && String(body.oldPassword || "") !== pass) return json({ ok: false, error: "bad_old" }, 403);
      await kv.delete(PASS_KEY);
      return new Response(JSON.stringify({ ok: true, set: false }), {
        headers: { "Content-Type": "application/json; charset=utf-8", "Set-Cookie": cookieHeader("", 0) }
      });
    }
    const np = String(body.password || "").trim();
    if (np.length < 4) return json({ ok: false, error: "too_short" }, 400);
    if (pass && String(body.oldPassword || "") !== pass) return json({ ok: false, error: "bad_old" }, 403);
    await kv.put(PASS_KEY, np);
    const sid = await hashPass(np);
    await appendLog(env, {
      t: Date.now(), type: "修改面板密码", detail: "已写入 KV",
      IP: request.headers.get("CF-Connecting-IP") || "",
      CC: request.cf ? `${request.cf.country || ""}`.trim() : "",
      ASN: request.cf ? (`AS${request.cf.asn || ""}`).trim() : "",
      URL: request.url, UA: request.headers.get("User-Agent") || ""
    });
    return new Response(JSON.stringify({ ok: true, set: true }), {
      headers: { "Content-Type": "application/json; charset=utf-8", "Set-Cookie": cookieHeader(sid) }
    });
  }
  return json({ ok: false, error: "method" }, 405);
}

async function handleLogin(request, env, url, path) {
  const kv = env && env.K;
  if (request.method === "GET") {
    return new Response(loginHtml("", path + (url.search || "")), {
      headers: { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store" }
    });
  }
  if (request.method === "POST") {
    let pw = "";
    const ct = (request.headers.get("Content-Type") || "").toLowerCase();
    if (ct.includes("json")) {
      try { const b = await request.json(); pw = b.password || ""; } catch {}
    } else {
      try { const fd = await request.formData(); pw = fd.get("password") || ""; } catch {}
    }
    const real = kv ? (await kv.get(PASS_KEY)) || "" : "";
    if (!real) {
      return new Response(loginHtml("尚未设置密码（需绑定 KV 变量 K）", path), {
        status: 200, headers: { "Content-Type": "text/html; charset=utf-8" }
      });
    }
    if (String(pw) !== real) {
      return new Response(loginHtml("密码错误", path), {
        status: 401, headers: { "Content-Type": "text/html; charset=utf-8" }
      });
    }
    await appendLog(env, {
      t: Date.now(), type: "登录后台", detail: "登录成功",
      IP: request.headers.get("CF-Connecting-IP") || "",
      CC: request.cf ? `${request.cf.country || ""} ${request.cf.city || ""}`.trim() : "",
      ASN: request.cf ? (`AS${request.cf.asn || ""} ${request.cf.asOrganization || ""}`).trim() : "",
      URL: request.url, UA: request.headers.get("User-Agent") || ""
    });
    const sid = await hashPass(real);
    return new Response(null, {
      status: 302,
      headers: { Location: "/", "Set-Cookie": cookieHeader(sid) }
    });
  }
  return json({ ok: false }, 405);
}

function handleNet(request) {
  const cf = request.cf || {};
  return json({
    ok: true,
    ip: request.headers.get("CF-Connecting-IP") || "",
    country: cf.country || "",
    city: cf.city || "",
    region: cf.region || "",
    colo: cf.colo || "",
    asn: cf.asn || "",
    asOrganization: cf.asOrganization || "",
    timezone: cf.timezone || "",
    httpProtocol: cf.httpProtocol || "",
    tlsVersion: cf.tlsVersion || "",
    ua: request.headers.get("User-Agent") || ""
  });
}

async function handleUsage(request, env, url, path) {
  // Simplified: show env-based notice; real CF GraphQL needs credentials
  const wantsJson = url.searchParams.get("format") === "json" || path.endsWith("getCloudflareUsage")
    || (request.headers.get("Accept") || "").includes("application/json");
  const data = {
    success: false,
    msg: "请在 Cloudflare 仪表盘查看 Workers/Pages 用量；本精简版不内置账号凭证抓取。",
    total: 0, max: 100000, percent: 0
  };
  if (wantsJson) return json(data);
  const html = `<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>用量</title><style>body{font-family:system-ui;padding:24px;background:#0f172a;color:#e2e8f0}a{color:#38bdf8}</style></head>
<body><h1>Workers/Pages 请求使用情况</h1>
<p>${data.msg}</p>
<p><a href="/">返回面板</a></p></body></html>`;
  return new Response(html, { headers: { "Content-Type": "text/html; charset=utf-8" } });
}

function loginHtml(err, action) {
  const msg = err ? `<div style="color:#f87171;margin:0 0 12px">${err}</div>` : "";
  return `<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>登录 · CFLYHL Lite</title>
<style>
body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;font-family:system-ui;background:#0f172a;color:#e2e8f0}
.card{width:min(380px,92vw);padding:28px;border-radius:16px;background:#1e293b;border:1px solid #334155}
h1{margin:0 0 16px;font-size:20px;text-align:center}
label{display:block;margin:0 0 6px;font-size:13px}
input{width:100%;box-sizing:border-box;padding:10px;border-radius:8px;border:1px solid #475569;background:#0f172a;color:#e2e8f0}
button{margin-top:14px;width:100%;padding:10px;border:0;border-radius:999px;background:linear-gradient(90deg,#f59e0b,#ef4444,#8b5cf6);color:#fff;font-weight:700;cursor:pointer}
</style></head><body><div class="card"><h1>CFLYHL Lite 登录</h1>${msg}
<form method="POST" action="${action || "/login"}"><label>密码</label>
<input name="password" type="password" required autofocus placeholder="请输入管理密码">
<button type="submit">登录</button></form></div></body></html>`;
}

function panelHtml() {
  return `<!DOCTYPE html>
<html lang="zh-CN" data-theme="light">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>CFLYHL Lite</title>
<style>
:root{--bg:#e9edf4;--card:#fdfefe;--tx:#1c2440;--mut:#626d86;--line:#d6dce9;--soft:#edf0f8}
html[data-theme=dark]{--bg:#151a2d;--card:#222940;--tx:#edf0fc;--mut:#a4adc8;--line:#39415e;--soft:#2d3550}
*{box-sizing:border-box}
body{margin:0;font:14px/1.55 system-ui,"PingFang SC","Microsoft YaHei",sans-serif;background:var(--bg);color:var(--tx)}
header{display:flex;align-items:center;gap:12px;padding:14px 20px;background:#202844;color:#93c5fd;position:sticky;top:0;z-index:10}
header h1{margin:0;font-size:18px}
.themes{margin-left:auto}
button{font:inherit;border:1px solid var(--line);background:var(--soft);color:var(--tx);border-radius:999px;padding:8px 14px;cursor:pointer;font-weight:600}
.tabs{display:flex;gap:8px;flex-wrap:wrap;padding:12px 20px}
.tab.on{outline:2px solid #3d55bd}
main{padding:0 20px 32px;max-width:1100px;margin:0 auto}
.panel{display:none}
.panel.on{display:block}
.box{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:16px;margin-bottom:14px}
.box h2{margin:0 0 10px;font-size:16px}
.hint{color:var(--mut);font-size:12px}
.field{width:100%;padding:10px;border-radius:8px;border:1px solid var(--line);background:var(--soft);color:var(--tx);margin:6px 0}
.row{display:flex;gap:8px;flex-wrap:wrap;align-items:center}
table{width:100%;border-collapse:collapse;font-size:12px}
th,td{border-bottom:1px solid var(--line);padding:6px 4px;text-align:left;vertical-align:top;word-break:break-word}
th{position:sticky;top:0;background:var(--card)}
.wrap{overflow:auto;max-height:60vh}
.pill{display:inline-block;padding:4px 10px;border-radius:999px;background:var(--soft);margin:2px}
.net-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:10px}
.net-card{background:var(--soft);border-radius:12px;padding:12px}
.net-card b{display:block;margin-bottom:4px}
</style>
</head>
<body>
<header>
  <h1>CFLYHL Lite</h1>
  <span class="hint" style="color:#93c5fd">无代理 · 无订阅</span>
  <div class="themes"><button type="button" id="theme-toggle">🌙</button></div>
</header>
<div class="tabs">
  <button class="tab on" data-t="t-over">概览</button>
  <button class="tab" data-t="t-net">网络信息</button>
  <button class="tab" data-t="t-logs">操作日志</button>
  <button class="tab" data-t="t-settings">设置</button>
  <button class="tab" data-t="t-about">关于</button>
</div>
<main>
  <section class="panel on" id="t-over">
    <div class="box">
      <h2>Workers/Pages 请求使用情况</h2>
      <p class="hint">精简版不内置 Cloudflare 账号抓取。请到仪表盘查看正式用量，或打开用量页。</p>
      <p><a href="/usage">打开用量说明页 →</a></p>
      <div class="row" style="margin-top:10px">
        <span class="pill" id="colo">边缘节点：-</span>
        <span class="pill" id="nowip">当前 IP：-</span>
      </div>
    </div>
  </section>
  <section class="panel" id="t-net">
    <div class="box">
      <h2>网络信息测试</h2>
      <p class="hint">基于 Cloudflare 请求元数据（非代理链路探测）。</p>
      <div class="row" style="margin-bottom:10px"><button type="button" id="net-refresh">刷新</button></div>
      <div class="net-grid" id="net-grid"><div class="hint">加载中…</div></div>
    </div>
  </section>
  <section class="panel" id="t-logs">
    <div class="box">
      <h2>操作日志</h2>
      <div class="row" style="margin-bottom:10px">
        <button type="button" id="log-refresh">刷新</button>
        <button type="button" id="log-clear">清空</button>
        <span class="hint" id="log-stat"></span>
      </div>
      <div class="wrap">
        <table>
          <thead><tr><th>时间</th><th>类型</th><th>详情</th><th>IP/地区</th><th>UA</th><th>ASN</th><th>URL</th></tr></thead>
          <tbody id="log-body"><tr><td colspan="7">暂无记录</td></tr></tbody>
        </table>
      </div>
    </div>
  </section>
  <section class="panel" id="t-settings">
    <div class="box">
      <h2>面板登录密码</h2>
      <div class="hint" id="pass-stat">加载中…</div>
      <label>当前密码（已设置时必填）</label>
      <input class="field" type="password" id="pass-old" placeholder="首次可留空">
      <label>新密码</label>
      <input class="field" type="password" id="pass-new" placeholder="至少 4 位">
      <label>确认新密码</label>
      <input class="field" type="password" id="pass-new2" placeholder="再输入一次">
      <div class="row" style="margin-top:10px">
        <button type="button" id="pass-save">保存</button>
        <button type="button" id="pass-clear">清除</button>
      </div>
      <p class="hint">密码写入 KV（绑定变量名 K）。设置后访问面板需登录。</p>
    </div>
  </section>
  <section class="panel" id="t-about">
    <div class="box">
      <h2>关于</h2>
      <p><b>CFLYHL Lite</b></p>
      <p class="hint">本版本已移除代理、订阅、节点、优选 IP 等核心能力，仅保留用量入口、网络信息、操作日志、密码与关于，便于在限制环境中部署验证。</p>
    </div>
  </section>
</main>
<script>
(function(){
  function $(id){ return document.getElementById(id); }
  function api(sub, opt){
    return fetch("/api/" + sub, opt || {}).then(function(r){ return r.json(); });
  }
  document.querySelectorAll(".tab").forEach(function(b){
    b.addEventListener("click", function(){
      document.querySelectorAll(".tab").forEach(function(x){ x.classList.remove("on"); });
      document.querySelectorAll(".panel").forEach(function(x){ x.classList.remove("on"); });
      b.classList.add("on");
      var t = b.getAttribute("data-t");
      $(t).classList.add("on");
      if (t === "t-logs") loadLogs();
      if (t === "t-net") loadNet();
      if (t === "t-settings") loadPass();
    });
  });
  var btn = $("theme-toggle");
  function cur(){ return document.documentElement.getAttribute("data-theme") === "dark" ? "dark" : "light"; }
  function sync(){ if (btn) btn.textContent = cur() === "dark" ? "☀️" : "🌙"; }
  if (btn) btn.addEventListener("click", function(){
    var v = cur() === "dark" ? "light" : "dark";
    document.documentElement.setAttribute("data-theme", v);
    try { localStorage.setItem("pth", v); } catch(e) {}
    sync();
  });
  try { var p = localStorage.getItem("pth"); if (p === "dark" || p === "light") document.documentElement.setAttribute("data-theme", p); } catch(e) {}
  sync();

  function loadNet(){
    api("net").then(function(d){
      if (!d || !d.ok) { $("net-grid").innerHTML = "<div class=hint>读取失败</div>"; return; }
      $("colo").textContent = "边缘节点：" + (d.colo || "-");
      $("nowip").textContent = "当前 IP：" + (d.ip || "-");
      var rows = [
        ["客户端 IP", d.ip],
        ["国家/城市", (d.country||"") + " " + (d.city||"")],
        ["地区", d.region||"-"],
        ["ASN", "AS" + (d.asn||"") + " " + (d.asOrganization||"")],
        ["Colo", d.colo||"-"],
        ["协议", (d.httpProtocol||"") + " / " + (d.tlsVersion||"")],
        ["时区", d.timezone||"-"],
        ["UA", d.ua||"-"]
      ];
      $("net-grid").innerHTML = rows.map(function(r){
        return '<div class="net-card"><b>'+r[0]+'</b><span>'+ (r[1]||"-") +'</span></div>';
      }).join("");
    }).catch(function(){ $("net-grid").innerHTML = "<div class=hint>读取失败</div>"; });
  }

  function loadLogs(){
    api("logs").then(function(d){
      var arr = (d && d.logs) || [];
      $("log-stat").textContent = "共 " + arr.length + " 条 · " + ((d && d.storage) || "");
      var tb = $("log-body");
      tb.textContent = "";
      if (!arr.length) {
        tb.innerHTML = '<tr><td colspan="7">暂无记录</td></tr>';
        return;
      }
      arr.forEach(function(item){
        var tr = document.createElement("tr");
        function c(v){ var td=document.createElement("td"); td.textContent=v||""; return td; }
        var dt = new Date(item.t);
        tr.appendChild(c(dt.toLocaleString("zh-CN", {hour12:false})));
        tr.appendChild(c(item.type));
        tr.appendChild(c(item.detail));
        tr.appendChild(c((item.IP||"") + (item.CC ? " " + item.CC : "")));
        tr.appendChild(c(item.UA));
        tr.appendChild(c(item.ASN));
        tr.appendChild(c(item.URL));
        tb.appendChild(tr);
      });
    });
  }
  $("log-refresh").onclick = loadLogs;
  $("log-clear").onclick = function(){
    api("logs", { method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify({action:"clear"}) })
      .then(loadLogs);
  };
  $("net-refresh").onclick = loadNet;

  function loadPass(){
    api("panel-pass").then(function(d){
      if (!d || !d.ok) { $("pass-stat").textContent = "无法读取"; return; }
      if (d.storage === "none") $("pass-stat").textContent = "未绑定 K，无法写入 KV";
      else if (d.set) $("pass-stat").textContent = "已设置面板登录密码";
      else $("pass-stat").textContent = "未设置密码（无需登录）";
    });
  }
  $("pass-save").onclick = function(){
    var o = $("pass-old").value || "";
    var n = $("pass-new").value || "";
    var n2 = $("pass-new2").value || "";
    if (n.length < 4) { $("pass-stat").textContent = "新密码至少 4 位"; return; }
    if (n !== n2) { $("pass-stat").textContent = "两次新密码不一致"; return; }
    api("panel-pass", { method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify({ password:n, oldPassword:o }) })
      .then(function(d){
        if (!d || !d.ok) { $("pass-stat").textContent = "失败：" + ((d && d.error) || ""); return; }
        $("pass-stat").textContent = "已保存";
        $("pass-old").value = $("pass-new").value = $("pass-new2").value = "";
      });
  };
  $("pass-clear").onclick = function(){
    var o = $("pass-old").value || "";
    api("panel-pass", { method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify({ action:"clear", oldPassword:o }) })
      .then(function(d){
        if (!d || !d.ok) { $("pass-stat").textContent = "清除失败：" + ((d && d.error) || ""); return; }
        $("pass-stat").textContent = "已清除密码";
      });
  };

  loadNet();
  loadPass();
})();
</script>
</body>
</html>`;
}
